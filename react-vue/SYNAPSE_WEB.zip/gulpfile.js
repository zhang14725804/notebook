﻿var gulp = require("gulp");
var fs = require("fs");
var browserSync = require("browser-sync").create();

gulp.task("server", function () {
    browserSync.init({
        server: "./dist"
    });
});

//生成enum.js
gulp.task("enum", function () {
    var input = "./src/constants/enum_d.js";
    var output = "./src/constants/enum.js";
    var text = fs.readFileSync(input, "utf-8");

    var enumGroup = {};
    var enumCnGroup = {};
    //匹配分组
    text.replace(/\/\/(.+)[\d\D]+?(?:const)\s*(\w+)\s*=\s*(\{[\d\D]+?\})/g, function (word, $1, $2, $3) {
        var doc = $1;//枚举注释
        var key = $2;//枚举名
        var itemObj = $3;//枚举项

        enumGroup[key] = {};
        enumCnGroup[key] = {};
        itemObj.replace(/\/\/(.+)[\d\D]+?(\w+)\s*:\s*"?([-\w]+)"?/g, function (word, $1, $2, $3) {
            var item_doc = $1;
            var item_key = $2;
            var item_val = $3;
            enumGroup[key][item_key] = isNaN(Number(item_val)) ? item_val : Number(item_val);
            enumGroup[key][item_val] = item_key;

            enumCnGroup[key][item_doc] = isNaN(Number(item_val)) ? item_val : Number(item_val);
            enumCnGroup[key][item_val] = item_doc;
        });
    });
    fs.writeFileSync(output, `
        export const Enum = ${JSON.stringify(enumGroup)};
        export const EnumCn = ${JSON.stringify(enumCnGroup)};
    `);
});

// 自定义配置URL
gulp.task("hostAndPort", function () {
    var args = process.argv;
    var host = '10.90.0.10';
    var port = 80;
    if (args && args.length >= 5) {
        host = args[3] ? args[3].slice(1) : '10.90.0.10';
        port = !isNaN(Number(args[4])) ? Number(args[4]) * (-1) : 80;
    };
    var input = "./src/utils/tools.js";
    var output = "./src/utils/tools.js";
    var text = fs.readFileSync(input, "utf-8");

    var tempText = ''
    var resText = '';

    var hostExp = /<%=((?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,6})>/g;
    var ipExp = /<%=((?:[0-9]{1,3}\.){3}[0-9]{1,3})>/g;

    if(text.search(hostExp) > -1){
      // 域名
      tempText = text.replace(hostExp, "<%=" + host + ">");
    } else if(text.search(ipExp) > -1){
      // IP 地址
      tempText = text.replace(ipExp, "<%=" + host + ">");
    }
    // tempText = text.replace(/<%=([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,6}>|<%=(?:[0-9]{1,3}\.){3}[0-9]{1,3}>/, "<%=" + host + ">");
    resText = tempText.replace(/<%=\d+>/g, "<%=" + port + ">")
    fs.writeFileSync(output, resText);
});

gulp.task("demoUrl", function () {
    var args = process.argv;
    var type = 'dev';
    if (args && args.length >= 4) {
        type = args[3] ? args[3].slice(1) : 'dev';
    };
    var input = "./src/utils/tools.js";
    var output = "./src/utils/tools.js";
    var text = fs.readFileSync(input, "utf-8");
    fs.writeFileSync(output, text.replace(/<%=([A-Za-z]+)>/, "<%=" + type + ">"));
});
