/**
 * 日期处理
 */
window.hDate = function (d) {
    if (typeof d === "string") {
        var [match, year, month, day, hour, minute, second] = d.match(/(\d+)-(\d+)-(\d+)\s*(\d+):(\d+):(\d+)/);
        d = new Date(Number(year), Number(month) - 1, Number(day), Number(hour), Number(minute), Number(second));
    }
    return !!d ? new Date(d) : new Date();
}

/**
 * 格式化日期
 */
Date.prototype.format = function (fmt) {
    const o = {
        "M+": this.getMonth() + 1, //月份 
        "d+": this.getDate(), //日 
        "h+": this.getHours(), //小时 
        "m+": this.getMinutes(), //分 
        "s+": this.getSeconds(), //秒 
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
        "S": this.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}

/**
 * 获取零时时间
 */
Date.prototype.zeroTime = function () {
    let dt = new hDate(this);
    dt = new hDate(dt.setHours(0, 0, 0, 0));
    return dt;
}

Date.prototype.rangeTime = function (skip) {
    let dt = new hDate(this);      
    dt = new hDate(dt.setHours(0, 0, 0, 0)).getTime()+(parseInt(skip)||0);
    return dt;
}
         