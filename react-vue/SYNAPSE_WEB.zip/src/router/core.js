import $ from "jquery"
import {tools} from "utils"



// export let componentCb = {};


// export function getComponent() {
//     const args = Array.prototype.slice.apply(arguments);
//     let [url, next, cb] = ["", {}, null];
//     if (args.length === 3) {
//         url = args[0]; next = args[1]; cb = args[2];
//     } else if (args.length === 2) {
//         next = args[0]; cb = args[1];
//     } else {
//         console.warn("[getComponent] error args")
//     }

//     const key = next.location.pathname;
//     componentCb[key] = function (nextState, callback) {
//         require.ensure([], require => {
//             callback(null, require("../views" + (url || nextState.location.pathname) + ".js").default)
//         });
//     }
//     return componentCb[key](next, cb);
// }


// export function getChildRoutes() { }



export function getRoute(cfg) {
    let _cfg = $.extend(true, {}, {
        // default


        
    }, cfg);
    

    //onEnter
    _cfg.onEnter = function () {
        if (typeof _cfg.getComponent === "function") {
            tools.showLoading();
        }
        if (typeof cfg.onEnter === "function") {
            cfg.onEnter.apply(this, Array.prototype.slice.call(arguments));
        }
    }

    //onLeave
    _cfg.onLeave = function () {
        if (typeof cfg.onLeave === "function") {
            cfg.onLeave.apply(this, Array.prototype.slice.call(arguments));
        }
    }

    return _cfg;

}