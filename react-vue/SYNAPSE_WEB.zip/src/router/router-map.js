export default {
    //概要
    "/": {},
    "/overview": {},
    //产品
    "/product/list": {
    },
    "/product/detail": {
        query: {
            productId: {
                require: true,
                name: "产品ID"
            }
        }
    },
    "/product/edit": {
        query: {
            taId: {
                require: false,
                name: "产品ID"
            }
        }
    },
    //治疗领域
    "/ta/list": {

    },
    "/ta/detail": {
        query: {
            taId: {
                require: true,
                name: "治疗领域ID"
            }
        }
    },
    "/ta/edit": {
        query: {
            keypointId: {
                require: false,
                name: "治疗领域ID"
            }
        }
    },
    //信息点
    "/keypoint/list": {
    },
    "/keypoint/edit": {
        query: {
            keyword_id: {
                name: "信息点ID"
            }
        }
    },
    "/keypoint/detail": {
        query: {
            keyword_id: {
                require: true,
                name: "信息点ID"
            }
        }
    },
    //图文
    "/news/list": {
    },
    "/news/edit": {
        query: {
            newsId: {
                require: false,
                name: "图文ID"
            }
        }
    },
    "/news/detail": {
        query: {
            newsId: {
                require: true,
                name: "图文ID"
            }
        }
    },
    //问卷调查
    "/qa/list": {
    },
    "/qa/edit": {
        query: {
            qaId: {
                require: false,
                name: "问卷ID"
            }
        }
    },
    "/qa/detail": {
        query: {
            qaId: {
                require: true,
                name: "问卷ID"
            }
        }
    },
    //直通车
    "/express/list": {
    },
    "/express/edit": {
        query: {
            expressId: {
                require: false,
                name: "直通车ID"
            }
        }
    },
    "/express/detail": {
        query: {
            expressId: {
                require: true,
                name: "直通车ID"
            }
        }
    },
    "/express/test": {
    },
    //权限
    "/root/list": {
    },
    "/root/edit": {
        query: {
            group_id: {
                require: false,
                name: "用户组Id"
            }
        }
    },
    "/root/detail": {
        query: {
            group_id: {
                require: true,
                name: "用户组Id"
            }
        }
    },
    "/root/recharge": {
        query: {
            userId: {
                require: false,
                name: "用户Id"
            }
        }
    },
    //视频
    "/video/list": {
    },
    //视频-点播
    // "/vod/detail": {
    //     query: {
    //         vodId: {
    //             require: true,
    //             name: "点播ID"
    //         }
    //     }
    // },
    // "/vod/edit": {
    //     query: {
    //         vodId: {
    //             require: false,
    //             name: "点播ID"
    //         }
    //     }
    // },
    //视频-直播
    "/vol/detail": {
        query: {
            volId: {
                require: true,
                name: "直播ID"
            }
        }
    },
    "/vol/edit": {
        query: {
            volId: {
                require: false,
                name: "直播ID"
            }
        }
    },
    //账户审核
    "/admin/list": {
    },
    //error
    "/error": {
    },
    //测试
    "/testing/charge": {

    }
}
