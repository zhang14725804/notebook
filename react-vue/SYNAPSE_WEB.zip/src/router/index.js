import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import {Router, Route, IndexRoute, hashHistory, withRouter} from "react-router"
import {syncHistoryWithStore, routerReducer} from 'react-router-redux'
import {routerMap, tools} from "../utils"
import {getRoute} from "./core"


export default class AppRouter extends React.Component {
    render() {
        const rootPath = "../views";
        const rootRoute = {
            path: "/",
            getComponent: (nextState, cb) => {
                require.ensure([], require => {
                    cb(null, require("../views/layout.js").default)
                })
            },
            childRoutes: [
                //概要
                getRoute({
                    path: "overview",
                    getComponent: (nextState, cb) => {
                        require.ensure([], require => {
                            cb(null, require("../views/overview/overview.js").default)
                        })
                    }
                }),
                //TODO临时chart
                getRoute({
                    path: "chartDemo",
                    getComponent: (nextState, cb) => {
                        require.ensure([], require => {
                            cb(null, require("../views/overview/chartDemo.js").default)
                        })
                    }
                }),
                //产品
                getRoute({
                    path: "product",
                    childRoutes: [
                        getRoute({
                            path: "list",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/product/list.js").default)
                                })
                            }
                        }),
                        getRoute({
                            path: "detail",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/product/detail.js").default)
                                })
                            }
                        }),
                        getRoute({
                            path: "edit",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/product/edit.js").default)
                                })
                            }
                        }),
                    ]
                }),
                //治疗领域
                getRoute({
                    path: "ta",
                    childRoutes: [
                        getRoute({
                            path: "list",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/ta/list.js").default)
                                })
                            }
                        }),
                        getRoute({
                            path: "detail",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/ta/detail.js").default)
                                })
                            }
                        })
                    ]
                }),
                //信息点
                getRoute({
                    path: "keypoint",
                    childRoutes: [
                        getRoute({
                            path: "list",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/keypoint/list.js").default)
                                })
                            }
                        }),
                        getRoute({
                            path: "detail",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/keypoint/detail.js").default)
                                })
                            }
                        }),
                        getRoute({
                            path: "edit",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/keypoint/edit.js").default)
                                })
                            }
                        })
                    ]
                }),
                // 首页卡片
                getRoute({
                    path: "broadcast",
                    getComponent: (nextState, cb) => {
                        require.ensure([], require => {
                            cb(null, require("../views/broadcast/broadcast.js").default)
                        })
                    }
                }),
                // 业务推广tabs
                getRoute({
                    path: "marketBusi",
                    getComponent: (nextState, cb) => {
                        require.ensure([], require => {
                            cb(null, require("../views/marketBusi/index.js").default)
                        })
                    }
                }),

                //营销战役详情
                getRoute({
                    path: "marketCamp",
                    childRoutes: [
                        getRoute({
                            path: "detail",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/marketCampaign/detail.js").default)
                                })
                            }
                        })
                    ]
                }),
                //营销战役编辑
                getRoute({
                    path: "marketCamp",
                    childRoutes: [
                        getRoute({
                            path: "edit",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/marketCampaign/edit.js").default)
                                })
                            }
                        })
                    ]
                }),
                //营销战役-推广详情
                getRoute({
                    path: "marketCamp/extension",
                    childRoutes: [
                        getRoute({
                            path: "detail",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/marketCampaign/extension/detail.js").default)
                                })
                            }
                        })
                    ]
                }),
                //营销战役-新建推广
                getRoute({
                    path: "marketCamp/extension",
                    childRoutes: [
                        getRoute({
                            path: "edit",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/marketCampaign/extension/edit.js").default)
                                })
                            }
                        })
                    ]
                }),
                //营销战役-新建编辑组合推广
                getRoute({
                    path: "marketCamp/groupExtension",
                    childRoutes: [
                        getRoute({
                            path: "edit",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/marketCampaign/groupExtension/edit.js").default)
                                })
                            }
                        }),
                        //营销战役-组合推广详情
                        getRoute({
                            path: "detail",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/marketCampaign/groupExtension/detail.js").default)
                                })
                            }
                        })
                    ]
                }),

                //文档中心
                getRoute({
                    path: "documentCenter",
                    childRoutes: [
                        getRoute({
                            path: "list",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/documentCenter/list.js").default)
                                })
                            }
                        }),
                        getRoute({
                            path: "edit",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/documentCenter/edit.js").default)
                                })
                            }
                        }),
                        getRoute({
                            path: "detail",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/documentCenter/detail.js").default)
                                })
                            }
                        })
                    ]

                }),
                 //人群管理
                getRoute({
                    path: "peopleManagement",
                    childRoutes: [
                        getRoute({
                            path: "list",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/peopleManagement/list.js").default)
                                })
                            }
                        }),
                        getRoute({
                            path: "edit",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/peopleManagement/edit.js").default)
                                })
                            }
                        })
                    ]

                }),
                // KM管理
                getRoute({
                    path: "KMManagement",
                    childRoutes: [
                        getRoute({
                            path: "detail",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/KMManagement/detail.js").default)
                                })
                            }
                        }),
                        // getRoute({
                        //     path: "edit",
                        //     getComponent: (nextState, cb) => {
                        //         require.ensure([], require => {
                        //             cb(null, require("../views/peopleManagement/edit.js").default)
                        //         })
                        //     }
                        // })
                    ]

                }),
                // 数据洞察卡片
                getRoute({
                    path: "dataInsight",
                    getComponent: (nextState, cb) => {
                        require.ensure([], require => {
                            cb(null, require("../views/dataInsight/index.js").default)
                        })
                    }
                }),
                //数据洞察-状态数据
                getRoute({
                    path: "statusData",
                    childRoutes: [
                        getRoute({
                            path: "commuEffect",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/statusData/contentPage").default)
                                })
                            }
                        })
                    ]
                }),
                //数据洞察-趋势变化
                getRoute({
                    path: "trendChange",
                    childRoutes: [
                        getRoute({
                            path: "commuEffect",
                            getComponent: (nextState, cb) => {
                                require.ensure([], require => {
                                    cb(null, require("../views/trendChange/contentPage").default)
                                })
                            }
                        })
                    ]
                }),
                getRoute({
                    path: "broadEffect",
                    getComponent: (nextState, cb) => {
                        require.ensure([], require => {
                            cb(null, require("../views/trendChange/broadEffect").default)
                        })
                    }
                }),
                getRoute({
                    path: "peopleDistribute",
                    getComponent: (nextState, cb) => {
                        require.ensure([], require => {
                            cb(null, require("../views/trendChange/peopleDistribute").default)
                        })
                    }
                }),
                getRoute({
                    path: "cognizeChange",
                    getComponent: (nextState, cb) => {
                        require.ensure([], require => {
                            cb(null, require("../views/trendChange/cognizeChange").default)
                        })
                    }
                })
            ]
        }

        const {store} = this.props;
        const history = syncHistoryWithStore(hashHistory, store);
        return (
            <Router
                history={history}
                onUpdate={this.onRouterUpload}
                routes={rootRoute}>
            </Router>
        )
    }


    onRouterUpload() {
        window.scrollTo(0, 0);
        tools.hideLoading();
        // let location = this.state.location;
        // let pattern = routerMap[location.pathname];
        // let msgArr = [];
        // if (pattern == null) {
        //     tools.showDialog.error("未设置路由匹配，请查看文件 utils/router-map.js");
        //     return;
        // }
        // //参数校验
        // $.each(pattern.query, (key, val) => {
        //     if (val.require === true && !location.query[key]) {
        //         msgArr.push("缺少参数：" + val.name);
        //     }
        // });
        // if (msgArr.length != 0) {
        //     tools.showDialog.error(msgArr.join("\n"));
        //     // this.history.replace({
        //     //   pathname: "/error"
        //     // })
        // }
    }
}
