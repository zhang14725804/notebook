import {
    Row,
    Col,
    Card,
    Icon,
    DatePicker,
    Button,
    Divider,
    Radio,
    Select,
    Form
} from "antd"
import $ from 'jquery'
import React, { Component } from "react"
import "./index.less"
import moment from "moment"

/*
* 编辑时基础信息bar
* 配置项 mockdata
*/
export default class EditInfo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            mockdata: {
                title: "暂无标题",
                creator: "暂无",
                department: "暂无",
                product: "暂无",
                field: "暂无",
                icon: "tuiguang",
                color: "#2591FC",
                bgColor: '#e6f7ff',
                cancelTxt: "取 消",
                completeTxt: "完 成"
            }
        }
    }

    render() {
        const dataSource = $.extend(true,
            this.state.mockdata,
            this.props.dataSource,
        );
        let iconStyle = {
            width: '32px',
            height: '32px',
            lineHeight: '32px',
            fontSize: '18px',
            color: dataSource.color,
            backgroundColor: dataSource.bgColor,
        }
        return (
            <div className="edit-info" style={{ paddingBottom: "30px" }}>
                <Row style={{ paddingTop: "30px" }}>
                    <Col span={16}>
                        <Icon className="back-icon" style={{ ...iconStyle }} type={dataSource.icon}></Icon>
                        <span className="camp-title">{dataSource.title}</span>
                    </Col>
                    <Col span={8}>
                        <div style={{ float: "right", marginRight: "55px" }}>
                            <Button className="m-margin-r-10" onClick={this.onCancel.bind(this)}>{dataSource.cancelTxt}</Button>
                            <Button type="primary" onClick={this.onComplete.bind(this)}>{dataSource.completeTxt}</Button>
                        </div>
                    </Col>
                </Row>
                <div className="create-info" style={{ marginTop: "15px" }}>
                    <Row>
                        <Col span={5}>创建人：{dataSource.creator}</Col>
                        <Col span={10}>所属部门：{dataSource.department}</Col>
                    </Row>
                    <Row>
                        <Col span={5}>产品名：{dataSource.product}</Col>
                        <Col span={10}>关联领域：{dataSource.field}</Col>
                    </Row>
                </div>
            </div>
        )
    }
    //点击完成
    onComplete() {
        console.log('-- onComplete --', this.props.onComplete)
        if (typeof this.props.onComplete === "function") {
            this.props.onComplete.call(this)
        }
    }
    //点击取消
    onCancel() {
        if (typeof this.props.onCancel === "function") {
            this.props.onCancel.call(this)
        }
    }

}
