import {
    Card,
} from "antd"
import React, {Component} from "react"
import "./index.less"

const {Meta} = Card;
export default class ImgCard extends Component {
    render() {
        let {data}=this.props;
        return (
            <div className="img-card-box">
                <Card
                    cover={<img alt="example"
                                src={data.img}/>}>
                    <Meta description={
                        <div>
                            <span className="img-card-name">{data.name}</span>
                            <span className="img-card-preview"> 预览 </span>
                        </div>
                    }/>
                </Card>
            </div>
        );
    }
}
ImgCard.defaultProps={
    data:{
        img:"https://gw.alipayobjects.com/zos/rmsportal/JiqGstEfoWAOHiTxclqi.png",
        name:"焦点图"
    }
};