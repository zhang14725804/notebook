import {
    Card,
    Icon
} from "antd"
import React ,{Component} from "react"
import "./index.less"
import {ColorEnum} from 'src/constants/customEnum'
import curve from "./images/u31.png"
export default class KMCard extends Component{
    constructor(props){
        super(props);
        this.state={
           color:ColorEnum.colorType[parseInt(Math.random()*4, 10)].color
        }
    }
    render(){
        // let {data}=this.state;
        let {data}=this.props;
        let color=this.state.color
        return(
            <div className="kmcard-box">
                <Card>
                    <div className="km-id"><div className="km-dot" style={{backgroundColor:color}}></div><span>{data.id}</span></div>
                    <div className="km-content">
                        <p className="km-msg">{data.message}</p>
                        <div className="km-link-box"><div className="km-link-bg"><Icon type="msnui-link"/></div><span>{"被引用"+data.link+"次"}</span></div>
                        <img src={curve} className="km-curve"/>
                    </div>
                </Card>
            </div>
        );
    }
}
KMCard.defaultProps={
    data:{
        id:"ID:123123",
        message:"疗效好！见效快",
        link:2
    }
};