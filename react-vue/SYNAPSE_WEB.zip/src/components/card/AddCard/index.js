import {
    Card,
} from "antd"
import React ,{Component} from "react"
import "./index.less"
export default class AddCard extends Component{
    constructor(props){
        super(props);
        this.state={

        }
    }
    render(){
        // let width=this.props.lg?"37.5rem":"24rem";
        let width="100%";
        let padding=this.props.lg?"6.6rem 0rem":"2.4rem"
        return(
            <div style={{width:width,textAlign:"center",cursor:"pointer",padding:"10px"}} onClick={typeof this.props.onClick==="function"?::this.props.onClick:null}>
                <Card style={{borderRadius:".3rem",border:"dashed 1px #cfcfcf",padding:padding,fontSize:".8rem"}}>
                    <span>+</span>
                    <span>添加</span>
                </Card>
            </div>
        );
    }
}