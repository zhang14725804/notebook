import {Card,Tooltip} from "antd"
import React ,{Component} from "react"
import "./index.less"
import {ColorEnum} from 'src/constants/customEnum'
export default class TextCard extends Component{
    constructor(props){
        super(props);
        this.state={
           color:ColorEnum.colorType[parseInt(Math.random()*4, 10)].color
        }
    }
    render(){
        // let {data}=this.state;
        let {data,inModal}=this.props;
        let values=data.values;
        let color=this.state.color;
        console.log(parseInt(Math.random()*4, 10))
        return(
            <div className={inModal&&data.checked?"text-card-box text-card-box-blueBorder":"text-card-box"} onClick={typeof this.props.onClick==="function"?::this.props.onClick:null}>
                <Card>
                    <div className="tcb-name"><div className="tcb-dot" style={{backgroundColor:color}}></div><span>{data.name}</span></div>
                    <div className="tcb-content">
                        <p className="tcb-v-title">{values[0].title}</p>
                        <p className="tcb-v-v-big" style={{color:color}}>{values[0].value}</p>
                        <table className="tcb-table">
                            <tbody>
                            <tr>
                                <td><div className="tcb-v-title">{values[1].title}</div><p className="tcb-v-v"><Tooltip placement="topLeft" title={values[1].value}>{values[1].value}</Tooltip></p></td>
                                <td><div className="tcb-v-title">{values[2].title}</div><p className="tcb-v-v"><Tooltip placement="topLeft" title={values[2].value}>{values[2].value}</Tooltip></p></td>
                            </tr>
                            <tr>
                                <td><div className="tcb-v-title">{values[3].title}</div><p className="tcb-v-v"><Tooltip placement="topLeft" title={values[3].value}>{values[3].value}</Tooltip></p></td>
                                <td><div className="tcb-v-title">{values[4].title}</div><p className="tcb-v-v"><Tooltip placement="topLeft" title={values[4].value}>{values[4].value}</Tooltip></p></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </Card>
            </div>

        )
    }
}
TextCard.defaultProps={
    data:{
        id:"1",
        checked:false,
        name:"华北华中华西地区高级职称医生",
        values:[
            {title:"预计覆盖人数",value:"3129228"},
            {title:"推广区域（3）",value:"华北 华西 华中"},
            {title:"覆盖科室（2）",value:"内科 免疫课"},
            {title:"医院等级（2）",value:"三级甲等 二级甲等"},
            {title:"医生职称（4）",value:"住院医师 主治医师 副主任医师 主任医师"},
        ]
    }
};