import {
    Card,
} from "antd"
import React, {Component} from "react"
import "./index.less"
import Icon from "./images/u1667.png"
const {Meta} = Card;
export default class IconCard extends Component {
    render() {
        let {inEdit,data}=this.props;
        let iconMap={
            1:require("./images/u1667.png"),
            2:require("./images/u1627.png"),
            3:require("./images/u1634.png"),
            4:require("./images/u1641.png"),
        }
        return (
            <div className={inEdit&&data.checked?"icon-card-box icon-card-box-blueBorder":"icon-card-box"} onClick={typeof this.props.onClick==="function"?this.props.onClick:null}>
                <Card className="icon-card"
                    cover={<img className="icon-card-img" alt="example"
                                src={iconMap[data.icon]}/>}>
                    <Meta description={
                        <div className="icon-card-name">
                            <span>{data.name}</span>
                        </div>
                    }/>
                </Card>
            </div>
        );
    }
}
IconCard.defaultProps={
    data:{
        icon:Icon,
        name:"杏仁医生"
    }
};