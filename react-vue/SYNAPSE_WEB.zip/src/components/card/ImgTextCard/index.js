import {
    Card,
} from "antd"
import React, {Component} from "react"
import "./index.less"
import $ from "jquery"
import img from "./images/u1621.png"
export default class ImgTextCard extends Component{
    constructor(props){
        super(props);
        this.state ={

        };
    }
    render(){
        let {data,link,imgs}=this.props;
        // debugger;
        return(
            <div className="img-text-card-box">
                <Card className="img-text-card">
                    <div><img className={data.type==="doc"?"itc-img-doc":"itc-img"} src={imgs[0] instanceof Object ?imgs[0].url:imgs[0]}/></div>
                    <div className="itcb-info" style={{paddingTop:data.type==="img"?"10px":"0px"}}>
                        <p className="itcb-name">{data.name}</p>
                        <p className="itcb-message">{data.message}</p>
                        <p className="itcb-data">{data.date}</p>
                    </div>
                    {
                       link? <div className="itcb-link">
                            <span onClick={typeof this.props.reUpload==="function"?::this.props.reUpload:null}>重新上传</span>
                            <span onClick={typeof this.props.delete==="function"?::this.props.delete:null}>删除</span>
                        </div>:null
                    }
                </Card>
            </div>
        );
    }
}
ImgTextCard.defaultProps={
    data:{
        type:"doc",
        imgs:[img],
        name:"慢性乙型肝炎的抗病毒药物及靶点的研究进展",
        message:"KM: 学术会议是重要的信息来源",
        date:"2017-12-11"
    },
    imgs:[img],
    link:false
};