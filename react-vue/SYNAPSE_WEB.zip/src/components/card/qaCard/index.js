import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import Checkbox from "antd/lib/checkbox"
import Radio from "antd/lib/radio"
import Tag from "antd/lib/tag"
import { Enum, EnumCn } from "enum"
import "./qaCard.less"

export default class QaCard extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        let { type, options } = this.props;
        let optJSX = null;
        const optProps = {
            style: {
                display: "block",
                lineHeight: "32px",
                whiteSpace: 'normal'
            },
            disabled: true
        };
        if (type == Enum.QuestionType.answer) {
            //问答
            optJSX = (<div></div>);
        } else if (type == Enum.QuestionType.radio) {
            //单选
            optJSX = $.map(options, (opt, index) => {
                return <div key={index}><Radio
                    style={{ display: 'inline-block' }}
                    key={opt.id}
                    checked={opt.isRight}
                    {...optProps}></Radio>{` ${String.fromCharCode(64 + Number(index) + 1)}. ${opt.content}`}</div>
            });
        } else if (type == Enum.QuestionType.checkbox) {
            //多选
            optJSX = $.map(options, (opt, index) => {
                return <div key={index}><Checkbox
                    style={{ display: 'inline-block' }}
                    key={opt.id}
                    checked={opt.isRight}
                    {...optProps}></Checkbox>{` ${String.fromCharCode(64 + Number(index) + 1)}. ${opt.content}`}</div>
            });
        }
        return (
            <div className="qa-card" style={{marginTop: '20px'}}>
                <div className="order">第{!isNaN(Number(this.props.order)) ? this.intToChinese(Number(this.props.order) + 1) : ''}题</div>
                <div style={{margin: "15px 0"}}>
                    <Tag color="blue">{EnumCn.QuestionType[type]}</Tag>
                    <Tag color="green">{this.props.score}分</Tag>
                </div>
                <div className="title">{this.props.head}</div>
                <div className="">{optJSX}</div>
            </div>
        );
    }
    intToChinese(str) {
        str = str + '';
        var len = str.length - 1;
        var idxs = ['', '十', '百', '千', '万', '十', '百', '千', '亿', '十', '百', '千', '万', '十', '百', '千', '亿'];
        var num = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
        return str.replace(/([1-9]|0+)/g, function ($, $1, idx, full) {
            var pos = 0;
            if ($1[0] != '0') {
                pos = len - idx;
                if (idx == 0 && $1[0] == 1 && idxs[len - idx] == '十') {
                    return idxs[len - idx];
                }
                return num[$1[0]] + idxs[len - idx];
            } else {
                var left = len - idx;
                var right = len - idx + $1.length;
                if (Math.floor(right / 4) - Math.floor(left / 4) > 0) {
                    pos = left - left % 4;
                }
                if (pos) {
                    return idxs[pos] + num[$1[0]];
                } else if (idx + $1.length >= len) {
                    return '';
                } else {
                    return num[$1[0]]
                }
            }
        });
    }

}

QaCard.defaultProps = {
    // 问题id
    "question_id": "-1",
    // 问题题干
    "head": "hhhhhh",
    // 问题类型 Enum.QuestionType
    "type": 1,
    // 问题序号
    "order": "0",
    // 问题分值
    "score": 123,
    // 选项数组
    "options": [
        {
            // 选项id
            "id": "2",
            // 选项内容
            "content": "123",
            // 是否正确
            "isRight": false
        },
        {
            // 选项id
            "id": "1",
            // 选项内容
            "content": "123",
            // 是否正确
            "isRight": false
        },
    ]
}
