import React ,{Component} from "react"
import _Chart from "../index"
export default class PortraitBar extends Component{
    render(){
        var labelOption = {
            normal: {
                show: true,
                position: 'insideBottom',
                distance: 15,
                align: 'left',
                verticalAlign: 'middle',
                rotate: 90,
                formatter: '{c}  {name|{a}}',
                fontSize: 16,
                rich: {
                    name: {
                        color:'#fff',
                        fontSize:16
                    }
                }
            }
        };
        let cfg= {
            color: ['#883347'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                }
            },
            legend: {
                data: ['单个用户每周平均接收信息']
            },
            calculable: true,
            grid: {
                width:'100%',
                height:'90%',
                top:35,
                left:0,
                containLabel: true
            },
            xAxis: [
                {
                    type: 'category',
                    axisTick: {show: false},
                    data: ['汇总', '医院分级']
                }
            ],
            yAxis: [
                {
                    type: 'value'
                }
            ],
            series: [
                {
                    name: '单个用户每周平均接收信息',
                    type: 'bar',
                    label: labelOption,
                    data: [98, 40]
                }
            ]
        };
        let height=this.props.height||557;
        let padding=this.props.padding||0;
        return(
            <div style={{backgroundColor:"#fff",margin:"1px",padding:padding,boxSizing:"border-box"}}>
                <_Chart {...cfg} height={height-2*padding}/>
            </div>
        );
    }
}