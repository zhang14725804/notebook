import React from "react"
import ReactDOM from "react-dom"
import Immutable from "immutable"
import Chart from "components/chart"
export default class Chart_CalenderHeatmapHor extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        function getVirtulData(year) {
            year = year || '2017';
            var date = +echarts.number.parseDate(year + '-01-01');
            var end = +echarts.number.parseDate((+year + 1) + '-01-01');
            var dayTime = 3600 * 24 * 1000;
            var data = [];
            for (var time = date; time < end; time += dayTime) {
                data.push([
                    echarts.format.formatTime('yyyy-MM-dd', time),
                    Math.floor(Math.random() * 1000)
                ]);
            }
            return data;
        }
        
        //趋势
        let option = {
            tooltip: {
                position: 'top'
            },
            visualMap: {
                min: 0,
                max: 1000,
                calculable: true,
                orient: 'horizontal',
                left: 'center',
                top: 'top'
            },
        
            calendar: [
            {
                range: '2017',
                cellSize: ['auto', 20]
            },
            {
                top: 260,
                range: '2016',
                cellSize: ['auto', 20]
            },
            {
                top: 450,
                range: '2015',
                cellSize: ['auto', 20],
                right: 5
            },{
                top: 640,
                range: '2014',
                cellSize: ['auto', 20],
                right: 5
            }],
        
            series: [{
                type: 'heatmap',
                coordinateSystem: 'calendar',
                calendarIndex: 0,
                data: getVirtulData(2017)
            }, {
                type: 'heatmap',
                coordinateSystem: 'calendar',
                calendarIndex: 1,
                data: getVirtulData(2016)
            }, {
                type: 'heatmap',
                coordinateSystem: 'calendar',
                calendarIndex: 2,
                data: getVirtulData(2015)
            }, {
                type: 'heatmap',
                coordinateSystem: 'calendar',
                calendarIndex: 3,
                data: getVirtulData(2014)
            }]
        
        };
        return (
            <Chart {...option} />
        )
    }
}