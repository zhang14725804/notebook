/**
 *
 * title: index.js
 *
 * author: WangPei.
 *
 * date: 2018/3/18.
 *
 */
import React ,{Component} from "react"
import {
    Card
} from "antd"
import $ from "jquery"
import "./index.less"
export default class ChartBox extends Component{
    constructor(props){
        super(props);
        this.state= $.extend(true, {
            title: "",
        }, props);

    }
    render(){
        return(
            <div className="cus-chart-box">
                <Card className="cus-chart-card" title={this.state.title} bordered={false}>
                    {this.props.children}
                </Card>
            </div>
        );
    }
}