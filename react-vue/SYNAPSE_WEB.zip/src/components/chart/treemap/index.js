import React from "react"
import ReactDOM from "react-dom"
import Immutable from "immutable"
import Chart from "components/chart"
import mockdata from "./mockdata"
export default class Chart_TreeMap extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        var diskData = mockdata;
        function colorMappingChange(value) {
            var levelOption = getLevelOption(value);
            chart.setOption({
                series: [{
                    levels: levelOption
                }]
            });
        }
    
        var formatUtil = echarts.format;
    
        function getLevelOption() {
            return [
                {
                    itemStyle: {
                        normal: {
                            borderWidth: 0,
                            gapWidth: 5
                        }
                    }
                },
                {
                    itemStyle: {
                        normal: {
                            gapWidth: 1
                        }
                    }
                },
                {
                    colorSaturation: [0.35, 0.5],
                    itemStyle: {
                        normal: {
                            gapWidth: 1,
                            borderColorSaturation: 0.6
                        }
                    }
                }
            ];
        }
        //趋势
        let cfg = {
            tooltip: {
                formatter: function (info) {
                    var value = info.value;
                    var treePathInfo = info.treePathInfo;
                    var treePath = [];
    
                    for (var i = 1; i < treePathInfo.length; i++) {
                        treePath.push(treePathInfo[i].name);
                    }
    
                    return [
                        '<div class="tooltip-title">' + formatUtil.encodeHTML(treePath.join('/')) + '</div>',
                        'Disk Usage: ' + formatUtil.addCommas(value) + ' KB',
                    ].join('');
                }
            },
    
            series: [
                {
                    name:'Disk Usage',
                    breadcrumb:{show:false},
                    type:'treemap',
                    visibleMin: 300,
                    width:'95%',
                    height:'95%',
                    label: {
                        show: true,
                        formatter: '{b}'
                    },
                    itemStyle: {
                        normal: {
                            borderColor: '#fff'
                        }
                    },
                    levels: getLevelOption(),
                    data: diskData
                }
            ]
        }
        let height=this.props.height||400;
        return (
            <Chart {...cfg} height={height}/>
        )
    }
}