import React, {Component} from "react"
import "./index.less"
export default class ChartCard extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: {
                title: "总曝光量",
                value: "126,560"
            }
        }
    }

    render() {
        let {data} = this.state;
        return (
            <div className="chart-card-box">
                <div className="c-c-title">{data.title}</div>
                <div className="c-c-value">{data.value}</div>
                <div className="c-c-content">
                    {this.props.content}
                </div>
                <div className="c-c-footer">
                    {this.props.footer}
                </div>
            </div>
        );
    }
}