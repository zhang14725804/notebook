import React from "react"
import ReactDOM from "react-dom"
import Immutable from "immutable"
import Chart from "components/chart"
export default class Chart_WordCloud extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        var keywords = {
            "一线用药": 39000,
            "组织学改善": 37500,
            "中国III期研究": 37500,
            "强效": 40000,
            "0耐药": 40000,
            "RCT安全性": 39000,
            "初治用药": 38000,
            "病毒性应答": 38000,
            "HBV DNA复制": 37500,
            "病毒高载量": 37500,
            "更具成本优势": 38000,
            "病例": 39000,
            "世界III期研究": 37500,
            "耐受性良好": 38000,
            "替诺福韦": 38000,
            "e抗原阳性": 38000,
            "Meta分析": 37500,
            "120/130研究": 37500,
            "e抗原阴性": 38000,
            "": 37000
        };

        var data = [];
        for (var name in keywords) {
            data.push({
                name: name,
                value: Math.sqrt(keywords[name])
            })
        }
        var option = {
            series: [{
                type: 'wordCloud',
                shape: 'diamond',
                sizeRange: [10, 100],
                rotationRange: [-90, 90],
                rotationStep: 90,
                gridSize: 8,
                textStyle: {
                    normal: {
                        color: function () {
                            return 'rgba(' + [
                                Math.round(Math.random() * 255),
                                Math.round(Math.random() * 255),
                                Math.round(Math.random() * 255)
                            ].join(',') + ',0.6)';
                        }
                    }
                },
                data: data.sort(function (a, b) {
                    return b.value - a.value;
                })
            }]
        };
        return (
            <Chart {...option} />
        )
    }
}
