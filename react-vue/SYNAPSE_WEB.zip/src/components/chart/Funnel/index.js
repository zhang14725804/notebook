import React ,{Component} from "react"
import _Chart from "../index"
export default class Funnel extends Component{
    render(){
        let cfg= {
           /* title: {
                text: '漏斗图',
                subtext: '纯属虚构'
            },*/
            tooltip: {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c}%"
            },
           /* toolbox: {
                feature: {
                    dataView: {readOnly: false},
                    restore: {},
                    saveAsImage: {}
                }
            },*/
            /*legend: {
                data: ['展现','点击','访问','咨询','订单']
            },*/
            calculable: true,
            series: [
                {
                    name:'漏斗图',
                    type:'funnel',
                    left:0,
                    top: 0,
                    x2: 80,
                    // bottom: 40,
                    width: '100%',
                    height:'100%',
                    // height: {totalHeight} - y - y2,
                    min: 0,
                    max: 100,
                    minSize: '0%',
                    maxSize: '100%',
                    sort: 'ascending',
                    gap: 2,
                    label: {
                        normal: {
                            show: true,
                            position: 'inside'
                        },
                        emphasis: {
                            textStyle: {
                                fontSize: 20
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            length: 10,
                            lineStyle: {
                                width: 1,
                                type: 'solid'
                            }
                        }
                    },
                    itemStyle: {
                        normal: {
                            borderColor: '#fff',
                            borderWidth: 1
                        }
                    },
                    data: [
                        {value: 60, name: '访问'},
                        {value: 40, name: '咨询'},
                        {value: 20, name: '订单'},
                        {value: 80, name: '点击'},
                        {value: 100, name: '展现'}
                    ]
                }
            ]
        };
        let height=this.props.height||560;
        let padding=this.props.padding||0;
        return(
            <div style={{backgroundColor:"#fff",margin:"1px",padding:padding,boxSizing:"border-box"}}>
                <_Chart {...cfg} height={height-2*padding}/>
            </div>
        );
    }
}