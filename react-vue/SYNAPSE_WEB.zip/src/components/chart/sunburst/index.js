import React, {Component} from "react"
import {
    Row,
    Col,
    Icon
} from "antd"
import ScatterMap from "components/chart/map/ScatterMap"
import RankTable from "components/RankTable"
import ChartCard from "components/chart/ChartCard"
import _Chart from "components/chart"
// import AreaImg from "./images/area.png"
// import BarImg from "./images/bar.png"
// import Bar2Img from "./images/u11493.png"
import "assets/style/views/statusData/commuEffect.less"
import StackBar from "components/chart/StackBar"
import Chart_TreeMap from "components/chart/treemap"
import Funnel from "components/chart/Funnel"
import Chart_RadarBasic from "components/chart/radarBasic"
import TransverseBar from "components/chart/TransverseBar"
import PortraitBar from "components/chart/PortraitBar"

var item1 = {
    color: '#FFB499'
};
var item2 = {
    color: '#FFB499'
};
var item3 = {
    color: '#FFB499'
};
var item4 = {
    color: '#4499ff'
};
var item5 = {
    color: '#d2d2d2'
}

var data = [
    {
        value: 40,
        itemStyle: item4,
        children: [
            {
                value: 12,
                itemStyle: item5,
                children: [
                    {
                        value: 4,
                        itemStyle: item5,
                        children:
                            [
                                {
                                    value: 2,
                                    itemStyle: item5,
                                    children: [
                                        {
                                            value: 1.5,
                                            itemStyle: item5,
                                            children: [
                                                {
                                                    value: 0.5,
                                                    itemStyle: item5
                                                },
                                                {
                                                    value: 1,
                                                    itemStyle: item5
                                                }
                                            ]
                                        },
                                        {
                                            value: 0.5,
                                            itemStyle: item5,
                                            children: [
                                                {
                                                    value: 0.5,
                                                    itemStyle: item5
                                                }
                                            ]
                                        }
                                    ]
                                },
                                {
                                    value: 1,
                                    itemStyle: item5
                                },
                                {
                                    value: 0.4,
                                    itemStyle: item5,
                                    children: [
                                        {
                                            value: 0.1,
                                            itemStyle: item5
                                        },
                                        {
                                            value: 0.1,
                                            itemStyle: item5
                                        },
                                        {
                                            value: 0.1,
                                            itemStyle: item4
                                        },
                                        {
                                            value: 0.1,
                                            itemStyle: item4
                                        }
                                    ]
                                },
                                {
                                    value: 0.3,
                                    itemStyle: item4
                                },
                                {
                                    value: 0.2,
                                    children: [
                                        {
                                            value: 0.1,
                                            itemStyle: item4
                                        },
                                        {
                                            value: 0.1,
                                            itemStyle: item5
                                        }
                                    ]
                                },
                                {
                                    value: 0.1,
                                    children: [
                                        {
                                            value: 0.1,
                                            itemStyle: item4
                                        }
                                    ]
                                }
                            ]
                    },
                    {
                        value: 3,
                    },
                    {
                        value: 2,
                        children: [
                            {
                                value: 1,
                                children: [
                                    {
                                        value: 0.2,
                                        children: [
                                            {
                                                value: 0.1
                                            },
                                            {
                                                value: 0.1
                                            }
                                        ]
                                    },
                                    {
                                        value: 0.4,
                                        children: [
                                            {
                                                value: 0.4
                                            }
                                        ]
                                    },
                                    {
                                        value: 0.6,
                                        children: [
                                            {
                                                value: 0.4
                                            },
                                            {
                                                value: 0.2
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                value: 0.8,
                                children: [
                                    {
                                        value: 0.2
                                    }
                                ]
                            },
                            {
                                value: 0.1,
                                children: [
                                    {
                                        value: 0.1,
                                        children: [
                                            {
                                                value: 0.1
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                value: 0.1,
                                children: [
                                    {
                                        value: 0.1,
                                        children: [
                                            {
                                                value: 0.1
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        value: 2,
                        children: [
                            {
                                value: 0.1,
                                children: [
                                    {
                                        value: 0.1
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        value: 1,
                        children: [
                            {
                                value: 0.1,
                                children: [
                                    {
                                        value: 0.1
                                    }
                                ]
                            }
                        ]
                    }
                ],
            },
            {
                value: 12,
                children:
                    [
                        {
                            value: 16,
                            children: [
                                {
                                    value: 10,
                                    itemStyle: item1,
                                    children: [
                                        {
                                            value: 2,
                                            children: [
                                                {
                                                    value: 1
                                                },
                                                {
                                                    value: 1
                                                }
                                            ]
                                        },
                                        {
                                            value: 4,
                                            children: [
                                                {
                                                    value: 1
                                                },
                                                {
                                                    value: 2
                                                }
                                            ]
                                        },
                                        {
                                            value: 2,
                                            children: [
                                                {
                                                    value: 1
                                                }
                                            ]
                                        }
                                    ]
                                },
                                {
                                    value: 2
                                },
                                {
                                    value: 3,
                                    itemStyle: item2,
                                    children: [
                                        {
                                            value: 1,
                                            children: [
                                                {
                                                    value: 1
                                                }
                                            ]
                                        },
                                        {
                                            value: 1,
                                            children: [
                                                {
                                                    value: 1
                                                }
                                            ]
                                        },
                                        {
                                            value: 1,
                                            children: [
                                                {
                                                    value: 1
                                                }
                                            ]
                                        }
                                    ]
                                },
                                {
                                    value: 1,
                                    children: [
                                        {
                                            value: 0.5,
                                            children: [
                                                {
                                                    value: 0.5
                                                }
                                            ]
                                        },
                                        {
                                            value: 0.5,
                                            children: [
                                                {
                                                    value: 0.4
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ],
                            itemStyle: item3
                        },
                        {
                            value: 3,
                            children:
                                [
                                    {
                                        value: 1
                                    }
                                ],
                            itemStyle: item3
                        },
                        {
                            value: 1,
                            itemStyle: item1,
                            children:
                                [
                                    {
                                        value: 1,
                                        itemStyle: item2
                                    }
                                ]
                        }
                    ],
                itemStyle: item2
            },
            {
                value: 8,
                itemStyle: item4,
                children: [
                    {
                        value: 1
                    },
                    {
                        value: 2
                    },
                    {
                        value: 1
                    }
                ]
            },
            {
                value: 4,
                itemStyle: item4
            },
            {
                value: 2,
                itemStyle: item4,
                children: [
                    {

                        value: 1,
                        itemStyle: item4,
                        children: [
                            {
                                value: 0.5,
                                itemStyle: item4,
                                children: [
                                    {
                                        value: 0.5,
                                        itemStyle: item4,
                                        children: [
                                            {
                                                value: 0.5,
                                                itemStyle: item4
                                            }
                                        ]

                                    }
                                ]
                            }
                        ]
                    },
                    {
                        value: 1,
                        children: [
                            {
                                value: 0.9,
                                itemStyle: item4,
                                children: [
                                    {
                                        value: 0.8,
                                        itemStyle: item4,
                                        children: [
                                            {
                                                value: 0.7,
                                                itemStyle: item4
                                            }
                                        ]

                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                value: 2,
                itemStyle: item4,
                children: [
                    {
                        value: 1,
                        children: [
                            {
                                value: 0.5,
                                itemStyle: item4,
                                children: [
                                    {
                                        value: 0.5,
                                        itemStyle: item4,
                                        children: [
                                            {
                                                value: 0.5,
                                                itemStyle: item4
                                            }
                                        ]

                                    }
                                ]
                            },
                            {
                                value: 0.5,
                                itemStyle: item4,
                                children: [
                                    {
                                        value: 0.5,
                                        itemStyle: item4,
                                        children: [
                                            {
                                                value: 0.5,
                                                itemStyle: item4
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        value: 1,
                        children: [
                            {
                                value: 0.5,
                                itemStyle: item4,
                                children: [
                                    {
                                        value: 0.5,
                                        itemStyle: item4,
                                        children: [
                                            {
                                                value: 0.5,
                                                itemStyle: item4
                                            }
                                        ]

                                    }
                                ]
                            },
                            {
                                value: 0.5,
                                itemStyle: item4,
                                children: [
                                    {
                                        value: 0.5,
                                        itemStyle: item4
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    },
    {
        value: 20,
        itemStyle: item2,
        children: [
            {
                value: 11,
                itemStyle: item1
            },
            {
                value: 5,
                children:
                    [
                        {
                            value: 5,
                            children:
                                [
                                    {
                                        value: 3,
                                        children: [
                                            {
                                                value: 2,
                                                children: [
                                                    {
                                                        value: 1
                                                    },
                                                    {
                                                        value: 0.6
                                                    },
                                                    {
                                                        value: 0.4
                                                    }
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        value: 1,
                                        itemStyle: item2,
                                        children: [
                                            {
                                                value: 0.8,
                                                children: [
                                                    {
                                                        value: 0.6
                                                    }
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        value: 1,
                                        itemStyle: item2,
                                        children: [
                                            {
                                                value: 0.8,
                                                children: [
                                                    {
                                                        value: 0.6
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                ]
                        },
                        {
                            value: 2
                        },
                        {
                            value: 1,
                            children: [
                                {
                                    value: 1,
                                    children: [
                                        {
                                            value: 0.8,
                                            children: [
                                                {
                                                    value: 0.6
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    ],
                itemStyle: item3
            },
            {
                value: 4,
                children: [
                    {
                        value: 2,
                        children: [
                            {
                                value: 2,
                                children: [
                                    {
                                        value: 1
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        value: 1,
                        children: [
                            {
                                value: 0.8,
                                children: [
                                    {
                                        value: 0.6
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        value: 1,
                        children: [
                            {
                                value: 0.8,
                                children: [
                                    {
                                        value: 0.6
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    },
    {
        value: 4,
        children:
            [
                {
                    value: 4,
                    children:
                        [
                            {
                                value: 1,
                                itemStyle: item3,
                                children: [
                                    {
                                        value: 1,
                                        children: [
                                            {
                                                value: 0.8,
                                                children: [
                                                    {
                                                        value: 0.6
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                value: 1,
                                children: [
                                    {
                                        value: 0.6,
                                        children: [
                                            {
                                                value: 0.4,
                                                children: [
                                                    {
                                                        value: 0.1
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                itemStyle: item2
                            },
                            {
                                value: 1,
                                children: [
                                    {
                                        value: 0.6,
                                        children: [
                                            {
                                                value: 0.4,
                                                children: [
                                                    {
                                                        value: 0.1
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                itemStyle: item1
                            },
                            {
                                value: 1,
                                children: [
                                    {
                                        value: 1,
                                        children: [
                                            {
                                                value: 0.5,
                                                children: [
                                                    {
                                                        value: 0.2
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                itemStyle: item1
                            }
                        ],
                    itemStyle: item3
                }
            ],
        itemStyle: item1
    },
    {
        value: 2,
        children: [
            {
                value: 1,
                children: [
                    {
                        value: 0.8,
                        children: [
                            {
                                value: 0.3,
                                children: [
                                    {
                                        value: 0.2
                                    }
                                ]
                            },
                            {
                                value: 0.2
                            },
                            {
                                value: 0.2,
                                children: [
                                    {
                                        value: 0.1
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        value: 0.2,
                        children:[
                            {
                                value:0.2,
                                children:[
                                    {
                                        value:0.1
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                value:1,
                children:[
                    {
                        value:0.8
                    }
                ]
            }
        ]
    }
];


export default class SunburstEffect extends Component {
    constructor(props) {
        super(props);
        this.state = {
            rankTable: [
                {name: "北京市", value: "46976947649"},
                {name: "北京市", value: "46976947649"},
                {name: "北京市", value: "46976947649"},
                {name: "北京市", value: "46976947649"},
                {name: "北京市", value: "46976947649"},
                {name: "北京市", value: "46976947649"},
                {name: "北京市", value: "46976947649"},
                {name: "北京市", value: "46976947649"},
                {name: "北京市", value: "46976947649"},
                {name: "北京市", value: "46976947649"},
                {name: "北京市", value: "46976947649"},
                {name: "北京市", value: "46976947649"},
                {name: "北京市", value: "46976947649"},
                {name: "北京市", value: "46976947649"},
                {name: "北京市", value: "46976947649"},
            ]
        }
    }

    render() {
        var option = {
            title: {
                text: "61.3%",
                left: "center",
                top: "center",
                subtext: "of visits begin with this\n" +
                "sequence of pages",
                subtextStyle:{
                    fontSize:8
                }
            },
            series: {
                radius: ['40%', '100%'],
                type: 'sunburst',
                sort: null,
                highlightPolicy: 'ancestor',
                data: data,
                label: {
                    rotate: 'radial'
                },
                levels: [],
                itemStyle: {
                    color: '#ddd',
                    borderWidth: 2
                }
            }
        };
        let height = this.props.height || 400;
        return <_Chart {...option} height={height}/>
    }
}