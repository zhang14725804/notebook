import React, {Component} from "react"
import _Chart from "../index"
import {Card,DatePicker,Row,Col} from 'antd'
import moment from "moment"
const { MonthPicker, RangePicker, WeekPicker } = DatePicker;
const data = require("src/mockdata/trendData");
const dateFormat = 'YYYY-MM-DD';

export default class TrendChart extends Component {
    render() {
        let type1=this.props.type1;
        let color=this.props.color;
        let cfg = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'line',
                    lineStyle: {
                        color: 'rgba(0,0,0,0.2)',
                        width: 1,
                        type: 'solid'
                    }
                }
            },

            legend: {
                data: type1?[]:['DQ', 'TY', 'SS', 'QG', 'SY', 'DD']
            },

            singleAxis: {
                top: 50,
                bottom: 50,
                axisTick: {},
                axisLabel: {},
                type: 'time',
                axisPointer: {
                    animation: true,
                    label: {
                        show: true
                    }
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: 'dashed',
                        opacity: 0.2
                    }
                }
            },
            color:color||['#D75953'],
            series: [
                {
                    type: 'themeRiver',
                    itemStyle: {
                        emphasis: {
                            shadowBlur: 20,
                            shadowColor: 'rgba(0, 0, 0, 0.8)'
                        }
                    },
                    data:type1?data.trendData2:data.trendData1
                }
            ]
        }

        let title=this.props.title;
        let ifTime=this.props.ifTime;
        return (
            <div>
                <Card title={title}>
                    {
                        ifTime?<Row style={{marginBottom:'20px',fontSize:'14px'}}>
                            时间段：<RangePicker
                            defaultValue={[moment('2018-10-02', dateFormat), moment('2018-10-10', dateFormat)]}/>
                        </Row>:null
                    }
                    <Row>
                        <_Chart {...cfg}/>
                    </Row>
                </Card>
            </div>
        );
    }
}