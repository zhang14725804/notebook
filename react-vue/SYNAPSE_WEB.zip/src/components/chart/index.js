import React from "react"
import ReactDOM from "react-dom"
import Immutable from "immutable"

// 引入 ECharts 主模块
const echarts = require("echarts");
const wordcloud = require("echarts-wordcloud");
const gl = require("echarts-gl");

// // 引入图表库
// require("echarts/lib/chart/line");
// require("echarts/lib/chart/scatter");
require("echarts/map/js/china");
// // 引入提示框和标题组件
// require("echarts/lib/component/legend");
// require("echarts/lib/component/tooltip");
// require("echarts/lib/component/title");
import $ from "jquery"


export default class Chart extends React.Component {
    componentDidMount() {
        echarts.init(ReactDOM.findDOMNode(this)).setOption(this.props);
    }
    componentWillReceiveProps(nextProps) {
        let prevState = this.props//.xAxis.data;
        let nextState = nextProps//.xAxis.data;
        if (!Immutable.fromJS(prevState).equals(Immutable.fromJS(nextProps))) {
            //重新渲染组件
            let chart = echarts.getInstanceByDom(ReactDOM.findDOMNode(this));
            chart.clear();
            chart.setOption(nextProps);
        }
    }
    render() {
        let height = this.props.height || 300;
        // console.log('---- chart props ----', this.props);
        return <div className="chart_line" style={{ width: "100%", height }}></div>
    }
}
