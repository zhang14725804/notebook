import React from "react"
import ReactDOM from "react-dom"
import { tools } from "utils"
import "./wechatPreview.less"
import WechatDemo from "components/demo/wechatDemo"
import Button from "antd/lib/button"
import Modal from "antd/lib/modal"
import Input from "antd/lib/input"
import $ from "jquery"
import Icon from "antd/lib/icon"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
/**
 * dataSource = { //页面所需数据  ==>传到内存组件的datasource属性上
 *          title: String,      //题目
 *          author: String,     //作者
 *          time: Number,       //时间
 *          content_text: String//内容
 *          img:String          //图片
 * }
 * type:String  按钮的样式  比antd多一种text即文字型,默认text
 * toPhone:Function  发送到手机的回调
 * onClick:Function  点击预览按钮的事件
**/
const Img = {
    sheet_info: require("assets/image/sheet_info.png"),
}
export default class WechatPreview extends React.Component {
    constructor(props) {
        super(props);
        this.defValue = {
            dataSource: {
                title: "",
                author: "",
                time: undefined,
                img: require("assets/image/11.png"),
                content_text: "",
            },
            type: "text"
        }
        this.state = {
            visible: false,
            numVisible: false,
            value: "",
            volidate: "",
            currentPage: 1
        }
    }
    componentDidMount() {
    }
    render() {
        let dataSource = $.extend(true,
            this.defValue.dataSource,
            this.props.dataSource,
        );
        let {title, author, time, img, content_text} = dataSource;
        let type = this.props.type || this.defValue.type;
        let {visible, value, numVisible, volidate, currentPage} = this.state;
        return (
            <div className="wechatPreview" >
                {type === "text" ? <span onClick={this.toPreview.bind(this)} className="btn">预览</span> : <Button onClick={this.toPreview.bind(this)} type={type}>预览</Button>}
                {visible && <div className="modalBg">
                    <div className="modal">
                        <div className="wechatDemoBg">
                            <Row className="header">
                                <Col span={8} className="back">
                                    {currentPage === 2 && <div onClick={this.back.bind(this)}>
                                        <Icon type="left" />
                                        <span>返回</span>
                                    </div>}
                                </Col>
                                <Col span={8} className="tit">预览</Col>
                                <Col span={8} className="more"><Icon type="ellipsis" /></Col>
                            </Row>
                            {currentPage === 1 && <div className="p-menu" onClick={this.toDetail.bind(this)}>
                                <div className="cont">
                                    <img className="menuImg" src={img} alt="图片" />
                                    <p className="title">{title}</p>
                                </div>
                            </div>}
                            {currentPage === 2 && <div className="p-content">
                                <h1 className="tit">{title}</h1>
                                <div className="addon">
                                    <span className="textGray">{new hDate(time).format(tools.dateFormat2)}</span>
                                    <span style={{ color: "#027cb1" }}>{author}</span>
                                </div>
                                <div className="cont" dangerouslySetInnerHTML={{ __html: content_text }}></div>
                            </div>}
                        </div>
                    </div>
                    <div className="phone" onClick={this.open.bind(this, "numVisible")}>发送到手机</div>
                    <div className="close" onClick={this.close.bind(this, "visible")}>关闭预览</div>
                    <Modal
                        title="发送预览"
                        visible={numVisible}
                        onOk={this.handleOk.bind(this)}
                        onCancel={this.close.bind(this, "numVisible")}>
                        <div style={{ padding: '20px 40px' }}>
                            <p>关注公众号后，才能接收图文信息预览</p>
                            <br />
                            <Input placeholder="请输入微信号/手机号" value={value} onChange={this.onChange.bind(this)} />
                            {volidate}
                            <br />
                            <p>预览功能仅用于公众号查看文章效果，不适用于公众传播，预览链接会在短时间内失效</p>
                        </div>
                    </Modal>
                </div>}
            </div>
        )
    }
    close(key) {
        const field = {};
        field[key] = false;
        this.setState(field);
        key === "visible" && this.setState({
            currentPage: 1
        })
    }
    open(key) {
        const field = {};
        field[key] = true;
        this.setState(field);
    }
    toPreview() {
        this.open("visible");
        if (typeof this.props.onClick === "function") {
            this.props.onClick.call(this);
        }
    }
    back() {
        this.setState({
            currentPage: 1
        })
    }
    toDetail() {
        this.setState({
            currentPage: 2
        })
    }
    onChange(e) {
        this.setState({
            value: e.target.value,
            volidate: ""
        })
    }
    handleOk() {
        let {value} = this.state;
        if (!value) {
            this.setState({
                volidate: <p className="red">请输入微信号</p>
            })
            return;
        }
        this.setState({
            numVisible: false,
        });
        if (typeof this.props.toPhone === "function") {
            this.props.toPhone.call(this, value);
        }
    }
    toPhone() {
    }

}
