import WechatDemo from "../wechatDemo"
import NewsDemo from "../newsDemo"
import "./choosePlatDemo.less"

const choosePlatDemoEn = {
  //app
  app: 1,
  //微信
  weixin: 2,
}
const choosePlatDemoCn = {
  "1": "应用",
  "2": "微信公众平台"
}

export default class ChoosePlatDemo extends React.Component {
  constructor(props) {
    super(props);
    this.dataSource = [{
      content_type:"1",
      title: "这是题目",
      author: "有趣的蚕宝宝",
      time: 1483276734,
      tag: "段子",
      content_text: "<p>ewrewrewr</p>"
    }, {
      content_type:"2",
      title: "这是题目",
      author: "有趣的蚕宝宝",
      time: 1483276734,
      tag: "段子",
      content_text: "<p>ewrewrewr</p>"
    }]
    this.state = {
      seletedIndex: 0,
      seletedContentType: choosePlatDemoEn.weixin
    }
  }
  componentDidMount() {

  }
  render() {
    // const {dataSource} = this.props;
    const dataSource = $.extend(true,
      this.dataSource,
      this.props.dataSource,
    );
    const {seletedContentType, seletedIndex} = this.state;

    let curData = {
      dataSource: {
        title: dataSource[seletedIndex].title,
        author: dataSource[seletedIndex].author,
        create_time: dataSource[seletedIndex].create_time,
        content_text: dataSource[seletedIndex].content_text,
      },
      bg: dataSource[seletedIndex].bg,
      qrcode: dataSource[seletedIndex].qrcode
    }
    // console.log('-- curData --', curData)

    const curPlatContentStyle = { marginLeft: '120px' }
    return (
      <div>
        {dataSource.length > 1 ? <div className="choose-plat-menu">
          {dataSource.map((item, index) => {
            return (
              <div
                className="choose-plat-menuitem"
                style={{
                  backgroundColor: item.content_type == seletedContentType ? 'rgb(145,194,0)' : '#FFF',
                  color: item.content_type == seletedContentType ? '#FFF' : 'rgb(145,194,0)'
                }}
                onClick={this.onClickMenuItem.bind(this, index, item.content_type)}
                >
                {choosePlatDemoCn[item.content_type]}
              </div>
            )
          })}
        </div> : null}
        <NewsDemo
          style={{
            display: seletedContentType == choosePlatDemoEn.app ? 'block' : 'none',
            marginLeft: dataSource.length > 1 ? '120px' : '0'
          }}
          {...curData}
          />
        <WechatDemo
          style={{
            display: seletedContentType == choosePlatDemoEn.weixin ? 'block' : 'none',
            marginLeft: dataSource.length > 1 ? '120px' : '0'
          }}
          {...curData}
          />
      </div>
    )
  }
  onClickMenuItem(index, content_type) {
    this.setState({ seletedIndex: index })
    this.setState({ seletedContentType: content_type })
  }
}
