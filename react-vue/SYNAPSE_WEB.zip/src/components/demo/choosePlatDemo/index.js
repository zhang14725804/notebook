import WechatDemo from "../wechatDemo"
import NewsDemo from "../newsDemo"
import "./choosePlatDemo.less"

const platformEn = {
    //app
    app: "1",
    //微信
    wechat: "2",

    "1": "app",
    "2": "wechat"
}
const platformCn = {
    "1": "应用",
    "2": "微信公众平台"
}
const appTypeEn = {
    //图文
    news: "1",
    //问卷
    qa: "2",
    //点播
    // vod: "3",
    //直播
    vol: "4",
    //H5
    h5: "5",

    //图文
    "1": "news",
    //问卷
    "2": "qa",
    //点播
    // "3": "vod",
    //直播
    "4": "vol",
    //H5
    "5": "h5",
}
const appTypeCn = {
    //图文
    "图文": "1",
    //问卷
    "问卷": "2",
    //点播
    "点播": "3",
    //直播
    "直播": "4",
    //H5
    "H5": "5",

    //图文
    "1": "图文",
    //问卷
    "2": "问卷",
    //点播
    "3": "点播",
    //直播
    "4": "直播",
    //H5
    "5": "H5",
}

/**
 * dataSource = {
 *    content:Object,
 *    bg:Boolean,
 *    qrcode:String,
 *    type：String,
 *    platform：String
 *  }

 * //内部组件所需数据，该层无需维护，直接传到内层即可
 * content:Object    //页面所需数据  ==>传到内存组件的datasource属性上
 *      title: String,      //题目
 *      author: String,     //作者
 *      time: Number,       //时间
 *      content_text: String//内容
 * bg:Boolean  有没有手机的背景默认有
 * qrcode:String  二维码的url
 *
 * //本层组件所需数据
 * platform：String       //平台        映射见platformEn和platformCn
**/
let data = [{
    platform: "1",
    content: {
        title: "这是题目",
        author: "有趣的蚕宝宝",
        time: 1483276734,
        content_text: "<p>ewrewrewr</p>"
    },
    qrcode: "https://www.baidu.com",
}, {
    platform: "2",
    content: {
        title: "这是题目",
        author: "有趣的蚕宝宝",
        time: 1483276734,
        content_text: "<p>ewrewrewr</p>"
    },
}]

export default class ChoosePlatDemo extends React.Component {
    constructor(props) {
        super(props);
        this.defValue = {
            content: null,
            bg: true,
            qrcode: "",
            platform: "2",
        }
        this.state = {
            curIndex: 0,
        }
    }
    componentDidMount() {

    }
    render() {
        const dataSource = this.props.dataSource || [];
        // const dataSource = this.props.dataSource || data;
        let {curIndex} = this.state;
        let {platform, content, bg, qrcode} = dataSource[curIndex] || this.defValue;
        bg = bg || this.defValue.bg;
        let demoProps = {
            dataSource: content,
            bg: bg,
            qrcode: qrcode
        }
        let contentJSX = "";
        if (platformEn[platform] === "wechat") {
            contentJSX = <WechatDemo {...demoProps} />
        } else if (platformEn[platform] === "app") {
            contentJSX = <NewsDemo {...demoProps} />;
        } else {
            contentJSX = '无此平台';
        }

        return (
            <div className="choosePlatDemo" style={{paddingLeft: '0'}, {...this.props.style}}>
                {dataSource.length > 1 && <div className="choose-plat-menu">
                    {dataSource.map((item, index) => {
                        return (
                            <div
                                className={item.platform == platform ? "choose-plat-menuitem active" : "choose-plat-menuitem"}
                                onClick={this.onClickMenuItem.bind(this, index)} >
                                {platformCn[item.platform]}
                            </div>
                        )
                    })}
                </div>}
                <div className="choose-plat-cont">
                    {contentJSX}
                </div>
            </div>
        )
    }
    onClickMenuItem(index) {
        this.setState({ curIndex: index })
    }
}
