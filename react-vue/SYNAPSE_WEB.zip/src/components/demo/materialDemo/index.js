import React from "react"
import ReactDOM from "react-dom"
import { tools } from "utils"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import { Enum, EnumCn } from "enum";
import "./materialDemo.less"

const platformEn = {
    //微信图文
    wechat: "1",
    //APP信息流
    app1: "2",
    //APP启动屏
    app2: "3",
    //APP焦点图
    app3: "4",

    "1": "wechat",
    "2": "app1",
    "3": "app2",
    "4": "app3"
}
const platformCn = {
    "1": "微信图文",
    "2": "APP信息流",
    "3": "APP启动屏",
    "4": "APP焦点图"
}
const imgMap = {
    sheet_info: require("assets/image/sheet_info.png"),
    sheet_scroll: require("assets/image/sheet_scroll.png"),
    sheet_start: require("assets/image/sheet_start.png"),
    wechat_position: require("assets/image/wechat_position.png"),
    app_position: require("assets/image/app_position.jpg"),
}

export default class MaterialDemo extends React.Component {
  constructor(props) {
      super(props);
      this.defaultValue = {
          platform: [],
          wx_img: "",
          banner_img: "",
          feeds_img: "",
          open_img: "",
          wx_title:""
      }
      this.state = {
          curPlatform: ""
      }
  }
  componentDidMount() {
      const {dataSource} = this.props;
      console.log("dataSource",dataSource);
      let data = $.extend({}, this.defaultValue, dataSource);
      data.platform && data.platform.length>0 && this.setState({curPlatform: data.platform[0]})
  }
  render() {
      const {dataSource} = this.props;
      const {curPlatform} = this.state;
      console.log("curPlatform",curPlatform);
      let data = $.extend({}, this.defaultValue, dataSource);
      let contentJSX = "";
      if (curPlatform == Enum.ProPlatform.weixin) {
          contentJSX = <WechatExhibition {...data} />
      } else if (curPlatform == Enum.ProPlatform.app1) {
          contentJSX = <APP1Exhibition {...data} />;
      } else if (curPlatform == Enum.ProPlatform.app2){
          contentJSX = <APP2Exhibition {...data} />;
      } else if (curPlatform == Enum.ProPlatform.app3){
          contentJSX = <APP3Exhibition {...data} />;
      }else {
          contentJSX = '无此平台';
      }
      return (
          <div className="material-demo">
               <div className="choose-plat-cont">
                 <div className="frame">
                   {contentJSX}
                 </div>
               </div>
               {
                 data.platform.length > 0 && <div className="choose-plat-menu">
                   {data.platform.map((item, index) => {
                       return (
                           <div
                               key={index}
                               className={item == this.state.curPlatform ? "choose-plat-menuitem active" : "choose-plat-menuitem"}
                               onClick={this.onClickMenuItem.bind(this, item)} >
                               {EnumCn.ProPlatform[item]}
                           </div>
                       )
                   })}
                 </div>
               }
          </div>
       )
    }
  onClickMenuItem(index) {
      this.setState({ curPlatform: index })
  }
}

class WechatExhibition extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
        console.log("props",props);
    }
    render() {
        const {wx_img,wx_title} = this.props;
        return (
            <div className="posPreview">
                <img src={imgMap.wechat_position} width={232} alt="微信推广位置展示图" />
                <div className="wechat_preview">
                    {wx_img && <img className="firstPos" src={wx_img} alt="微信推广位置展示图" />}
                    <p className="wechatTit">{wx_title}</p>
                    {wx_img && <img className="otherPos" src={wx_img} alt=" 推广" />}
                </div>
                <div className="txt">
                    <p>* 说明:</p>
                    <p>上图仅做示意，实际投放不会将一条推广信息，同时显示在一个微信公众号，一次图文消息的多个位置，仅展示一个有效位置。</p>
                </div>
            </div>
          )
    }
}

class APP1Exhibition extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }
    render() {
        const {banner_img, feeds_img,wx_title} = this.props;
        return(
            <div className="posPreview">
                <img className="bgimg" src={imgMap.app_position} alt="APP推广位置展示图" />
                { banner_img && <div className="banner_preview">
                    <img src={banner_img} alt="焦点图图片" />
                </div>}
                <div className="feeds_preview">
                    <Row>
                        <Col span={17}>
                            <p className="tit">{wx_title}</p>
                            <p className="des">
                                <span>synapse</span>
                                <span>ideabinder</span>
                            </p>
                        </Col>
                        {feeds_img &&
                            <Col span={6} className="feeds_image">
                                <img src={feeds_img} alt="焦点图图片" />
                            </Col>
                        }
                    </Row>
                </div>
            </div>)
    }
}

class APP2Exhibition extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }
    render() {
        const {open_img} = this.props;
        return(
            <div className="posPreview" style={{height:"385px"}}>
                { open_img && <div className="first_screen__preview">
                    <img src={open_img} alt="焦点图图片" />
                </div>}
            </div>)
    }
}

class APP3Exhibition extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }
    render() {
        const {banner_img, feeds_img,wx_title} = this.props;
        return(
            <div className="posPreview">
                <img className="bgimg" src={imgMap.app_position} alt="APP推广位置展示图" />
                { banner_img && <div className="banner_preview">
                    <img src={banner_img} alt="焦点图图片" />
                </div>}
                <div className="feeds_preview">
                    <Row>
                        <Col span={17}>
                            <p className="tit">{wx_title}</p>
                            <p className="des">
                                <span>synapse</span>
                                <span>ideabinder</span>
                            </p>
                        </Col>
                        {feeds_img &&
                            <Col span={6} className="feeds_image">
                                <img src={feeds_img} alt="焦点图图片" />
                            </Col>
                        }
                    </Row>
                </div>
            </div>)
    }
}