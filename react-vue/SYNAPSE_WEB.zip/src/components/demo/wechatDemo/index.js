import React from "react"
import ReactDOM from "react-dom"
import { tools } from "utils"
import "./wechatDemo.less"
import QRCode from "components/QRCode"

/**
 * bg:Boolean  有没有手机的背景
 * qrcode:String  二维码的url
 * dataSource:Object    //页面所需数据
 *      title: String,      //题目
 *      author: String,     //作者
 *      time: Number,       //时间
 *      content_text: String//内容 
 *
**/

export default class WechatDemo extends React.Component {
    constructor(props) {
        super(props);
        this.dataSource = {
            title: "",
            author: "",
            time: undefined,
            content_text: ""
        }
    }
    componentDidMount() {

    }
    render() {
        const dataSource = $.extend(true,
            this.dataSource,
            this.props.dataSource,
        );
        let {bg, qrcode} = this.props;
        return (
            <div className="wechatDemo" style={this.props.style}>
                <div className={bg ? "wechatDemoBg" : ""}>
                    <section className="p-content">
                        <h1 className="tit">{dataSource.title}</h1>
                        <div className="addon">
                            <span className="textGray">{new hDate().format(tools.dateFormat2)}</span>
                            <span style={{ color: "#027cb1" }}>{dataSource.author}</span>
                        </div>
                        <div className="cont" dangerouslySetInnerHTML={{ __html: dataSource.content_text }}></div>
                    </section>
                    {qrcode && <div className="qrcode">
                        <QRCode value={qrcode} />
                    </div>}
                </div>
            </div>
        )
    }
}
