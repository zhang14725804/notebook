import React from "react"
import ReactDOM from "react-dom"
import { tools } from "utils"
import "./qaDemo.less"

export default class QaDemo extends React.Component {
    constructor(props) {
        super(props);
        this.defValue = {
            dataSource: {
                title: '',
                begin_time: undefined,
                end_time: undefined,
                question: []
            }
        }
    }
    componentDidMount() {
        console.log("问卷组件");
    }
    render() {
        const quesTypeEnum = {
            radio: 1,
            multi: 2,
            answer: 3
        };
        const value = this.props.value || "";
        let dataSource = $.extend({}, this.defValue.dataSource, this.props.dataSource);
        let { title, begin_time, end_time, question } = dataSource;
        if (!dataSource.title) return null;
        var questionJSX = dataSource.question.length >= 1 && dataSource.question.map((item, index) => {
            var headObj = {};
            var optionJSX = "";
            try {
                headObj = JSON.parse(item.head);
                if (item.type == quesTypeEnum.radio || item.type == quesTypeEnum.multi) {
                    optionJSX = headObj.options.map((o, i) => {
                        return (
                            <li className="m-border-t fz-row m-row" key={i}>
                                <div className="ques-option-row">
                                    <h4 className="fz-row-mainTitle">{o.content}</h4>
                                    <div className="ep-content">
                                        <span className="fz-checkbox" onClick={this.radio.bind(this,o)}>
                                            <i className="anticon anticon-tick-ivt fz-checkbox-cb unchecked"></i>
                                        </span>
                                    </div>
                                </div>
                            </li>

                        )
                    })
                }
            } catch (err) {
                console.error('invaild json question')
            }
            return (
                <div key={index} style={{ padding: "20px" }}>
                    <div className="title">
                        <h3>
                            <span className="ques-order">{item.order + 1}</span>
                            <span>{"/" + question.length}</span>
                        </h3>
                        <br />
                        <h3>{headObj.head}{item.score ? `(${item.score}分)` : null}</h3>
                    </div>
                    <div>
                        {(item.type == quesTypeEnum.radio || item.type == quesTypeEnum.multi) &&
                            <ul>
                                {optionJSX}
                            </ul>
                        }
                        {item.type == quesTypeEnum.answer &&
                            <ul>
                                <div>
                                    <div className="m-row">
                                        <textarea style={{ resize: "none" }} placeholder="请作答"></textarea>
                                    </div>
                                </div>
                            </ul>
                        }
                    </div>
                </div>
            )
        })
        return (
            <div id="p-content-qa" style={this.props.style}>
                <div className="p-content">
                    <div id="p-qustDetail">
                        <header className="p-header">
                            <h1>{title}</h1>
                            <h6>调研时间:{!begin_time && !end_time ? tools.emptyInfo : new hDate(begin_time).format("yyyy.MM.dd") + " - " + new hDate(end_time).format("yyyy.MM.dd")}</h6>
                        </header>
                        {questionJSX}
                    </div>
                </div>
            </div>
        )
    }
    radio(item) {
        console.log("item",item);
    }
}
