import React from "react"
import ReactDOM from "react-dom"
import { tools } from "utils"
import "./newsDemo.less"
import QRCode from "components/QRCode"

/**
 * bg:Boolean  有没有手机的背景
 *
 *
 *
**/

export default class NewsDemo extends React.Component {
  constructor(props) {
    super(props);
    this.dataSource = {
      title: "",
      author: "",
      time: "",
      source: "",
      periodical: "",
      release_time: undefined,
      content_text: ""
    }
  }
  componentDidMount() {

  }
  render() {
    const dataSource = $.extend(true,
      this.dataSource,
      this.props.dataSource,
    );
    let {bg, qrcode} = this.props;
    return (
      <div className="newsDemo" style={this.props.style}>
        <div className={bg ? "newsDemoBg" : ""}>
          <section className="p-content">
            <div className="p-infoDetail">
              <title>文献</title>
              <header className="p-header">
                <h1>{dataSource.title}</h1>
                <h6>{dataSource.author}</h6>
                <h6>{new hDate().format("yyyy-MM-dd")}</h6>
              </header>
              <section className='p-ctn' dangerouslySetInnerHTML={{ __html: dataSource.content_text }}></section>
            </div>
          </section>
          {qrcode && <div className="qrcode">
            <QRCode value={qrcode} />
          </div>}
        </div>
      </div>
    )
  }
}
