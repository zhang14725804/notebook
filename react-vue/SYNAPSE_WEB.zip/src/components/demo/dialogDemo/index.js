import React from "react"
import ReactDOM from "react-dom"
import { tools } from "utils"
import "./dialogDemo.less"
import "../choosePlatDemo/choosePlatDemo.less"
import ChoosePlatDemo from "components/demo/choosePlatDemo"
import H5Demo from "components/demo/h5Demo"
import QaDemo from "components/demo/qaDemo"
import ReactQRCode from 'components/QRCode'
import Button from "antd/lib/button"
import { Enum, EnumCn } from "enum"

/**
 * dataSource = { //页面所需数据  ==>传到内存组件的datasource属性上
 *    content:Object,
 *          title: String,      //题目
 *          author: String,     //作者
 *          time: Number,       //时间
 *          tag: String,        //标签
 *          content_text: String//内容
 *    bg:Boolean,       有没有手机的背景，默认有
 *    qrcode:String,    二维码的url
 *    platform：String  平台
 * }
 * materialType: 素材类型,默认"1",即图文
 * type:String  按钮的样式  比antd多一种text即文字型
 * onBeforeShowModal: 弹窗前回调
**/
//                                                                   遮罩层
export default class DialogDemo extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            visible: false
        }
    }
    componentDidMount() {

    }
    render() {
        let {materialType, type, dataSource, onBeforeShowModal} = this.props;
        let {visible} = this.state;
        //有遮罩层时，如果既有微信又有app,左侧不加padding。否则
        //加paddingLeft使手机模型居中
        //所以dialog组件里面传了一个参数控制是否有遮罩层
        console.log('-- dataSource --', dataSource);
        if(dataSource || (dataSource && dataSource.length>0))
        var qrCodeShowDataSource = materialType == Enum.DocumentType.h5 ? 
            dataSource ? dataSource.qrcode : ''
            : dataSource.length > 0 ? dataSource[0].qrcode : '';
        return (
            <div className="dialogDemo">
                {
                  type === "text" ? <span onClick={this.showModal.bind(this)} className="btn">预览</span> :
                  type === "qrcode" ? <span onClick={this.showModal.bind(this)}><ReactQRCode value='' size={60} fgColor="#666" isText={false} /></span> : <Button onClick={this.showModal.bind(this)} type={type}>预览</Button>
               }
                {visible && <div className="modalBg">
                    <div className="modal">
                        {materialType == Enum.DocumentType.h5 ?
                          <H5Demo style={{marginLeft: '120px'}} value={dataSource.qrcode} /> :
                          materialType == Enum.DocumentType.qa ? 
                          <QaDemo style={{marginLeft: '120px'}} dataSource={dataSource}/> :
                          <ChoosePlatDemo style={dataSource.length > 1 ? {paddingLeft: '0'} : {paddingLeft: '120px'}} dataSource={dataSource} />}
                        <div className="close" onClick={this.handleClose.bind(this)}>关闭预览</div>
                    </div>
                </div>}
            </div>
        )
    }
    showModal() {
        if(typeof this.props.onBeforeShowModal == "function"){
          this.props.onBeforeShowModal.call(this);
        }
        this.setState({
            visible: true,
        });
    }
    handleClose(e) {
        this.setState({
            visible: false,
        });
    }
}
