import React from "react"
import ReactDOM from "react-dom"
import { tools } from "utils"
import ReactQRCode from '../../QRCode'
import "./h5Demo.less"

export default class H5Demo extends React.Component {
  constructor(props) {
    super(props);
  }
  componentDidMount() {

  }
  render() {
    const value = this.props.value || "";
    return (
      <section id="p-content" style={this.props.style}>
        <div className="p-content-QRCode">
          <ReactQRCode value={value} size={128} />
        </div>
      </section>
    )
  }
}
