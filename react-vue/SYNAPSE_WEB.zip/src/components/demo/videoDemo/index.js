import React from "react"
import ReactDOM from "react-dom"
import { tools } from "utils"
import { Link } from "react-router"
import { Enum, EnumCn } from "enum"
import "./videoDemo.less"

export default class VideoDemo extends React.Component {
  constructor(props) {
    super(props);
    this.dataSource = {
      videoType: null
    }
  }
  componentDidMount() {

  }
  _onClick() {
    console.log('-- click video demo --')
    this.props.onClick.call(this)
  }
  render() {
    const dataSource = $.extend(true,
      this.dataSource,
      {
        videoType: this.props.videoType
      }
    );
    const {videoType} = dataSource;
    return (
      <section id="p-content">
        <div className="cont" style={{textAlign:"center",fontSize:'14px'}}>
          <p>
            {videoType ?
              <a onClick={this._onClick.bind(this)}>{videoType === Enum.DocumentType.vol ? '直播' : '点播'}详情页，请点击此处进入</a>
              : null
            }
          </p>
        </div>
      </section>
    )
  }
}
