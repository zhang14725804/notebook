import React from "react"
import ReactDOM from "react-dom"
import { tools } from "utils"
import "./previewDemo.less"
import "../materialDemo/materialDemo.less"
import MaterialDemo from "components/demo/materialDemo"
import Button from "antd/lib/button"
import { Enum, EnumCn } from "enum"

/**
 * dataSource = { //页面所需数据  ==>传到内存组件的datasource属性上
 *    content:Object,
 *          title: String,      //题目
 *          author: String,     //作者
 *          time: Number,       //时间
 *          tag: String,        //标签
 *          content_text: String//内容
 *    bg:Boolean,       有没有手机的背景，默认有
 *    qrcode:String,    二维码的url
 *    platform：String  平台
 * }
 * materialType: 素材类型,默认"1",即图文
 * type:String  按钮的样式  比antd多一种text即文字型
 * onBeforeShowModal: 弹窗前回调
**/
//                                                                   遮罩层
export default class PreviewDemo extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            visible: false
        }
    }
    componentDidMount() {

    }
    render() {
        let {dataSource, materialType, type, onBeforeShowModal } = this.props;
        let { visible } = this.state;
        return (
            <div className="dialogDemo">

                <a onClick={this.showModal.bind(this)}>预览</a>

                {visible && <div className="modalBg">
                    <div className="modal">
                        <MaterialDemo {...this.props}/>
                        <div className="close" onClick={this.handleClose.bind(this)}>关闭预览</div>
                    </div>
                </div>}
            </div>
        )
    }
    showModal() {
        if (typeof this.props.onBeforeShowModal == "function") {
            this.props.onBeforeShowModal.call(this);
        }
        this.setState({
            visible: true,
        });
    }
    handleClose(e) {
        this.setState({
            visible: false,
        });
    }
}
