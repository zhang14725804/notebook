import {
    Row,
    Col,
    Input,
    Select
} from "antd"
import React, {Component} from "react"
import "./index.less"
const Option = Select.Option;
export default class BroadSteps extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }

    render() {
        let item = this.props;
        let ifEdit = item.edit;
        let con = item.condition;//单个条件
        let conditionJSX = con.map((item, i) => {
            return (
                <Row className='condition-row' key={i} gutter={24}>
                    <Col span={3}><span>条件{item}:</span></Col>
                    <Col span={3}>
                        <div>
                            {
                                ifEdit ? <Input/> : "1"
                            }
                        </div>
                    </Col>
                    <Col span={1}><span>次</span></Col>
                    <Col span={2}><span>打开</span></Col>
                    <Col span={3}><span>不打开</span></Col>
                    <Col span={2}><span>则</span></Col>
                    <Col span={10}>
                            <span>
                                {
                                    ifEdit ?
                                        <Select placeholder='选择展示的物料或结束' style={{width: 420}} onChange={this.selectChange.bind(this)}>
                                            <Option value="jack">开始</Option>
                                            <Option value="lucy">结束</Option>
                                        </Select>
                                        : "结束"
                                }

                        </span>
                    </Col>
                </Row>
            )
        })
        return (
            <div className='step-font'>
                <Row>
                    <Col><span className='step-name'>{item.id}:</span><span>{item.des}</span></Col>
                </Row>
                <Row className='detail-row'>
                    {conditionJSX}
                </Row>
            </div>
        );
    }
    selectChange(val){
        if(this.props.onSelectChange && typeof this.props.onSelectChange === "function"){
            this.props.onSelectChange.call(this,val)
        }
    }
}