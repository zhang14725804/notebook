import React from "react"
import ReactDOM from "react-dom"
import {tools} from "utils"

export default class _VolPlayer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            playerId: "player_" + tools.getRandom(),
            player: null,
            isSDKLoad: false
        }
    }
    componentWillReceiveProps(next){
        if (!!next.channel_id) {
            this._init(next);
        }
    }
    componentDidMount() {
        //添加直播sdk
        tools.insertSDK({
            name: "volPlayer",
            src: tools.sdk.volPlayer
        }, (script) => {
            this.setState({
                isSDKLoad: true
            });
        });
    }

    // componentDidUpdate(prevProps, prevState) {
    //     const {isSDKLoad, player, playerId} = this.state;
    //     if (isSDKLoad
    //         && player == null
    //         && document.querySelectorAll("#" + playerId).length > 0
    //         && !!this.props.channel_id) {
    //         console.log("初始化player，channel_id：" + this.props.channel_id);
    //         //初始化player
    //         const player = new qcVideo.Player(playerId, this.props);
    //         this.setState({
    //             player: player
    //         })
    //     }
    // }

    componentWillUnmount() {
        this.setState({
            player: null
        });
        tools.removeSDK("volPlayer");
        window.qcVideo = null;
    }
    render() {
        return (
            <div id={this.state.playerId}></div>
        )
    }
    _init(cfg) {
        const {player, playerId} = this.state;
        //初始化player
        if (!!window.qcVideo
            && document.querySelectorAll("#" + playerId).length > 0
            && !!cfg.channel_id
        ) {
            const _player = new qcVideo.Player(playerId, cfg);
            this.setState({
                player: _player
            })
        }
    }
}

_VolPlayer.distory = () => {
    //官方未提供destory方法，暂时直接置空
    //this.state.player = null;
    tools.removeSDK("volPlayer");
}

_VolPlayer.defaultProps = {
    //直播id
    channel_id: "",
    //应用id（暂时直接写死在前端）
    app_id: "1252213672",
    //宽
    width: 400,
    //高
    height: 300,
    //最大缓冲时间
    cache_time: 0.3
}
