import React from "react"
import ReactDOM from "react-dom"
import $ from "jquery"
import { tools } from "utils"

export default class _VodPlayer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            playerId: "player_" + tools.getRandom(),
            player: null
        }

    }
    componentWillReceiveProps(next) {
        if (!!next.file_id) {
            this._init(next);
        }
    }
    componentDidMount() {
        //添加点播sdk
        tools.insertSDK({
            name: "vodPlayer",
            src: tools.sdk.vodPlayer
        }, (script) => {
            const {player} = this.state;
            if (player == null) {
                console.log('点播初始化')
                this._init(this.props);
            }
        });
    }
    componentWillUnmount() {
        this.setState({
            player: null
        });
        tools.removeSDK("vodPlayer");
        window.qcVideo = null;
    }
    render() {
        return (
            <div id={this.state.playerId}></div>
        )
    }
    _init(cfg) {
        const {player, playerId} = this.state;
        //初始化player
        if (!!window.qcVideo
            && document.querySelectorAll("#" + playerId).length > 0
            && !!cfg.file_id
        ) {
            const _player = new qcVideo.Player(playerId, cfg);
            this.setState({
                player: _player
            })
        }
    }
}


_VodPlayer.defaultProps = {
    //点播id
    file_id: "",
    //应用id（暂时直接写死在前端）
    app_id: "1252213672",
    //宽
    width: 400,
    //高
    height: 300,
    //最大缓冲时间
    cache_time: 0.3,
    //是否打开全屏模式
    disable_full_screen: 0
}

