import React from "react"
import ReactDOM from "react-dom"
import $ from "jquery"
// import { tools, ueditorConfig } from "utils"
import { tools } from "utils"
import { Enum, EnumCn } from "enum"

require("./ueditor.less")

const common_toolbar = [
    [
        'undo', 'redo', '|', 'fontsize', 'blockquote', 'horizontal',
        '|','removeformat', 'formatmatch', '|', 'source',
    ],
    [
        'bold', 'italic', 'table_underline', 'forecolor', 'backcolor', '|',
        'indent', 'justifyleft', 'justifycenter', 'justifyright',
        'justifyjustify', '|', 'rowspacingtop', 'rowspacingbottom',
        'lineheight',

    ],
    [
        'fontborder', 'strikethrough', 'autotypeset', 'pasteplain', '|', 'inserttable', '|', 'insertorderedlist',
        'insertunorderedlist',
    ],
    [
      'simpleupload', '|', 'imagenone', 'imageleft', 'imageright', 'imagecenter'
    ]
];
const weixin_toolbar = [
    [
        'undo', 'redo', '|', 'fontsize', 'blockquote', 'horizontal',
        '|','removeformat', 'formatmatch', 'link','|',
        'show-image-select','weixin-video','weixin-music', 'source',
    ],
    [
        'bold', 'italic', 'table_underline', 'forecolor', 'backcolor', '|',
        'indent', 'justifyleft', 'justifycenter', 'justifyright',
        'justifyjustify', '|', 'rowspacingtop', 'rowspacingbottom',
        'lineheight',

    ],
    [
        'fontborder', 'strikethrough', 'autotypeset', 'pasteplain', 'emotion',
        'spechars', 'searchreplace', '|', 'inserttable', '|', 'insertorderedlist',
        'insertunorderedlist','weixin-video-optimize',
    ],
    [
      'simpleupload', '|', 'imagenone', 'imageleft', 'imageright', 'imagecenter'
    ]
];
const app_toolbar = [
    [
        'undo', 'redo', '|', 'fontsize', 'blockquote', 'horizontal',
        '|','bold', 'italic','forecolor', 'backcolor', '|', 'insertorderedlist',
        'insertunorderedlist', 'removeformat', 'formatmatch', 'link', 'source', '|', 'simpleupload'
    ]
]

export default class _UEditor extends React.Component {
    constructor(props) {
        super(props);
        // 这个页面的编辑器
        this.state =  {
            editor: null,
        }
    }
    componentWillReceiveProps(next) {
      const {editor} = this.state;
      if(!editor) return;
      // 编辑器加载完成后
      editor.ready(()=>{
        // 点击编辑器内按钮时不刷新
        if(editor.isFocus()) return
        // 当前选中的 key 改变，或者内容改变时，刷新编辑器
        // 当前选中平台，或微信中内容，或app中内容改变时，将editor中内容刷新为新值
        if((this.props.curKey != next.curKey) || (this.props.content != next.content)) {
            const {content} = next;
            // console.log('-- editor content --', content)
            if(typeof content !== "undefined"){
                editor.setContent(content);
            }
        }
        // 如果title的值从无到有，将title输入框刷新为新值
        // console.log('-- this.props.title --', this.props.title, '-- next.title --', next.title);
        if((this.props.curKey != next.curKey) || (this.props.title != next.title)){
            const {title} = next;
            if(document.getElementById('editor-extend-title-input')){
              document.getElementById('editor-extend-title-input').value = title;
            }
        }
      });
    }
    componentDidMount() {
        // $.when(
        //   ueditorConfig.init()
        // ).done(
        //   () => {
        //     tools.insertSDK({
        //       name: "ueditorAll",
        //       src: "http://synapse-test.oss-cn-beijing.aliyuncs.com/ueditor/ueditor.all.js"}, () => {
        //         tools.insertSDK({
        //           name: "ueditorZhCn",
        //           src: "http://synapse-test.oss-cn-beijing.aliyuncs.com/ueditor/lang/zh-cn/zh-cn.js"}, () => {
                    const {id, contentType} = this.props;
                    if(!!window.UE) {
                        // var editorContent = document.createElement('script')
                        // editorContent.id = 'editor';
                        // editorContent.type = 'text/plain';
                        // editorContent.style.width = '1024px';
                        // editorContent.style.height = '500px';
                        // document.getElementsByClassName('editor-extent')[0].appendChild(editorContent)

                        // 初始化编辑器
                        var editor = UE.getEditor(id, {
                            toolbars: common_toolbar
                        });

                        // 将编辑器存到界面内
                        this.setState({
                            editor: editor
                        })

                        // 给编辑器加上标题输入框
                        var editorExtendTitle = document.createElement('div');
                        editorExtendTitle.classList.add('editor-extend-title');
                        var editorExtendTitleInput = document.createElement('input');
                        editorExtendTitleInput.type = 'text';
                        editorExtendTitleInput.id = 'editor-extend-title-input';
                        editorExtendTitleInput.placeholder = '请在这里输入标题';
                        editorExtendTitleInput.setAttribute("maxLength", "64");
                        editorExtendTitle.appendChild(editorExtendTitleInput);

                        // 编辑器加载完成后，加入标题输入框，调外面传进来的编辑器加载完成函数                      
                        editor.ready(()=>{
                            document.getElementsByClassName('edui-editor-toolbarbox')[0].after(editorExtendTitle);
                            var titleInput = document.getElementById('editor-extend-title-input');
                            titleInput.addEventListener("keyup", (e) => {
                                let argObj = {
                                    // TODO
                                    title: titleInput.value,
                                    content: editor.getContent()
                                }
                                this._onKeyup(argObj)    
                            }, true); 
                            
                            // 编辑器失去焦点，调外面传进来的失去焦点函数，参数为title，content
                            editor.addListener('wordCount',()=>{
                                let argObj = {
                                    title: titleInput.value,
                                    content: editor.getContent()
                                }
                                this._onKeyup(argObj)
                            });          
                                   
                            if (typeof this.props.onEditorReady === "function") {
                                return this.props.onEditorReady.call(this);
                            }
                        });
                    }
        //           })
        //       })
        //   }
        // )
      }
    componentWillUnmount() {
      // tools.removeSDK("ueditorAll");
      // tools.removeSDK("ueditorZhCn");
    }
    render() {
        return (
          <div className="editor-extent">
              <script id={this.props.id} type="text/plain" style={{width:"100%",height:"730px"}}></script>
          </div>
        )
    }
    //离开编辑器时执行
    _onKeyup(value) {
        if (typeof this.props.onKeyup === "function") {
            return this.props.onKeyup.call(this, value);
        }
    }
}


_UEditor.defaultProps = {
}
