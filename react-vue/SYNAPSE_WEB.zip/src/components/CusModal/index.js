import {
    Row,
    Col,
    Modal,
    Tabs,
    Alert,
    Input
} from "antd"

const TabPane = Tabs.TabPane;
const Search = Input.Search;
import TextCard from "components/card/TextCard"
import KMCard from "components/card/KMCard"
import React, {Component} from "react"
import "./index.less"

export default class CusModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            visible: props.visible,
            data: props.data,
        }
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            visible: nextProps.visible,
            data: nextProps.data,
        });
    }

    render() {
        let {cardType, isShowTabs} = this.props;
        let data = this.state.data;
        let content = null;
        if (isShowTabs) {
            content = <Tabs defaultActiveKey="1" onChange={() => {
            }}>
                <TabPane tab="战役目标" key="1">
                    <div className="extension-edit-modal-alert">
                        {/*<Alert message="Informational Notes" type="info" showIcon/>*/}
                    </div>
                    <Row>
                        {
                            data.map((item, index) => {
                                if (item.isCamp) {
                                    return (
                                        <Col span={12} key={index}><TextCard data={item} inModal
                                                                             onClick={this.onChecked.bind(this, item.id)}/></Col>
                                    )
                                }
                            })
                        }
                    </Row>
                </TabPane>
                <TabPane tab="全部目标" key="2">
                    <Row>
                        {
                            data.map((item, index) => {
                                return (
                                    <Col span={12} key={index}><TextCard data={item} inModal
                                                                         onClick={this.onChecked.bind(this, item.id)}/></Col>
                                );
                            })
                        }
                    </Row>
                </TabPane>
            </Tabs>;
        } else {
            switch (cardType) {
                case "text":
                    content = <Tabs defaultActiveKey="1" onChange={() => {
                    }}>
                        <TabPane tab="全部目标" key="1">
                            <div>
                                <div className="extension-edit-modal-alert">
                                    {/*<Alert message="Informational Notes" type="info" showIcon/>*/}
                                </div>
                                <Row>
                                    {
                                        data.map((item, index) => {
                                            return (
                                                <Col key={index} span={12}><TextCard data={item} inModal
                                                                                     onClick={this.onChecked.bind(this, item.id)}/></Col>
                                            );
                                        })
                                    }
                                </Row>
                            </div>
                        </TabPane>
                        <TabPane tab="" key="2"></TabPane>
                    </Tabs>
                    ;
                    break;
                case "km":
                    content = <div>
                        <div className="extension-edit-modal-alert">
                            {/*<Alert message="Informational Notes" type="info" showIcon/>*/}
                        </div>
                        <Row>
                            <Col span={8}><KMCard/></Col>
                            <Col span={8}><KMCard/></Col>
                            <Col span={8}><KMCard/></Col>
                        </Row>
                    </div>;
                    break;
            }
        }
        return (
            <Modal className="cusModal"
                title="添加目标人群"
                visible={this.state.visible}
                onOk={::this.confirm}
                okText="确定"
                cancelText="取消"
                width={1200}
                onCancel={::this.cancel}>
                {content}
                <div className="extension-edit-modal-search">
                    <Search
                        placeholder=""
                        onSearch={value => console.log(value)}
                        style={{width: 200}}/>
                </div>
            </Modal>
        );
    }

    cancel() {
        this.props.cancel.call(this);
    }

    confirm() {
        this.props.confirm.call(this, this.state.data);
    }

    /**
     *
     * @param id
     */
    onChecked(id) {
        let data = this.state.data;
        let modifyData = [];
        data.forEach((item, index) => {
            if (item.id === id) {
                item.checked = !item.checked;
                modifyData.push(item);
            } else {
                modifyData.push(item)
            }
        });
        this.setState({data: modifyData});
    }
}
CusModal.defaultProps = {
    data: [],
    cardType: "text",
    visible: false
};