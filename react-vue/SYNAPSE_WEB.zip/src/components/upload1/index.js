import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import "./upload.less"
import Button from "antd/lib/button"
import Icon from "antd/lib/icon"

export default class _Upload extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            uploadState: {
                uploading: "uploading",
                done: "done",
                error: "error",
                removed: "removed"
            }
        }
    }
    render() {
        const Inner = this._createInner();
        return (
            <div className="sy-upload">
                <Inner />
                <input type="file" name="imgUpload" onChange={this.onFileChange.bind(this)} style={{ display: "none" }} />
            </div>
        );
    }
    _createInner() {
        const {style, type} = this.props;
        const _this = this;
        return React.createClass({
            render() {
                let imgStyle = {};
                _this.props.width ? imgStyle.width = _this.props.width : "";
                _this.props.height ? imgStyle.height = _this.props.height : "";
                return type === "button" ?
                    <Button type="ghost" onClick={_this.onClickUpload.bind(_this)}>
                        <Icon type="upload" />点击上传
                    </Button>
                    :
                    <div
                        className="sy-upload-preview"
                        onClick={_this.onClickUpload.bind(_this)}
                        style={imgStyle}>
                        {!!_this.props.previewUrl ?
                            <img src={_this.props.previewUrl} className="img" />
                            :
                            <div className="noneImg">
                                <p style={{fontSize:"18px"}}>＋</p>
                                <p>{_this.props.description}</p>
                            </div>
                        }
                    </div>
            }
        })
    }

    onClickUpload() {
        $(ReactDOM.findDOMNode(this)).find("input[name='imgUpload']").click();
    }
    //选择本地图片后执行
    onFileChange(e) {
        let file = e.target.files[0];
        //校验
        if (this._validate(file) === false) return;
        //以formdata格式上传
        var formdata = new FormData();
        formdata.append('file', file);
        this.props.measure && formdata.append('measure', this.props.measure);
        this._upload(formdata);

        //base64格式上传
        // let reader = new FileReader();
        // reader.readAsDataURL(file);
        // reader.onload = (e) => {
        //     let postData = {
        // imgcontent: reader.result.replace(/^data.+base64,/, ""),
        // isbase64: 1,
        // filename: ""
        // }
        // this._upload(postData);
        // }
    }
    //上传
    _upload(data) {
        $.ajax({
            type: "post",
            url: this.props.url,
            data: data,
            processData: false,
            contentType: false,
            success: this._onSuccess.bind(this),
            error: this._onError.bind(this),
            headers:this.props.headers
        })
    }
    //上传成功后事件
    _onSuccess(resp) {
        if (resp.code == 10000) {
            //成功
            //显示预览图
            let $preview = $(ReactDOM.findDOMNode(this)).find(".sy-upload-preview");
            $preview.css("background-image", "url(" + resp.data.absolute_url + ")");
            if (typeof this.props.onSuccess === "function") {
                return this.props.onSuccess.call(this, resp.data);
            }
        } else if (resp.code === 10001) {
            //失败
            this._getMessage(resp.msg);
        } else {
            this._getMessage("error response code")
        }
    }
    //上传失败后事件
    _onError(e) {
        this._getMessage(e);
        if (typeof this.props.onError === "function") {
            return this.props.onError.call(this, $.makeArray(arguments));
        }
    }
    //提交前校验
    _validate(file) {
        //size
        if (typeof this.props.maxSize === "number" && file.size > this.props.maxSize) {
            this._getMessage("文件大小超过限制");
            return false;
        }
        //extension
        let ext = file.name.substring(file.name.lastIndexOf("."));
        if (typeof this.props.extension === "string" && $.inArray(ext.toLowerCase(), $.map(this.props.extension.split("|"), ex => ex.toLowerCase())) < 0) {
            this._getMessage("文件类型支持jpg、png、jpeg");
            return false;
        }
        return true;
    }

    _getMessage(error) {
        if (typeof this.props.onErrorMessage === "function") {
            return this.props.onErrorMessage.call(this, error);
        }
    }
}

_Upload.defaultProps = {
    //文件上传接口
    url: "",
    //是否支持多文件上传
    multiple: false,
    //上传提交参数
    data: {},
    //文件大小上限
    maxSize: undefined,
    //允许扩展名
    extension: ".jpg|.png|.jpeg",
    //上传点击区域结构
    inner: undefined,
    //beforeUpload: $.noop,
    //上传成功事件
    onSuccess: $.noop,
    //上传失败事件
    onError: $.noop,
    //onRemove: $.noop,
    //获取错误信息
    onErrorMessage: $.noop,
    //类型是按钮还是预览框,默认预览框  "button"按钮
    type: "",
    //图片显示尺寸，适用于预览框模式
    width: "",
    height: "",
    //.....
    description:"点击上传",
    headers:{}
}
