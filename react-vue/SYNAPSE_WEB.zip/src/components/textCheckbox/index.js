import React from "react"
import ReactDOM from "react-dom"

import "./textCheckbox.less"

/*
* 文本多选TextCheckbox
* title:String 题目
* value:Aarray[String] 选中的key  注意处理组件内部对数组型数据的地址引用问题
*/

export default class TextCheckbox extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            value: props.value.map(id => id)
        }
    }
    componentWillReceiveProps(nextProps) {
        let prevValue = this.props.value;
        let nextValue = nextProps.value;
        if (prevValue.sort().toString() != nextValue.sort().toString()) {
            let value = nextValue.map(id => id)
            this.setState({
                value: value
            })
        }
    }
    render() {
        let {title, className, options, otherProps} = this.props;
        let {value} = this.state
        let optionsJSX = options.map((item) => {
            return <span key={item.key} className={`option ${value.indexOf(item.key) != -1 && 'checked'}`} onClick={this._onClick.bind(this, item.key)}>{item.text}</span>
        })
        return (
            <div className={`textCheckbox ${className}`} {...otherProps}>
                <span className="title">{title}</span>
                {optionsJSX}
            </div>
        )
    }
    _onClick(key) {
        let value = this.state.value.map(id => id)
        if (value.indexOf(key) == -1) {
            //没有找到这个值
            value.push(key);
        } else {
            //有这个值
            value.splice(value.indexOf(key), 1)
        }
        if (typeof this.props.onChange === "function") {
            this.props.onChange.call(this, value);
        }
    }
}
