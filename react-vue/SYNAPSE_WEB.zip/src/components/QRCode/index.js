import React from "react"
import QRCode from 'qrcode.react'

export default class ReactQRCode extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    let _config = Object.assign({}, {
      value: "",
      size: 128,
      bgColor: "#FFF",
      fgColor: "#000",
      level: "M",
      isText: true
    }, this.props)
    return (
      <div>
        <QRCode {..._config}></QRCode>
        <div style={{ textAlign: 'center', display: _config.isText ? "block" : "none"}}>
          <p>请扫描二维码</p>
          <p>在手机端预览</p>
        </div>
      </div>
    )
  }
}
