import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import Upload from "antd/lib/upload"
import Icon from "antd/lib/icon"

const Dragger = Upload.Dragger

export default class _Upload extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            uploadState: {
                uploading: "uploading",
                done: "done",
                error: "error",
                removed: "removed"
            },
            headers: {
                "Content-Type": "multiple/form-data"
            },
            beforeUpload: $.noop,
            onChange: $.noop
        }
    }
    componentDidMount() {
        let state = this.state.uploadState;
        this.setState({
            beforeUpload: (file) => {
                let {beforeUpload} = this.props;
                //提交校验
                if (this._validate(file) === false) return false;
                return new Promise(function (resolve, reject) {
                    if (typeof beforeUpload === "function") {
                        resolve(beforeUpload.call(this, file));
                    }
                })
            },
            onChange: (info) => {
                switch (info.file.status) {
                    case state.uploading:
                        this._uploading(info); break;
                    case state.done:
                        this._done(info); break;
                    case state.error:
                        this._error(info); break;
                    case state.removed:
                        this._removed(info); break;
                    default:
                        break;
                }
            }
        })
    }
    render() {
        return (
            <div>
                <span>上传图片</span>
                <div style={{ marginTop: 5, height: 180 }}>
                    <Dragger
                        {...this.props}
                        {...this.state}>
                        <p className="ant-upload-drag-icon">
                            <Icon type="cloud-upload-o" />
                        </p>
                        <p className="ant-upload-text">点击或将文件拖拽到此区域上传</p>
                        <p className="ant-upload-hint">支持扩展名：.png.jpg</p>
                    </Dragger>
                </div>
            </div>
        );

    }
    //提交前校验
    _validate(file) {
        //size
        if (typeof this.props.maxSize === "number" && file.size > this.props.maxSize) {
            this._getMessage("文件大小超过限制");
            return false;
        }
        //extension
        if (typeof this.props.extension === "string" && $.grep(this.props.extension.split("|"), ex => ex.toLowerCase().indexOf(file.type.toLowerCase()) > -1).length === 0) {
            this._getMessage("文件类型不符");
            return false;
        }
        return true;
    }
    _uploading() { }
    _done(info) {
        let resp = info.file.response;
        if (resp.code === 10000) {
            //成功
            if (typeof this.props.onSuccess === "function") {
                //显示远程连接
                info.fileList = info.fileList.map((file) => {
                    if (file.response) {
                        file.url = file.response.url;
                    }
                    return file;
                });
                return this.props.onSuccess.call(this, info.response.data, info);
            }
        } else if (resp.code === 10001) {
            //失败
            this._getMessage(resp.msg);
            //删除上传队列中当前文件
            info.fileList.splice(-1);//todo
        } else {
            this._getMessage("error response code")
        }
    }
    _error(info) {
        this._getMessage(info);
        if (typeof this.props.onError === "function") {
            return this.props.onError.call(this, info);
        }
    }
    _removed(info) {
        if (typeof this.props.onRemove === "function") {
            return this.props.onRemove.call(this, info);
        }
    }
    _getMessage(error) {
        if (typeof this.props.onErrorMessage === "function") {
            return this.props.onErrorMessage.call(this, error);
        }
    }
}

_Upload.defaultProps = () => {
    return {
        action: "",
        multiple: false,
        data: {},
        uploadList: true,
        maxSize: undefined,
        extension: "jpg|png",
        beforeUpload: $.noop,
        onSuccess: $.noop,
        onError: $.noop,
        onRemove: $.noop,
        onErrorMessage: $.noop
    }
}
