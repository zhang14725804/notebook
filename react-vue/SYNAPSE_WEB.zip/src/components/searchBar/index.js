import React from "react"
import ReactDOM from "react-dom"
import Icon from "antd/lib/icon"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
// import classNames from "classnames"
import $ from "jquery"
const InputGroup = Input.Group
import "./searchBar.less"

/*
* 搜索栏组件SearchBar
* value:any         搜索栏输入框的值
* placeholder:any   搜索栏输入框placeholder
* clear:(){}        用来强行清空搜索框内容，需在searchBar上用ref属性调用
* onSearch:(value:string,e:ReactEvent)=>any     点击搜索栏输入框执行事件
*/
export default class SearchBar extends React.Component {
    constructor(props) {
        super(props);
        this.state = $.extend(true, {
            value: "",
            placeholder: "请输入搜索内容",
        }, props);
    }
    render() {
        // const btnCls = classNames({
        //     "ant-search-btn": true,
        //     "ant-search-btn-noempty": !!this.state.value.trim()
        // });
        // const searchCls = classNames({
        //     "ant-search-input": true
        // });
        return (
            <InputGroup className="ant-search-input searchBar" style={this.props.style}>
                <Input
                    ref='searchInput'
                    placeholder={this.state.placeholder}
                    value={this.state.value}
                    onChange={this._onInputChange.bind(this)}
                    onBlur={this._onInputBlur}
                    onPressEnter={this._search.bind(this)} />
                <div className="ant-input-group-wrap">
                    <Button
                        className={"ant-search-btn " + (!!this.state.value.trim() ? "ant-search-btn-noempty" : "")}
                        style={{ margin: 0 }}
                        size={this.props.size}
                        onClick={this._search.bind(this)}>
                        <Icon type="search" />
                    </Button>
                    {this.state.value.length ? <span className='cancelBtn' onClick={this.onCancel.bind(this)}>×</span> : ''}
                </div>
            </InputGroup>
        );
    }
    clear() {
        this.setState({
            value: ''
        })
    }
    onCancel() {
        this.setState({
            value: ''
        })
        $(ReactDOM.findDOMNode(this.refs.searchInput)).find("input").focus();
    }
    //变更输入框内容：更新this.state.value
    _onInputChange(e) {
        this.setState({
            value: e.target.value
        });
    }
    //点击搜索按钮：调用父组件搜索函数
    _search(e) {
        const value = this.state.value.replace(/^\s*(.+?)\s*$/, "$1");
        // if (value == null || value.length === 0) return;
        if (typeof this.props.onSearch === "function") {
            this.props.onSearch.call(this, this.state.value, e);
        }
    }
}
