import React from "react"
import ReactDOM from "react-dom"
import Icon from "antd/lib/icon"

import "./LButton.less"

/* 
* 大按钮LButton
* 默认单标签，当启用双标签时，内部值可以自定义
* layout:String 横排or竖排
* title:String 按钮显示文字
* icon:{type:String,className:String}  图标的类型和样式
* type:String【optional】  按钮主题 默认描边主题
*    "primary":实心主题 
* style:String【optional】  按钮整体样式
* className:String【optional】  按钮整体样式
* checked:Boolean【optional】 多选模式的值
* onClick:function【optional】 点击事件
*/

export default class LButton extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            checked: props.checked
        }
    }
    componentWillReceiveProps(nextProps) {
        let prevChecked = this.props.checked;
        let nextChecked = nextProps.checked;
        if (prevChecked != nextChecked) {
            this.setState({
                checked: nextChecked
            })
        }
    }
    render() {
        let {title, icon, type, size, style, className, children, layout, otherProps} = this.props;
        let {checked} = this.state;
        const LButtonProps = {
            className: `lButton ${className} ${type === 'primary' || checked === true ? 'primary' : ''} ${size === 'small' ? 'small' : ''} ${layout === 'horizontal' ? 'horizontal' : 'vertical'} `,
            style: style,
            onClick: this._toggle.bind(this),
        }
        let defaultChildren = (<div>{
            icon && icon.type && <Icon type={icon.type} className={`btnIcon ${icon && icon.className || ''}`} />}
            < span > {title || '大按钮'}</span>
            {/*
                选中的对勾，先不做
            {checked === true && <Icon type="check" />}
             */}
        </div>)
        return (
            <div {...LButtonProps} {...otherProps}>
                {children || defaultChildren}
            </div>
        )
    }
    _toggle(key, e) {
        let checked = this.state.checked;
        //按钮开关的交互效果
        if (checked) {
            this.setState({
                checked: !checked
            })
        }
        if (typeof this.props.onChange === "function") {
            this.props.onChange.call(this, !checked);
        }
        if (typeof this.props.onClick === "function") {
            this.props.onClick.call(this, !checked);
        }
    }
}
