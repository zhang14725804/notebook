import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import {tools} from "utils"
import {
    Card
} from "antd"
import "./index.less"
// 上传图片组件
export default class BatchUpload extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
        this.data = {
            wx_img: {
                show: true,
                url: "",
            },
            banner_img: {
                show: true,
                url: "",
            },
            feeds_img: {
                show: true,
                url: "",
            },
            open_img: {
                show: true,
                url: "",
            }
        }
    }

    render() {
        let {Appearance,style} = this.props;
        let uploadJSX = Appearance && Appearance === "text" ?
            <div>
                <a style={{fontSize: '13px'}} onClick={this.onClickUpload.bind(this)}>一键上传...</a>
            </div> :
            <Card onClick={this.onClickUpload.bind(this)}>
                <span>一键上传图片包  360*200 , 640*240 , 200*150 , 1242*2208</span>
            </Card>;
        return (
            <div className="batch-upload-box" style={{...this.props.style}}>
                {uploadJSX}
                <input type="file" name="imgUploadAll" ref="upload-input" onChange={this.onFileChange.bind(this)} style={{display: "none"}}
                       multiple/>
            </div>
        )
    }

    // 点击上传按钮
    onClickUpload() {
        if (typeof this.props.onClick === "function") {
            this.props.onClick.call(this);
        }
        $(ReactDOM.findDOMNode(this)).find("input[name='imgUploadAll']").click();
    }

    //选择本地图片后执行
    onFileChange(e) {
        // debugger;
        let files = e.target.files;
        let imgs = [];
        if (files) {
            $.map(files, (item, index) => {
                if (this._validate(item) === false) return;   // 校验单个文件是否合法
                let imgObj = {};
                imgObj.name = "wx_img";
                imgObj.url = "https://ss3.baidu.com/-rVXeDTa2gU2pMbgoY3K/it/u=3044192727,472157510&fm=202&src=764&mola=new&crop=v1";
                imgs.push(imgObj);
                var formdata = new FormData();
                formdata.append('imgcontent', item);
                formdata.append('measure', ['360_200', '640_240', '200_150', '1242_2208'].join());
                // this._upload(formdata);//请求上传接口
            });
            this.refs["upload-input"].value=null;//清空input框，否则下次上传相同图片时无法调用onChange时间
            return this.props.onSuccess.call(this, imgs);
        }
    }

    //上传
    _upload(data) {
        $.ajax({
            type: "post",
            url: tools.javaApi("/uploadpic"),
            data: data,
            processData: false,
            contentType: false,
            success: this._onSuccess.bind(this),
            error: this._onError.bind(this)
        })
    }

    //上传成功后事件
    _onSuccess(resp) {
        if (resp.code == 10000) {
            this.mark++;
            if (typeof this.props.onSuccess === "function") {
                // return this.props.onSuccess.call(this, resp.data);
                return this.props.onSuccess.call(this, this.mark);
            }
        } else if (resp.code === 10001) {
            //失败
            this._getMessage(resp.msg);
        } else {
            this._getMessage("error response code")
        }
    }

    //上传失败后事件
    _onError(e) {
        this._getMessage(e);
        if (typeof this.props.onError === "function") {
            return this.props.onError.call(this, $.makeArray(arguments));
        }
    }

    //提交前校验
    _validate(file) {
        //size
        if (typeof this.props.maxSize === "number" && file.size > this.props.maxSize) {
            this._getMessage(`文件［${file.name}］大小超过限制`);
            return false;
        }
        //extension
        let ext = file.name.substring(file.name.lastIndexOf("."));
        if (typeof this.props.extension === "string" && $.inArray(ext.toLowerCase(), $.map(this.props.extension.split("|"), ex => ex.toLowerCase())) < 0) {
            this._getMessage(`文件［${file.name}］类型不符`);
            return false;
        }
        return true;
    }

    //错误提示框
    _getMessage(error) {
        tools.showDialog.error(error)
    }
}
BatchUpload.defaultProps = {};
