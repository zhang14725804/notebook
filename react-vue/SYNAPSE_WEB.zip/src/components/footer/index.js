import React from "react"
import ReactDOM from "react-dom"

import "./index.less"


export default class Footer extends React.Component {
	constructor(props) {
		super(props);
	}
    render() {
		const isFix = this.getScrollHeight() - this.getClientHeight() <= 0;
        return (
            <div className="ft">
				<div className="ft-ctn">
					<ul className="ft-list">
						<li>关于</li>
						<li>常见问题</li>
						<li>服务协议</li>
						<li>版权声明</li>
						<li>联系我们</li>
					</ul>
					<div>&copy;2010-2017 Synapse.xin 版权所有 ICP证：京备11006696号-10</div>
				</div>
				<div className="ft-bg"></div>
			</div>
        );
	}
	getClientHeight() {
		var clientHeight = 0;
		if (document.body.clientHeight && document.documentElement.clientHeight) {
			var clientHeight = (document.body.clientHeight < document.documentElement.clientHeight) ? document.body.clientHeight : document.documentElement.clientHeight;
		}
		else {
			var clientHeight = (document.body.clientHeight > document.documentElement.clientHeight) ? document.body.clientHeight : document.documentElement.clientHeight;
		}
		return clientHeight;
	}
	getScrollHeight() {
		return Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
	}
}
