import React from "react"
import ReactDOM from "react-dom"
import Immutable from "immutable"
import {Row,Col} from 'antd'
import $ from "jquery"
import './index.less'

export default class DataInsightCard extends React.Component {
    componentDidMount() {

    }
    componentWillReceiveProps(nextProps) {

    }
    render() {
        let data={
            type:'Offline',
            content:[{
                name:'拜访',
                num:'10923'
            },{
                name:'会议',
                num:'109'
            },{
                name:'会议',
                num:'109'
            },]
        }
        let spanCol=24/Number(this.props.datas.content.length);
        let contJSX=this.props.datas.content.map((item,i)=>{
            return (
                <Col key={i} span={spanCol}>
                    <p style={{color:'#999'}}>{item.name}</p>
                    <p style={{fontSize:'18px',color:'#000'}}>{item.num}</p>
                </Col>
            )
        })
        return <div className="dataInsight-linecard">
            <Row style={{marginBottom:'26px',color:'#ccc'}}>
                <Col>
                    <p style={{fontSize:'15px'}}>{data.type}</p>
                </Col>
            </Row>
            <Row gutter={16}>
                {contJSX}
            </Row>
        </div>
    }
}
