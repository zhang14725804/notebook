import React from "react"
import ReactDOM from "react-dom"
import Immutable from "immutable"
import {Row,Col,Table,Card} from 'antd'
import $ from "jquery"
import {tools} from "utils"
import './index.less'
const imgs = {
    img1: require('src/assets/image/u11463.png'),
    img2: require('src/assets/image/u14547.png'),
}
export default class TableCard extends React.Component {
    componentDidMount() {

    }
    componentWillReceiveProps(nextProps) {

    }
    render() {
        const dataSource = [{
            key: '1',
            battle: '慢性乙型肝炎的抗病毒药物及靶点的研究进展',
            type:'普通文档'
        },{
            key: '2',
            battle: '医保目录调整完毕,支付标准箭在弦上',
            type:'HTML5'
        },{
            key: '3',
            battle: '韦瑞德合成工艺的优化',
            type:'图文消息'
        },{
            key: '4',
            battle: '韦瑞德的长期疗效和安全性',
            type:'在线直播'
        },{
            key: '5',
            battle: '医保目录调整完毕,支付标准箭在弦上',
            type:'录播视频'
        },];

        let cfg = {
            dataSource: dataSource,
            rowKey: r => r.key,
            columns: [{
                title: 'ID',
                dataIndex: 'key',
                key: 'key',
            }, {
                title: '名称',
                dataIndex: 'battle',
                key: 'battle',
                render:text=><div>
                    <a href="">{text}</a>
                </div>
            }, {
                title: '类型',
                dataIndex: 'type',
                key: 'type',
            }],
            pagination: $.extend(true, {}, tools.config.pagination, {
                current: 2,
                pageSize: 5,
                total: 20
            }),
            onChange: (page, filter, sort) => {
                console.log(page, filter, sort,'page');
            },

        };
        return <div className="table-card">
            <Card className='' title={<div className=''>涉及资源</div>} bordered={false}>
                <Row style={{marginBottom:'20px'}}>
                    <Col span={4}>
                        <Col style={{fontSize:'14px',color:'#999'}}>资源数量</Col>
                        <Col style={{fontSize:'19px',color:'#5F5F5F'}}>1046</Col>
                    </Col>
                    <Col span={2}>
                        <Col span={24} style={{height:'24px'}}></Col>
                        <Col span={24}>
                            <span style={{fontSize:'14px',marginRight:'3px'}}>12</span>
                            <span><img src={imgs.img1} style={{width:'12px'}} alt=""/></span>
                        </Col>
                    </Col>
                    <Col span={6}></Col>
                    <Col span={12} style={{position:'relative'}}><img src={imgs.img2} style={{height:'46px',position:'absolute',right:'0px'}} alt=""/></Col>
                </Row>
                <Row>
                    <Table {...cfg}/>
                </Row>

            </Card>
        </div>
    }
}
