import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { tools } from "utils"
import Form from "antd/lib/form"
import Upload from "components/upload"
import Message from "antd/lib/message"
import PreviewDemo from "components/demo/previewDemo"
import { Enum, EnumCn } from "enum"
import "./uploadMaterialPic.less"
const FormItem = Form.Item;
// 上传图片组件
export default class UploadMaterialPic extends React.Component {
    constructor(props) {
        super(props);
        this.defValue = {
            isDetail:false,
        }
    }
    componentDidMount() {
    }
    render() {
        let { isDetail } = $.extend({},this.defValue,this.props);     
        return (
            <div>
                <div className="uploadpic-inline-container">
                    {this.getUploadJSX()}
                </div>
                <UploadAll 
                    style={{display: isDetail===false ? 'block' : 'none'}}
                    extension=".jpg|.png"
                    onErrorMessage={(error) => { tools.showDialog.error(error);}} 
                    onSuccess={this.onUploadAllSuccess.bind(this)}/>
            </div>     
        )
    }
    getUploadJSX() {
        let { form, imgSource} = this.props;
        let { isDetail } = $.extend({},this.defValue,this.props);
        let uploadpicCfg = {};
        let dataSource = imgSource ? imgSource.data : null;
        let uploadFields = dataSource ? Object.getOwnPropertyNames(dataSource) : null;
        let materialDataSource = {};
        const openPreSize = {
            wx_img: {
                width: 360,
                height: 200
            },
            banner_img: {
                width: 640,
                height: 240
            },
            feeds_img: {
                width: 200,
                height: 150
            },
            open_img: {
                width: 1242,
                height: 2208
            }
        };
        // 动态生成FieldPropJSX
        if (isDetail===false&&uploadFields) {
            let { getFieldProps } = form;
            return uploadFields.map((item, index) => {
                if (dataSource[item].show) {
                    let uploadpicProps = getFieldProps(`${item}`, {
                        initialValue: dataSource[item].url,
                        rules: [
                            { required: true, message: "请上传图片" },
                        ]
                    })
                    let patt = /\S*-[0-9]+$/;
                    let type = patt.test(item) ? item.substring(0, item.indexOf('-')) : item;
                    uploadpicCfg[`${item}`] = {
                        url: tools.javaApi("/uploadpic"),
                        previewUrl: form.getFieldsValue()[`${item}`],
                        measure: `${openPreSize[type].width}_${openPreSize[type].height}`,
                        description: `${openPreSize[type].width}×${openPreSize[type].height}`,
                        width: '150px',
                        height: '100px',
                        onSuccess: (data, res) => {
                            Message.success("上传成功");
                            let newFieldProp = {};
                            newFieldProp[`${item}`] = data.imageurl;
                            this.props.form.setFieldsValue(newFieldProp);
                        },
                        onErrorMessage: (error) => {
                            tools.showDialog.error(error);
                        }
                    }
                    switch (type) {
                        case "wx_img":
                            var msg = "微信图"; break;
                        case "banner_img":
                            var msg = "焦点图"; break;
                        case "feeds_img":
                            var msg = "信息流"; break;
                        case "open_img":
                            var msg = "启动屏"; break;
                    }
                    // TODO
                    // 区分不同平台上传框是否显示
                    //组件所需数据
                    materialDataSource[`${item}`] = {
                        wx_title: imgSource.title,
                        platform: `${type}` == "wx_img" ? [Enum.ProPlatform.weixin] :
                            `${type}` == "open_img" ? [Enum.ProPlatform.app2] :
                                `${type}` == "feeds_img" ? [Enum.ProPlatform.app1] :
                                    `${type}` == "banner_img" ? [Enum.ProPlatform.app3] : '',
                        wx_img: `${type}` == "wx_img" ? form.getFieldsValue()[`${item}`] : null,
                        banner_img: `${type}` == "banner_img" ? form.getFieldsValue()[`${item}`] : null,
                        feeds_img: `${type}` == "feeds_img" ? form.getFieldsValue()[`${item}`] : null,
                        open_img: `${type}` == "open_img" ? form.getFieldsValue()[`${item}`] : null,
                    }
                    return (
                        <div className="uploadpic-inline" key={`${item}`}>
                            <p className="uploadpic-msg">
                                {msg}
                            </p>
                            <FormItem required style={{marginBottom: "5px"}}>
                                <Upload
                                    {...uploadpicProps}
                                    {...uploadpicCfg[`${item}`]} />
                                <div style={!!form.getFieldsValue()[`${item}`] ? { "display": "block" } : { "display": "none" }}>
                                    <PreviewDemo {...this.props} dataSource={materialDataSource[`${item}`]} />&nbsp;&nbsp;&nbsp;&nbsp;
                                    <a onClick={this.resetUrl.bind(this, `${item}`)}>重置</a>
                                </div>
                            </FormItem>
                        </div>
                    )
                }
            })
        }
        else if(uploadFields) {
            return uploadFields.map((item, index) => {
                if (dataSource[item].show) {
                    let patt = /\S*-[0-9]+$/;
                    let type = patt.test(item) ? item.substring(0, item.indexOf('-')) : item;
                    switch (type) {
                        case "wx_img":
                            var msg = "微信图"; break;
                        case "banner_img":
                            var msg = "焦点图"; break;
                        case "feeds_img":
                            var msg = "信息流"; break;
                        case "open_img":
                            var msg = "启动屏"; break;
                    }
                    // TODO
                    // 区分不同平台上传框是否显示
                    //组件所需数据
                    materialDataSource[`${item}`] = {
                        wx_title: imgSource.title,
                        platform: `${type}` == "wx_img" ? [Enum.ProPlatform.weixin] :
                            `${type}` == "open_img" ? [Enum.ProPlatform.app2] :
                                `${type}` == "feeds_img" ? [Enum.ProPlatform.app1] :
                                    `${type}` == "banner_img" ? [Enum.ProPlatform.app3] : '',
                        wx_img: `${type}` == "wx_img" ? dataSource[`${item}`].url : null,
                        banner_img: `${type}` == "banner_img" ? dataSource[`${item}`].url : null,
                        feeds_img: `${type}` == "feeds_img" ? dataSource[`${item}`].url : null,
                        open_img: `${type}` == "open_img" ? dataSource[`${item}`].url : null,
                    }
                    let imgStyle = {
                        width: '150px',
                        height: '100px'
                    };
                    return (
                        <div className="uploadpic-inline" key={`${item}`}>
                            <p className="uploadpic-msg">
                                {msg}
                            </p>
                            <div className="sy-upload-detail">
                                <div
                                    className="sy-upload-preview"
                                    style={imgStyle}>
                                    {!!dataSource[`${item}`].url ?
                                        <img src={dataSource[`${item}`].url} className="img" />
                                        :
                                        <div className="noneImg">

                                        </div>
                                    }
                                </div>
                                <div style={!!dataSource[`${item}`].url ? { "display": "block" } : { "display": "none" }}>
                                    <PreviewDemo {...this.props} dataSource={materialDataSource[`${item}`]} />
                                </div>
                            </div>
                        </div>
                    )
                }
            })
        }
    }
    //重置
    resetUrl(item) {
        this.props.form.setFieldsValue({
            [item]: null,
        });
        $(ReactDOM.findDOMNode(this)).find("input[name='imgUpload']").val('');
    }
    //一键上传成功
    onUploadAllSuccess(data) {
        let { form, imgSource} = this.props;
        let dataSource = imgSource ? imgSource.data : null;
        let uploadFields = dataSource ? Object.getOwnPropertyNames(dataSource) : null;
        Message.success(`文件［${data.img_name}］上传成功`);
        let newFieldProp = {};
        let item;
        switch(data.img_size){
            case '360_200':
                item = $.map(uploadFields, (o, i)=>{
                    if(o && /wx_img/.test(o)){
                        return o;
                    }
                });
                break;
            case '640_240':
                item = $.map(uploadFields, (o, i)=>{
                    if(o && /banner_img/.test(o)){
                        return o;
                    }
                });
                break;
            case '200_150':
                item = $.map(uploadFields, (o, i)=>{
                    if(o && /feeds_img/.test(o)){
                        return o;
                    }
                });
                break;
            case '1242_2208':
                item = $.map(uploadFields, (o, i)=>{
                    if(o && /open_img/.test(o)){
                        return o;
                    }
                });
                break
        }
        if(item){
            newFieldProp[`${item}`] = data.imageurl;
            this.props.form.setFieldsValue(newFieldProp);
        }
    }
}

class UploadAll extends React.Component {
    render() {
        return (
            <div style={{...this.props.style}}>
                <a style={{fontSize: '13px'}} onClick={this.onClickUpload.bind(this)}>一键上传...</a>
                <input type="file" name="imgUploadAll" onChange={this.onFileChange.bind(this)} style={{ display: "none" }} multiple/>
            </div>
        )
    }
    // 点击上传按钮
    onClickUpload(){
        $(ReactDOM.findDOMNode(this)).find("input[name='imgUploadAll']").click();
    }
    //选择本地图片后执行
    onFileChange(e) {
        let files = e.target.files;
        if(files){
            $.map(files, (item, index) => {
                if (this._validate(item) === false) return;   // 校验单个文件是否合法
                var formdata = new FormData();
                formdata.append('imgcontent', item);
                formdata.append('measure', ['360_200', '640_240', '200_150', '1242_2208'].join());
                this._upload(formdata);
            })
        }
        //校验
        // if (this._validate(file) === false) return;
        // //以formdata格式上传
        // var formdata = new FormData();
        // formdata.append('imgcontent', file);
        // this.props.measure && formdata.append('measure', this.props.measure);
        // this._upload(formdata);
    }
    //上传
    _upload(data) {
        $.ajax({
            type: "post",
            url: tools.javaApi("/uploadpic"),
            data: data,
            processData: false,
            contentType: false,
            success: this._onSuccess.bind(this),
            error: this._onError.bind(this)
        })
    }
    //上传成功后事件
    _onSuccess(resp) {
        if (resp.code == 10000) {
            //成功
            //显示预览图
            let $preview = $(`#${resp.data.img_size}`);
            $preview.css("background-image", "url(" + resp.data.imageurl + ")");
            if (typeof this.props.onSuccess === "function") {
                return this.props.onSuccess.call(this, resp.data);
            }
        } else if (resp.code === 10001) {
            //失败
            this._getMessage(resp.msg);
        } else {
            this._getMessage("error response code")
        }
    }
    //上传失败后事件
    _onError(e) {
        this._getMessage(e);
        if (typeof this.props.onError === "function") {
            return this.props.onError.call(this, $.makeArray(arguments));
        }
    }
    //提交前校验
    _validate(file) {
        //size
        if (typeof this.props.maxSize === "number" && file.size > this.props.maxSize) {
            this._getMessage(`文件［${file.name}］大小超过限制`);
            return false;
        }
        //extension
        let ext = file.name.substring(file.name.lastIndexOf("."));
        if (typeof this.props.extension === "string" && $.inArray(ext.toLowerCase(), $.map(this.props.extension.split("|"), ex => ex.toLowerCase())) < 0) {
            this._getMessage(`文件［${file.name}］类型不符`);
            return false;
        }
        return true;
    }
    //错误提示框
    _getMessage(error) {
        if (typeof this.props.onErrorMessage === "function") {
            return this.props.onErrorMessage.call(this, error);
        }
    }
}