/**
 * Created by Yvan on 2017/3/20.
 */
import React from "react";

import Row from "antd/lib/row";
import Col from "antd/lib/col";
import Steps from "antd/lib/steps"
const Step = Steps.Step;

export default class MatterSteps extends React.Component {
    constructor(props) {
        super(props);
        this.state = {}
    }
    render() {
        const{stepList,current}=this.props;
        const stepJSX = stepList.map((step, i) => <Step key={i} title={step.title} />);
        return (
            <Row type="flex" justify="center" className="m-margin-b m-margin-t">
                <Col span="24" >
                    <Col span={6}></Col>
                    <Col span={12}>
                        <Steps current={current} size="small">{stepJSX}</Steps>
                    </Col>
                </Col>
            </Row>)
    }
}