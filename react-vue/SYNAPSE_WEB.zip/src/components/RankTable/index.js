import React,{Component} from "react"
import "./index.less"
export default class RankTable extends Component{
    constructor(props){
        super(props);
        this.state={
            data:props.data
        }
    }
    render(){
        return(
            <div className="rank-table-box">
                <div className="r-t-title">{this.props.title}</div>
                <table>
                    <tbody>
                    {
                        this.state.data.map((item,index)=>{
                            return(
                                <tr key={index}>
                                    <td><div className={index+1<4?"black-circle":"gray-circle"}>{index+1}</div><span>{item.name}</span></td>
                                    <td><span>{item.value}</span></td>
                                </tr>
                            );
                        })
                    }
                    </tbody>
                </table>
            </div>
        );
    }
}