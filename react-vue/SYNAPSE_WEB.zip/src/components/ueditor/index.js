import React from "react"
import ReactDOM from "react-dom"
import $ from "jquery"
// import { tools, ueditorConfig } from "utils"
import { tools } from "utils"
import { Enum, EnumCn } from "enum"

require("./ueditor.less")

const common_toolbar = [
    [
        'undo', 'redo', '|', 'fontsize', 'blockquote', 'horizontal',
        '|','removeformat', 'formatmatch', '|', 'source',
    ],
    [
        'bold', 'italic', 'table_underline', 'forecolor', 'backcolor', '|',
        'indent', 'justifyleft', 'justifycenter', 'justifyright',
        'justifyjustify', '|', 'rowspacingtop', 'rowspacingbottom',
        'lineheight',

    ],
    [
        'fontborder', 'strikethrough', 'autotypeset', 'pasteplain', '|', 'inserttable', '|', 'insertorderedlist',
        'insertunorderedlist',
    ],
    [
      'simpleupload', 'insertvideo', '|', 'imagenone', 'imageleft', 'imageright', 'imagecenter', '|', 'xiumi'
    ]
];

export default class _UEditor extends React.Component {
    constructor(props) {
        super(props);
        this.state =  {
            editor: null,
        }
    }
    componentWillReceiveProps(next) {
      const {editor} = this.state;
      if(!editor) return;
      editor.ready(()=>{
        // 点击编辑器内按钮时不刷新
        if(editor.isFocus()) return
        if ((this.props.contentType != next.contentType) || (this.props.content_wx != next.content_wx) || (this.props.content != next.content)) {
            const {contentType, content_wx, content} = next;
              if(contentType == Enum.NewsPlatform.weixin){
                editor.setContent(content_wx);
              } else if(contentType == Enum.NewsPlatform.app){
                editor.setContent(content);
              } else if(contentType == Enum.NewsPlatform.both){
                editor.setContent(content_wx);
              }
        }
        if(this.props.title.length == 0 && next.title.length != 0){
            const {title} = next;
            if(document.getElementById('editor-extend-title-input')){
              document.getElementById('editor-extend-title-input').value = title;
            }
        }
      });
    }
    componentDidMount() {
        // $.when(
        //   ueditorConfig.init()
        // ).done(
        //   () => {
        //     tools.insertSDK({
        //       name: "ueditorAll",
        //       src: "http://synapse-test.oss-cn-beijing.aliyuncs.com/ueditor/ueditor.all.js"}, () => {
        //         tools.insertSDK({
        //           name: "ueditorZhCn",
        //           src: "http://synapse-test.oss-cn-beijing.aliyuncs.com/ueditor/lang/zh-cn/zh-cn.js"}, () => {
                    const {id, contentType} = this.props;
                    if(!!window.UE) {
                        // var editorContent = document.createElement('script')
                        // editorContent.id = 'editor';
                        // editorContent.type = 'text/plain';
                        // editorContent.style.width = '1024px';
                        // editorContent.style.height = '500px';
                        // document.getElementsByClassName('editor-extent')[0].appendChild(editorContent)

                        // 编辑器增加秀米按钮
                        // 参见 http://blog.csdn.net/zzq900503/article/details/77050823
                        // 修改文件：oss -> synapse-static -> third_party_new 下的
                        // ueditor.all.js, 同步修改 ueditor.all.min.js 搜索 TODO synapse
                        // themes -> default -> css -> ueditor.css 搜索 TODO synapse
                        // themes -> default -> images 增加图片
                        
                        var editor = UE.getEditor(id, {
                            toolbars: common_toolbar,
                            labelMap: {'xiumi': '秀米'}
                        });

                        this.setState({
                            editor: editor
                        })

                        var editorExtendTitle = document.createElement('div');
                        editorExtendTitle.classList.add('editor-extend-title');
                        var editorExtendTitleInput = document.createElement('input');
                        editorExtendTitleInput.type = 'text';
                        editorExtendTitleInput.id = 'editor-extend-title-input';
                        editorExtendTitleInput.placeholder = '请在这里输入标题';
                        editorExtendTitle.appendChild(editorExtendTitleInput);

                        editor.ready(()=>{
                            document.getElementsByClassName('edui-editor-toolbarbox')[0].after(editorExtendTitle);
                            if (typeof this.props.onEditorReady === "function") {
                                return this.props.onEditorReady.call(this);
                            }
                        });
                        editor.addListener('blur',()=>{
                            this._onBlur(editor.getContent())
                        });
                    }
        //           })
        //       })
        //   }
        // )
      }
    componentWillUnmount() {
      // tools.removeSDK("ueditorAll");
      // tools.removeSDK("ueditorZhCn");
    }
    render() {
        return (
          <div className="editor-extent">
              <script id={this.props.id} type="text/plain" style={{width:"100%",height:"500px"}}></script>
          </div>
        )
    }
    //离开编辑器时执行
    _onBlur(value) {
        if (typeof this.props.onBlur === "function") {
            return this.props.onBlur.call(this, value);
        }
    }
}


_UEditor.defaultProps = {
}
