import React from "react"
import ReactDOM from "react-dom"
//doc：http://simditor.tower.im/
import Simditor from "simditor"
require("../../../node_modules/simditor/styles/simditor.css")
import "./editor.less"

export default class Editor extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            editor: null
        }
    }
    componentDidMount() {
        let editor = new Simditor({
            textarea: ReactDOM.findDOMNode(this)
        });
        //事件
        editor.on("valuechanged", (e) => {
            this._onChange(editor.getValue(), e);
        });
        this.setState({
            editor: editor
        })
    }
    componentWillReceiveProps(next) {
        if (this.props.value.length == 0 && next.value.length != 0) {
            //仅在请求完远端数据时赋值
            this.state.editor.setValue(next.value);
            this.state.editor.focus()
        }
    }

    render() {
        return (
            <textarea id={this.props.id} ></textarea>
        )
    }
    //值变更时执行
    _onChange(value, e) {
        if (typeof this.props.onChange === "function") {
            return this.props.onChange.call(this, value, e);
        }
    }
}