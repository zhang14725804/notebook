import {
    Card,
    Icon,
    DatePicker,
    Button,
    Divider,
    Radio,
    Select,
    Form,
    Tag
} from "antd"
import React, {Component} from "react"
import "./index.less"
import moment from "moment"
import $ from 'jquery'

const customPanelStyle = {
    border: 0,
    overflow: 'hidden',
};
const {RangePicker} = DatePicker;
const dateFormat = 'YYYY-MM-DD';
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const Option = Select.Option;
const FormItem = Form.Item;
const CheckableTag = Tag.CheckableTag;

/*
* 高级搜索
* dataItem:Array     所属类目
* resourceType:Array   资源类型下拉
* type:default(人群管理) document(文档库)
*
* 需要传入的方法
* 1.点击类目切换按钮 —— 所属类目切换方法 —— 传出类目value ——onChangeItem
* 2.点击查询按钮 —— 查询高级条件方法 —— 传出类目value和起止时间 ——onSeniorQuery
*/

class search extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpen: false,
            selectedTags: ["0"]
        }
        this.dataSource = {
            dataItem: [
                // {
                //     name: "全部",
                //     value: "0"
                // }, {
                //     name: "华北",
                //     value: "1"
                // }, {
                //     name: "华南",
                //     value: "2"
                // }
            ],
            resourceType: [
                // {
                //     name: "全部",
                //     value: "0"
                // }, {
                //     name: "华北",
                //     value: "1"
                // }, {
                //     name: "华南",
                //     value: "2"
                // }
            ],
            type: 'default'
        }
    }

    handleTagChange(value, checked) {
        const {selectedTags} = this.state;
        var nextSelectedTags = [];
        /* const nextSelectedTags = checked ?
             [...selectedTags, value] :
             selectedTags.filter(t => t !== value);
         console.log('You are interested in: ', nextSelectedTags);*/
        if (value === "0") {
            nextSelectedTags = checked ? [value] : []
        } else if (value !== "0" && this.state.selectedTags[0] === "0") {
            selectedTags.splice(selectedTags.indexOf("0"), 1);
            nextSelectedTags = checked ?
                [...selectedTags, value] :
                selectedTags.filter(t => t !== value);
        } else {
            nextSelectedTags = checked ?
                [...selectedTags, value] :
                selectedTags.filter(t => t !== value);
        }
        this.setState({selectedTags: nextSelectedTags});
    }

    render() {
        let isShow = this.state.isOpen ? 'block' : 'none';

        const dataSource = $.extend(true,
            this.dataSource,
            this.props.dataSource,
        );

        const RadioJSX = dataSource.dataItem.map((item, index) => {
            // return <RadioButton value={item.value} key={index}>{item.name}</RadioButton>
            return <CheckableTag
                key={item.value}
                checked={this.state.selectedTags.indexOf(item.value) > -1}
                onChange={checked => this.handleTagChange(item.value, checked)}>
                {item.name}
            </CheckableTag>
        });

        const SelectJSX = dataSource.resourceType.map((item, index) => {
            return <Option value={item.value} key={index}>{item.name}</Option>
        });

        const {getFieldDecorator} = this.props.form;
        return (
            <div className="advSearch">
                <Form layout="inline">
                    <div className="advSearch-item">
                        <FormItem>
                            <span style={{fontSize:"14px"}}>所属类目：</span>{getFieldDecorator('selectCategory', {
                            initialValue: "0"
                        })(
                            <RadioGroup onChange={this.onChange.bind(this)}>
                                {RadioJSX}
                            </RadioGroup>
                        )}
                        </FormItem>
                        <span className="rt openBtn" onClick={this.onCollapse.bind(this)}>
                        <a>{this.state.isOpen ? "收起" : "展开"}</a>&nbsp;
                            <a className={this.state.isOpen ? "anticon anticon-down" : "anticon anticon-right"}></a>
                    </span>
                    </div>
                    <Divider dashed style={{display: isShow}}/>
                    <div className="advSearch-form" style={{display: isShow}}>
                        <FormItem style={{display: dataSource.type == 'document' ? 'inline-block' : 'none'}}>
                            资源类型：{getFieldDecorator('selectType', {
                            // rules: [{ required: true, message: "请选择资源类型" }],
                        })(
                            <Select placeholder="请选择" style={{width: 200, marginRight: "20px"}}
                                    onChange={this.handleChange.bind(this)}>
                                {SelectJSX}
                            </Select>
                        )}
                        </FormItem>
                        <FormItem>
                            <span style={{fontSize:"14px"}}>日期：</span>{getFieldDecorator('selectDate', {
                            rules: [{required: true, message: "请选择起止日期"}],
                        })(
                            <RangePicker onChange={this.dateChange.bind(this)}/>
                        )}
                        </FormItem>
                        <FormItem className="rt">
                            <Button type="primary" onClick={this.onSearch.bind(this)}>查 询</Button>
                            <Button className="reset" onClick={this.onReset.bind(this)}>重 置</Button>
                        </FormItem>
                    </div>
                </Form>
            </div>
        )
    }

    //点击展开
    onCollapse() {
        this.setState({
            isOpen: !this.state.isOpen
        })
    }

    //切换所属类目
    onChange(e) {
        if (typeof this.props.onChangeItem === "function") {
            this.props.onChangeItem.call(this, e.target.value);
        }
    }

    //select框
    handleChange(value) {
        // console.log("value", value);
    }

    //日期选择框
    dateChange(date, dateString) {
        // console.log(date, dateString);
    }

    //点击查询
    onSearch() {
        this.props.form.validateFields((err, values) => {
            if (!err) {
                let obj = {
                    status: values.selectCategory,
                    start: values.selectDate[0].format('X'),
                    end: values.selectDate[1].format('X'),
                }
                if (typeof this.props.onSeniorQuery === "function") {
                    this.props.onSeniorQuery.call(this, obj);
                }
                console.log('Received values of form: ', obj);
            }
        });
    }

    //点击重置
    onReset() {
        this.props.form.resetFields();
    }
}

const AdvSearch = Form.create()(search);
export default AdvSearch;