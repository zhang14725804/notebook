import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import AppRouter from "./router"
import { Provider } from "react-redux"
import LocaleProvider from "antd/lib/locale-provider"

//import DevTools from "../devTools"
import configureStore from "./store"
import "./assets/style/index.less"
import zhCN from 'antd/lib/locale-provider/zh_CN';

const store = configureStore();


class Root extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <LocaleProvider locale={zhCN}>
        <Provider store={store}>
          <div>
            <AppRouter store={store} />
          </div>
        </Provider>
      </LocaleProvider>
    )
  }
}
//  { (process.env.NODE_ENV === "production") ? null : <DevTools /> }
ReactDOM.render(<Root />, document.getElementById("p_app"))


