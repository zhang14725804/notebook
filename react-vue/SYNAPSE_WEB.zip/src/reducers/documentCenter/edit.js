import Immutable from "immutable"
import {
    RESET_DOCUMENT_CENTER_EDIT,
    GET_DC_RELATED_BRAND,
    GET_DOCUMENT_THERAPEUTICAREA,
    GET_DC_KEYMESSAGE,
    GET_PREVIEW_IMG,
    SAVE_FILE,
    SAVE_CHECKED_TAGKEYS,
    SAVE_DC_CONFIG,
    GET_DC_RELATED_TREE,
    GET_DC_RELATED_TREE_TRUE,
    UPDATE_DOCUMENT_CENTER_CHECKED,
    GET_ALL_PRODUCT,
    GET_ALL_TA,
    GET_ALL_KMSG,
    GET_EDIT_NEWS,
    GET_DETAIL_NEWS,
    SAVE_NEWS_PREVIEW,
    GET_NEWS_PREVIEW_DETAIL,
    SAVE_DOCUMENT_CENTER_EXPIRE,
    ADD_DOCUMENT_CENTER_IMAGETEXT,
    UPDATE_DOCC_WX_INTRODUCTION,
    UPDATE_DOCC_WX_INDEX,
    GET_HTML_TYPE,
    SAVE_DC_HTML_URL,
    SAVE_PAGE_KEY_INFO,
    SAVE_PAGE,
    GET_EDIT_WX_NEWS,
    GET_DETAIL_WX_NEWS,
    SAVE_EQUAL_TREE_DATA,
    GET_DC_CONFIG_DETAIL,
    GET_TOP_FOLDER_RELATION,
    SAVE_UPLOAD_STATUS,
    // QA
    SET_DC_QUESTION,
    REMOVE_DC_QA_OPTION,
    UPDATE_DC_QA_OPTION_CONTENT,
    UPDATE_DC_QA_RADIO_STATE,
    UPDATE_DC_QA_CHECKBOX_STATE,
    RESET_DC_QUESTION,
    // VOL
    GET_DC_VOL_MUDU_ACCOUNT,
} from "actionType"
import { Enum } from "enum"

let initState = Immutable.fromJS({
    // DCConfig: {
    //     brand_ids: [],
    //     cover_image: "",
    //     expire: null,
    //     expire_time: null,
    //     feedback: true,
    //     file_name: "",
    //     file_size: 0,
    //     folder_id: 0,
    //     introduction: "",
    //     name: "",
    //     share_scopes: [],
    //     therapeutic_area_ids: [],
    //     use_scopes: [],
    //     water_mark: "",
    //     type: "1"
    // },
    DCConfig: [],
    relaAreaAndBrand: {
        brand: [],
        therapeutic_area: []
    },
    brands: [],
    therapeutic: [],
    keyMessage: [],
    previewImg: [],
    file: [],
    tagkeys: [],
    relatedTree: [],
    relatedTreeTrue: [],
    checked: 1,
    news: [{
        brands: [],
        document_id: null,
        feedback: false,
        id: 1,
        introduction: "",
        key_messages: [],
        labels: [],
        material: {
            title: "",
            author: "",
            content: ""
        },
        share_scope: '',
        therapeutic_areas: [],
        use_scope: '',
        water_mark: "1",
        expire_time: null,
        avater: ""
    }],
    //微信
    wx_news: [{
        brands: [],
        cover_image: "",
        feedback: true,
        introduction: "",
        key_messages: [],
        labels: [],
        material: {
            title: "",
            author: "",
            content: ""
        },
        therapeutic_areas: [],
        use_scope: '',
        share_scope: '',
        water_mark: "1",
    }],
    allProduct: [],
    allTa: [],
    allkp: [],//信息点
    expire: false,
    htmlType: 1,
    uploadStatus: false,
    htmlURL: "",
    pageKeyInfo: [
        { km: [] }
    ],
    equalTreeData: [],
    qa: {//问卷
        //问卷题目增量
        add: [],
        up: [],
        del: [],
        //qa
        title: "",
        desc: "",//描述
        image: "",
        status: Number(Enum.QAState.draft.toString()),
        question: [],

        //relates
        drug_ids: [],
        ta_ids: [],
        km_ids: [],
    },
    question: {//单个问题
        question_id: "",
        head: "",
        type: Enum.QuestionType.radio,
        order: -1,
        score: null, //分值
        options: [
            // {
            //     id: "1",
            //     content: "选项1",
            //     isRight: true
            // }
        ]
    },
    // 直播
    muduAccount: {}
});

export default (state = initState, action) => {
    switch (action.type) {
        case GET_NEWS_PREVIEW_DETAIL:
            return _getNewsPreviewDetail(state, Immutable.fromJS(action.data))//GET_EDIT_NEWS, GET_DETAIL_NEWS
        case SAVE_NEWS_PREVIEW:
            return _saveNewsPreview(state, Immutable.fromJS(action.data));
        case GET_EDIT_NEWS:
            return _getAppNewsEdit(state, Immutable.fromJS(action.data));
        case GET_EDIT_WX_NEWS:
            return _getWXNewsEdit(state, Immutable.fromJS(action.data));
        case GET_ALL_KMSG:
            return _getAllKeyMsg(state, Immutable.fromJS(action.data));
        case GET_ALL_TA:
            return _getAllTa(state, Immutable.fromJS(action.data));
        case GET_ALL_PRODUCT:
            return _getAllProduct(state, Immutable.fromJS(action.data));
        case SAVE_DC_CONFIG:
            return _saveDCConfig(state, Immutable.fromJS(action.data));
        case GET_DC_CONFIG_DETAIL:
            return _getDCConfigDetail(state, Immutable.fromJS(action.data));
        case RESET_DOCUMENT_CENTER_EDIT:
            return initState;
        case GET_TOP_FOLDER_RELATION:
            return _getTopFolderRelation(state, Immutable.fromJS(action.data));
        case GET_DC_RELATED_BRAND:
            return _getDCRelatedBrand(state, Immutable.fromJS(action.data));
        case GET_DC_RELATED_TREE:
            return _getDCRelatedTree(state, Immutable.fromJS(action.data));
        case GET_DC_RELATED_TREE_TRUE:
            return _getDCRelatedTreeTrue(state, Immutable.fromJS(action.data));
        case GET_DOCUMENT_THERAPEUTICAREA:
            return _getTherapeuticArea(state, Immutable.fromJS(action.data));
        case GET_DC_KEYMESSAGE:
            return _getKeyMessage(state, Immutable.fromJS(action.data));
        case GET_PREVIEW_IMG:
            return _getPreviewImg(state, Immutable.fromJS(action.data));
        case SAVE_FILE:
            return _saveFile(state, Immutable.fromJS(action.data));
        case SAVE_CHECKED_TAGKEYS:
            return _saveCheckedTagkeys(state, Immutable.fromJS(action.data));
        case UPDATE_DOCUMENT_CENTER_CHECKED:
            return _UpdateChecked(state, action.data);
        case GET_HTML_TYPE:
            return _getHtmlType(state, action.data);
        case SAVE_UPLOAD_STATUS:
            return _saveUploadStatus(state, action.data);
        case SAVE_EQUAL_TREE_DATA:
            return _saveEqualTreeData(state, action.data);
        case SAVE_DC_HTML_URL:
            return _saveHtmlURL(state, action.data);
        case SAVE_PAGE_KEY_INFO:
            return _savePageKeyInfo(state, action.data);
        case SAVE_DOCUMENT_CENTER_EXPIRE:
            return _saveExpire(state, action.data);
        case SAVE_PAGE:
            return _savePage(state);
        case ADD_DOCUMENT_CENTER_IMAGETEXT:
            return _addImageText(state);
        case UPDATE_DOCC_WX_INTRODUCTION:
            return _updateWXNews(state, action.data);
        case UPDATE_DOCC_WX_INDEX:
            return _updateWXIndex(state, action.data);
        case SET_DC_QUESTION:
            return _setQuestion(state, Immutable.fromJS(action.data));
        case REMOVE_DC_QA_OPTION:
            return _removeOption(state, Immutable.fromJS(action.data));
        case UPDATE_DC_QA_OPTION_CONTENT:
            return _updateOptContent(state, Immutable.fromJS(action.data));
        case UPDATE_DC_QA_RADIO_STATE:
            return _updateRadioState(state, Immutable.fromJS(action.data));
        case UPDATE_DC_QA_CHECKBOX_STATE:
            return _updateCheckboxState(state, Immutable.fromJS(action.data));
        case GET_DC_VOL_MUDU_ACCOUNT:
            return _getMuduAccount(state, Immutable.fromJS(action.data))
        case RESET_DC_QUESTION:
            return _resetQuestion(state);
        default:
            return state
    }
}

function _getAllProduct(state, data) {
    // let products = data.get("data");
    // console.log("====data",products)
    // products = products.map(product => {
    //     return product
    //         .set("id", product.toJS().id.toString())
    // })
    return state.set("allProduct", data);
}

function _getAllTa(state, data) {
    // let tas = data.get("data");
    // tas = tas.map(ta => {
    //     return ta
    //         .set("id", ta.toJS().id.toString())
    // })
    return state.set("allTa", data);
}
function _getAllKeyMsg(state, data) {
    return state.set("allkp", data);
}
function _getAppNewsEdit(state, data) {
    return state.set("news", data);
}
function _getWXNewsEdit(state, data) {
    return state.set("wx_news", data);
}

function _UpdateChecked(state, data) {
    return state.set("checked", data);
}

function _getHtmlType(state, data) {
    return state.set("htmlType", data);
}

function _saveUploadStatus(state, data) {
    return state.set("uploadStatus", data);
}

function _saveEqualTreeData(state, data) {
    return state.set("equalTreeData", data);
}

function _saveHtmlURL(state, data) {
    return state.set("htmlURL", data);
}

function _savePage(state) {
    let stateJs = state.toJS();
    stateJs.pageKeyInfo.push({ km: [] })
    return Immutable.fromJS(stateJs);
}
function _savePageKeyInfo(state, data) {
    let { index, keyInfo } = data;
    let stateJs = state.toJS();
    stateJs.pageKeyInfo[index].km = keyInfo;
    return Immutable.fromJS(stateJs);
}

function _saveExpire(state, data) {
    return state.set("expire", data);
}

function _getTopFolderRelation(state, data) {
    return state.set("relaAreaAndBrand", data);
}

function _getDCRelatedBrand(state, data) {
    return state.set("brands", data);
}

function _getDCRelatedTree(state, data) {
    return state.set("relatedTree", data);
}

function _getDCRelatedTreeTrue(state, data) {
    return state.set("relatedTreeTrue", data);
}

function _getTherapeuticArea(state, data) {
    return state.set("therapeutic", data);
}

function _getKeyMessage(state, data) {
    return state.set("keyMessage", data);
}

function _getPreviewImg(state, data) {
    return state.set("previewImg", data);
}

function _saveDCConfig(state, value) {
    return state;
}

function _saveFile(state, data) {
    return state.set("file", data);
}

function _saveCheckedTagkeys(state, data) {
    return state.set("tagkeys", data);
}

function _getDCConfigDetail(state, data) {
    return state.mergeDeepWith((prev, next) => next === undefined ? prev : next, { "DCConfig": data });
}
// function _getDCConfig(state, product) {
//   return state.mergeDeepWith((prev, next) => next === undefined ? prev : next, { "DCConfig": product });
// }

function _saveNewsPreview(state) {
    return state;
}

function _getNewsPreviewDetail(state, news) {
    return state;
}

//添加一组图文
function _addImageText(state, news) {
    let stateJS = state.toJS();
    stateJS.wx_news.push({
        brands: [],
        feedback: false,
        introduction: "",//导语
        key_messages: [],
        labels: [],
        material: {
            title: "",
            author: "",
            content: ""
        },
        share_scopes: '',
        therapeutic_areas: [],
        use_scopes: '',
        water_mark: "1",
        cover_image: ""//封面
    });
    return Immutable.fromJS(stateJS);
}
//更新导语
function _updateWXNews(state, data) {
    let { index, value, type } = data;
    let stateJs = state.toJS();
    if (type == 'introduction') {
        stateJs.wx_news[index].introduction = value;
    } else if (type == 'author') {
        stateJs.wx_news[index].material.author = value;
    } else if (type == 'brand') {
        stateJs.wx_news[index].brands = value;
    } else if (type == 'therapeutic') {
        stateJs.wx_news[index].therapeutic_areas = value;
    } else if (type == 'km') {
        stateJs.wx_news[index].key_messages = value;
    } else if (type == 'label') {
        stateJs.wx_news[index].labels = value;
    }
    return Immutable.fromJS(stateJs);
}

function _UpdateNorms(state, data) {
    let { index, value, type } = data;
    let stateJs = state.toJS();
    if (type == 'spec') {
        stateJs.product.specification[index].spec = value;
    } else if (type == 'price') {
        stateJs.product.specification[index].price = value;
    } else if (type == 'rate') {
        stateJs.product.specification[index].rate = value;
    }
    return Immutable.fromJS(stateJs);
}
function _updateWXIndex(state, data) {
    return state.set("wx_news", data);
}

// 问卷
function _getQA(state, qa) {
    qa = qa
        .set("question", qa.get("question").map(a => a
            .set("head", JSON.parse(a.get("head")).head)
            .set("options", JSON.parse(a.get("head")).options)
        ))
        .set("drug_ids", qa.getIn(["relates", "product"], Immutable.List()).map(item => item.get("id").toString()))
        .set("ta_ids", qa.getIn(["relates", "ta"], Immutable.List()).map(item => item.get("id").toString()))
        .set("km_ids", qa.getIn(["relates", "keyword"], Immutable.List()).map(item => item.get("id").toString()))
    return state.set("qa", qa);
}

function _setQuestion(state, value) {
    return state.updateIn(["question"], function (q) { return q.merge(value); });
}

function _removeOption(state, value) {
    return state.updateIn(["question", "options"], function (arr) {
        return arr.filter((a) => a.get("id") != value);
    });
}

function _updateOptContent(state, opt) {
    return state.updateIn(["question", "options"], function (arr) {
        return arr.map((a) => a.get("id") === opt.get("id") ? a.set("content", opt.get("value")) : a);
    });
}

function _updateRadioState(state, chkKey) {
    return state.updateIn(["question", "options"], function (arr) {
        return arr.map((a) => a.set("isRight", a.get("id") === chkKey ? !a.get("isRight") : false));
    });
}

function _updateCheckboxState(state, chkKey) {
    return state.updateIn(["question", "options"], function (arr) {
        return arr.map((a) => a.get("id") === chkKey ? a.set("isRight", !a.get("isRight")) : a);
    });
}

function _resetQuestion(state) {
    return state.set("question", initState.get("question"));
}

// 直播
function _getMuduAccount(state, data){
    return state.set("muduAccount", data);
}


