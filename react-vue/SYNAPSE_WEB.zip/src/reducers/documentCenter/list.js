import Immutable from "immutable"
import {Enum} from "enum"
import {tools} from "utils"

import {
  GET_DOCUMENT_CENTER_LIST,
  GET_DOCUMENT_CENTER_LIST_BYSEARCH,
  RESET_DOCUMENT_CENTER_LIST,
  UPDATE_DOCUMENT_CENTER_LIST_CONDITIONS,
  SAVE_SELECTED_DOCUMENTCENTER_KEYS,
  RENAME_DOCUMEMT,
  DELETE_DOCUMENT,
  GET_PREVIEW_IMG,
  OPERATE_TOP_FOLDER,
  GET_TOP_FOLDER,
  ADD_FOLDER,
  GET_DC_ANCESTOR_LIST,
  GET_DC_RELATED_BRAND,
  GET_DC_EMP_BRAND,
  GET_DC_RELATED_TREE,
  SAVE_DOCUMNENT_CONDITIONS_TEMP,
  GET_DOCUMENT_THERAPEUTICAREA,
  SET_CHECKED_DOCUMENT,
  DOWNLOAD_DOCUMENT,
  UPDATE_DOCUMENT_LIST_CONDITIONS,
  CHANGE_SEARCH_LABELID
} from "actionType"

var _isString = function (param) {
    return Object.prototype.toString.call(param) === '[object Array]'
};

let initState = Immutable.fromJS({
    conditions: {
        id: "0",
        // value: "",
        page_index: 1,
        page_size: tools.listPageSize,
        // area_ids: [],    
        // brand_ids: [],
        // end_time: "",
        // label_ids: [],
        // start_time: "",
        // share_scope: [],
        // use_scope:  [],
        // enabled: null,
        // overdue: null,
        // suffix: ""
    },
    conditionsSearch: {
        id: "0",
        value: "",
        page_index: 1,
        page_size: tools.listPageSize,
        area_ids: null,    
        brand_ids: null,
        end_time: null,
        label_ids: null,
        start_time: null,
        share_scope: null,
        use_scope:  null,
        enabled: null,
        overdue: null,
        suffix: ""
    },
    tempConditions: {
        id: "0",
        value: "",
        page_index: 1,
        area_ids: null,    
        brand_ids: null,
        end_time: null,
        label_ids: null,
        start_time: null,
        share_scope: null,
        use_scope:  null,
        page_size: tools.listPageSize,
        enabled: null,
        overdue: null,
        suffix: ""
    },
    documentCenterList: {
        list: [],
        total: 0
    },
    selectedKeys:[],
    ancestorList: [],
    brands: [],
    empBrands: [],
    area_ids: [],
    checkedInfos: [],
    previewImgH5: [],
    topFolder: {
        folder_name: "",
        brand_ids: [],
        therapeutic_area_ids: []
    }
});

export default (state = initState, action) => {
    switch (action.type) {
        case GET_DOCUMENT_CENTER_LIST:
            return _getDocumentCenterList(state, Immutable.fromJS(action.data));
        case GET_DOCUMENT_CENTER_LIST_BYSEARCH:
            return _getDocumentCenterListBySearch(state, Immutable.fromJS(action.data));
        case RESET_DOCUMENT_CENTER_LIST:
            return initState;
        case UPDATE_DOCUMENT_CENTER_LIST_CONDITIONS:
            return _updateDocumentCenterListConditions(state, Immutable.fromJS(action.data));
        case CHANGE_SEARCH_LABELID:
            return _changeSearchLabelId(state, Immutable.fromJS(action.data));
        case UPDATE_DOCUMENT_LIST_CONDITIONS:
            return _updateDocumentListConditions(state, Immutable.fromJS(action.data));
        case SAVE_SELECTED_DOCUMENTCENTER_KEYS:
            return _saveSelectedKeys(state, Immutable.fromJS(action.data));
        case RENAME_DOCUMEMT:
            return _renameDocument(state, Immutable.fromJS(action.data));
        case DELETE_DOCUMENT:
            return _deleteDocument(state, Immutable.fromJS(action.data));
        case ADD_FOLDER:
            return _addFolder(state, Immutable.fromJS(action.data));
        case OPERATE_TOP_FOLDER:
            return _operateTopFolder(state, Immutable.fromJS(action.data));
        case GET_TOP_FOLDER:
            return _getTopFolder(state, Immutable.fromJS(action.data));
        case GET_DC_ANCESTOR_LIST:
            return _getAncestorList(state, Immutable.fromJS(action.data));
        case GET_DC_RELATED_BRAND:
            return _getDCListRelatedBrand(state, Immutable.fromJS(action.data));
        case GET_DC_EMP_BRAND:
            return _getDCEmpBrand(state, Immutable.fromJS(action.data));
        case SET_CHECKED_DOCUMENT:
            return _setCheckedDocument(state, Immutable.fromJS(action.data));
        case GET_DOCUMENT_THERAPEUTICAREA:
            return _getDCListTherapeuticarea(state, Immutable.fromJS(action.data));
        case GET_DC_RELATED_TREE:
            return _getDCListRelatedTree(state, Immutable.fromJS(action.data));
        case SAVE_DOCUMNENT_CONDITIONS_TEMP:
            return _saveDocumentConditionsTemp(state, Immutable.fromJS(action.data));
        case DOWNLOAD_DOCUMENT:
            return _downloadDocument(state, Immutable.fromJS(action.data));
        case GET_PREVIEW_IMG:
            return _getPreviewImg(state, Immutable.fromJS(action.data));
        default:
            return state 
    }
}


function _getDocumentCenterList(state, data) {
    console.log('--documentCenterList data --', data.toJS());
    return state.set("documentCenterList",data);
}

function _getDocumentCenterListBySearch(state, data) {
    return state.set("documentCenterList",data);
}

function _updateDocumentCenterListConditions(state, cdt) {
    //取出state更新前代表label标签的数组
    let label_ids = state.getIn(['conditionsSearch', 'label_ids']);
    //如果不为bull的话将其转化为js赋值给label_ids_tojs
    let label_ids_tojs = label_ids && label_ids.toJS();
    //判断更新后的state中是否选中了标签
    if(cdt && cdt.toJS().label_ids && cdt.toJS().label_ids.length > 0){
        //如果更新前的state有值，并且它的数组长度大于更新后的state标签的数组长度
        if(label_ids_tojs && (label_ids_tojs.length > cdt.toJS().label_ids.length)) {
            //将原来state中的标签值置为null
            state = state.setIn(['conditionsSearch', 'label_ids'],null)
        }
    }
    return state.mergeDeepWith((prev, next) => next === undefined ? prev : next, { conditionsSearch: cdt });
}
function _changeSearchLabelId(state, cdt) {
    // console.log("---reducer中的conditionsSearch----",cdt.toJS())
    return state.mergeDeepWith((prev, next) => next === undefined ? prev : next, { conditionsSearch: cdt });
}

function _updateDocumentListConditions(state, cdt) {
    // TODO 参见 _updateDocumentCenterListConditions 少的merge多的会出问题，需要单独处理
    return state.mergeDeepWith((prev, next) => next === undefined ? prev : next, { conditions: cdt });
}

function _saveDocumentConditionsTemp(state, cdt) {
    let oState = state.toJS();
    oState.tempConditions.label_ids = cdt.toJS().label_ids;
    return Immutable.fromJS(oState).mergeWith((prev, next) => next === undefined ? prev : next, { tempConditions: cdt });

}

function _saveSelectedKeys(state, chkKeys){
     return state.set("selectedKeys", chkKeys);
}

function _getDCListRelatedBrand(state, data){
     return state.set("brands", data);
}

function _getDCEmpBrand(state, data){
     return state.set("empBrands", data);
}

function _setCheckedDocument(state, data){
     return state.set("checkedInfos", data);
}

function _getDCListTherapeuticarea(state, data){
     return state.set("area_ids", data);
}

function _getDCListRelatedTree(state, data){
     return state.set("trees", data);
}

function _renameDocument(state, data){
     return state;
}

function _deleteDocument(state, data){
     return state;
}

function _addFolder(state, data){
     return state;
}

function _operateTopFolder(state, data){
     return state;
}

function _getTopFolder(state, data){
     return state.set("topFolder", data);
}
function _downloadDocument(state, data){
     return state;
}

function _getAncestorList(state, data){
     return state.set("ancestorList", data);
}

function _getPreviewImg(state, data){
     return state.set("previewImgH5", data);
}

