import Immutable  from "immutable";
import {tools} from "utils"
import {Enum} from "enum"
import {
	GET_KP_SRC,
	GET_KP_INFO,
	SET_KPID,
	RESET_KP_DETAIL,
	SET_SEARCH_CONDITION_KPSRC,
	GET_KP_OVERVIEWS,
	GET_KP_TREND} from  "actionType"

let initState = Immutable.fromJS({
	//keyword_id: "",
	kp: {
		id: "",
		create_user: {
			nickname: ""
		},
		description: "",
		ctime: new hDate(),
		keyword: "",
		relate_essay_total: 0,
		relate_product: [],
		relate_ta: [],
		status: Enum.KpState.disable,
		update_time: new hDate()
	},
	kpsrc: {
		data: [],
		total: 0
	},
	searchCondition: {
		keyword_id: "",
		page: 1,
		count: tools.listPageSize
	},
	//数据统计
    summary: {
        trend_condition: {
			keypoint_id: "",
            range: Enum.ChartTime.today.toString(),
            type: [Enum.ChartTarget.pv.toString()]
        },
        info: {
            relates_essay: 0,   //被引用的文档
            relates_qa: 0,      //被引用的问卷
            relates_vod: 0, //被引用的点播
            relates_lvb: 0 //被引用的直播
        },
        trend_data: []
    }
});

export default function keypointEdit(state = initState, action) {
	switch (action.type) {
		case GET_KP_SRC:
			return _getkpSRC(state, Immutable.fromJS(action.data));
		case GET_KP_INFO:
			return _getkpInfo(state, Immutable.fromJS(action.data))
		case RESET_KP_DETAIL:
			return initState;
		case SET_SEARCH_CONDITION_KPSRC:
			return _setSearchCondition_kpsrc(state, Immutable.fromJS(action.data))
		case GET_KP_OVERVIEWS:
			return _getOverview(state, Immutable.fromJS(action.data));
		case GET_KP_TREND:
			return _getTrend(state, Immutable.fromJS(action.data));
		default:
			return state;
	}
}


function _getkpSRC(state, list) {
	return state.set("kpsrc", list);
}

function _getkpInfo(state, data) {
	return state.set("kp", data);
}

function _setSearchCondition_kpsrc(state, cdt) {
	return state.mergeDeepWith((prev, next) => next === undefined ? prev : next, { searchCondition: cdt });
}

function _getOverview(state, data) {
    return state.setIn(["summary", "info"], data);
}

function _getTrend(state, list) {
    return state.setIn(["summary", "trend_data"], list);
}
