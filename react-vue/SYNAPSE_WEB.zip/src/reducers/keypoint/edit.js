import Immutable from "immutable";
import {
	SAVE_KP,
	GET_EDIT_KP,
	RESET_KP_EDIT
} from "actionType"
import { Enum } from "enum"

let initState = Immutable.fromJS({
	kp: {
		keyword: "",
		description: "",
		status: false,
		relate_product: [],
		relate_ta: []
	},
	kpNameProps: "",
	kpDescriptProps: ""
});

export default function keypointEdit(state = initState, action) {
	switch (action.type) {
		case SAVE_KP:
			return _saveKP(state);
		case GET_EDIT_KP:
			return _getKp(state, Immutable.fromJS(action.data));
		case RESET_KP_EDIT:
			return initState;
		default:
			return state;
	}
}

function _editKP(state, value) {
	return state;
}


function _saveKP(state) {
	return state;
}


function _getKp(state, data) {
	data = data
		.set("status", data.get("status") == Enum.KpState.enable)
		.set("relate_product", data.get('relate_product').map(product => {
			return product
				.set("id", product.toJS().id.toString()) //option要求value是string类型，因此此处将id转为string
		}))
		.set("relate_ta", data.get('relate_ta').map(ta => {
			return ta
				.set("id", ta.toJS().id.toString()) //option要求value是string类型，因此此处将id转为string
		}))
	return state.set("kp", data);
}
