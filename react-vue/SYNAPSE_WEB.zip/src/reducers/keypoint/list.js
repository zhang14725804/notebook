import Immutable from  "immutable"
import {tools} from "utils"
import {
	RESET_KP_LIST,
	GET_KP_LIST,
	UPDATE_KP_CONDITION,
	CHANGE_KP_STATE,
	SET_CHECKED_KP,
	DEL_KP,
} from "actionType"
import {Enum} from "enum"


//初始state
let initState = Immutable.fromJS({
	condition: {
		type: Enum.SearchType.simple,
		key: {
			title: "",
			ta_name: "",
			cn_name: "",
			start: "",
			end: ""
		},
		page: 1,
		count: tools.listPageSize,
		order: "ctime",
		order_type: Enum.OrderType.desc
	},
    chkKeypoint: [],
    kpList: {
		data: [],
		count: 0   
	}
});


export default function keypoint(state = initState, action) {
	switch (action.type) {
		case GET_KP_LIST:
			return _getKpList(state, Immutable.fromJS(action.data));
		case UPDATE_KP_CONDITION:
			return _updateCdt(state, Immutable.fromJS(action.data));
		case SET_CHECKED_KP:
			return _setChkKp(state, Immutable.fromJS(action.data))
		case CHANGE_KP_STATE:
			return _changeKpState(state)
		case DEL_KP:
			return _delKeypoint(state)
		case RESET_KP_LIST:
			return initState;
		default:
			return state
	}
}


function _getKpList(state, value) {
	return state.set("kpList", value);
}

function _updateCdt(state, value) {
	return state.mergeDeepWith((prev, next) => next === undefined ? prev : next, { condition: value });
}


function _delKeypoint(state) {
	return state;
}


function _setChkKp(state, data) {
	return state.set("chkKeypoint", data);
}


function _changeKpState(state) {
	return state;
}
