import Immutable from "immutable"
import {
    GET_OVERVIEWS,
    GET_TREND,
    UPDATE_TREND_CONDITIONS,
    GET_DISTRIBUTION,
    UPDATE_DISTRIBUTION_CONDITIONS,
    RESET_OVERVIEW,
    GET_RELATE_FREQ,
    GET_INCLUDING_FREQ,
    GET_CONCENTRATE,
    UPDATE_FREQ_RELATE,
    UPDATE_FREQ_INCLUDING
} from "actionType"
import { Enum } from "enum"
const initState = Immutable.fromJS({
    info_condition: Enum.StatisticTime.today.toString(),
    trend_condition: {
        range: Enum.ChartTime.today.toString(),
        type: [Enum.ChartTarget.pv.toString()]
    },
    distribute_condition: {
        range: Enum.ChartTime.today.toString(),
        type: Enum.ChartTarget.pv.toString()
    },
    freq_relate: Enum.ChartRelateType.product.toString(),
    freq_including: Enum.ChartCoverageType.docLevel.toString(),

    //data_source
    info: {
        cover_count: 0,
        total_cost: 0,
        cover_user: 0,
        new_user: 0
    },
    trend_data: [],
    distribute_data: [],
    freq_relate_data: [],
    freq_including_data: [],
    concentrate_data: []
});


export default (state = initState, action) => {
    switch (action.type) {
        case GET_OVERVIEWS:
            return _getOverViews(state, Immutable.fromJS(action.data));
        case GET_TREND:
            return _getTrend(state, Immutable.fromJS(action.data));
        case UPDATE_TREND_CONDITIONS:
            return _updateTrendCdt(state, Immutable.fromJS(action.data));
        case GET_DISTRIBUTION:
            return _getDistribute(state, Immutable.fromJS(action.data));
        case UPDATE_DISTRIBUTION_CONDITIONS:
            return _updateDistributeCdt(state, Immutable.fromJS(action.data));
        case GET_RELATE_FREQ:
            return _getRelateFreq(state, Immutable.fromJS(action.data));
        case UPDATE_FREQ_RELATE:
            return _updateFreqRelate(state, Immutable.fromJS(action.data));
        case GET_INCLUDING_FREQ:
            return _getIncludingFreq(state, Immutable.fromJS(action.data));
        case UPDATE_FREQ_INCLUDING:
            return _updateFreqIncluding(state, Immutable.fromJS(action.data));
        case GET_CONCENTRATE:
            return _getConcentrate(state, Immutable.fromJS(action.data));
        case RESET_OVERVIEW:
            return initState;
        default:
            return state;
    }
}

function _getOverViews(state, data) {
    return state.set("info", data);
}

function _getTrend(state, list) {
    return state.set("trend_data", list);
}

function _updateTrendCdt(state, cdt) {
    return state.mergeDeepWith((prev, next) => next === undefined ? prev : next, { trend_condition: cdt });
}

function _getDistribute(state, list) {
    list = list.map(item => item
        .set("value", item.get("count"))
        .set("name", item.get("name").replace(/(.+?)(省|市|特别行政区|(壮族|维吾尔|回族)?自治区)/g, "$1"))
    ).concat([Immutable.fromJS({ name: "南海诸岛", value: 0 })]);
    return state.set("distribute_data", list);
}

function _updateDistributeCdt(state, cdt) {
    return state.mergeDeepWith((prev, next) => next === undefined ? prev : next, { distribute_condition: cdt });
}

function _getRelateFreq(state, list) {
    return state.set("freq_relate_data", list);
}

function _updateFreqRelate(state, cdt) {
    return state.set("freq_relate", cdt);
}

function _getIncludingFreq(state, list) {
    return state.set("freq_including_data", list);
}

function _updateFreqIncluding(state, cdt) {
    return state.set("freq_including", cdt);
}

function _getConcentrate(state, list) {
    list = list.map(item => item.set("value", item.get("count")));
    return state.set("concentrate_data", list);
}