import Immutable from "immutable"
import {Enum} from "enum"
import {tools} from "utils"

import {
    GET_LIST_PEOPLEGROUP
} from "actionType"

let initState = Immutable.fromJS({
    peopleGroupData:[]
});

export default (state = initState, action) => {
    switch (action.type) {
        case GET_LIST_PEOPLEGROUP:
            return _getPeopleGroup(state, Immutable.fromJS(action.data.data));
        default:
            return state
    }
}


function _getPeopleGroup(state, data) {
    return state.set("peopleGroupData",data);
}


