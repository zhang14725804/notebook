import Immutable from "immutable"
import {
    RESET_PRODUCT_LIST,
    GET_PRODUCT_LIST,
    SET_CHECKED_PRODUCTS,
    DELETE_PRODUCTS,
    UPDATE_PRODUCTS_STATE,
    UPDATE_PRODUCT_CONDITIONS
} from "actionType"
import {tools} from "utils"
import {Enum} from "enum"

const initState = Immutable.fromJS({
    conditions: {
        key: {title:""},
        page: 1,
        count: tools.listPageSize,
        order: "ctime",
        order_type: Enum.OrderType.desc
    },
    products: {
        data: [],
        total: 0
    },
    checkedPdts: []
});


export default function productList(state = initState, action) {
    switch (action.type) {
        case UPDATE_PRODUCT_CONDITIONS:
            return _updateProductConditions(state, Immutable.fromJS(action.data));
        case GET_PRODUCT_LIST:
            return _getProductList(state, Immutable.fromJS(action.data));
        case SET_CHECKED_PRODUCTS:
            return _getCheckedProducts(state, Immutable.fromJS(action.data));
        case UPDATE_PRODUCTS_STATE:
            return _updateProductState(state);
        case DELETE_PRODUCTS:
            return _deleteProducts(state);
        case RESET_PRODUCT_LIST:
            return initState;
        default:
            return state
    }
}

function _updateProductConditions(state, cdt) {
    return state.mergeDeepWith((prev, next) => next === undefined ? prev : next, { conditions: cdt });
}

function _getProductList(state, data) {
    data = data.set("total", data.get("total", data.get("count")));
    return state.set("products", data);
}

function _getCheckedProducts(state, chkKeys) {
    return state.set("checkedPdts", chkKeys);
}

function _updateProductState(state) {
    return state;
}

function _deleteProducts(state) {
    return state;
}