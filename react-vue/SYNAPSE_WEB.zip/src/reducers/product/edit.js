import Immutable from "immutable"
import {
    GET_EDIT_PRODUCT,
    SAVE_PRODUCT,
    RESET_PRODUCT_EDIT
} from "actionType"
import {Enum} from "enum"

let initState = Immutable.fromJS({
    product: {
        id:"",
        cn_name: "",
        en_name: "",
        general_name: "",
        image: "",
        ingredient: "",
        adaptation: "",
        usage: "",
        reactions: "",
        taboos: "",
        matters: "",
        classification: "",
        listing_time: new hDate(),
        price: "",
        insurance_type: Enum.InsuranceType.classA.toString(),
        status: Enum.ProductState.disable,
        otc: Enum.DrugType.OTC.toString()
    }
});

export default function productEdit(state = initState, action) {

    switch (action.type) {
        case GET_EDIT_PRODUCT:
            return _getPdt(state, Immutable.fromJS(action.data));
        case SAVE_PRODUCT:
            return _savePdt(state, Immutable.fromJS(action.data));
        case RESET_PRODUCT_EDIT:
            return initState;
        default:
            return state
    }
}

function _setPdt(state, pdt) {
    let product = state.get("product");
    let res = product.mergeWith((prev, next) => {
        return next === undefined ? prev : next;
    }, pdt);
    return state.set("product", res);
}

function _getPdt(state, pdt) {
    pdt = pdt.set("listing_time", new hDate(pdt.get("listing_time")))
    return state.set("product", pdt);
}


function _savePdt(state, value) {
    return state;
}
