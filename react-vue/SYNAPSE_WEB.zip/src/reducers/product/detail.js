import Immutable from "immutable"
import {Enum} from "enum"
import {
    GET_DETAIL_PRODUCT,
    RESET_PRODUCT_DETAIL,
    GET_PDT_OVERVIEWS,
    GET_PDT_TREND
} from "actionType"


let initState = Immutable.fromJS({
    product: {
        cn_name: "",
        en_name: "",
        general_name: "",
        image: "",
        ingredient: "",
        adaptation: "",
        usage: "",
        reactions: "",
        taboos: "",
        matters: "",
        classification: "",
        department: "",
        listing_time: "",
        price: "",
        status: Enum.ProductState.disable,
        insurance_type: "",
        otc: ""
    },
    //数据统计
    summary: {
        trend_condition: {
            range: Enum.ChartTime.today.toString(),
            type: [Enum.ChartTarget.pv.toString()]
        },
        info: {
            cash: 0,//总花费
            cover_count: 0,   //覆盖次数
            cover_user: 0,    //覆盖用户数
            relates_essay: 0,   //被引用的文档
            relates_qa: 0,      //被引用的问卷
            relates_vod: 0, //被引用的点播
            relates_lvb: 0 //被引用的直播
        },
        trend_data: []
    }
});

export default (state = initState, action) => {
    switch (action.type) {
        case GET_DETAIL_PRODUCT:
            return _getPdt(state, Immutable.fromJS(action.data));
        case GET_PDT_OVERVIEWS:
            return _getOverview(state, Immutable.fromJS(action.data));
        case GET_PDT_TREND:
            return _getTrend(state, Immutable.fromJS(action.data));
        case RESET_PRODUCT_DETAIL:
            return initState;
        default:
            return state
    }
}

function _getPdt(state, pdt) {
    return state.set("product", pdt);
}

function _getOverview(state, data) {
    return state.setIn(["summary", "info"], data);
}

function _getTrend(state, list) {
    return state.setIn(["summary", "trend_data"], list);
}
