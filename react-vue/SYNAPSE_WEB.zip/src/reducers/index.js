import { combineReducers } from "redux"
import { routerReducer } from 'react-router-redux'
import $$common from "./common/common.js"
import $$layout from "./layout"
import $$overview from "./overview/overview"
import $$productList from "./product/list"
import $$productEdit from "./product/edit"
import $$productDetail from "./product/detail"
import $$taList from "./ta/list"
import $$taDetail from "./ta/detail"
import $$taEdit from "./ta/edit"
import $$keypointList from "./keypoint/list"
import $$keypointEdit from "./keypoint/edit"
import $$keypointDetail from "./keypoint/detail"


import $$documentCenterList from "./documentCenter/list"
import $$documentCenterEdit from "./documentCenter/edit"
//首页
import $$broadcardlist from "./broadcast/broadlist.js"
//KM
import $$kmtreelist from "./km/detail.js"
import $$kmtreeDetail from "./km/edit.js"

//人群管理
import $$peopleGroupList from "./peopleManagement/list"

const rootReducer = combineReducers({
  routing: routerReducer,
  $$common,
  $$layout,
  $$overview,
  $$productList,
  $$productDetail,
  $$productEdit,
  $$taList,
  $$taDetail,
  $$taEdit,
  $$keypointList,
  $$keypointEdit,
  $$keypointDetail,

    //文档中心
    $$documentCenterList,
    $$documentCenterEdit,

    $$broadcardlist,
    //KM
    $$kmtreelist,
    $$kmtreeDetail,
    //人群管理
    $$peopleGroupList
});

export default rootReducer;
