import Immutable from 'immutable';
import {
    GET_TREE_TAG_DETAIL,
    RESET_KMTREE_DETAIL
} from 'actionType';

let initState = Immutable.fromJS({
    kmtreeDetail: {
        name: null,
        enabled:true,
        parent_id:null
    }
});

export default function kmtreeDetail(state = initState, action) {
    switch (action.type) {
        case GET_TREE_TAG_DETAIL:
            return _getKMtreeDetail(state, Immutable.fromJS(action.data));
        case RESET_KMTREE_DETAIL:
            return initState;
        default:
            return state;
    }
}

function _getKMtreeDetail(state, data) {
    return state.set('kmtreeDetail', data);
}