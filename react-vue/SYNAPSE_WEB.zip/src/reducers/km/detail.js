import Immutable from 'immutable';
import {
    GET_KMTREE_LIST,
    RESET_KMTREE_LIST
} from 'actionType';

let initState = Immutable.fromJS({
    kmtreelist: []
});

export default function kmtreelist(state = initState, action) {
    switch (action.type) {
        case GET_KMTREE_LIST:
            return _getKMtreeList(state, Immutable.fromJS(action.data));
        case RESET_KMTREE_LIST:
            return initState;
        default:
            return state;
    }
}

function _getKMtreeList(state, data) {
    return state.set('kmtreelist', data);
}