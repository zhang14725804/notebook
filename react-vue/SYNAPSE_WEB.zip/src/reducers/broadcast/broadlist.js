import Immutable from 'immutable';
import {
    GET_BROADCARD_LIST,
    RESET_BROAD_LIST,
} from 'actionType';

let initState = Immutable.fromJS({
    broadcardlist: []
});

export default function broadcardlist(state = initState, action) {
    switch (action.type) {
        case GET_BROADCARD_LIST:
            return _getBroadList(state, Immutable.fromJS(action.data));
        case RESET_BROAD_LIST:
            return initState;
        default:
            return state;
    }
}

function _getBroadList(state, data) {
    return state.set('broadcardlist', data);
}