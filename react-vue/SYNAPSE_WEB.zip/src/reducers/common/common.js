import Immutable from "immutable"
import {
    GET_ALL_PRODUCT,
    GET_ALL_TA,
    GET_ALL_TEMPLATE,
    GET_ALL_DEPARTMENT,
    GET_ALL_HOSPLEVEL,
    GET_ALL_DOCLEVEL,
    GET_ALL_ARTICLE_TYPE,
    GET_KM_BY_CONDITION,
    GET_All_AUTHORITY,
    GET_ALL_KP,
    SET_FIELD_VALUE,
    GET_ALL_USERGROUP,
    GET_DEPTLIST,
    GET_NEWS_PREVIEW,
    RESET_PREVIEW,
    GET_H5_PREVIEW,
    GET_QA_PREVIEW,
    GET_ALL_PROVINCE,
    SET_CUR_TAB_MENU
} from "actionType"
import { Enum } from "enum"

const initState = Immutable.fromJS({
    allProduct: [],
    allTa: [],
    allTemplate: [],
    allDepartment: [],
    allProvince: [],
    allHospLevel: [],
    allDocLevel: [],
    allAuthority: [],
    allArticleType: [],
    allUserGroup: [],
    kms: [],
    //一级科室列表
    deptlist: [],
    newsPreview: {
        id: "",
        title: "",
        author: "",
        content_type: undefined,
    },
    h5Preview: "",
    qaPreview: "",
    curTabMenu: '1-1',
});

//用于获取所有不分页的数据集合
export default (state = initState, action) => {
    switch (action.type) {
        case GET_ALL_PRODUCT:
            return _getAllProduct(state, Immutable.fromJS(action.data));
        case GET_ALL_TA:
            return _getAllTa(state, Immutable.fromJS(action.data));
        case GET_ALL_TEMPLATE:
            return _getAllTemplate(state, Immutable.fromJS(action.data));
        case GET_ALL_DEPARTMENT:
            return _getAllDepartment(state, Immutable.fromJS(action.data));
        case GET_ALL_PROVINCE:
            return _getALLProvince(state, Immutable.fromJS(action.data));
        case GET_ALL_HOSPLEVEL:
            return _getAllHospLevel(state, Immutable.fromJS(action.data));
        case GET_ALL_DOCLEVEL:
            return _getAllDocLevel(state, Immutable.fromJS(action.data));
        case GET_ALL_ARTICLE_TYPE:
            return _getAllArticleType(state, Immutable.fromJS(action.data));
        case GET_All_AUTHORITY:
            return _getAllAuthority(state, Immutable.fromJS(action.data));
        case GET_KM_BY_CONDITION:
            return _getKmByCondition(state, Immutable.fromJS(action.data));
        case GET_ALL_KP:
            return _getAllKp(state, Immutable.fromJS(action.data));
        case SET_FIELD_VALUE:
            return _setFieldValue(state, Immutable.fromJS(action.data));
        case GET_ALL_USERGROUP:
            return _getAllUserGroup(state, Immutable.fromJS(action.data));
        case GET_DEPTLIST:
            return _getDeptList(state, Immutable.fromJS(action.data.data));
        case GET_NEWS_PREVIEW:
            return _getNewsPreview(state, Immutable.fromJS(action.data));
        case GET_H5_PREVIEW:
            return _getH5Preview(state, Immutable.fromJS(action.data));
        case GET_QA_PREVIEW: 
            return _getQaPreview(state, Immutable.fromJS(action.data));
        case RESET_PREVIEW:
            return state
                .set("newsPreview", initState.get("newsPreview"))
                .set("h5Preview", initState.get("h5Preview"));
        case SET_CUR_TAB_MENU:
            return _setCurTabMenu(state, Immutable.fromJS(action.data));
        default:
            return state;
    }
}

function _getAllProduct(state, data) {
    let products = data.get("data");
    products = products.map(product => {
        return product
            .set("id", product.toJS().id.toString())
    })
    return state.set("allProduct", products);
}

function _getAllTa(state, data) {
    let tas = data.get("data");
    tas = tas.map(ta => {
        return ta
            .set("id", ta.toJS().id.toString())
    })
    return state.set("allTa", tas);
}

function _getAllTemplate(state, value) {
    let templates = value.get("data");
    templates = templates.map(tpm => {
        return tpm
            .set("id", tpm.toJS().id.toString()) //option要求value是string类型，因此此处将id转为string
            .set("provinces", JSON.parse(tpm.toJS().template).filter(item => item.category == Enum.CoverageType.province))
            .set("hospLevels", JSON.parse(tpm.toJS().template).filter(item => item.category == Enum.CoverageType.hospLevel))
            .set("docLevels", JSON.parse(tpm.toJS().template).filter(item => item.category == Enum.CoverageType.docLevel))
            .set("departments", JSON.parse(tpm.toJS().template).filter(item => item.category == Enum.CoverageType.department))
    })
    return state.set("allTemplate", templates);
}

function _getAllDepartment(state, data) {
    let departments = data.get("data");
    departments = departments.map(group => {
        return group
            .set("id", group.toJS().id.toString()) //option要求value是string类型，因此此处将id转为string
            .set("leaves", group.get('leaves').map(department => {
                return department
                    .set("id", department.toJS().id.toString()) //option要求value是string类型，因此此处将id转为string
            }))
    })
    return state.set("allDepartment", departments);
}

function _getALLProvince(state, data) {
    let provinces = data.get("data");
    provinces = provinces.map(province => {
        return province
            .set("id", province.toJS().id.toString()) 
    })
    return state.set("allProvince", provinces);
}


function _getAllHospLevel(state, data) {
    let hospLevels = data.get("data");
    hospLevels = hospLevels.map(hospLevel => {
        return hospLevel
            .set("id", hospLevel.toJS().id.toString()) //option要求value是string类型，因此此处将id转为string
    })
    return state.set("allHospLevel", hospLevels);
}


function _getAllDocLevel(state, data) {
    let docLevels = data.get("data");
    docLevels = docLevels.map(docLevel => {
        return docLevel
            .set("id", docLevel.toJS().id.toString()) //option要求value是string类型，因此此处将id转为string
    })
    return state.set("allDocLevel", docLevels);
}

function _getAllArticleType(state, value) {
    value = Immutable.fromJS([
        { id: "1", name: "图文" },
        { id: "2", name: "问卷调查" }
    ]);
    return state.set("allArticleType", value);
}

function _getAllAuthority(state, data) {
    return state.set("allAuthority", data);
}

function _getKmByCondition(state, kms) {
    kms = kms.map(km => {
        return km
            .set("id", km.toJS().id.toString()) //option要求value是string类型，因此此处将id转为string
    })
    return state.set("kms", kms);
}

function _getAllUserGroup(state, data) {
    return state.set("allUserGroup", data.get("data"));
}

function _setFieldValue(state, field) {
    return state.set(field.name, field.value);
}

function _getDeptList(state, deptlist) {
    deptlist = deptlist.map(depart => {
        return depart
            .set("department_id", depart.toJS().department_id.toString()) //option要求value是string类型，因此此处将id转为string
    })
    return state.set("deptlist", deptlist);
}

function _getNewsPreview(state, newsPreview) {
    return state.set("newsPreview", newsPreview);
}
function _getH5Preview(state, data) {
    return state.set("h5Preview", data);
}
function _getQaPreview(state, data) {
    return state.set("qaPreview", data);
}
function _setCurTabMenu(state, data){
    return state.set("curTabMenu", data);
}

