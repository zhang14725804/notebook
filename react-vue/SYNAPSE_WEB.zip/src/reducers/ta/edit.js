import Immutable from "immutable"
import {
    RESET_TA_EDIT,
    GET_EDIT_TA,
} from "actionType"
import {Enum} from "enum"

const initState = Immutable.fromJS({
    ta: {
        id: "",
        name: "",
        status: Enum.TAState.disable,
        description: "",
        create_user: "",
        ctime: undefined,
        company_id: ""
    }
});
export default (state = initState, action) => {
    switch (action.type) {
        case GET_EDIT_TA:
            return getTA(state, Immutable.fromJS(action.data))
        case RESET_TA_EDIT:
            return initState
        default:
            return state;
    }
}


function getTA(state, ta) {
    return state.set("ta", ta);
}