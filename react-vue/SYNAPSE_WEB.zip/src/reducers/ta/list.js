import Immutable from "immutable"
import {
    RESET_TA_LIST,
    GET_TA_LIST,
    UPDATE_TA_CONDITION,
    SET_CHECKED_TAS,
    DELETE_TAS,
    UPDATE_TAS_STATE,
    SET_TA,
    GET_TA,
    SAVE_TA
} from "actionType"
import {tools} from "utils"
import {Enum} from "enum"

const initState = Immutable.fromJS({
    tas: {
        data: [],
        total: 0
    },
    conditions: {
        key: {title: ""},
        page: 1,
        count: tools.listPageSize,
        order: "ctime",
        order_type: Enum.OrderType.desc
    },
    checkedTAs: []
})



export default (state = initState, action) => {
    switch (action.type) {
        case GET_TA_LIST:
            return _getTAList(state, Immutable.fromJS(action.data));
        case UPDATE_TA_CONDITION:
            return _updateTAConditions(state, Immutable.fromJS(action.data));
        case SET_CHECKED_TAS:
            return _setCheckedTAs(state, Immutable.fromJS(action.data));
        case DELETE_TAS:
            return _deleteTAs(state);
        case UPDATE_TAS_STATE:
            return _updateTAsState(state);
        case RESET_TA_LIST:
            return initState;
        default:
            return state;
    }
}

function _getTAList(state, list) {
    list = list.set("total", list.get("total", list.get("count")));
    return state.set("tas", list);
}

function _updateTAConditions(state, cdt) {
    return state.mergeDeepWith((prev, next) => next === undefined ? prev : next, { conditions: cdt });
}

function _setCheckedTAs(state, chkKey) {
    return state.set("checkedTAs", chkKey);
}

function _deleteTAs(state) {
    return state;
}

function _updateTAsState(state) {
    return state;
}
