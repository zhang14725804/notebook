import Immutable from "immutable"
import {
    RESET_TA_DETAIL,
    GET_DETAIL_TA,
    GET_REFER_BY_TA,
    GET_TA_OVERVIEWS,
    GET_TA_TREND,
    SET_REFER_CONDITION_BY_TA
} from "actionType"
import {tools} from "utils"
import {Enum} from "enum"

const initState = Immutable.fromJS({
    ta: {
        id: "",
        name: "",
        status: Enum.TAState.disable,
        description: "",
        create_user: {
            nickname: ""
        },
        ctime: undefined,
        company_id: ""
    },
    conditions: {
        ta_id: "",
        page: 1,
        count: tools.listPageSize
    },
    infoList: {
        data: [],
        total: 0
    },
    //数据统计
    summary: {
        trend_condition: {
            range: Enum.ChartTime.today.toString(),
            type: [Enum.ChartTarget.pv.toString()]
        },
        info: {
            cash: 0,//总花费
            cover_count: 0,   //覆盖次数
            cover_user: 0,    //覆盖用户数
            relates_essay: 0,   //被引用的文档
            relates_qa: 0,      //被引用的问卷
            relates_vod: 0, //被引用的点播
            relates_lvb: 0 //被引用的直播
        },
        trend_data: []
    }
});

export default (state = initState, action) => {
    switch (action.type) {
        case GET_DETAIL_TA:
            return _getTa(state, Immutable.fromJS(action.data));
        case GET_REFER_BY_TA:
            return _getReferByTa(state, Immutable.fromJS(action.data));
        case SET_REFER_CONDITION_BY_TA:
            return _setReferConditionByTA(state, Immutable.fromJS(action.data))
        case GET_TA_OVERVIEWS:
            return _getOverview(state, Immutable.fromJS(action.data));
        case GET_TA_TREND:
            return _getTrend(state, Immutable.fromJS(action.data));
        case RESET_TA_DETAIL:
            return initState;
        default:
            return state;
    }
}

function _getTa(state, value) {
    return state.set("ta", value);
}

function _getReferByTa(state, value) {
    return state.set("infoList", value);
}

function _setReferConditionByTA(state, cdt) {
  return state.mergeDeepWith((prev, next) => next === undefined ? prev : next, {conditions: cdt});
}

function _updateReferCondition(state, value) {
    return state.mergeDeepWith((prev, next) => next === undefined ? prev : next, { conditions: value });
}

function _getOverview(state, data) {
    return state.setIn(["summary", "info"], data);
}

function _getTrend(state, list) {
    return state.setIn(["summary", "trend_data"], list);
}
