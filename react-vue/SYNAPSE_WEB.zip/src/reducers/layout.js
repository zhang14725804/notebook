import Immutable from "immutable";
import {
    GET_MENU,
    GET_LOGIN_USER,
    SET_LOGIN_STATUS,
    LOGOUT
} from "actionType"
import { tools } from "utils"
import layoutDataJson from "mockdata/layoutData.js"


let initState = Immutable.fromJS({
    menus: [],
    login_user: {},
    isLogin: false,
    pageReload: '',
});


export default function layout(state = initState, action) {
    switch (action.type) {
        case GET_MENU:
            return _getMenu(state, Immutable.fromJS(action.data));
        case GET_LOGIN_USER:
            return _getLoginUser();
        case SET_LOGIN_STATUS:
            return _setLoginStatus(state, Immutable.fromJS(action.data));
        default:
            return state;
    }
}


function _getMenu(state, value) {
    // value=Immutable.fromJS(layoutDataJson.menus)
    return state
        .set("menus", value.get("menulist"))
        .set("login_user", value.get("loginuser"))
}

function _getLoginUser() {

}

function _setLoginStatus(state, isLogin) {
    return state.set("isLogin", isLogin);
}



