module.exports = {
    "menulist": [
        {
            "id": "0",
            "name": "首页",
            "url": "/overview",
            "power": "0",
            "subchild": []
        }, {
            "id": "1",
            "name": "推广",
            "url": "/expSingle/edit",
            "power": "10007",
            "subchild": [
                {
                    "id": "1-0",
                    "name": "学术速递",
                    "power": "10004",
                    "url": "/expSingle/list"
                }, {
                    "id": "1-1",
                    "name": "线上科会",
                    "power": "10010",
                    "url": "/expVol/list"
                }, {
                    "id": "1-2",
                    "name": "调研问卷",
                    "power": "10005",
                    "url": "/expQa/list"
                }, {
                    "id": "1-3",
                    "name": "线上互动",
                    "power": "10006",
                    "url": "/expComb/list"
                }, {
                    "id": "1-4",
                    "name": "旧推广",
                    "power": "10007",
                    "url": "/express/list"
                }
            ]
        }, {
            "id": "2",
            "name": "素材",
            "url": "/news/list",
            "subchild": [
                {
                    "id": "2-0",
                    "name": "图文",
                    "power": "10004",
                    "url": "/news/list"
                }, {
                    "id": "2-1",
                    "name": "H5",
                    "power": "10010",
                    "url": "/h5/list"
                },{
                    "id": "2-2",
                    "name": "问卷",
                    "power": "10011",
                    "url": "/qa/list"
                }]
        }, {
            "id": "3",
            "name": "标签管理",
            "url": "/product/list",
            "subchild": [
                {
                    "id": "3-0",
                    "name": "产品标签",
                    "power": "10001",
                    "url": "/product/list"
                }, {
                    "id": "3-1",
                    "name": "治疗领域标签",
                    "power": "10003",
                    "url": "/ta/list"
                }, {
                    "id": "3-2",
                    "name": "信息点标签",
                    "power": "10002",
                    "url": "/keypoint/list"
                }
            ]
        }, {
            "id": "4",
            "name": "设置",
            "url": "/root/list",
            "subchild": [
                {
                    "id": "4-0",
                    "name": "权限设置",
                    "power": "10008",
                    "url": "/root/list"
                }, {
                    "id": "4-1",
                    "name": "账户充值",
                    "power": "10009",
                    "url": "/root/recharge"
                }
            ]
        },{
            "id":"5",
            "name":'业务推广',
            "url":'/broadcast',
            "subchild":[]
        }
    ]
};
