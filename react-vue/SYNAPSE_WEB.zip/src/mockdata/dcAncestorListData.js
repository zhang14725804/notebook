module.exports = {
    "0": {"code":10000,"msg":"success","data":[]},
    "1": {"code":10000,"msg":"success","data":[{"id":1,"top_id":0,"parent_id":0,"name":"诊断分类"}]}
}