module.exports = {
    vodList: {
      "code": 10000,
      "msg": "Success",
      "data": {
        "data": [
          {
            "id": 257,
            "title": "测试直通车关联点播在C端显示视频名称",
            "image": "http://synapse-static.oss-cn-beijing.aliyuncs.com/img/80/1477879812257.jpg",
            "ctime": 1477879835000,
            "utime": 1480525805000,
            "expire_time": 1480525805000,
            "view_count": 2333
          }
        ],
        "total": 1
      }
    },
    vodDetail: {
      "code": 10000,
      "msg": "Success",
      "data": {
        "desciption": "测试直通车关联点播在C端显示视频介绍",
        "image": "http://synapse-static.oss-cn-beijing.aliyuncs.com/img/80/1477879812257.jpg",
        "qcloud_fileid": "14651978969403638236",
        "company_id": 80,
        "relates": {
          "product": [
            {
              "cn_name": "产品0000001产品名称",
              "en_name": "0000001",
              "id": 149206,
              "general_name": "产品0000001通用名"
            }
          ],
          "keyword": [],
          "ta": []
        },
        "author": "测试直通车关联点播在C端显示讲者名称",
        "author_title": "测试直通车关联点播在C端显示讲者职称",
        "expire_time": 1480521599000,
        "ctime": 1477879835000,
        "begin_time": 1477843200000,
        "promotion_id": 2074,
        "threshold": 100,
        "title": "测试直通车关联点播在C端显示视频名称",
        "comment_status": 1,
        "author_introduction": "测试直通车关联点播在C端显示讲师介绍",
        "author_image": "http://synapse-static.oss-cn-beijing.aliyuncs.com/img/80/1477879816665.jpg",
        "tags": "",
        "utime": 1480525805000,
        "author_hospital": "测试直通车关联点播在C端显示所属医院",
        "template_id": 166,
        "id": 257,
        "create_user": 462,
        "status": 2
      }
    }
}
