module.exports = {
  infoDetail: {
    "code": 10000,
    "msg": "Success",
    "data": {
      "subject_id": 591,
      "coverage": 0,
      "image": "http://synapse-static.oss-cn-beijing.aliyuncs.com/img/102/1479433088950.jpg",
      "company_id": 102,
      "content_id": 654,
      "relates": {
        "product": [
          {
            "cn_name": "B",
            "en_name": "B",
            "id": 149240,
            "general_name": "ffd"
          }
        ],
        "keyword": [
          {
            "description": "的粉",
            "id": 634,
            "keyword": "B1"
          }
        ],
        "ta": [
          {
            "name": "B",
            "description": "多少",
            "id": 297
          }
        ]
      },
      "author": "中国",
      "end_time": 1480089599000,
      "insert_time": 1479433112000,
      "begin_time": 1479398400000,
      "promotion_id": 2427,
      "threshold": 2,
      "source": "Synapse",
      "title": "掌控————医院级别不同，不显示在APP000000【礼来为下一代赖脯胰岛素达成一项价值 5.7 亿美元的协议】",
      "tags": "礼来为下一代赖脯胰岛素达成一项价值 5.7 亿美元的协议【题目】",
      "update_time": 1480093800000,
      "content_cn": "<p>礼来通过一项价值达 5.7 亿美元的协议从法国公司 Adocia 许可获得一款其畅销胰岛素产品赖脯胰岛素（Humalog）的一款升级产品。Adocia 与礼来将基于该法国公司 BioChaperone 技术共同开发该赖脯胰岛素（HumalogU100）的升级产品，BioChaperone 技术旨在防止蛋白质在体内分解，并改善它们在体内的吸收。</p><p>两家公司早先曾为赖脯胰岛素的 BioChaperone 版本达成过一项协议，但因礼来决定把注意力放到别处而于 2011 年放弃这一协议，据报道背后的原因是两家公司对这一项目的方向意见不统一。但 Adocia 决心继续独立进行这一项目，据 9 月份报道的临床试验称，BioChaperone 赖脯胰岛素与 Humalog 相比显示起效更快。</p><p>据 Adocia 称，这款药物更接近地模仿了在健康个体所观察到的内生胰岛素对进餐的响应，这使董事长 Soula 激动地称结果支持 BioChaperone 赖脯胰岛素在膳食胰岛素中的一流潜能。</p><p>礼来显然同意这一观点，并正向 Adocia 支付 5000 万美元的预付款来获得这款药物的权利，另外还有 2.8 亿美元基于监管里程碑的潜在付款及 2.4 亿美元的商业里程碑付款。礼来表示，该公司还将补偿 Adocia 与 BioChaperone 赖脯胰岛素研发相关的费用。</p><p>BioChaperone 赖脯胰岛素的潜在收益包括“胰岛素注射时更大的灵活性、餐后血糖水平较低的波动性，较低的低血糖发生率及更好的总体血糖控制”，该公司在一份声明中如是表示。</p><p>与此同时，Humalog 仍是礼来的一款重磅产品，尽管这款药物的化合物专利于去年在美国失去保护，但其前 9 个月的销售仍增长 10%，达到 20.5 亿美元。该公司正在很好地保持这款药物的发展势头，因为这款药物的生物仿制药尚未在美国及欧洲获批，不过迈兰去年曾表示，该公司正在开发该药物的一款生物仿制药。</p><p>礼来最近获欧盟批准了一款新型高剂量笔型 Humalog 用于每天需要超过 20 单位速效胰岛素来控制血糖的糖尿病患者。Humalog U200 已在美国提交上市申请，但预计今年底会重新提交。与此同时， Humalog U200 制剂的 BioChaperone 版本也在研发中，另外还有更高的 U300 剂量，据 Adocia 与礼来称。</p><p>作者：fyc5078</p>",
      "charge_id": 1804,
      "periodical": "中国周刊",
      "template_id": 242,
      "id": 591,
      "create_user": 485,
      "release_time": 1470187392000,
      "status": 2
    }
  }
}
