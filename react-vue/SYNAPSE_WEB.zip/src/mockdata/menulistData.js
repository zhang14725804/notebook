module.exports = {
  menulist: {
    "code": 10000,
    "msg": "Success",
    "data": {
      "loginuser": {
        "id": 462,
        "nickname": "高鑫",
        "useremail": "ubuntugx@hotmail.com",
        "avatar": null,
        "phone": "13436309153",
        "group_id": 0,
        "company_id": 80,
        "status": 1,
        "ctime": 1480304151000,
        "utime": 1480304151000,
        "company_manager": true
      },
      "menulist": [
        {
          "name": "概况",
          "url": "",
          "power": "0",
          "subchild": [
            {
              "id": "1-1",
              "name": "概况",
              "power": "0",
              "url": "/overview"
            }
          ]
        },
        {
          "name": "基础数据",
          "url": "",
          "subchild": [
            {
              "id": "2-1",
              "name": "产品管理",
              "power": "10001",
              "url": "/product/list"
            },
            {
              "id": "2-2",
              "name": "治疗领域管理",
              "power": "10003",
              "url": "/ta/list"
            },
            {
              "id": "2-3",
              "name": "信息点管理",
              "power": "10002",
              "url": "/keypoint/list"
            }
          ]
        },
        {
          "name": "推广中心",
          "url": "",
          "subchild": [
            {
              "id": "3-1",
              "name": "图文",
              "power": "10004",
              "url": "/news/list"
            },
            {
              "id": "3-2",
              "name": "问卷调查",
              "power": "10005",
              "url": "/qa/list"
            },
            {
              "id": "3-3",
              "name": "医学视频",
              "power": "10006",
              "url": "/video/list"
            }
          ]
        },
        {
          "name": "直通车",
          "url": "",
          "subchild": [
            {
              "id": "4-1",
              "name": "直通车管理",
              "power": "10007",
              "url": "/express/list"
            }
          ]
        },
        {
          "name": "设置",
          "url": "",
          "subchild": [
            {
              "id": "5-1",
              "name": "权限设置",
              "power": "10008",
              "url": "/root/list"
            },
            {
              "id": "5-2",
              "name": "账户充值",
              "power": "10009",
              "url": "/root/recharge"
            }
          ]
        }
      ]
    }
  }
}
