module.exports = {
    "code":10000,
    "msg":"success",
    "data":[{"question_id":"pt73yl1h","head":"您的工作年限是：","type":1,"order":"0","score":"10","options":[{"id":"sk6gmalf","content":"0-6个月","isRight":true},{"id":"3ifrrwd3","content":"6个月-1年","isRight":false},{"id":"vzo4fujc","content":"1-2年","isRight":false},{"id":"xeytvgwd","content":"2年以上","isRight":false}]},{"question_id":"qdylbr2r","head":"您认为以下不正确的选项是","type":"2","order":"1","score":"10","options":[{"id":"w7n8wlr4","content":"0-6个月","isRight":true},{"id":"bnjph509","content":"6个月-1年","isRight":false},{"id":"7rnvog9r","content":"1-2年","isRight":true},{"id":"axoallcb","content":"2年以上","isRight":false}]}]
}