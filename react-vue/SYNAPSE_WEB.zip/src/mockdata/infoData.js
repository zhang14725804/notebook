module.exports = {
    infoList: {
        "code": 10000,
        "msg": "Success",
        "data": {
            "total": 37,
            "data": [{
                "id": 610,
                "expire_time": 1481990399000,
                "ctime": 1479881547000,
                "title": "达克宁的疗效",
                "content_type": 2,
                "product":"产品",
                "ta":"治疗领域",
                "status": 1
            }, {
                "expire_time": 1481471999000,
                "ctime": 1479879601000,
                "title": "杏仁联调数据",
                "id": 608,
                "content_type": 3,
                "product":"产品1",
                "ta":"治疗领域1",
                "status": 1
            }, {
                "expire_time": 1479830399000,
                "ctime": 1479204355000,
                "title": "ios测试-掌控-用户1显示在APP43243",
                "id": 582,
                "content_type": 3,
                "product":"产品2",
                "ta":"治疗领域2",
                "status": 1
            }, {
                "expire_time": 1479571199000,
                "ctime": 1479090185000,
                "title": "测试阈值为1，区域不同，不显示在APP端",
                "id": 567,
                "content_type": 2,
                "product":"产品",
                "ta":"",
                "status": 0
            }, {
                "expire_time": 1479571199000,
                "ctime": 1478836000000,
                "title": "测试闪屏-选择全部，显示在所有账号",
                "id": 558,
                "content_type": 1,
                "product":"",
                "ta":"治疗领域",
                "status": 0
            }, {
                "expire_time": 1479571199000,
                "ctime": 1478774379000,
                "title": "测试闪屏-区域不同0002，不显示在APP端",
                "id": 556,
                "content_type": 1,
                "product":"产品3",
                "ta":"治疗领域3",
                "status": 1
            }, {
                "expire_time": 1479571199000,
                "ctime": 1478762523000,
                "title": "测试闪屏-医生级别不同，不显示在APP端",
                "id": 554,
                "content_type": 1,
                "product":"产品4",
                "ta":"",
                "status": 1
            }, {
                "expire_time": 1479571199000,
                "ctime": 1478762464000,
                "title": "测试banner-科室不同，不显示在APP0002",
                "id": 553,
                "content_type": 2,
                "product":"",
                "ta":"治疗领域5",
                "status": 0
            }, {
                "expire_time": 1479571199000,
                "ctime": 1478762371000,
                "title": "测试闪屏-科室不同，不显示在APP端0002",
                "id": 552,
                "content_type": 2,
                "product":"产品6",
                "ta":"",
                "status": 1
            }, {
                "expire_time": 1478966399000,
                "ctime": 1478762288000,
                "title": "测试banner-医院级别不同，不显示在APP端",
                "id": 551,
                "content_type": 2,
                "product":"产品",
                "status": 1
            }]
        }
    },
    infoDetail: {
        "code": 10000,
        "msg": "Success",
        "data": {
            "relates": {
              "product": [{
                "cn_name": "产品0000001产品名称",
                "en_name": "0000001",
                "id": 149206,
                "general_name": "产品0000001通用名"
              }],
              "keyword": [{
                  "description": "信息点000001描述",
                  "id": 646,
                  "keyword": "信息点000001名称"
              }],
              "ta": [{
                  "name": "治疗领域000001",
                  "description": "治疗领域000001描述",
                  "id": 306
              }]
            },
            "author": "测试图文关联好多东西",
            "expire_time": 1480607999000,
            "ctime": 1480557496000,
            "source": "",
            "title": "测试图文关联好多东西",
            "tags": "",
            "utime": 1480557496000,
            "content_text": "<p>测试图文关联好多东西<br></p>",
            "content_h5": "http://www.baidu.com",
            "id": 662,
            "create_user_name": "创建人名称",
            "status": "0",
            "content_type": 1,
            "link": "http://www.baidu.com"
        }
    }
}
