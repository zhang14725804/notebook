import { createStore, applyMiddleware, compose } from "redux"
import thunk from "redux-thunk"
import { routerMiddleware } from "react-router-redux"
import { hashHistory } from "react-router"
import reducer from "../reducers"

const reduxRouterMiddleware = routerMiddleware(hashHistory);

const finalCreateStore = compose(
  applyMiddleware(thunk),
  applyMiddleware(reduxRouterMiddleware),
)(createStore)


export default function configureStore(initialState) {
  const store = finalCreateStore(reducer, initialState);
  //监听store变化
  // store.subscribe(function () {
  //   console.warn("change");
  // })

  if (module.hot) {
    module.hot.accept("reducers/index.js", () =>
      store.replaceReducer(require("reducers/index.js").default)
    );
  }
  return store
}
