import $ from "jquery"
import { tools } from "utils"
import { push } from "react-router-redux"
import {
	GET_KP_SRC,
	GET_KP_INFO,
	RESET_KP_EDIT,
	RESET_KP_LIST,
	RESET_KP_DETAIL,
	SET_CHECKED_KP,
	DEL_KP,
	CHANGE_KP_STATE,
	SET_SEARCH_CONDITION_KPSRC,
	GET_KP_OVERVIEWS,
	GET_KP_TREND,
	GET_EDIT_KP,
	SAVE_KP,
	GET_KP_LIST,
	UPDATE_KP_CONDITION
} from "actionType"
import { Enum } from "enum"


const url = {
	remove: tools.javaApi("/keyword/delete"),
	info: tools.javaApi("/keyword/info"),
	search: tools.javaApi("/keyword/search"),
	changeState: tools.javaApi("/keyword/updatestatus"),
	getrelateessay: tools.javaApi("/keyword/getrelateessay"),
	create: tools.javaApi("/keyword/create"),
	edit: tools.javaApi("/keyword/edit"),
	statistics_info: tools.javaApi("/statistics/keypoint/info"),
	statistics_trend: tools.javaApi("/statistics/keypoint/content")
}
const infoEnum = {
	detail: 1,
	edit: 2
}
export function resetList() {
	return {
		type: RESET_KP_LIST
	}
}

export function resetEdit() {
	return {
		type: RESET_KP_EDIT
	}
}

export function resetDetail() {
	return {
		type: RESET_KP_DETAIL
	}
}


export function reset() {
	return function (dispatch) {
		dispatch(resetList());
		dispatch(resetEdit());
		dispatch(resetDetail());
	}
}



/**
 * 获取信息点列表
 *
 * @export
 * @param combCdt (description)
 * @returns (description)
 */
export function getKeypointList(combCdt) {
	return (dispatch, getState) => {
		dispatch(updateKpConditions(combCdt));
		let conditions = getState().$$keypointList.toJS().condition;
		//数据转换
		$.extend(true, conditions, {
			key: {
				start: conditions.key.ctime instanceof Array && conditions.key.ctime.length >= 2 && conditions.key.ctime[0] ? conditions.key.ctime[0].valueOf() : undefined,
				end: conditions.key.ctime instanceof Array && conditions.key.ctime.length >= 2 && conditions.key.ctime[1]? conditions.key.ctime[1].valueOf() : undefined
			}
		})
		delete conditions.key.ctime;
		return tools.ajax({
			url: url.search,
			info: "获取信息点",
			data: $.extend(true, {}, conditions, {
				key: JSON.stringify(conditions.key)
			}),
			dispatch: dispatch,
			actionType: GET_KP_LIST
		})
	}
}

/**
 * 更新搜索条件
 *
 * @param combCdt 待更新的查询条件
 * @returns (description)
 */
export function updateKpConditions(combCdt) {
	return {
		type: UPDATE_KP_CONDITION,
		data: combCdt
	}
}




/**
 * 变更信息点状态
 *
 * @export
 * @param keys (description)
 * @param status (description)
 * @returns (description)
 */
export function changeKpState(keys, status) {
	return function (dispatch) {
		return tools.ajax({
			type: "post",
			url: url.changeState,
			data: {
				keyword_ids: keys.join(),
				status: status
			},
			result: tools.ajax.resultEnum.bool,
			info: "变更信息点状态",
			isShowSuccess: true,
			dispatch: dispatch,
			actionType: CHANGE_KP_STATE,
			success: () => {
				dispatch(getKeypointList());
				dispatch(setChkKp([]));
			}
		})
	}
}

export function delKp(keyword_ids) {
	return function (dispatch) {
		return tools.ajax({
			type: "post",
			url: url.remove,
			data: { keyword_ids: keyword_ids.join() },
			result: tools.ajax.resultEnum.bool,
			info: "删除信息点",
			isShowSuccess: true,
			dispatch: dispatch,
			actionType: DEL_KP,
			success() {
				dispatch(getKeypointList({
					page: 1
				}));
				dispatch(setChkKp([]));
			}
		})
	}
}

export function setChkKp(chkKeys) {
	return {
		type: SET_CHECKED_KP,
		data: chkKeys
	}
}




/**
 * 获取信息点详情
 *
 * @export
 * @param keyword_id (description)
 * @param isEdit (description)
 * @returns (description)
 */
export function getKp(keyword_id, isEdit) {
	return function (dispatch) {
		return tools.ajax({
			url: url.info,
			data: {
				keyword_id: keyword_id,
				option: infoEnum.edit
			},
			info: "获取信息点编辑内容",
			dispatch: dispatch,
			actionType: GET_EDIT_KP
		})
	}
}



export function saveKp(kp, isEdit) {
	return function (dispatch) {
		return tools.ajax({
			type: "post",
			url: isEdit ? url.edit : url.create,
			result: isEdit ? tools.ajax.resultEnum.bool : tools.ajax.resultEnum.guid,
			data: {
				// keyword_id: isEdit ? kp.keyword_id : undefined,
				id: isEdit ? kp.keyword_id : undefined,
				keyword: kp.keyword,
				description: kp.description,
				product_ids: (kp.product_ids || []).join(","),
				ta_ids: (kp.ta_ids || []).join(","),
				status: kp.status ? Enum.KpState.enable : Enum.KpState.disable,
			},
			info: "保存信息点",
			isShowSuccess: true,
			dispatch: dispatch,
			actionType: SAVE_KP,
			success(resp) {
				dispatch(push({
					pathname: "/keypoint/detail",
					query: {
						keyword_id: isEdit ? kp.keyword_id : resp.data
					}
				}))
			}
		})
	}
}



//detail
export function getKeypointSRC(cdt) {
	return function (dispatch, getState) {
		let cd = $.extend(true, {}, getState().$$keypointDetail.toJS().searchCondition, cdt);
		return tools.ajax({
			url: url.getrelateessay,
			data: cd,
			info: "获取信息点资源",
			dispatch: dispatch,
			actionType: GET_KP_SRC,
			success() {
				dispatch(setSearchCondition_kpsrc(cd))
			}
		})
	}
}


export function setSearchCondition_kpsrc(searchCondition) {
	return {
		type: SET_SEARCH_CONDITION_KPSRC,
		data: searchCondition
	}
}



export function getKeypointInfo(keyword_id) {
	return function (dispatch) {
		return tools.ajax({
			url: url.info,
			data: {
				keyword_id: keyword_id,
				option: infoEnum.detail
			},
			info: "获取信息点详情内容",
			dispatch: dispatch,
			actionType: GET_KP_INFO
		})
	}
}



//------------数据统计-------------
export function getOverView(cdt) {
	return dispatch => {
		return tools.ajax({
			url: url.statistics_info,
			data: {
				company_id: cdt.company_id,
				keypoint_id: cdt.keypoint_id
			},
			info: "获取概要",
			dispatch: dispatch,
			actionType: GET_KP_OVERVIEWS
		});
	}
}

/*
 * 根据查询条件获取趋势列表
 *
 * @export
 * @param combCdt 待合并的查询条件
 * @returns (description)
 */
export function getTrend(cdt) {
	return (dispatch, getState) => {
		return tools.ajax({
			url: url.statistics_trend,
			data: {
				company_id: cdt.company_id,
				keypoint_id: cdt.keypoint_id,
				range: cdt.range,
				type: cdt.type.join()
			},
			info: "获取趋势",
			result: tools.ajax.resultEnum.array,
			dispatch: dispatch,
			actionType: GET_KP_TREND
		});
	}
}
