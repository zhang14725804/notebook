import {
    GET_LIST_PEOPLEGROUP,
    ADD_PEOPLEGROUP,
    GET_INFO_PEOPLEGROUP,
    MODIFY_INFO_PEOPLEGROUP,
    DELETE_PEOPLEGROUP
} from 'actionType';
import {tools} from 'src/utils';
const url = {
    getPeopleGroup: tools.javaApi("/aj/templates/list"),//人群列表接口
    addPeopleGroup: tools.javaApi("/aj/templates/add"),//新增人群接口
    getInfoPeopleGroup: tools.javaApi("/aj/templates/info"),//获取人群详情
    modifyInfoPeopleGroup: tools.javaApi("/aj/templates/moidfy"),//修改人群详情
    deletePeopleGroup: tools.javaApi("/aj/templates/delete"),//删除人群
};

export function getPeopleGroup(params){
    return (dispatch) => {
        return tools.ajax({
            url: url.getPeopleGroup,
            method: 'get',
            data:params,
            responseType: 'json',
            dispatch: dispatch,
            actionType: GET_LIST_PEOPLEGROUP,
        });
    }
}
export function addPeopleGroup(params){
    return (dispatch) => {
        return tools.ajax({
            url: url.addPeopleGroup,
            method: 'post',
            data:params,
            responseType: 'json',
            dispatch: dispatch,
            actionType: ADD_PEOPLEGROUP,
        });
    }
}
export function getInfoPeopleGroup(params){
    return (dispatch) => {
        return tools.ajax({
            url: url.getInfoPeopleGroup,
            method: 'get',
            data:params,
            responseType: 'json',
            dispatch: dispatch,
            actionType: GET_INFO_PEOPLEGROUP,
        });
    }
}
export function modifyInfoPeopleGroup(params){
    return (dispatch) => {
        return tools.ajax({
            url: url.modifyInfoPeopleGroup,
            method: 'post',
            data:params,
            responseType: 'json',
            dispatch: dispatch,
            actionType: MODIFY_INFO_PEOPLEGROUP,
        });
    }
}
export function deletePeopleGroup(params){
    return (dispatch) => {
        return tools.ajax({
            url: url.deletePeopleGroup,
            method: 'get',
            data:params,
            responseType: 'json',
            dispatch: dispatch,
            actionType: DELETE_PEOPLEGROUP,
        });
    }
}