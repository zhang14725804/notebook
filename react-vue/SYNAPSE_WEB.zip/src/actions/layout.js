import {
    GET_MENU,
    GET_LOGIN_USER,
    SET_LOGIN_STATUS,
    LOGOUT} from "actionType"
import {tools} from "utils"

const url = {
    menulist: tools.javaApi("/account/menulist"),
    logout: tools.javaApi("/account/logout")
}

export function getMenu() {
    return (dispatch) => {
        return tools.ajax({
            url: url.menulist,
            info: "获取菜单",
            actionType: GET_MENU,
            dispatch: dispatch
        });
    }
}

export function setIsLogin(isLogin) {
    return {
        type: SET_LOGIN_STATUS,
        data: isLogin
    }
}

export function logout() {
    return dispatch => {
        tools.ajax({
            url: url.logout,
            info: "登出系统",
            actionType: LOGOUT,
            dispatch: dispatch,
			result: tools.ajax.resultEnum.bool,
            success: resp => {
              dispatch(setIsLogin(false));
              window.location.href='/';
            }
        });
    }
}






