import $ from "jquery"
import Immutable from "immutable"
import {
    RESET_TA_LIST,
    RESET_TA_DETAIL,
    RESET_TA_EDIT,
    GET_TA_LIST,
    UPDATE_TA_CONDITION,
    GET_CHECKED_TAS,
    DELETE_TAS,
    UPDATE_TAS_STATE,
    GET_EDIT_TA,
    GET_DETAIL_TA,
    SAVE_TA,
    GET_REFER_BY_TA,
    SET_CHECKED_TAS,
    GET_TA_OVERVIEWS,
    GET_TA_TREND,
    SET_REFER_CONDITION_BY_TA
} from "actionType"
import {tools} from "utils"
import {push} from "react-router-redux"

const url = {
    create: tools.javaApi("/ta/create"),
    edit: tools.javaApi("/ta/edit"),
    list: tools.javaApi("/ta/search"),
    info: tools.javaApi("/ta/info"),
    search: tools.javaApi("/ta/search"),
    updatestatus: tools.javaApi("/ta/updatestatus"),
    remove: tools.javaApi("/ta/delete"),
    getrelateessay: tools.javaApi("/ta/getrelateessay"),
    statistics_info: tools.javaApi("/statistics/ta/info"),
    statistics_trend: tools.javaApi("/statistics/ta/content")
}

export function reset() {
    return (dispatch) => {
        dispatch(resetList());
        dispatch(resetDetail());
        dispatch(resetEdit());
    }
}

export function resetList() {
    return {
        type: RESET_TA_LIST
    }
}

export function resetDetail() {
    return {
        type: RESET_TA_DETAIL
    }
}

export function resetEdit() {
    return {
        type: RESET_TA_EDIT
    }
}




/**
 * 搜索治疗领域列表
 *
 * @export
 * @param combCdt 待更新的查询条件
 * @returns (description)
 */
export function getTAList(combCdt) {
    // debugger;
    return (dispatch, getState) => {
        dispatch(updateTAConditions(combCdt));
        let conditions = getState().$$taList.toJS().conditions;
        return tools.ajax({
            url: url.search,
            info: "获取治疗领域列表",
            data: $.extend(true, {}, conditions, {
                key: JSON.stringify(conditions.key)
            }),
            dispatch: dispatch,
            actionType: GET_TA_LIST
        })
    }
}

/**
 * 更新搜索条件
 *
 * @param combCdt 待更新的查询条件
 * @returns (description)
 */
export function updateTAConditions(combCdt) {
    return {
        type: UPDATE_TA_CONDITION,
        data: combCdt
    }
}


/**
 * 更新选中的治疗领域
 *
 * @export
 * @param checkedTAs 选中治疗领域key的集合
 * @returns (description)
 */
export function setCheckedTAs(checkedTAs) {
    return {
        type: SET_CHECKED_TAS,
        data: checkedTAs
    }
}

/**
 * 批量删除治疗领域
 *
 * @export
 * @param checkedTAs 待删除的治疗领域key的集合
 * @returns (description)
 */
export function deleteTAs(checkedTAs) {
    return (dispatch) => {
        return tools.ajax({
            type: "post",
            url: url.remove,
            info: "刪除治疗领域",
            data: {
                ta_ids: checkedTAs.join()
            },
            result: tools.ajax.resultEnum.bool,
            dispatch: dispatch,
            actionType: DELETE_TAS,
            isShowSuccess: true,
            success() {
                dispatch(getTAList({
                    page: 1
                }));
                dispatch(setCheckedTAs([]));
            }
        })
    }
}


/**
 * 批量变更治疗领域状态
 *
 * @export
 * @param checkedTAs 待变更的治疗领域key的集合
 * @param dstState 变更后的状态
 * @returns (description)
 */
export function changeTAsState(checkedTAs, dstState) {
    return (dispatch) => {
        return tools.ajax({
            type: "post",
            url: url.updatestatus,
            info: "变更治疗领域状态",
            data: {
                ta_ids: checkedTAs.join(),
                status: dstState
            },
            result: tools.ajax.resultEnum.bool,
            dispatch: dispatch,
            actionType: UPDATE_TAS_STATE,
            isShowSuccess: true,
            success() {
                dispatch(getTAList());
                dispatch(setCheckedTAs([]));
            }
        })
    }
}



/**
 * 获取治疗领域详情信息
 *
 * @export
 * @param TAId 治疗领域id
 * @param isEdit 当前是否处于编辑页面
 * @returns (description)
 */
export function getTA(TAId, isEdit) {
    return (dispatch) => {
        return tools.ajax({
            url: url.info,
            info: "获取治疗领域详情",
            data: {
                ta_id: TAId
            },
            dispatch: dispatch,
            actionType: isEdit ? GET_EDIT_TA : GET_DETAIL_TA
        });
    }
}


/**
 * (description)
 *
 * @export
 * @param conditions 查询条件
 * @returns (description)
 */
export function getReferByTA(conditions) {
    return (dispatch, getState) => {
        return tools.ajax({
            url: url.getrelateessay,
            info: "获取引用详情",
            data: conditions,
            dispatch: dispatch,
            actionType: GET_REFER_BY_TA,
            success() {
      				dispatch(setReferConditionByTA(conditions))
      			}
        })
    }
}

export function setReferConditionByTA(conditions) {
	return {
		type: SET_REFER_CONDITION_BY_TA,
		data: conditions
	}
}



/**
 * 保存治疗领域
 *
 * @export
 * @param ta 待保存的治疗领域信息
 * @param isEdit 是否
 * 为编辑状态
 * @returns (description)
 */
export function saveTA(ta, isEdit = false) {
    return (dispatch) => {
        return tools.ajax({
            type: "post",
            url: isEdit ? url.edit : url.create,
            info: "保存治疗领域",
            data: ta,
            result: isEdit ? tools.ajax.resultEnum.bool : tools.ajax.resultEnum.guid,
            dispatch: dispatch,
            actionType: SAVE_TA,
            isShowSuccess: true,
            success(resp) {
                if (isEdit) {
                    dispatch(getTA(ta.ta_id));
                } else {
                    dispatch(updateTAConditions({
                        page: 1,
                        key: {title: ''}
                    }));
                    dispatch(getTAList());
                }
            }
        });
    }
}

//------------数据统计-------------
export function getOverView(cdt) {
    return dispatch => {
        return tools.ajax({
            url: url.statistics_info,
            data: {
                company_id: cdt.company_id,
                ta_id: cdt.ta_id
            },
            info: "获取概要",
            dispatch: dispatch,
            actionType: GET_TA_OVERVIEWS
        });
    }
}

/*
 * 根据查询条件获取趋势列表
 *
 * @export
 * @param combCdt 待合并的查询条件
 * @returns (description)
 */
export function getTrend(cdt) {
    return (dispatch, getState) => {
        return tools.ajax({
            url: url.statistics_trend,
            data: {
                company_id: cdt.company_id,
                ta_id: cdt.ta_id,
                range: cdt.range,
                type: cdt.type.join()
            },
            info: "获取趋势",
            result: tools.ajax.resultEnum.array,
            dispatch: dispatch,
            actionType: GET_TA_TREND
        });
    }
}
