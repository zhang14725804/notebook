import {
    GET_BROADCARD_LIST,
    RESET_BROAD_LIST
} from 'actionType';
import {tools} from 'src/utils';
const url = {
    getBroadCardList: tools.javaApi("/block/list"),//业务推广卡片列表
}
export function resetbroadlist() {
    return (dispatch)=>{
        dispatch({
            type:RESET_BROAD_LIST
        })
    }
}

export function getBroadcardList(){
    let data=[
        {
            id:1,
            cn_name:'力白汀',
            des:'阿莫西林克拉维酸钾',
            zz:'呼吸道感染',
            sumP:32198,
            sum1:7,
            sum2:8,
            sum3:32,
            labelName:'HCP',
            labelType:1
        },{
            id:2,
            cn_name:'韦瑞德',
            des:'富马酸替诺福韦二吡呋酯克拉维酸钾',
            zz:'HIV',
            sumP:321,
            sum1:2,
            sum2:3,
            sum3:12,
            labelName:'大众',
            labelType:2
        },{
            id:3,
            cn_name:'利必通',
            des:'拉莫三嗪',
            zz:'癫痫',
            sumP:22312,
            sum1:5,
            sum2:5,
            sum3:21,
            labelName:'大众',
            labelType:2
        },{
            id:4,
            cn_name:'万托林',
            des:'硫酸沙丁胺醇',
            zz:'慢性阻塞性肺部疾患',
            sumP:1252,
            sum1:7,
            sum2:8,
            sum3:32,
            labelName:'HCP',
            labelType:1
        },
    ]
    return (dispatch,getState) => {
        // return tools.ajax({
        //     url: url.getBroadCardList,
        //     method: 'get',
        //     responseType: 'json',
        //     dispatch: dispatch,
        //     actionType: GET_BROADCARD_LIST,
        //     success(resp) {}
        // });

        dispatch({
            type:GET_BROADCARD_LIST,
            data:data
        })
    }
}