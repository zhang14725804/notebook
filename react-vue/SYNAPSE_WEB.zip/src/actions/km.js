import {
    GET_KMTREE_LIST,
    RESET_KMTREE_LIST,
    POST_CHANGETREE_STATUS,
    POST_SAVE_ADDOREDIT,
    GET_TREE_TAG_DETAIL,
    GET_TREE_TAG_ADD,
    RESET_KMTREE_DETAIL
} from 'actionType';
import {tools} from 'src/utils';
const url = {
    getKMTreeList: tools.javaApi("/KM/tree"),//业务推广卡片列表
    changeTreeStatus1: tools.javaApi("/KM/enable"),//启用
    changeTreeStatus2: tools.javaApi("/KM/disable"),//禁用
    deleteTreeTag: tools.javaApi("/KM/delete"),//删除树节点
    getTreeDetail: tools.javaApi("/KM/info"),//获取节点详情
    saveAddKMTree: tools.javaApi("/KM/addKM"),//保存新增树节点
    saveEditKMTree: tools.javaApi("/KM/update"),//保存编辑树节点
}
export function resetkmTreelist() {
    return (dispatch)=>{
        dispatch({
            type:RESET_KMTREE_LIST
        })
    }
}

export function getkmTreeList(params){
    let data=[
        {a:1}
    ]
    return (dispatch,getState) => {
        return tools.ajax({
            url: url.getKMTreeList,
            method: 'get',
            data:params,
            responseType: 'json',
            dispatch: dispatch,
            actionType: GET_KMTREE_LIST,
        });

        // dispatch({
        //     type:GET_KMTREE_LIST,
        //     data:data
        // })
    }
}

// 启用禁用
export function changeStatus(status,id) {
    console.log(status,id, 'changeStatus');
    let urlNow=status?url.changeTreeStatus1:url.changeTreeStatus2;
    let param=status?{id:id,enable:true}:{id:id,disable:false}
    return dispatch => {
        return tools.ajax({
            url: urlNow,
            type: "get",
            info: status?'启用':'禁用',
            data: param,
            // result: tools.ajax.resultEnum.bool,
            isShowSuccess: true,
            dispatch: dispatch,
            actionType: POST_CHANGETREE_STATUS,
            success(resp){
                dispatch(getkmTreeList({block_id:1}));//启用禁用成功后重新获取树列表
            }
        });
    }
}

// 删除树节点
export function deleteTreeTag(treeId){
    console.log(treeId,'treeId');
    return (dispatch) => {
        return tools.ajax({
            url: url.deleteTreeTag+"/"+treeId,
            method: 'post',
            info: "删除节点",
            isShowSuccess: true,
            dispatch: dispatch,
            actionType: RESET_KMTREE_LIST,
            success(resp) {
                if(resp.code==10000){
                    dispatch(getkmTreeList({block_id:1}));
                }
            }
        });
    }
}

//新增 编辑树
export function saveKMTree(data,isEdit) {
    console.log("isEdit===",data,isEdit)
    return (dispatch) => {
        return tools.ajax({
            type: "post",
            url: isEdit ? url.saveEditKMTree :　url.saveAddKMTree,
            info: "保存树",
            data: data,
            dispatch: dispatch,
            actionType: POST_SAVE_ADDOREDIT,
            success(resp) {
                dispatch(getkmTreeList({block_id:1}));
            }
        });
    }
}

//获取标签详情
export function getTreeDetail(treeId) {
    return (dispatch) => {
        return tools.ajax({
            url: url.getTreeDetail,
            type:'get',
            data:{id:treeId},
            info: "获取节点详情",
            dispatch: dispatch,
            actionType:GET_TREE_TAG_DETAIL
            // actionType: isEdit ? GET_TREE_TAG_DETAIL : GET_TREE_TAG_ADD
        });
    }
}
export function resetTreeDetail() {
    return (dispatch)=>{
        dispatch({
            type:RESET_KMTREE_DETAIL
        })
    }
}