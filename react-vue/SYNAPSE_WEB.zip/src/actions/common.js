import $ from "jquery"
import Immutable from "immutable"
import {
    GET_ALL_PRODUCT,
    GET_ALL_TA,
    GET_ALL_TEMPLATE,
    GET_ALL_DEPARTMENT,
    GET_ALL_HOSPLEVEL,
    GET_ALL_DOCLEVEL,
    GET_ALL_ARTICLE_TYPE,
    GET_All_AUTHORITY,
    GET_KM_BY_CONDITION,
    GET_ALL_KP,
    SET_FIELD_VALUE,
    GET_ALL_USERGROUP,
    GET_DEPTLIST,
    GET_NEWS_PREVIEW,
    RESET_PREVIEW,
    GET_H5_PREVIEW,
    GET_QA_PREVIEW,
    GET_ALL_PROVINCE,
    SET_CUR_TAB_MENU
} from "actionType"
import { tools } from "utils"
import { Enum } from "enum"


const url = {
    druglist: tools.javaApi("/product/list"),
    talist: tools.javaApi("/ta/list"),
    keywordlist: tools.javaApi("/keyword/list"),
    coverage: tools.javaApi("/aj/promotion/coverage"),
    powerlist: tools.javaApi("/group/powerlist"),
    getrelatelist: tools.javaApi("/keyword/getrelatelist"),
    templatelist: tools.javaApi("/promotion/templatelist"),
    grouplist: tools.javaApi("/group/list"),
    deptlist: tools.javaApi("/promotion/deptlist"),
    essayDetail: tools.openApi("/subject/preview/essay/details"),
    h5Detail: tools.javaApi("/h5/preview"),
    qaDetail: tools.openApi("/subject/preview/qa/details"),
}

/**
 * 获取所有产品集合
 *
 * @export
 * @returns (description)
 */
export function getAllProduct() {
    return (dispatch) => {
        return tools.ajax({
            url: url.druglist,
            info: "获取产品列表",
            data: {
                page: 1,
                status: Enum.ProductState.enable
            },
            dispatch: dispatch,
            actionType: GET_ALL_PRODUCT
        })
    }
}

/**
 * 获取所有治疗领域集合
 *
 * @export
 * @returns (description)
 */
export function getAllTa() {
    return (dispatch) => {
        return tools.ajax({
            url: url.talist,
            info: "获取治疗领域列表",
            data: {
                page: 1,
                status: Enum.TAState.enable
            },
            dispatch: dispatch,
            actionType: GET_ALL_TA
        })
    }
}


/**
 * 获取所有信息点集合
 *
 * @export
 * @returns (description)
 */
export function getAllKp() {
    return (dispatch) => {
        return tools.ajax({
            url: url.kplist,
            info: "获取信息点列表",
            data: {
                page: 1,
                status: Enum.KpState.enable
            },
            dispatch: dispatch,
            actionType: GET_ALL_KP
        })
    }
}


/**
 * 获取全部受众模板列表
 *
 * @export
 * @returns (description)
 */
export function getAllTemplate() {
    return (dispatch) => {
        return tools.ajax({
            url: url.templatelist,
            info: "获取受众模板列表",
            dispatch: dispatch,
            actionType: GET_ALL_TEMPLATE
        });
    }
}

/**
 * 获取所有科室
 *
 * @export
 * @returns (description)
 */
export function getAllDepartment() {
    return (dispatch) => {
        return tools.ajax({
            url: url.coverage,
            data: {
                type: Enum.CoverageType.department
            },
            info: "获取科室列表",
            dispatch: dispatch,
            actionType: GET_ALL_DEPARTMENT
        });
    }
}


/**
 * 获取省份列表
 *
 * @export
 * @returns (description)
 */
export function getAllProvince() {
    return (dispatch) => {
        return tools.ajax({
            url: url.coverage,
            data: {
                type: Enum.CoverageType.province
            },
            info: "获取省份列表",
            dispatch: dispatch,
            actionType: GET_ALL_PROVINCE
        });
    }
}

/**
 * 获取全部医院分级
 *
 * @export
 * @returns (description)
 */
export function getAllHospLevel() {
    return (dispatch) => {
        return tools.ajax({
            url: url.coverage,
            data: {
                type: Enum.CoverageType.hospLevel
            },
            info: "获取医院分级列表",
            dispatch: dispatch,
            actionType: GET_ALL_HOSPLEVEL
        });
    }
}

/**
 * 获取全部医生分级
 *
 * @export
 * @returns (description)
 */
export function getAllDocLevel() {
    return (dispatch) => {
        return tools.ajax({
            url: url.coverage,
            data: {
                type: Enum.CoverageType.docLevel
            },
            info: "获取医生分级列表",
            dispatch: dispatch,
            actionType: GET_ALL_DOCLEVEL
        });
    }
}

/**
 * 获取全部功能模块权限
 *
 * @export
 * @returns (description)
 */
export function getAllAuthority() {
    return (dispatch) => {
        return tools.ajax({
            url: url.powerlist,
            result: tools.ajax.resultEnum.array,
            info: "获取功能权限",
            dispatch: dispatch,
            actionType: GET_All_AUTHORITY
        });
    }
}



// /**
//  * 获取所有文章类型
//  *
//  * @export
//  * @returns (description)
//  */
// export function getAllArticleType(pdtIds, taIds) {
//     return (dispatch) => {
//         return tools.ajax({
//             url: "http://emkt.sfaessentials.com/aj/department/list",
//             info: "获取文章类型",
//             dispatch: dispatch,
//             actionType: GET_ALL_ARTICLE_TYPE
//         });
//     }
// }

/**
 * 获取全部用户组
 *
 * @returns (description)
 */
export function getAllUserGroup() {
    return (dispatch) => {
        return tools.ajax({
            url: url.grouplist,
            info: "获取全部用户组",
            data: {
                page: 1
            },
            dispatch: dispatch,
            actionType: GET_ALL_USERGROUP
        });
    }
}


/**
 * 根据条件获取信息点
 *
 * @export
 * @param pdtIds 产品id集合
 * @param taIds 治疗领域id集合
 * @returns (description)
 */
export function getKmByPdtAndTa(pdtIds, taIds) {
    return (dispatch) => {
        return tools.ajax({
            url: url.getrelatelist,
            info: "获取信息点",
            data: {
                product_id: (pdtIds || []).join(",") || undefined,
                ta_id: (taIds || []).join(",") || undefined,
                status: Enum.KpState.enable
            },
            result: tools.ajax.resultEnum.array,
            dispatch: dispatch,
            actionType: GET_KM_BY_CONDITION
        });
    }
}

export function setFieldValue(name, value) {
    return {
        type: SET_FIELD_VALUE,
        data: {
            name: name,
            value: value
        }
    }
}


/*
* 获取一级科室列表
* @param
*/
export function getDeptList() {
    return (dispatch, getState) => {
        return tools.ajax({
            url: url.deptlist,
            info: "获取一级科室列表",
            result: tools.ajax.resultEnum.array,
            dispatch: dispatch,
            actionType: GET_DEPTLIST
        });
    }
}


export function resetPreview() {
    return {
        type: RESET_PREVIEW
    }
}

/*
* 获取图文预览
* @param id 推广id
*/
export function getNewsPreview(newsId, promotionId) {
    if (newsId == 0) {
        return {
            type: GET_NEWS_PREVIEW
        }
    } else {
        return (dispatch, getState) => {
            return tools.ajax({
                url: url.essayDetail,
                data: {
                    essay_id: newsId,
                    promotion_id: promotionId || 0
                },
                info: "获取图文预览",
                dispatch: dispatch,
                actionType: GET_NEWS_PREVIEW
            });
        }
    }
}

/*
* 获取H5预览
* @param id 推广id
*/
export function getH5Preview(h5Id, promotionId) {
    return (dispatch, getState) => {
        return tools.ajax({
            url: url.h5Detail,
            data: {
                id: h5Id,
            },
            info: "获取H5预览",
            dispatch: dispatch,
            actionType: GET_H5_PREVIEW
        });
    }
}

/*
* 获取H5预览
* @param id 推广id
*/
export function getQaPreview(qaId) {
    return (dispatch, getState) => {
        return tools.ajax({
            url: url.qaDetail,
            data: {
                qaId: qaId,
            },
            info: "获取问卷预览",
            dispatch: dispatch,
            actionType: GET_QA_PREVIEW
        });
    }
}

// 储存当前所在的二级菜单项
export function setCurTabMenu(id){
    return (dispatch, getState) => {
        return dispatch({
            type: SET_CUR_TAB_MENU,
            data: id
        })
    }
}
