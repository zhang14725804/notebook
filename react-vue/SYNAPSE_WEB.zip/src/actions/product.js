import $ from "jquery"
import Immutable from "immutable"
import {push} from "react-router-redux"
import {
    RESET_PRODUCT_LIST,
    RESET_PRODUCT_DETAIL,
    RESET_PRODUCT_EDIT,
    GET_PRODUCT_LIST,
    SET_CHECKED_PRODUCTS,
    DELETE_PRODUCTS,
    UPDATE_PRODUCTS_STATE,
    GET_EDIT_PRODUCT,
    GET_DETAIL_PRODUCT,
    SET_PRODUCT,
    SAVE_PRODUCT,
    UPDATE_PRODUCT_CONDITIONS,
    GET_PDT_OVERVIEWS,
    GET_PDT_TREND
} from "actionType"
import {tools} from "utils"
import {Enum} from "enum"

const url = {
    create: tools.javaApi("/product/create"),
    edit: tools.javaApi("/product/edit"),
    list: tools.javaApi("/product/search"),
    info: tools.javaApi("/product/info"),
    updatestatus: tools.javaApi("/product/updatestatus"),
    search: tools.javaApi("/product/search"),
    remove: tools.javaApi("/product/delete"),
    statistics_info: tools.javaApi("/statistics/product/info"),
    statistics_trend: tools.javaApi("/statistics/product/content")
}


export function reset() {
    return (dispatch) => {
        dispatch(resetList());
        dispatch(resetDetail());
        dispatch(resetEdit());
    }
}

export function resetList() {
    return {
        type: RESET_PRODUCT_LIST
    }
}

export function resetDetail() {
    return {
        type: RESET_PRODUCT_DETAIL
    }
}

export function resetEdit() {
    return {
        type: RESET_PRODUCT_EDIT
    }
}

/**
 * 获取产品列表
 *
 * @export
 * @param combCdt 待更新的查询条件
 * @returns (description)
 */
export function getProductList(combCdt) {
    return (dispatch, getState) => {
        dispatch(updatePdtConditions(combCdt));
        let conditions = getState().$$productList.toJS().conditions;
        return tools.ajax({
            url: url.search,
            info: "获取产品列表",
            // data: conditions,
            data: $.extend(true, {}, conditions, {
                key: JSON.stringify(conditions.key)
            }),
            dispatch: dispatch,
            actionType: GET_PRODUCT_LIST
        })
    }
}

/**
 * 更新搜索条件
 *
 * @param combCdt 更新并的查询条件
 * @returns (description)
 */
function updatePdtConditions(combCdt) {
    return {
        type: UPDATE_PRODUCT_CONDITIONS,
        data: combCdt
    }
}

/**
 * 更新选中的产品
 *
 * @export
 * @param checkedPdts 选中产品key的集合
 * @returns (description)
 */
export function setCheckedPdts(checkedPdts) {
    return {
        type: SET_CHECKED_PRODUCTS,
        data: checkedPdts
    }
}

/**
 * 批量删除产品
 *
 * @export
 * @param checkedPdts 待删除的产品key的集合
 * @returns (description)
 */
export function deletePdts(checkedPdts) {
    return (dispatch, getState) => {
        return tools.ajax({
            type: "post",
            url: url.remove,
            info: "刪除产品",
            data: {
                product_ids: checkedPdts.join()
            },
            result: tools.ajax.resultEnum.bool,
            isShowSuccess: true,
            dispatch: dispatch,
            actionType: DELETE_PRODUCTS,
            success() {
                dispatch(getProductList({
                    page: 1
                }));
                dispatch(setCheckedPdts([]));
            }
        })
    }
}


/**
 * 批量变更产品状态
 *
 * @export
 * @param checkedPdts 待变更的产品key的集合
 * @param dstState 变更后的状态
 * @returns (description)
 */
export function changePdtsState(checkedPdts, dstState) {
    return (dispatch, getState) => {
        return tools.ajax({
            type: "post",
            url: url.updatestatus,
            info: "变更产品状态",
            data: {
                product_ids: checkedPdts.join(),
                status: dstState
            },
            result: tools.ajax.resultEnum.bool,
            isShowSuccess: true,
            dispatch: dispatch,
            actionType: UPDATE_PRODUCTS_STATE,
            success() {
                dispatch(getProductList());
                dispatch(setCheckedPdts([]));
            }
        })
    }
}


/**
 * 获取产品详情信息
 *
 * @export
 * @param pdtId 产品id
 * @param isEdit 是否为在添加编辑页获取
 * @returns (description)
 */
export function getPdt(pdtId, isEdit) {
    return (dispatch) => {
        return tools.ajax({
            url: url.info,
            info: "获取产品详情",
            data: {
                product_id: pdtId
            },
            dispatch: dispatch,
            actionType: isEdit ? GET_EDIT_PRODUCT : GET_DETAIL_PRODUCT
        });
    }
}


/**
 * 保存产品
 *
 * @export
 * @param pdt 待保存的产品信息
 * @param isEdit 是否为编辑状态
 * @returns (description)
 */
export function savePdt(pdt, isEdit) {
    return (dispatch) => {
        return tools.ajax({
            type: "post",
            url: isEdit ? url.edit : url.create,
            info: "保存产品",
            data: $.extend(true, {}, pdt, {
                //上市时间
                listing_time: pdt.listing_time ? new hDate(pdt.listing_time).getTime() : undefined,
                //状态
                status: pdt.status === true ? Enum.ProductState.enable : Enum.ProductState.disable
            }),
            result: isEdit ? tools.ajax.resultEnum.bool : tools.ajax.resultEnum.guid,
            dispatch: dispatch,
            actionType: SAVE_PRODUCT,
            isShowSuccess: true,
            success(resp) {
                //跳转详情页
                dispatch(push({
                    pathname: "/product/detail",
                    query: {
                        productId: isEdit ? pdt.product_id : resp.data
                    }
                }));
            }
        });
    }
}


//------------数据统计-------------
export function getOverView(cdt) {
    return dispatch => {
        return tools.ajax({
            url: url.statistics_info,
            data: {
                company_id: cdt.company_id,
                product_id: cdt.product_id
            },
            info: "获取概要",
            dispatch: dispatch,
            actionType: GET_PDT_OVERVIEWS
        });
    }
}

/*
 * 根据查询条件获取趋势列表
 *
 * @export
 * @param combCdt 待合并的查询条件
 * @returns (description)
 */
export function getTrend(cdt) {
    return (dispatch, getState) => {
        return tools.ajax({
            url: url.statistics_trend,
            data: {
                company_id: cdt.company_id,
                product_id: cdt.product_id,
                range: cdt.range,
                type: cdt.type.join()
            },
            info: "获取趋势",
            result: tools.ajax.resultEnum.array,
            dispatch: dispatch,
            actionType: GET_PDT_TREND
        });
    }
}
