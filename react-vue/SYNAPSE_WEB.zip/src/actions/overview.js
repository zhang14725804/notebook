import $ from "jquery"
import {
    GET_OVERVIEWS,
    GET_TREND,
    UPDATE_TREND_CONDITIONS,
    GET_DISTRIBUTION,
    UPDATE_DISTRIBUTION_CONDITIONS,
    RESET_OVERVIEW,
    GET_RELATE_FREQ,
    GET_INCLUDING_FREQ,
    GET_CONCENTRATE,
    UPDATE_FREQ_RELATE,
    UPDATE_FREQ_INCLUDING
} from "actionType"
import { tools } from "utils"

const url = {
    info: tools.javaApi("/statistics/general/info"),
    trend: tools.javaApi("/statistics/general/trend"),
    area: tools.javaApi("/statistics/general/area"),
    Frequency: tools.javaApi("/statistics/general/Frequency"),
    grades: tools.javaApi("/statistics/general/grades"),
    usercount: tools.javaApi("/statistics/general/usercount")
}

/**
 *
 * 重置页面数据
 * @export
 * @returns
 */
export function reset() {
    return {
        type: RESET_OVERVIEW
    }
}

/**
 *
 * 获取概要详情
 * @export
 * @param {any} cdt
 * @returns
 */
export function getOverView(cdt) {
    return dispatch => {
        return tools.ajax({
            url: url.info,
            data: {
                company_id: cdt.company_id,
                range: cdt.range
            },
            info: "获取概要",
            dispatch: dispatch,
            actionType: GET_OVERVIEWS
        });
    }
}

/*
 * 根据查询条件获取趋势列表
 *
 * @exportp
 * @param combCdt 待合并的查询条件
 * @returns (description)
 */
export function getTrend(cdt) {
    return (dispatch, getState) => {
        return tools.ajax({
            url: url.trend,
            data: {
                company_id: cdt.company_id,
                range: cdt.range,
                type: cdt.type.join()
            },
            info: "获取趋势",
            result: tools.ajax.resultEnum.array,
            dispatch: dispatch,
            actionType: GET_TREND,
            success() {
                dispatch(updateTrendConditions({
                    range: cdt.range.toString(),
                    type: cdt.type.map((item) => {
                        return item.toString();
                    })
                }))
            }
        });
    }
}

/**
 * 更新搜索条件
 *
 * @param combCdt 更新并的查询条件
 * @returns (description)
 */
function updateTrendConditions(combCdt) {
    return {
        type: UPDATE_TREND_CONDITIONS,
        data: combCdt
    }
}

/*
 * 根据查询条件获取分布列表
 *
 * @export
 * @param combCdt 待合并的查询条件
 * @returns (description)
 */
export function getDistribute(cdt) {
    return (dispatch, getState) => {
        return tools.ajax({
            url: url.area,
            data: cdt,
            info: "获取地区访问量分布",
            result: tools.ajax.resultEnum.array,
            dispatch: dispatch,
            actionType: GET_DISTRIBUTION,
            success() {
                dispatch(updateDistributeConditions({
                    range: cdt.range.toString(),
                    type: cdt.type.toString()
                }))
            }
        });
    }
}

/**
 * 更新搜索条件
 *
 * @param combCdt 更新并的查询条件
 * @returns (description)
 */
function updateDistributeConditions(combCdt) {
    return {
        type: UPDATE_DISTRIBUTION_CONDITIONS,
        data: combCdt
    }
}

/*
 * 根据查询条件获取关联频次
 *
 * @export
 * @param relate_id 查询的关联条件
 * @returns (description)
 */
export function getRelateFreq(cdt) {
    return (dispatch, getState) => {
        return tools.ajax({
            url: url.Frequency,
            data: {
                company_id: cdt.company_id,
                type: cdt.type
            },
            info: "获取关联频次占比",
            result: tools.ajax.resultEnum.array,
            dispatch: dispatch,
            actionType: GET_RELATE_FREQ,
            success() {
                dispatch(updateFreqRelate(cdt.type.toString()))
            }
        });
    }
}


/**
 * 更新搜索条件
 *
 * @param combCdt 更新并的查询条件
 * @returns (description)
 */
function updateFreqRelate(combCdt) {
    return {
        type: UPDATE_FREQ_RELATE,
        data: combCdt
    }
}



/*
 * 根据查询条件获取覆盖频次
 *
 * @export
 * @param relate_id 查询的覆盖条件
 * @returns (description)
 */
export function getIncludingFreq(cdt) {
    return (dispatch, getState) => {
        return tools.ajax({
            url: url.grades,
            data: {
                company_id: cdt.company_id,
                type: cdt.type
            },
            info: "获取覆盖频次占比",
            result: tools.ajax.resultEnum.array,
            dispatch: dispatch,
            actionType: GET_INCLUDING_FREQ,
            success() {
                dispatch(updateFreqIncluding(cdt.type.toString()))
            }
        });
    }
}

/**
 * 更新搜索条件
 *
 * @param combCdt 更新并的查询条件
 * @returns (description)
 */
function updateFreqIncluding(combCdt) {
    return {
        type: UPDATE_FREQ_INCLUDING,
        data: combCdt
    }
}



/**
 * 获取内容关注度
 *
 * @export
 * @returns (description)
 */
export function getConcentrate(cdt) {
    return (dispatch, getState) => {
        return tools.ajax({
            url: url.usercount,
            data: cdt,
            info: "获取关注度",
            result: tools.ajax.resultEnum.array,
            dispatch: dispatch,
            actionType: GET_CONCENTRATE
        });
    }
}

