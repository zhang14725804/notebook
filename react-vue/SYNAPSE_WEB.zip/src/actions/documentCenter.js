import $ from "jquery"
import Immutable from "immutable"
import { push } from "react-router-redux"
import {
    UPDATE_DOCUMENT_CENTER_LIST_CONDITIONS,
    GET_DOCUMENT_CENTER_LIST,
    RESET_DOCUMENT_CENTER_LIST,
    SAVE_SELECTED_DOCUMENTCENTER_KEYS,
    RENAME_DOCUMEMT,
    DELETE_DOCUMENT,
    OPERATE_TOP_FOLDER,
    GET_TOP_FOLDER,
    ADD_FOLDER,
    GET_DC_ANCESTOR_LIST,
    RESET_DOCUMENT_CENTER_EDIT,
    GET_DC_RELATED_BRAND,
    GET_DC_EMP_BRAND,
    GET_DOCUMENT_THERAPEUTICAREA,
    GET_DC_KEYMESSAGE,
    GET_PREVIEW_IMG,
    SAVE_DC_CONFIG,
    SAVE_FILE,
    SAVE_CHECKED_TAGKEYS,
    GET_DC_RELATED_TREE,
    GET_DC_RELATED_TREE_TRUE,
    UPDATE_DOCUMENT_CENTER_CHECKED,
    GET_ALL_PRODUCT,
    GET_ALL_KMSG,
    SAVE_NEWS_PREVIEW,
    GET_EDIT_NEWS,
    GET_DETAIL_NEWS,
    SAVE_NEWS_PREVIEW_UPDATE,
    SAVE_NEWS,
    GET_NEWS_PREVIEW_DETAIL,
    SAVE_DOCUMNENT_CONDITIONS_TEMP,
    SET_CHECKED_DOCUMENT,
    SAVE_DOCUMENT_CENTER_EXPIRE,
    ADD_DOCUMENT_CENTER_IMAGETEXT,
    UPDATE_DOCC_WX_INTRODUCTION,
    UPDATE_DOCC_WX_INDEX,
    GET_HTML_TYPE,
    SAVE_DC_HTML_URL,
    SAVE_PAGE_KEY_INFO,
    SAVE_PAGE,
    GET_EDIT_WX_NEWS,
    GET_DETAIL_WX_NEWS,
    SAVE_EQUAL_TREE_DATA,
    GET_DC_CONFIG_DETAIL,
    DOWNLOAD_DOCUMENT,
    GET_DOCUMENT_CENTER_LIST_BYSEARCH,
    UPDATE_DOCUMENT_LIST_CONDITIONS,
    GET_TOP_FOLDER_RELATION,
    CHANGE_SEARCH_LABELID,
    SAVE_UPLOAD_STATUS,   //保存上传文件的状态，用于判断点击下一步按钮显示的文字

    // QA
    SET_DC_QUESTION,
    REMOVE_DC_QA_OPTION,
    UPDATE_DC_QA_OPTION_CONTENT,
    UPDATE_DC_QA_RADIO_STATE,
    UPDATE_DC_QA_CHECKBOX_STATE,
    RESET_DC_QUESTION,
    SAVE_DC_QA,

    // VOL
    GET_DC_VOL_MUDU_ACCOUNT
} from "actionType"
import { tools } from "utils"
import { Enum } from "enum"
import dcListData from "mockdata/dcListData"
import dcAncestorListData from "mockdata/dcAncestorListData"

// import documentCenterManagementData from '../mockdata/documentCenterManagementData.js'

const url = {
    getDocumentCenterList: tools.javaApi("/api/doc/search"), //列表
    getAncestorList: tools.javaApi("/api/doc/getAncestorList"),   //获取上一级文件
    getVolMuduAccount: tools.javaApi("/ol/mudu"),

    getDocumentCenterListBySearch: tools.javaApi("/api/doc/advancedSearch"), //列表搜索
    changeBatchEnable: tools.javaApi("/api/doc/batchEnable"),
    changeBatchDisable: tools.javaApi("/api/doc/batchDisable"),
    renameDocument: tools.javaApi("/api/doc/rename"),
    deleteDocument: tools.javaApi("/api/doc/delete/"),
    operateTopFolder: tools.javaApi("/api/doc/operateTopFolder"),
    getTopFolder: tools.javaApi("/api/doc/getTopFolder"),
    addFolder: tools.javaApi("/api/doc/addFolder"),
    downloadDocument: tools.javaApi("/api/doc/download"),     //下载文件

    getDCRelatedBrand: tools.javaApi("/api/brand/selectAll"),       //获取关联品牌 ？---是否包含确认
    getDCEmpBrand: tools.javaApi("/api/brand/myBrand"),       //获取关联品牌 ？---是否包含确认
    getTherapeuticArea: tools.javaApi("/api/therapeuticArea/list"), // ？状态为启用的接口
    getKeyMessage: tools.javaApi("/api/keyMessage/list"), // ？状态为启用的接口
    getDCPreview: tools.javaApi("/api/doc/preview"),
    saveDCConfig: tools.javaApi("/api/doc/add"),//新增文档上传配置
    getDCConfigDetail: tools.javaApi("/api/doc/getInformationForUpdate"),//获取文档详情
    // getDCConfigDetail: tools.javaApi("/api/doc/getInformation?isFirst=true"),//获取文档详情
    updateDCConfig: tools.javaApi("/api/doc/edit/"),//编辑文档上传配置
    getDCRelatedTree: tools.javaApi("/api/label/tree"),
    getDCRelatedTreeTrue: tools.javaApi("/api/label/tree/true"),
    // saveDocumentCenterList: tools.javaApi("/api/commonName/add"),
    // getDocumentCenterDetail: tools.javaApi("/api/commonName/"),
    // editDocumentCenter: tools.javaApi("/api/commonName/update"),
    kplist: tools.javaApi("/api/keyMessage/searchByProdAndTheaArea"),//根据产品和治疗领域去查询信息点
    add: tools.javaApi("/api/doc/material/add"),//单图文新增
    preview_update: tools.javaApi("/api/doc/material/update"),//单图文编辑
    preview_info: tools.javaApi("/api/doc/getInformationForUpdate"),//单图文详情
    preview_add: tools.javaApi("/api/doc/addPreview"),//单图文保存前预览
    preview_detail: tools.javaApi("/api/doc/preview/details"),//单图文保存前预览
    getTopFolderRelation: tools.javaApi("/api/doc/getRelation"),//获取顶级文件夹关联的治疗领域

}

/******************************* 列表页 start *****************************/
/**
 * 获取文档列表
 * 
 * @export
 * @param {any} combCdt
 * @returns
 */
export function getDocumentCenterList(combCdt) {
    return (dispatch, getState) => {
        dispatch(updateDocumentListConditions(combCdt));
        let conditions = getState().$$documentCenterList.toJS().conditions;
        //数据转换
        $.extend(true, conditions, {
            id: !isNaN(Number(conditions.id)) ? Number(conditions.id) : 0
        })
        console.log('-- dcListData --', dcListData, conditions.id, dcListData[conditions.id])
        // return tools.ajax({
        //     url: url.getDocumentCenterList,
        //     type: "post",
        //     info: "获取文档列表",
        //     data: $.extend(true, {}, conditions),
        //     dispatch: dispatch,
        //     actionType: GET_DOCUMENT_CENTER_LIST
        // });
        return dispatch({
            type: GET_DOCUMENT_CENTER_LIST,
            data: dcListData[conditions.id].data
        })
    }
}

/**
 * 获取文档搜索结果列表
 * 
 * @export
 * @param {any} combCdt
 * @returns
 */
export function getDocumentCenterListBySearch(combCdt) {
    return (dispatch, getState) => {
        //   dispatch(updateDocumentCenterListConditions(combCdt));
        let conditionsSearch = getState().$$documentCenterList.toJS().conditionsSearch;
        return tools.ajax({
            url: url.getDocumentCenterListBySearch,
            type: "post",
            info: "获取文档搜索结果列表",
            data: $.extend(true, {}, conditionsSearch),
            dispatch: dispatch,
            actionType: GET_DOCUMENT_CENTER_LIST_BYSEARCH
        });
    }
}

/**
 * 获取上一级文件路径
 * 
 * @export
 * @param {any} id 
 * @returns 
 */
export function getAncestorList(docId) {
    var id = !isNaN(Number(docId)) ? Number(docId) : 0;
    return (dispatch) => {
        // return tools.ajax({
        //     url: url.getAncestorList + "?id=" + id,
        //     info: "获取上级文件",
        //     dispatch: dispatch,
        //     actionType: GET_DC_ANCESTOR_LIST
        // });
        return dispatch({
            type: GET_DC_ANCESTOR_LIST,
            data: dcAncestorListData[id].data
        })
    }

}

/**
 * 新增顶级文件夹
 * 
 * @export
 * @param {any} id 
 * @returns 
 */
export function getTopFolder(id) {
    return (dispatch) => {
        return tools.ajax({
            url: url.getTopFolder + `?id=${id}`,
            info: "获取顶级文件夹信息",
            dispatch: dispatch,
            actionType: GET_TOP_FOLDER,
        });
    }

}

/**
 * 获取顶级文件夹信息
 * 
 * @export
 * @param {any} id 
 * @param {any} name 
 * @returns 
 */
export function operateTopFolder(data) {
    return (dispatch, getState) => {
        let conditions = getState().$$documentCenterList.toJS().conditions;
        return tools.ajax({
            url: url.operateTopFolder,
            type: "post",
            data: data,
            info: "新增顶级文件夹",
            dispatch: dispatch,
            actionType: OPERATE_TOP_FOLDER,
            success: (data) => {
                dispatch(getDocumentCenterList(conditions));
            }
        });
    }

}
/**
 * 新增文件夹
 * 
 * @export
 * @param {any} id 
 * @param {any} name 
 * @returns 
 */
export function addFolder(id, name) {
    return (dispatch) => {
        return tools.ajax({
            url: url.addFolder,
            type: "post",
            data: {
                "folder_name": name,
                "parent_id": id
            },
            info: "新增文件夹",
            dispatch: dispatch,
            actionType: ADD_FOLDER
        });
    }

}

/**
 * 重命名文档
 * 
 * @export
 * @param {any} id 
 * @param {any} name 
 * @returns 
 */
export function renameDocument(id, name) {
    return (dispatch) => {
        return tools.ajax({
            // url: encodeURI(url.renameDocument + "?id=" + id + "&name=" + name),
            // url: url.renameDocument + "?id=" + id + "&name=" + encodeURI(name),
            url: url.renameDocument,
            type: "post",
            info: "重命名文档",
            data: {
                "id": id,
                "name": name
            },
            dispatch: dispatch,
            actionType: RENAME_DOCUMEMT
        });
    }
}

/**
 * 删除文档
 * 
 * @export
 * @param {any} data 
 * @returns 
 */
export function deleteDocument(data) {
    return (dispatch) => {
        return tools.ajax({
            url: url.deleteDocument + data,
            type: "post",
            info: "删除文档",
            dispatch: dispatch,
            actionType: DELETE_DOCUMENT
        });
    }
}

/**
 * 下载文件
 */
export function downloadDocument(docId) {
    return (dispatch) => {
        return tools.ajax({
            url: url.downloadDocument + "/" + docId,
            info: "下载文件",
            dispatch: dispatch,
            actionType: DOWNLOAD_DOCUMENT,
            // success: (data) => {
            //     var $a = document.createElement('a');
            //     $a.setAttribute("href", data.data);
            //     $a.setAttribute("download", "1.jpg");
            //    window.location.href = data.data;
            // }
        });

    }
}

/**
 * 更新搜索条件
 */
export function updateDocumentCenterListConditions(combCdt) {
    return {
        type: UPDATE_DOCUMENT_CENTER_LIST_CONDITIONS,
        data: combCdt
    }
}

/**
 * 更新列表条件
 */
export function updateDocumentListConditions(combCdt) {
    return {
        type: UPDATE_DOCUMENT_LIST_CONDITIONS,
        data: combCdt
    }
}

/**
 * 暂存更新条件
 * 
 * @export
 * @param {any} checkedPcs 
 * @returns 
 */
export function saveTempConditions(combCdt) {
    // return (dispatch,getState) => {
    // dispatch(changeSearchLabelId(combCdt));
    return {
        type: SAVE_DOCUMNENT_CONDITIONS_TEMP,
        data: combCdt
    }
    // } 
}
/**
 * 修改标签数组的值（高级搜索标签多选问题）
 * 
 * @export
 * @param {any} checkedPcs 
 * @returns 
 */
export function changeSearchLabelId(combCdt) {
    return (dispatch, getState) => {
        // dispatch(updateDocumentCenterListConditions(combCdt))
        let conditionsSearch = getState().$$documentCenterList.toJS().conditionsSearch;
        conditionsSearch.label_ids = null;
        // console.log("action=====conditionsSearch",conditionsSearch)
        return {
            type: CHANGE_SEARCH_LABELID,
            data: conditionsSearch,
            // success(resp) {
            //     dispatch(saveTempConditions(combCdt));
            // }
        }
    }
}

/**
 * 列表中当前选中的项的集合
 * 
 * @export
 * @param {any} values 
 * @returns 
 */
export function setCheckedDocument(values) {
    return {
        type: SET_CHECKED_DOCUMENT,
        data: values
    }
}

// TODO actiontype
/**
* 更新选中的通用名称的状态
* 
* @export
* @param {any} checkedTds 选中的治疗领域key的集合
* @returns 
*/
export function setCheckedDocumentCenterState(checkedPcs) {
    return (dispatch, getState) => {
        let conditions = getState().$$documentCenterList.toJS().conditions;
        return tools.ajax({
            url: url.changeBatchEnable,
            type: "POST",
            info: "启用",
            isShowSuccess: true,
            data: checkedPcs,
            dispatch: dispatch,
            actionType: RESET_DOCUMENT_CENTER_LIST,
        });
    }
}
export function setCheckedDisabled(checkedPcs) {
    return (dispatch, getState) => {
        let conditions = getState().$$documentCenterList.toJS().conditions;
        return tools.ajax({
            url: url.changeBatchDisable,
            type: "POST",
            info: "禁用",
            isShowSuccess: true,
            data: checkedPcs,
            dispatch: dispatch,
            actionType: RESET_DOCUMENT_CENTER_LIST,
        });
    }
}

export function setSelectKeys(data) {
    return {
        type: SAVE_SELECTED_DOCUMENTCENTER_KEYS,
        data: data
    }
}
/**
 * 批量启用/禁用适应症
 * 
 * @export
 * @param {any} value 选中的治疗领域key的集合
 * @returns 
 */
export function setDocumentCenterState(value) {
    return (dispatch, getState) => {
        dispatch(setCheckedDocumentCenterState(value));
    }
}

/**
 * 列表页高级搜索部分
 */
/**
 * 获取产品名称下拉
 * 
 * @export
 * @returns 
 */
export function getDCListRelatedBrand() {
    return (dispatch) => {
        return tools.ajax({
            url: url.getDCRelatedBrand,
            info: "获取关联产品下拉列表",
            data: {},
            dispatch: dispatch,
            actionType: GET_DC_RELATED_BRAND
        });

    }
}

/**
 * 列表新增文件夹
 */
/**
 * 获取产品名称下拉
 * 
 * @export
 * @returns 
 */
export function getDCEmpBrand() {
    return (dispatch) => {
        return tools.ajax({
            url: url.getDCEmpBrand,
            info: "获取关联产品下拉列表",
            data: {},
            dispatch: dispatch,
            actionType: GET_DC_EMP_BRAND
        });

    }
}
/***********************  文档上传配置  ***********************************/
/**
 * 获取关联品牌
 * 
 * @export
 * @returns 
 */
export function getTopFolderRelation(id) {
    return (dispatch) => {
        return tools.ajax({
            url: url.getTopFolderRelation + `?parent_id=${id}`,
            info: "获取顶级文件夹关联的治疗领域",
            dispatch: dispatch,
            actionType: GET_TOP_FOLDER_RELATION
        })
    }
}
/**
 * 获取关联品牌
 * 
 * @export
 * @returns 
 */
export function getDCRelatedBrand() {
    return (dispatch) => {
        return tools.ajax({
            url: url.getDCRelatedBrand,
            info: "获取关联品牌",
            data: {
                enabled: true
            },
            dispatch: dispatch,
            actionType: GET_DC_RELATED_BRAND
        })
    }
}

/**
 * 获取关联治疗领域
 * 
 * @export
 * @returns 
 */
export function getTherapeuticArea() {
    return (dispatch) => {
        return tools.ajax({
            url: url.getTherapeuticArea,
            info: "关联治疗领域",
            data: {},
            dispatch: dispatch,
            actionType: GET_DOCUMENT_THERAPEUTICAREA
        })
    }
}

/**
 * 获取信息点
 * 
 * @export
 * @returns 
 */
export function getKeyMessage() {
    return (dispatch) => {
        return tools.ajax({
            url: url.getKeyMessage,
            info: "获取信息点",
            dispatch: dispatch,
            actionType: GET_DC_KEYMESSAGE
        });
    }
}

/**
 * 获取预览图片
 * 
 * @export
 * @returns 
 */
export function getPreviewImg(name) {
    return (dispatch) => {
        return tools.ajax({
            url: url.getDCPreview + "?file=" + name,
            info: "获取预览图片",
            dispatch: dispatch,
            actionType: GET_PREVIEW_IMG
        });
    }
}

/**
 * 获取预览图片  OTHER OR ZIP (H5)
 * 
 * @export
 * @returns 
 */
export function getDCPreviewH5(documentId) {
    return (dispatch) => {
        return tools.ajax({
            url: url.getDCPreview + "/" + documentId,
            info: "获取预览图片",
            dispatch: dispatch,
            actionType: GET_PREVIEW_IMG
        });
    }
}

/**
 * 获取标签树
 * 
 * @export
 * @param {any} data 
 * @returns 
 */
export function getDCRelatedTree() {
    return (dispatch) => {
        return tools.ajax({
            url: url.getDCRelatedTree,
            type: "get",
            info: "获取标签树",
            dispatch: dispatch,
            actionType: GET_DC_RELATED_TREE
        });
    }
}
/**
 * 获取标签树
 * 
 * @export
 * @param {any} data 
 * @returns 
 */
export function getDCRelatedTreeTrue() {
    return (dispatch) => {
        return tools.ajax({
            url: url.getDCRelatedTreeTrue,
            type: "get",
            info: "获取标签树",
            dispatch: dispatch,
            actionType: GET_DC_RELATED_TREE_TRUE
        });
    }
}

/**
 * 保存文档配置详情
 * 
 * @export
 * @returns 
 */
export function saveDCConfig(data, isEdit, docId) {
    return (dispatch) => {
        return tools.ajax({
            url: isEdit ? url.updateDCConfig + docId : url.saveDCConfig,
            type: "post",
            info: "保存文档配置详情",
            data: data,
            dispatch: dispatch,
            actionType: SAVE_DC_CONFIG,
            success: (resp) => {
                dispatch(push({
                    pathname: "documentCenter/list",
                    query: {
                        documentId: data.folder_id
                    }
                }))
            }
        });
    }
}

/**
 * 获取文档配置详情
 * 
 * @export
 * @returns 
 */
export function getDCConfigDetail(docId, docType) {
    return (dispatch) => {
        return tools.ajax({
            url: url.getDCConfigDetail,
            type: "post",
            info: "获取文档配置详情",
            data: {
                "id": docId,
                "type": docType
            },
            dispatch: dispatch,
            actionType: GET_DC_CONFIG_DETAIL,
        });
    }
}
/**
 * 保存文档名称
 * 
 * @export
 * @returns 
 */
export function saveFile(data) {
    return {
        type: SAVE_FILE,
        data: data
    }
}

/**
 * 保存选中的tagId
 * 
 * @export
 * @returns 
 */
export function saveCheckedTagkeys(data) {
    return {
        type: SAVE_CHECKED_TAGKEYS,
        data: data
    }
}

export function reset() {
    return (dispatch) => {
        dispatch(resetList());
        dispatch(resetEdit());
    }
}

export function resetList() {
    return {
        type: RESET_DOCUMENT_CENTER_LIST
    }
}

export function resetEdit() {
    return {
        type: RESET_DOCUMENT_CENTER_EDIT
    }
}

//更新类型选择
export function UpdateChecked(combCdt) {
    return {
        type: UPDATE_DOCUMENT_CENTER_CHECKED,
        data: combCdt
    }
}

//H5类型选择
export function getHtmlType(data) {
    return {
        type: GET_HTML_TYPE,
        data: data
    }
}

//保存上传的状态-> 上传中，上传完成
export function saveUploadStatus(data) {
    return {
        type: SAVE_UPLOAD_STATUS,
        data: data
    }
}

//单一标签树
export function saveEqualTreeData(data) {
    return {
        type: SAVE_EQUAL_TREE_DATA,
        data: data
    }
}

//外部链接
export function saveHtmlURL(data) {
    return {
        type: SAVE_DC_HTML_URL,
        data: data
    }
}

//页面关联信息点
export function savePageKeyInfo(data) {
    return {
        type: SAVE_PAGE_KEY_INFO,
        data: data
    }
}
//页面关联信息点
export function savePage() {
    return {
        type: SAVE_PAGE,
    }
}

//保存是否永不过期
export function saveExpire(combCdt) {
    return {
        type: SAVE_DOCUMENT_CENTER_EXPIRE,
        data: combCdt
    }
}

/**
 * 获取所有信息点集合
 * 
 * @export
 * @returns (description)
 */
export function getAllKeyMsg() {
    return (dispatch) => {
        return tools.ajax({
            url: url.kplist,
            info: "获取信息点列表",
            // data: {
            //     page: 1,
            //     status: Enum.KpState.enable
            // },
            data: {},
            dispatch: dispatch,
            actionType: GET_ALL_KMSG
        })
    }
}

/**
 * 保存图文
 *
 * @export
 * @param
 * @param isEdit 是否
 * 为编辑状态
 * @returns (description)
 */
export function saveNewsPreview(newValue) {
    // var data = {
    //     // content_type: news.content_type,
    //     title: news.title,
    //     content: news.content,
    //     // content_wx: news.content_wx,

    // }
    return (dispatch) => {
        return tools.ajax({
            type: "post",
            url: url.add,
            info: "保存图文",
            data: newValue,
            // result: tools.ajax.resultEnum.guid,
            dispatch: dispatch,
            actionType: SAVE_NEWS,
            success(data) {
                dispatch(push({
                    pathname: "documentCenter/list",
                    query: {
                        documentId: newValue.parent_id
                    }
                }))
            }
        });
    }
}
/**
 * 保存图文更新
 *
 * @export
 * @param
 * @param isEdit 是否
 * 为编辑状态
 * @returns (description)
 */
export function savePreviewEdit(newValue) {
    // var data = {
    //     // content_type: news.content_type,
    //     title: news.title,
    //     content: news.content,
    //     // content_wx: news.content_wx,

    // }
    return (dispatch) => {
        return tools.ajax({
            type: "post",
            url: url.preview_update,
            info: "更新图文",
            data: newValue,
            // result: tools.ajax.resultEnum.guid,
            dispatch: dispatch,
            actionType: SAVE_NEWS_PREVIEW_UPDATE,
            success(data) {
                dispatch(push({
                    pathname: "documentCenter/list",
                    query: {
                        documentId: newValue.parent_id
                    }
                }))
            }
        });
    }
}

/**
 * 获取图文详情信息
 *
 * @export
 * @param newsId 图文id
 * @returns (description)
 */
export function getAppNews(data, isEdit) {
    return (dispatch) => {
        return tools.ajax({
            url: url.preview_info,
            info: "获取图文详情",
            type: "post",
            data: {
                id: Number(data.id),
                type: Number(data.type)
            },
            dispatch: dispatch,
            actionType: isEdit ? GET_EDIT_NEWS : GET_DETAIL_NEWS,
            success(res) {
            }
        });
    }
}

/**
 * 保存图文预览
 *
 * @export
 * @param
 * @param isEdit 是否
 * 为编辑状态
 * @returns (description)
 */
export function savePreview(news) {
    var data = {
        // content_type: news.content_type,
        title: news.title,
        content: news.content,
        // content_wx: news.content_wx,
        author: news.author
    }
    return (dispatch) => {
        return tools.ajax({
            type: "post",
            url: url.preview_add,
            info: "保存图文预览",
            data,
            result: tools.ajax.resultEnum.guid,
            dispatch: dispatch,
            actionType: SAVE_NEWS_PREVIEW,
            success(resp) {
            }
        });
    }
}

/**
 * 获取图文预览详情信息
 *
 * @export
 * @param newsId 图文id
 * @returns (description)
 */
export function getNewsPreviewDetail(newsPrevId) {
    return (dispatch) => {
        return tools.ajax({
            url: url.preview_detail,
            info: "获取图文预览详情",
            data: {
                key: newsPrevId
            },
            dispatch: dispatch,
            actionType: GET_NEWS_PREVIEW_DETAIL,
            success(res) {
            }
        });
    }
}

/***********************************多图文*****************************/

//图文列表【+】
export function addImageText() {
    return {
        type: ADD_DOCUMENT_CENTER_IMAGETEXT,
    }
}
export function UpdateWXNews(combCdt) {
    return {
        type: UPDATE_DOCC_WX_INTRODUCTION,
        data: combCdt
    }
}
export function updateWXIndex(wx) {
    return {
        type: UPDATE_DOCC_WX_INDEX,
        data: wx
    }
}

/**
 * 获取多图文详情信息
 *
 * @export
 * @param newsId 图文id
 * @returns (description)
 */
export function getWXNews(data, isEdit) {
    // dispatch({
    //     type: isEdit ? GET_EDIT_NEWS : GET_DETAIL_NEWS,
    //     data: infoDataJson.infoDetail.data
    // });
    // return;
    return (dispatch) => {
        return tools.ajax({
            url: url.preview_info,
            info: "获取多图文详情",
            type: "post",
            data: {
                id: Number(data.id),
                type: Number(data.type)
            },
            dispatch: dispatch,
            actionType: isEdit ? GET_EDIT_WX_NEWS : GET_DETAIL_WX_NEWS,
            success(res) {
            }
        });
    }
}

/**
 * 根据条件获取信息点
 *
 * @export
 * @param pdtIds 产品id集合
 * @param taIds 治疗领域id集合
 * @returns (description)
 */
// export function getKmByPdtAndTa(pdtIds, taIds) {
//     console.log('===pdtIds',pdtIds,taIds)
//     return (dispatch) => {
//         return tools.ajax({
//             url: url.kplist,
//             info: "获取信息点",
//             type:"post",
//             data: {
//                 'product_id': pdtIds.length==0?null:pdtIds[0],
//                 'therapeutic_area_ids': (taIds || []),
//             },
//             dispatch: dispatch,
//             actionType: GET_ALL_KMSG
//         });
//     }
// }
export function getKmByPdtAndTa(data) {
    return (dispatch) => {
        return tools.ajax({
            url: url.kplist,
            info: "获取信息点",
            type: "post",
            data: data,
            dispatch: dispatch,
            actionType: GET_ALL_KMSG
        });
    }
}

// ----------------- GAOXIN 问卷部分 -------------------

/**
 * 重置题目
 *
 * @export
 * @returns (description)
 */
export function resetQuestion() {
    return {
        type: RESET_DC_QUESTION
    }
}


/**
 * 更新题目对象
 *
 * @export
 * @param combField 待更新的题目字段
 * @returns (description)
 */
export function setQuestion(combField) {
    return {
        type: SET_DC_QUESTION,
        data: combField
    }
}

/**
 * 删除选项
 *
 * @export
 * @param optId 待删除的选项id
 * @returns (description)
 */
export function removeOption(optId) {
    return {
        type: REMOVE_DC_QA_OPTION,
        data: optId
    }
}

/**
 * 更新选项内容
 *
 * @export
 * @param optId 待更新的选项id
 * @param value 待更新的选项内容
 * @returns (description)
 */
export function updateOptContent(optId, value) {
    return {
        type: UPDATE_DC_QA_OPTION_CONTENT,
        data: {
            id: optId,
            value: value
        }
    }
}

/**
 * 更新单选选项状态
 *
 * @export
 * @param optId 待更新的选项状态的id
 * @returns (description)
 */
export function updateRadioState(optId) {
    return {
        type: UPDATE_DC_QA_RADIO_STATE,
        data: optId
    }
}


/**
 * 更新复选选项状态
 *
 * @export
 * @param optId 待更新的选项id
 * @returns (description)
 */
export function updateCheckboxState(optId) {
    return {
        type: UPDATE_DC_QA_CHECKBOX_STATE,
        data: optId
    }
}




/**
 * 保存问卷
 *
 * @export
 * @param ta 待保存的问卷信息
 * @param isEdit 是否
 * 为编辑状态
 * @returns (description)
 */
export function saveQA(qa, isEdit = false) {
    let data = {
        id: isEdit ? qa.id : undefined,
        title: qa.title,
        desc: qa.desc,
        expire_time: qa.expire_time.valueOf(),
        question: isEdit ?
            //编辑
            {
                add: $.map(qa.add, q => {
                    return {
                        question_id: undefined,
                        type: q.type,
                        order: q.order,
                        score: q.score || null,
                        head: JSON.stringify({ head: q.head, options: q.type == Enum.QuestionType.answer ? undefined : q.options }),
                        stem: $.map(q.type == Enum.QuestionType.answer ? [] : q.options, opt => opt.isRight ? opt.id : null).join(",")
                    }
                }),
                up: $.map(qa.up, q => {
                    return {
                        question_id: q.question_id,
                        type: q.type,
                        order: q.order,
                        score: q.score || null,
                        head: JSON.stringify({ head: q.head, options: q.type == Enum.QuestionType.answer ? undefined : q.options }),
                        stem: $.map(q.type == Enum.QuestionType.answer ? [] : q.options, opt => opt.isRight ? opt.id : null).join(",")
                    }
                }),
                del: $.map(qa.del, q => q.question_id)
            } :
            //添加
            qa.question.map(q => {
                return {
                    type: q.type,
                    order: q.order,
                    score: q.score || null,
                    head: JSON.stringify({ head: q.head, options: q.type == Enum.QuestionType.answer ? undefined : q.options }),
                    stem: $.map(q.type == Enum.QuestionType.answer ? [] : q.options, opt => opt.isRight ? opt.id : null).join(",")
                }
            }),
        relates: [].concat(
            $.map([].concat(qa.drug_ids), id => { return { relate_type: Enum.RelateType.product.toString(), relate_id: id } })
        ).concat(
            $.map([].concat(qa.ta_ids), id => { return { relate_type: Enum.RelateType.ta.toString(), relate_id: id } })
            ).concat(
            $.map(qa.km_ids, id => { return { relate_type: Enum.RelateType.keypoint.toString(), relate_id: id } })
            ),
    }
    console.log('qa提交数据', data);
    return (dispatch) => {
        return tools.ajax({
            type: "post",
            url: isEdit ? url.modify : url.add,
            info: "保存问卷",
            data: data,
            result: isEdit ? tools.ajax.resultEnum.bool : tools.ajax.resultEnum.guid,
            dispatch: dispatch,
            actionType: SAVE_DC_QA,
            isShowSuccess: true,
        });
    }
}

// 获取目睹直播用户名密码
export function getVolMuduAccount(){
    return (dispatch, getState) => {
        // return tools.ajax({
        //     url: url.getVolMuduAccount,
        //     data: {},
        //     info: "获取目睹账户名",
        //     dispatch: dispatch,
        //     actionType: GET_DC_VOL_MUDU_ACCOUNT,
        // })
        return dispatch({
            type: GET_DC_VOL_MUDU_ACCOUNT,
            data: Immutable.fromJS({
                mudu_username: 'demo',
                mudu_password: '4wxxeu'
            })
        })
    }
}





