//导航对应枚举,为了记录属性的默认选择
export default function navEnum(pathName) {
    let key = '';
    if (pathName.match(/\/overview/)) {
        key = '1';
    } else if (pathName.match(/\/expSingle/)) {
        key = '21';
    } else if (pathName.match(/\/expVol/)) {
        key = '22';
    } else if (pathName.match(/\/expQa/)) {
        key = '23';
    } else if (pathName.match(/\/expComb/)) {
        key = '24';
    } else if (pathName.match(/\/news/)) {
        key = '31';
    } else if (pathName.match(/\/h5/)) {
        key = '32';
    } else if (pathName.match(/\/qa/)) {
        key = '33';
    } else if (pathName.match(/\/product/)) {
        key = '41';
    } else if (pathName.match(/\/ta/)) {
        key = '42';
    } else if (pathName.match(/\/keypoint/)) {
        key = '43';
    } else if (pathName.match(/\/root/)) {
        if (pathName.match(/\/list/)) {
            key = '51';
        } else if (pathName.match(/\/recharge/)) {
            key = '52';
        }
    } else {
        key = '1'
    }
    return key;
}
