//产品状态
const ProductState = {
    //禁用
    disable: 0,
    //启用
    enable: 1,
    //已删除
    remove: -1
}


//治疗领域状态
const TAState = {
    //禁用
    disable: 0,
    //启用
    enable: 1,
    //已删除
    remove: -1
}


//信息点状态
const KpState = {
    //禁用
    disable: 0,
    //启用
    enable: 1,
    //已删除
    remove: -1
}


//素材状态
const MaterialState = {
    //禁用
    disable: 0,
    //启用
    enable: 1,
}


//图文状态
const NewsState = {
    //禁用
    disable: 0,
    //启用
    enable: 1,
    //已过期
    expire: 2,
    //草稿
    draft: 3,
    //已删除
    remove: -1
}

//H5状态
const H5State = {
    //禁用
    disable: 0,
    //启用
    enable: 1,
    //已过期
    expire: 2,
    //草稿
    draft: 3,
    //已删除
    remove: -1
}

//问卷状态
const QAState = {
    //禁用
    disable: 0,
    //启用
    enable: 1,
    //已过期
    expire: 2,
    //草稿
    draft: 3,
    //已删除
    remove: -1
}

//直播状态
const VolState = {
    //禁用
    disable: 0,
    //启用
    enable: 1,
    //已过期
    expire: 2,
    //草稿
    draft: 3,
    //已删除
    remove: -1
}

//点播状态
const VodState = {
    //禁用
    disable: 0,
    //启用
    enable: 1,
    //已过期
    expire: 2,
    //草稿
    draft: 3,
    //已删除
    remove: -1
}

//推广状态
const ExpressState = {
    //禁用
    disable: 0,
    //进行中
    doing: 1,
    //已结束
    expire: 2,
    //草稿
    draft: 3,
    //待生效
    enable: 4,
    //余额不足
    arrears: 5
}

//推广平台
const platformType = {
    //APP
    app: 1,
    //微信
    wechat: 2,
    //全部平台
    all: 3
}
//投放媒体
const platform = {
    //基于个体的精准投放
    app: 1,
    //基于群体的广覆盖投放
    wechat: 2,
}

//启动屏尺寸
const openImgSize = {
    //p1
    p1: "640_960",
    //p2
    p2: "640_1136",
    //p3
    p3: "750_1334",
    //p4
    p4: "1242_2208",
    //p5
    p5: "720_1280"
}

//素材第二步尺寸
const drewImgSize = {
    wx_img:"320_200",
    banner_img:"640_240",
    feeds_img:"686_343",
    open_img:"1242_2208"
};

//视频类型
const VideoType = {
    //直播
    vol: 4
}


//权限组成员状态
const RootState = {
    //启用
    enable: 1,
    //禁用
    disable: 0,
    //已删除
    remove: -1,
    //待审核
    toReview: -2,
    //待激活
    toActive: -3
}

//权限组状态
const rootGroupState = {
    //启用
    enable: 1,
    //禁用
    disable: 0
}


// 账户状态
const AccountState = {
    //已启用
    enable: 1,
    //已禁用
    disable: 0,
    //已删除
    remove: -1,
    //待审核
    toReview: -2,
    //待激活
    toActive: -3
}



//医保类型
const InsuranceType = {
    //甲类
    classA: 0,
    //乙类
    classB: 1
}

//产品类型
const DrugType = {
    //RX
    RX: 0,
    //OTC
    OTC: 1
}

//文档类型
const DocumentType = {
    //图文
    news: 1,
    //H5
    h5: 5,
    //问卷
    qa: 2
}

//统计详情信息时间维度查询条件
const StatisticTime = {
    //当月
    today: 1,
    //全部
    all: 2
}

//图表时间维度查询条件
const ChartTime = {
    //今天
    today: 1,
    //昨天
    yesterday: 2,
    //最近7天
    lastWeek: 3,
    //最近30天
    lastMonth: 4
}

//图表指标维度查询条件
const ChartTarget = {
    //浏览量（PV）
    pv: 1,
    //独立用户数（UV）
    uv: 2,
    //新增用户数
    increase: 3
}

//图表受众接口类型
const ChartCoverageType = {
    //潜在用户占比
    docLevel: 1,
    //目标覆盖医生占比
    hospLevel: 2
}

//图表关联指标类型
const ChartRelateType = {
    //产品
    product: 1,
    //治疗领域
    ta: 2
}

//题目类型
const QuestionType = {
    //单选题
    radio: 1,
    //多选题
    checkbox: 2,
    //问答题
    answer: 3
}

//评论状态
const CommentState = {
    //通过
    pass: 1,
    //删除
    remove: 0
}

//禁言类型
const ForbiddenUserType = {
    //禁言一天
    day: 1
}

//是否允许评论
const CommentAllow = {
    //允许
    enable: 0,
    //不允许
    disable: 1
}

//----------------------------------
//受众接口类型
const CoverageType = {
    //省市
    province: 1,
    //医院等级
    hospLevel: 2,
    //科室
    department: 3,
    //医生等级
    docLevel: 4
}

//关联指标类型
const RelateType = {
    //产品
    product: 1,
    //治疗领域
    ta: 2,
    //信息点
    keypoint: 3
}

//搜索类型
const SearchType = {
    //简易搜索
    simple: "simple",
    //高级搜索
    senior: "senior"
}

//排序类型
const OrderType = {
    //正序
    asc: "asc",
    //倒叙
    desc: "desc"
}

//搜索包含扩展字段
const ExtraState = {
    //启用扩展
    enable: 1,
    //禁用扩展
    disable: 0
}

//内容是否被修改（仅用于图文、qa编辑）
const ModifyState = {
    //启用修改
    enable: 1,
    //禁用修改
    disable: 0
}


//设置密码状态
const PasswordState = {
    //初始化
    init: 0,
    //重置
    reset: 1
}

//是否直播后转为点播
const VideoTransfor = {
    //转换
    enable: 1,
    //不转换
    disable: 0
}

//直播推流状态
const VolStreamState = {
    //无输入流
    none: 0,
    //直播中
    live: 1,
    //异常
    error: 2,
    //关闭
    close: 3
}

//图文类型
const NewsPlatform = {
    //APP
    app: 1,
    //微信
    weixin: 2,
    //微信&APP
    both: 3
}

//素材推广类型
const ProPlatform = {
    //微信图文
    weixin: 1,
    //APP信息流
    app1: 2,
    //APP启动屏
    app2: 3,
    //APP焦点图
    app3: 4,
}

//推广类型
const PromotionType = {
  //单次推广
  once: 1,
  //组合推广
  combination: 2
}

//推广类型
const ExpressType = {
  //学术速递
  single: 1,
  //组合推广
  combination: 2,
  //调研问卷
  qa: 3,
  //在线科会
  vol: 4
}

//----------------------------------
//文档库素材类型
const ResourceType = {
    //文件夹
    folder: 0,
    //普通文档
    normal: 1,
    //HTML5
    h5: 2,
    //图文消息
    imagetxt: 3,
    //微信图文
    wximagetxt: 4,
    //调研问卷
    qa: 5,
    //在线直播
    vol: 6,
    //录播视频
    vod: 7
}

//战役状态
const BattleStatus={
    //已结束
    end:0,
    //进行中
    goning:1,
    //已完成
    complete:2
}
