//自定义枚举--颜色
export const ColorEnum = {
    colorType: [
        {
            color: '#1890ff',
            bgColor: '#e6f7ff'
        },
        {
            color: '#a0d911',
            bgColor: '#fcffe6'
        },
        {
            color: '#faad14',
            bgColor: '#fffbe6'
        },
        {
            color: '#722ed1',
            bgColor: '#f9f0ff'
        },
        {
            color: '#eb2f96',
            bgColor: '#fff0f6'
        }],

    //战役颜色
    BattleStatusColor: {
        //已结束
        0: "red",
        //进行中
        1: "#1890ff",
        //已完成
        2: "#a0d911"
    },
    // 文档库颜色
    DcColorIcon: {
        //文件夹
        folder: {
            icon: 'wenjianjia1',
            color: '#FFAD36',
            bgColor: 'transparent'
        },
        //普通文档
        normal: {
            icon: 'document',
            color: '#FFB112',
            bgColor: '#FFFCE5'
        },
        //HTML5
        h5: {
            icon: 'yasuowenjian',
            color: '#8300D4',
            bgColor: '#FCEEFF'
        },
        //图文消息
        imagetxt: {
            icon: 'pic',
            color: '#2A9CFF',
            bgColor: '#E3F8FF'
        },
        //微信图文
        wximagetxt: {
            icon: 'weixin',
            color: '#A1DB43',
            bgColor: '#FCFFE7'
        },
        //调研问卷
        qa: {
            icon: 'edit',
            color: '#F42D95',
            bgColor: '#FFF0F6'
        },
        //在线直播
        vol: {
            icon: 'shexiangtou',
            color: '#FFAD36',
            bgColor: '#FFFBE7'
        },
        //录播视频
        vod: {
            icon: 'shipinbofang',
            color: '#0F96FA',
            bgColor: '#E4F7FE'
        },
    }
}