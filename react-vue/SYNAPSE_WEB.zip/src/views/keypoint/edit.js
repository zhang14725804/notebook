import React from "react"
import ReactDOM from "react-dom"
import $ from "jquery"
import { bindActionCreators } from "redux"
import { connect } from "react-redux"
import { withRouter } from "react-router"
import *  as KpActions from "actions/keypoint"
import *  as CommActions from "actions/common"
import { Enum } from "enum"
// import {Button, Form, Input, Row, Col, Checkbox, Transfer} from "assets/lib/antd"
import Button from "antd/lib/button"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Checkbox from "antd/lib/checkbox"
import Transfer from "antd/lib/transfer"
const FormItem = Form.Item

class KeypointEdit extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            query: props.location.query,
            isEdit: !!props.location.query.keyword_id
        }
    }

    componentDidMount() {
        const { kpAct, commAct } = this.props;
        kpAct.resetEdit();
        $.when(
            commAct.getAllProduct(),
            commAct.getAllTa()
        ).done(() => {
            const { isEdit, query } = this.state;
            if (isEdit) {
                kpAct.getKp(query.keyword_id, true)
            }
        });
    }
    render() {
        const common = this.props.$$common.toJS();
        const { isEdit } = this.state;
        const formItemLayout = {
            labelCol: { span: 5 },
            wrapperCol: { span: 19 }
        };
        const formItemLayout_rela = {
            labelCol: { span: 4 },
            wrapperCol: { span: 20 }
        };
        const fieldProps = this._getFieldProps();
        return (
            <section>
                <Form>
                    <Row className="m-margin-b m-edit-header">
                        <Col span="18">
                            <Col span="5"><span className="m-edit-title">{isEdit ? "编辑信息点" : "新增信息点"}</span></Col>
                            <Col span="16">
                                {fieldProps.status(
                                    <Checkbox
                                        {...formItemLayout}>启用</Checkbox>
                                )}
                            </Col>
                        </Col>
                    </Row>
                    <Row style={{ "paddingLeft": "20px" }}>
                        <Col span="18">
                            <FormItem
                                label="信息点"
                                {...formItemLayout}>
                                {fieldProps.keyword(
                                    <Input
                                        placeholder="请输入内容" />
                                )}
                            </FormItem>
                            <FormItem
                                label="信息点描述"
                                {...formItemLayout}>
                                {fieldProps.description(
                                    <Input.TextArea
                                        placeholder="请输入内容" />
                                )}
                            </FormItem>
                        </Col>
                    </Row>
                    <Row style={{ "paddingLeft": "20px" }}>
                        <Col className="kp-transferForm">
                            <FormItem
                                label="关联产品"
                                {...formItemLayout_rela}>
                                {fieldProps.product_ids(
                                    <Transfer
                                        titles={["全部产品", "关联产品"]}
                                        listStyle={{
                                            width: 200,
                                            height: 300
                                        }}
                                        dataSource={common.allProduct}
                                        rowKey={record => record.id}
                                        render={record => record.cn_name}
                                        showSearch />
                                )}
                            </FormItem>
                            <FormItem
                                label="关联治疗领域"
                                {...formItemLayout_rela}>
                                {fieldProps.ta_ids(
                                    <Transfer
                                        titles={["全部治疗领域", "关联治疗领域"]}
                                        listStyle={{
                                            width: 200,
                                            height: 300
                                        }}
                                        dataSource={common.allTa}
                                        rowKey={record => record.id}
                                        render={record => record.name}
                                        showSearch />
                                )}
                            </FormItem>
                        </Col>
                    </Row >
                </Form >
                <div className="m-handle-btn">
                    <div className="wrap">
                        <Button type="primary" onClick={this.onClickSave.bind(this)}>保存</Button>
                    </div>
                </div>
            </section>
        )
    }
    onClickSave() {
        const { isEdit, query } = this.state;
        const { $$keypointEdit, kpAct, form } = this.props;
        const { validateFieldsAndScroll, getFieldsValue } = form;
        validateFieldsAndScroll(Object.getOwnPropertyNames(getFieldsValue()), { force: true }, (error, values) => {
            if (!!error) return;
            kpAct.saveKp($.extend(true, values, {
                keyword_id: query.keyword_id
            }), isEdit);
        })
    }
    _getFieldProps() {
        const { $$keypointEdit, form } = this.props;
        const { getFieldDecorator, validateFields } = form;
        const { kp } = $$keypointEdit.toJS();
        return {
            keyword: getFieldDecorator("keyword", {
                initialValue: kp.keyword,
                rules: [
                    { required: true, message: "请填写信息点名称" },
                    { max: 50, message: "信息点名称不得超过50个字符" }
                ]
            }),
            description: getFieldDecorator("description", {
                initialValue: kp.description,
                // rules: [
                //     { max: 1500, message: "描述不得超过1500个字符" }
                // ]
            }),
            status: getFieldDecorator("status", {
                initialValue: kp.status,
                valuePropName: "checked"
            }),
            product_ids: getFieldDecorator("product_ids", {
                initialValue: kp.relate_product.map(item => item.id),
                valuePropName: "targetKeys",
                rules: [
                    {
                        validator: (rule, values, cb) => {
                            const { validateFields } = this.props.form
                            return validateFields(["ta_ids"], { force: true }, (error, values) => {
                                cb();
                            })
                        }
                    }
                ],
            }),
            ta_ids: getFieldDecorator("ta_ids", {
                initialValue: kp.relate_ta.map(item => item.id),
                valuePropName: "targetKeys",
                rules: [
                    {
                        validator: (rule, values, cb) => {
                            const { getFieldValue, validateFields } = this.props.form
                            if (getFieldValue("product_ids").length === 0 && values.length === 0) {
                                return cb("产品和治疗领域请至少关联一种")
                            } else {
                                cb();
                            }
                        }
                    }
                ]
            })
        }
    }
    _getCharCount(fieldName, maxLength) {
        const { getFieldValue } = this.props.form;
        const curLength = getFieldValue(fieldName).length;
        const style = {
            position: "absolute",
            right: 0,
            bottom: "-28px"
        }
        return (
            <div style={{ position: "relative" }}>
                <div style={style}>
                    <span className={curLength > maxLength ? "m-text-error" : ""}>{curLength}</span>
                    <span>/{maxLength}</span>
                </div>
            </div>
        )
    }
}

KeypointEdit = Form.create()(KeypointEdit);


export default connect(
    state => {
        return {
            $$keypointEdit: state.$$keypointEdit,
            $$common: state.$$common
        }
    },
    dispatch => {
        return {
            kpAct: bindActionCreators(KpActions, dispatch),
            commAct: bindActionCreators(CommActions, dispatch)
        }
    }
)(KeypointEdit)
