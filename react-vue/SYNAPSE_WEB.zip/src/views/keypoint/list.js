import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import { Enum, EnumCn } from "enum"
import SearchBar from "components/searchBar"
import * as Actions from "actions/keypoint"
import { tools } from "utils"
// import {Icon, Row, Col, Input, Button, Table, Form, DatePicker, Modal, Tag} from "assets/lib/antd"
import Icon from "antd/lib/icon"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import Table from "antd/lib/table"
import Form from "antd/lib/form"
import DatePicker from "antd/lib/date-picker"
import Modal from "antd/lib/modal"
import Tag from "antd/lib/tag"
const ButtonGrup = Button.Group
const FormItem = Form.Item
const RangePicker = DatePicker.RangePicker;


class KeypointList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            pageReload: tools.getLocationRandom(),
            isSearchAdv: false
        }
    }
    componentDidMount() {
        this._pageReloadInit()
    }
    componentWillReceiveProps(nextProps) {
        if (this.state.pageReload !== tools.getLocationRandom()) {
            this._pageReloadInit()
            if (this.refs.searchBar && this.refs.searchBar.clear) {
                this.refs.searchBar.clear()
            }
        }
    }
    _pageReloadInit() {
        let { kpActs } = this.props;
        kpActs.reset();
        kpActs.getKeypointList();
        this.setState({
            pageReload: tools.getLocationRandom(),
        })
    }
    render() {
        let { kpList, condition, chkKeypoint } = this.props.$$keypointList.toJS();
        let cfg = {
            dataSource: kpList.data,
            rowKey: r => r.id,
            columns: [
                {
                    title: '信息点',
                    dataIndex: 'title',
                    key: 'title',
                    width: "19%",
                    render: (text, r) => {
                        return (<Link to={{ pathname: "/keypoint/detail", query: { keyword_id: r.id } }} >{r.keyword}</Link>);
                    }
                }, {
                    title: '关联产品',
                    dataIndex: 'relate_product',
                    key: 'relate_product',
                    width: "18%",
                    render: (text, r) => (r.relate_product || []).map(o => <Tag key={o.id}><div className="m-ect" style={{ maxWidth: "70px" }} title={o.cn_name}>{o.cn_name}</div></Tag>)
                }, {
                    title: '关联治疗领域',
                    dataIndex: 'relate_ta',
                    key: 'relate_ta',
                    width: "28%",
                    render: (text, r) => (r.relate_ta || []).map(o => <Tag key={o.id}><div className="m-ect" style={{ maxWidth: "70px" }} title={o.name}>{o.name}</div></Tag>)
                },
                {
                    title: '创建时间',
                    dataIndex: 'ctime',
                    key: 'ctime',
                    width: "18%",
                    sorter: true,
                    render: (text, r) => {
                        return new hDate(text).format(`${tools.dateFormat} hh:mm:ss`);
                    }
                }, {
                    title: '状态',
                    dataIndex: 'status',
                    width: "10%",
                    sorter: true,
                    key: 'status',
                    render: (text, r) => {
                        let iconMap = {
                            state_1: { type: "check-circle", className: "m-text-success" },
                            state_0: { type: "cross-circle", className: "m-text-error" },
                        }
                        return (
                            <div>
                                <Icon
                                    type={iconMap["state_" + text].type}
                                    className={"m-margin-r " + iconMap["state_" + text].className} />
                                <span>{EnumCn.KpState[text]}</span>
                            </div>
                        );
                    }
                }
            ],
            // bordered: true,
            onChange: (page, filter, sort) => {
                let { kpActs } = this.props;
                kpActs.getKeypointList({
                    page: page.current,
                    count: page.pageSize,
                    order: sort.field,
                    order_type: typeof sort.order === "string" ? sort.order.replace("end", "") : undefined
                });
            },

            pagination: $.extend(true, {}, tools.config.pagination, {
                current: condition.page,
                pageSize: condition.count,
                total: kpList.total
            }),
            rowSelection: {
                selectedRowKeys: chkKeypoint.map(d => d.id),
                onChange: (selectedRowKeys, selectedRows) => {
                    let { kpActs } = this.props;
                    kpActs.setChkKp(selectedRows);
                }
            }
        }
        return (
            <section>
                <div className="m-margin-b">信息点列表</div>
                <Row className="m-margin-b">
                    <Col span="16">
                        <Button
                            type="primary"
                            size="large"
                            className="m-margin-r"
                            onClick={() => { this.props.router.push({ pathname: "/keypoint/edit" }) }}>新增</Button>
                        <ButtonGrup size="large">
                            <Button type="ghost" onClick={this.onClickEnable.bind(this)} disabled={chkKeypoint.length == 0}>启用</Button>
                            <Button type="ghost" onClick={this.onClickDisable.bind(this)} disabled={chkKeypoint.length == 0}>禁用</Button>
                            <Button type="ghost" onClick={this.onClickDelete.bind(this)} disabled={chkKeypoint.length == 0}>删除</Button>
                        </ButtonGrup>
                    </Col>
                    {!this.state.isSearchAdv ?
                        <Col span="8">
                            <Col span="20">
                                <SearchBar
                                    ref='searchBar'
                                    onSearch={this.onClickSearch.bind(this)} />
                            </Col>
                            <Col span="4" className="m-ta-r">
                                <a className="m-searchAdv-text" onClick={this.onClickSearchAdv.bind(this)}>高级搜索</a>
                            </Col>
                        </Col>
                        : null}
                </Row>
                {this.state.isSearchAdv ?
                    <Row key="searchAdv" className="m-margin-b">
                        <Col span="24">
                            <_SearchAdv
                                {...this.props}
                                onClickSearchSmp={this.onClickSearchSmp.bind(this)} />
                        </Col>
                    </Row>
                    : null}
                <Row>
                    <Col span="24">
                        <Table {...cfg} />
                    </Col>
                </Row>

            </section>
        );

    }
    //点击搜索
    onClickSearch(title) {
        let { kpActs } = this.props;
        kpActs.getKeypointList({
            key: { title: title },
            type: Enum.SearchType.simple,
            page: 1
        });
    }
    //点击高级搜索
    onClickSearchAdv() {
        this.setState({
            isSearchAdv: true
        })
    }
    //点击简易搜索按钮
    onClickSearchSmp() {
        this.setState({
            isSearchAdv: false
        })
    }
    //点击启用按钮
    onClickEnable() {
        let { kpActs, $$keypointList } = this.props;
        let chkKeys = this.props.$$keypointList.toJS().chkKeypoint;
        kpActs.changeKpState(chkKeys.map(o => o.id), Enum.KpState.enable);
    }
    //点击禁用按钮
    onClickDisable() {
        let { kpActs, $$keypointList } = this.props;
        let chkKeys = this.props.$$keypointList.toJS().chkKeypoint;
        tools.showDialog.confirm("禁用后，对现有已关联的推广内容无影响，但新建推广时将无法关联该信息点，请确认是否禁用", () => {
            kpActs.changeKpState(chkKeys.map(o => o.id), Enum.KpState.disable);
        })
    }
    //点击删除按钮
    onClickDelete() {
        let { kpActs, $$keypointList } = this.props;
        let chkKeys = this.props.$$keypointList.toJS().chkKeypoint;
        tools.showDialog.confirm("确认删除选中的信息点？", () => {
            kpActs.delKp(chkKeys.map(o => o.id));
        })
    }
}


class _SearchAdv extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            pageReload: '',
        }
    }
    _pageReloadInit() {
        this.setState({
            pageReload: tools.getLocationRandom(),
        })
    }
    componentDidMount() {
        this._pageReloadInit()
    }
    componentWillReceiveProps() {
        if (this.state.pageReload !== tools.getLocationRandom()) {
            this.onClickClear()
            this._pageReloadInit()
        }
    }
    render() {
        const fieldProps = this._getFieldProps();
        const formItemLayout = {
            labelCol: { span: 10 },
            wrapperCol: { span: 14 }
        };
        return (
            <Form className="m-searchAdv">
                <Row>
                    <Col span="7">
                        <FormItem {...formItemLayout} label="信息点名称：">
                            {fieldProps.title(
                                <Input
                                    type="text"
                                    placeholder="请输入内容" />
                            )}
                        </FormItem>
                    </Col>
                    <Col span="7" offset="1">
                        <FormItem {...formItemLayout} label="产品名称：">
                            {fieldProps.cn_name(
                                <Input
                                    type="text"
                                    placeholder="请输入内容" />
                            )}
                        </FormItem>
                    </Col>
                    <Col span="7" offset="1">
                        <FormItem {...formItemLayout} label="治疗领域名称：">
                            {fieldProps.ta_name(
                                <Input
                                    type="text"
                                    placeholder="请输入内容" />
                            )}
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="14">
                        <FormItem {...{
                            labelCol: { span: 5 },
                            wrapperCol: { span: 14 }
                        }} label="创建时间：">
                            {fieldProps.ctime(
                                <RangePicker
                                    style={{ width: "100%" }} />
                            )}
                        </FormItem>
                    </Col>
                    <Col span="7" offset="2" className="m-ta-r">
                        <Button type="primary" onClick={this.onSearchAdv.bind(this)} className="m-margin-r">搜索</Button>
                        <Button type="ghost" onClick={this.onClickClear.bind(this)} className="m-margin-r">清空</Button>
                        <a onClick={this.onClickSearchSmp.bind(this)}>简易搜索</a>
                    </Col>
                </Row>
            </Form>
        );
    }
    componentWillUnmount() {
        this.onClickClear()
    }
    //点击高级搜索
    onSearchAdv() {
        let { kpActs, form } = this.props;
        kpActs.getKeypointList({
            key: form.getFieldsValue(),
            type: Enum.SearchType.senior
        });
    }
    //点击清空
    onClickClear() {
        let { kpActs, form } = this.props;
        form.resetFields();
        kpActs.updateKpConditions({
            key: $.extend(true, form.getFieldsValue(), {
                ctime: null
            })
        });
    }
    //点击简易搜索
    onClickSearchSmp() {
        this.props.onClickSearchSmp.call(this);
    }
    //设置属性
    _getFieldProps() {
        let { getFieldDecorator } = this.props.form;
        return {
            title: getFieldDecorator("title", {
                initialValue: ""
            }),
            cn_name: getFieldDecorator("cn_name", {
                initialValue: ""
            }),
            ta_name: getFieldDecorator("ta_name", {
                initialValue: ""
            }),
            ctime: getFieldDecorator("ctime", {
                initialValue: []
            })
        }
    }
}

_SearchAdv = Form.create({})(_SearchAdv);

export default connect(
    (state) => {
        return {
            $$keypointList: state.$$keypointList
        }
    },
    (dispatch) => {
        return {
            kpActs: bindActionCreators(Actions, dispatch)
        }
    })(withRouter(KeypointList))
