import $ from "jquery"
import Immutable from "immutable"
import React from "react"
import ReactDOM from "react-dom"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/keypoint"
import { Link, withRouter } from "react-router"
import Chart from "components/chart"
import { Enum, EnumCn } from "enum"
import { tools } from "utils"
// import {Table, Tabs, Icon, Button, Col, Row, Form, Select, Tag } from "assets/lib/antd"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Icon from "antd/lib/icon"
import Button from "antd/lib/button"
import Tabs from "antd/lib/tabs"
import Table from "antd/lib/table"
import Form from "antd/lib/form"
import Select from "antd/lib/select"
import Tag from "antd/lib/tag"
const TabPane = Tabs.TabPane
const Option = Select.Option

class keypointDetail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            query: props.location.query
        }
    }

    componentDidMount() {
        let {$$layout, kpActs} = this.props;
        let loginUser = $$layout.toJS().login_user;
        let kp_id = this.state.query.keyword_id;
        kpActs.getKeypointInfo(kp_id);//基本信息
        kpActs.getKeypointSRC({//引用资源
            keyword_id: kp_id
        });

        //统计
        // kpActs.getOverView({
        //     company_id: loginUser.company_id,
        //     keypoint_id: kp_id
        // });
        // kpActs.getTrend({
        //     company_id: loginUser.company_id,
        //     keypoint_id: kp_id,
        //     range: Enum.ChartTime.today,
        //     type: [Enum.ChartTarget.pv]
        // });
    }

    render() {
        const {kp, kpsrc, searchCondition} = this.props.$$keypointDetail.toJS();
        const iconMap = {
            state_0: { type: "cross-circle", className: "m-text-error" },
            state_1: { type: "check-circle", className: "m-text-success" }
        }
        const tbcfg = {
            dataSource: kpsrc.data,
            rowKey: (r) => { return `${(r || {}).type}_${(r.data || {}).id}` },
            columns: [
                {
                    title: '引用本条信息点资源',
                    dataIndex: 'data',
                    key: "data",
                    width: "65%",
                    render: (text, r) => {
                        return r.data.title;
                    }
                }, {
                    title: '分类',
                    dataIndex: 'type',
                    key: 'type',
                    width: "17.5%",
                    render: (text, r) => {
                        return EnumCn.DocumentType[r.type];
                    }
                }, {
                    title: '状态',
                    dataIndex: 'status',
                    width: "17.5%",
                    key: 'status',
                    render: (text, r) => {
                        let status = r.data.status;
                        let iconMap = {
                            state_0: { icon: "cross-circle", className: "m-text-error" },
                            state_1: { icon: "check-circle", className: "m-text-success" },
                            state_2: { icon: "minus-circle", className: "m-text-minor" },
                            state_3: { icon: "question-circle", className: "m-text-warning" }
                        }
                        let map = iconMap["state_" + status] || {};
                        return (
                            <div>
                                <Icon
                                    type={map.icon}
                                    className={map.className} />
                                <span>{EnumCn.NewsState[status]}</span>
                            </div>
                        )
                    }
                }
            ],
            // bordered: true,
            pagination: $.extend(true, {}, tools.config.pagination, {
                current: searchCondition.page,
                pageSize: searchCondition.count,
                total: kpsrc.total
            }),
            onChange: (page, filters, sorter) => {
                const {kpActs} = this.props;
                kpActs.getKeypointSRC({
                    keyword_id: this.state.query.keyword_id,
                    count: page.pageSize,
                    page: page.current
                })
            }
        }
        const pdtJSX = kp.relate_product.map(obj => <Tag key={obj.id}>{obj.cn_name}</Tag>);
        const taJSX = kp.relate_ta.map(obj => <Tag key={obj.id}>{obj.name}</Tag>);
        return (
            <section>
                <Row className="m-margin-b">
                    <Col span="20">
                        <Icon
                            type={iconMap["state_" + kp.status].type}
                            className={"m-margin-r " + iconMap["state_" + kp.status].className} />
                        <span>{EnumCn.KpState[kp.status]}</span>
                    </Col>
                    <Col span="4" className="m-ta-r">
                        <Button type="ghost" onClick={this.onClickEdit.bind(this)}>编辑</Button>
                    </Col>
                </Row>
                <div className="m-tb m-margin-b">
                    <div className="m-tb-title"><a>{(kp.keyword || tools.emptyInfo)}</a></div>
                    <div className="m-tb-text">
                        描述：{(kp.description || tools.emptyInfo)}
                    </div>
                    <div className="m-tb-text">
                        关联产品：{pdtJSX.length > 0 ? pdtJSX : tools.emptyInfo}
                    </div>
                    <div className="m-tb-text">
                        关联治疗领域：{taJSX.length > 0 ? taJSX : tools.emptyInfo}
                    </div>
                </div>
                <Row className="m-margin-b">
                    <Col span="24">
                        <div className="m-bgb">
                            <Icon type="pencil-o" className="m-ico red" />
                            <div className="m-tb">
                                <div className="m-tb-title">创建人</div>
                                <div className="m-tb-text">{(kp.create_user.nickname || tools.emptyInfo)}</div>
                            </div>
                        </div>
                        <div className="m-bgb">
                            <Icon type="tip-o" className="m-ico blue" />
                            <div className="m-tb">
                                <div className="m-tb-title">被引用的资源</div>
                                <div className="m-tb-text">{(kpsrc.total || 0)}个</div>
                            </div>
                        </div>
                        <div className="m-bgb">
                            <Icon type="calendar-o" className="m-ico orange" />
                            <div className="m-tb">
                                <div className="m-tb-title">创建时间</div>
                                <div className="m-tb-text">{kp.ctime ? new hDate(kp.ctime).format(`${tools.dateFormat} hh:mm:ss`) : tools.emptyInfo}</div>
                            </div>
                        </div>
                    </Col>
                </Row>
                <Row>
                    <Tabs defaultActiveKey="1">
                        <TabPane tab="引用详情" key="1">
                            <Table {...tbcfg} />
                        </TabPane>
                        {/* 
                        统计    
                        <TabPane tab="统计分析" key="2">
                            <_Chart_Trend
                                {...this.props} />
                        </TabPane>
                        */}
                    </Tabs>
                </Row>
            </section>
        );
    }
    onClickEdit() {
        let props = this.props;
        props.router.push({
            pathname: "/keypoint/edit",
            query: {
                keyword_id: this.state.query.keyword_id
            }
        })
    }
}

//趋势图
class _Chart_Trend extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        let fieldProps = this._getFieldProps();
        let {$$keypointDetail} = this.props;
        let summary = $$keypointDetail.toJS().summary;
        let axisXLength = Math.max.apply(Math, $.map(summary.trend_data, o => (o.data || []).length));

        //趋势
        let trendCfg = {
            grid: {
                left: "0%",
                right: "0%",
                bottom: "0%",
                top: "10%",
                containLabel: true
            },
            tooltip: {
                trigger: "axis"
            },
            xAxis: {
                splitLine: { show: false },
                data: (((summary.trend_data.filter(o => o.data.length === axisXLength).pop() || {}).data) || []).map(o => o.step)
            },
            yAxis: {
                minInterval: 1,
                axisLine: { show: false },
                splitLine: { lineStyle: { color: "rgb(230,230,230)" } }
            },
            series: $.map(summary.trend_data, o => {
                return {
                    name: o.name,
                    type: "line",
                    data: o.data.map(d => d.count)
                }
            }),
            legend: {
                orient: "horizontal",
                left: "left",
                top: 0,
                data: summary.trend_data.map(o => o.name)
            },
            color: tools.chartColor
        }
        //时间范围
        const rangeJSX = Object.getOwnPropertyNames(EnumCn.ChartTime)
            .filter(name => !isNaN(Number(name)))
            .map(key => <Option key={key} value={key}>{EnumCn.ChartTime[key]}</Option>);
        //数据类型
        const targetJSX = Object.getOwnPropertyNames(EnumCn.ChartTarget)
            .filter(name => !isNaN(Number(name)))
            .map(key => <Option key={key} value={key}>{EnumCn.ChartTarget[key]}</Option>);
        return (
            <Form>
                <Row className="m-margin-b">
                    <div className="m-stb">
                        <div className="m-tb-title">被引用的文档</div>
                        <div className="m-tb-text">{summary.info.relates_essay || 0}篇</div>
                    </div>
                    <div className="m-stb">
                        <div className="m-tb-title">被引用的问卷</div>
                        <div className="m-tb-text">{summary.info.relates_qa || 0}项</div>
                    </div>
                    <div className="m-stb">
                        <div className="m-tb-title">被引用的视频（直播/点播）</div>
                        <div className="m-tb-text">{(Number(summary.info.relates_vod) + Number(summary.info.relates_lvb)) || 0}例</div>
                    </div>
                </Row>
                <Row className="chart-box">
                    <div className="chart-cdt">
                        <div>趋势图</div>
                        <Select
                            placeholder="请选择"
                            style={{ width: 170 }}
                            className="m-margin-r"
                            {...fieldProps.trend_range}>{rangeJSX}</Select>
                        <Select
                            mode='multiple'
                            placeholder="请选择"
                            style={{ width: 400 }}
                            {...fieldProps.trend_type}>{targetJSX}</Select>
                    </div>
                    <Chart {...trendCfg} />
                </Row>
            </Form>
        )
    }
    //获取字段属性
    _getFieldProps() {
        let {form, $$keypointDetail, $$layout} = this.props;
        let summary = $$keypointDetail.toJS().summary;
        let loginUser = $$layout.toJS().login_user;
        return {
            //趋势时间范围
            trend_range: form.getFieldProps("trend_range", {
                initialValue: summary.trend_condition.range,
                onChange: (range) => {
                    let fields = form.getFieldsValue();
                    let {kpActs, location} = this.props;
                    kpActs.getTrend({
                        company_id: loginUser.company_id,
                        keypoint_id: location.query.keyword_id,
                        range: range,
                        type: fields.trend_type
                    })
                }
            }),
            //趋势折线类型
            trend_type: form.getFieldProps("trend_type", {
                initialValue: summary.trend_condition.type,
                onChange: (type) => {
                    let fields = form.getFieldsValue();
                    let {kpActs, location} = this.props;
                    kpActs.getTrend({
                        company_id: loginUser.company_id,
                        keypoint_id: location.query.keyword_id,
                        type: type,
                        range: fields.trend_range
                    })
                }
            })
        }
    }
}
_Chart_Trend = Form.create()(_Chart_Trend);


export default connect(
    state => {
        return {
            $$keypointDetail: state.$$keypointDetail,
            $$layout: state.$$layout
        }
    },
    dispatch => {
        return {
            kpActs: bindActionCreators(Actions, dispatch)
        }
    })(withRouter(keypointDetail));
