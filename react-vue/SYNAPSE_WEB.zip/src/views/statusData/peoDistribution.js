import React, {Component} from "react"
import {
    Row,
    Col,
    Icon
} from "antd"
import ScatterMap from "components/chart/map/ScatterMap"
import RankTable from "components/RankTable"
import ChartCard from "components/chart/ChartCard"
import _Chart from "components/chart"
import AreaImg from "./images/area.png"
import BarImg from "./images/bar.png"
import Bar2Img from "./images/u11493.png"
import "assets/style/views/statusData/commuEffect.less"
import StackBar from "components/chart/StackBar"
import Chart_TreeMap from "components/chart/treemap"
import Sunburst from "components/chart/sunburst"
import Funnel from "components/chart/Funnel"
import Chart_RadarBasic from "components/chart/radarBasic"
import ChartBox from "components/chart/ChartBox"

export default class PeoDistribution extends Component {
    constructor(props){
        super(props);
        this.state={
            rankTable:[
                {name:"北京市",value:"46976947649"},
                {name:"北京市",value:"46976947649"},
                {name:"北京市",value:"46976947649"},
                {name:"北京市",value:"46976947649"},
                {name:"北京市",value:"46976947649"},
                {name:"北京市",value:"46976947649"},
                {name:"北京市",value:"46976947649"},
                {name:"北京市",value:"46976947649"},
                {name:"北京市",value:"46976947649"},
                {name:"北京市",value:"46976947649"},
                {name:"北京市",value:"46976947649"},
                {name:"北京市",value:"46976947649"},
                {name:"北京市",value:"46976947649"},
                {name:"北京市",value:"46976947649"},
                {name:"北京市",value:"46976947649"},
            ]
        }
    }
    render() {
        let card1Content = <Row>
            <Col span={12}>
                <div style={{lineHeight: "60px"}}>
                    <span className="card1-content-name">周同比</span>
                    <Icon type="triangle-top" style={{color: "#92D978", margin: "0px 5px"}}/>
                    <span>12%</span>
                </div>
            </Col>
            <Col span={12}>
                <div style={{lineHeight: "60px"}}>
                    <span className="card1-content-name">日环比</span>
                    <Icon type="triangle-bottom" style={{color: "#F21934", margin: "0px 5px"}}/>
                    <span>12%</span>
                </div>
            </Col>
        </Row>;
        let card1Footer = <div style={{lineHeight: "60px", fontSize: "14px", color: "#666"}}>
            <span>日均曝光量</span>
            <span style={{marginLeft: "15px"}}>2,423</span>
        </div>
        return (
            <div>
                <Row>
                    <Col span={6}>
                        <div style={{paddingRight: "12px"}}>
                            <ChartCard content={card1Content} footer={card1Footer}/>
                        </div>
                    </Col>
                    <Col span={6}>
                        <div style={{paddingRight: "12px"}}>
                            <ChartCard content={<img src={AreaImg} style={{width: "100%", marginTop: "10px"}}/>}
                                       footer={card1Footer}/>
                        </div>
                    </Col>
                    <Col span={6}>
                        <div style={{paddingRight: "12px"}}>
                            <ChartCard content={<img src={BarImg} style={{width: "100%", marginTop: "10px"}}/>}
                                       footer={null}/>
                        </div>
                    </Col>
                    <Col span={6}>
                        <ChartCard content={<img src={Bar2Img} style={{width: "100%", marginTop: "20px"}}/>} footer={card1Content}/>
                    </Col>
                </Row>
                <Row style={{marginTop: "12px"}}>
                    <Col span={24}>
                        <ChartBox title="全国地域分布">
                            <div style={{width:"70%",float:"left"}}><ScatterMap height={644}/></div>
                            <div style={{width:"30%",float:"left",marginTop:"1px"}}><RankTable data={this.state.rankTable} title={"城市分布数量 TOP 15"}/></div>
                        </ChartBox>
                    </Col>
                </Row>
                <Row style={{marginTop: "12px"}}>
                    <Col span={9} style={{paddingRight:"12px"}}>
                        <ChartBox title="传播效果最好的城市 TOP 10"><StackBar height={440}/></ChartBox>
                    </Col>
                    <Col span={15}>
                        <ChartBox title="传播效果最好城市详细分析"><Chart_TreeMap height={440}/></ChartBox>
                    </Col>
                </Row>
                <Row style={{marginTop: "12px"}}>
                    <Col span={9} style={{paddingRight:"12px"}}>
                        <ChartBox title="传播效果最弱的城市 TOP 10"><StackBar height={440}/></ChartBox>
                    </Col>
                    <Col span={15}>
                        <ChartBox title="传播效果最弱城市详细分析"><Chart_TreeMap height={440}/></ChartBox>
                    </Col>
                </Row>
                <Row style={{marginTop: "12px"}}>
                    <Col span={12} style={{paddingRight:"12px"}}>
                        <ChartBox title="市场分级覆盖"><Funnel height={560} padding={40}/></ChartBox>
                    </Col>
                    <Col span={12}>
                        <ChartBox title="多维分析"><Sunburst height={560}/></ChartBox>
                    </Col>
                </Row>
                <Row style={{marginTop: "12px"}}>
                    <Col span={8} style={{paddingRight:"12px"}}>
                        <ChartBox title="城市分级覆盖 - 全量用户"><Chart_RadarBasic height={382} padding={10}/></ChartBox>
                    </Col>
                    <Col span={8} style={{paddingRight:"12px"}}>
                        <ChartBox title="城市分级覆盖 - 全量用户"><Chart_RadarBasic height={382} padding={10}/></ChartBox>
                    </Col>
                    <Col span={8}>
                        <ChartBox title="城市分级覆盖 - 全量用户"><Chart_RadarBasic height={382} padding={10}/></ChartBox>
                    </Col>
                </Row>
            </div>
        );
    }
}

class _AreaChart extends Component {
    render() {
        let cfg = {
            backgroundColor: '#394056',
            title: {
                text: '请求数',
                textStyle: {
                    fontWeight: 'normal',
                    fontSize: 16,
                    color: '#F1F1F3'
                },
                left: '6%'
            },
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    lineStyle: {
                        color: '#57617B'
                    }
                }
            },
            /*legend: {
             icon: 'rect',
             itemWidth: 14,
             itemHeight: 5,
             itemGap: 13,
             data: ['移动', '电信', '联通'],
             right: '4%',
             textStyle: {
             fontSize: 12,
             color: '#F1F1F3'
             }
             },*/
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: [{
                type: 'category',
                boundaryGap: false,
                axisLine: {
                    lineStyle: {
                        color: '#57617B'
                    }
                },
                data: ['13:00', '13:05', '13:10', '13:15', '13:20', '13:25', '13:30', '13:35', '13:40', '13:45', '13:50', '13:55']
            }, {
                axisPointer: {
                    show: false
                },
                axisLine: {
                    lineStyle: {
                        color: '#57617B'
                    }
                },
                axisTick: {
                    show: false
                },

                position: 'bottom',
                offset: 20,
                data: ['', '', '', '', '', '', '', '', '', '', {
                    value: '周六',
                    textStyle: {
                        align: 'left'
                    }
                }, '周日']
            }],
            yAxis: [{
                type: 'value',
                name: '单位（%）',
                axisTick: {
                    show: false
                },
                axisLine: {
                    lineStyle: {
                        color: '#57617B'
                    }
                },
                axisLabel: {
                    margin: 10,
                    textStyle: {
                        fontSize: 14
                    }
                },
                splitLine: {
                    lineStyle: {
                        color: '#57617B'
                    }
                }
            }],
            series: [{
                name: '移动',
                type: 'line',
                smooth: true,
                symbol: 'circle',
                symbolSize: 5,
                showSymbol: false,
                lineStyle: {
                    normal: {
                        width: 1
                    }
                },
                areaStyle: {
                    normal: {
                        color: 'blue',
                        shadowColor: 'rgba(0, 0, 0, 0.1)',
                        shadowBlur: 10
                    }
                },
                itemStyle: {
                    normal: {
                        color: 'red',
                        borderColor: 'blue',
                        borderWidth: 0

                    }
                },
                data: [220, 182, 191, 134, 150, 120, 110, 125, 145, 122, 165, 122]
            }
            ]
        };
        return (
            <_Chart {...cfg}/>
        );
    }
}