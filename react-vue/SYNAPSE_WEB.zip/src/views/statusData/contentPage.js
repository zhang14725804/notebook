/**
 *
 * title: contentPage.js
 *
 * author: WangPei.
 *
 * date: 2018/3/18.
 *
 */
import React,{Component} from "react"
import {Tabs} from "antd"
import GlobalSearch from "components/globalSearch"
import CommuEffect from "./commuEffect"
import PeoDistribution from "./peoDistribution"
import "src/assets/style/views/statusData/contentPage.less"
const TabPane = Tabs.TabPane;

export default class ContentPage extends Component{
    constructor(props){
        super(props);
        this.state={
            data:{
                dataItem: [
                    {
                        name: "传播效果",
                        value: "0"
                    }, {
                        name: "人群分布",
                        value: "1"
                    }, {
                        name: "行为习惯",
                        value: "2"
                    }, {
                        name: "内容质量",
                        value: "3"
                    }, {
                        name: "认知变化",
                        value: "4"
                    }
                ]
            },
            selectedTag:"0"
        }
    }
    render(){
        let content=null;
        switch (this.state.selectedTag){
            case "0":
                content=<CommuEffect/>;
                break;
            case "1":
                content=<PeoDistribution/>;
                break;

        }
        return(
            <div className="data-ins-content" style={{backgroundColor: "rgba(243, 244, 247, 1)", padding: "12px"}}>
                <div style={{marginBottom:"12px"}}>
                    <GlobalSearch dataSource={this.state.data} onChangeItem={::this.onChangeTag} isHideItem2={this.state.selectedTag!=="0"?true:false}/>
                </div>
                {
                    this.state.selectedTag==="3"?
                        <div style={{backgroundColor:"#fff"}}>
                            <Tabs defaultActiveKey="1" className="content-tab">
                                <TabPane tab="客观数据" key="1">Content of Tab Pane 1</TabPane>
                                <TabPane tab="内容偏好" key="2">Content of Tab Pane 2</TabPane>
                            </Tabs></div>:null
                }
                {content}
            </div>
        );
    }
    onChangeTag(tag){
        this.setState({selectedTag:tag});
    }
}