import React, {Component} from "react"
import {
    Card,
    Row,
    Col,
    Breadcrumb,
    Radio,
    Icon,
    Tag,
    Input,
    DatePicker,
    Checkbox,
    Modal,
    Popover,
    Alert
} from "antd"
import moment from "moment"
import {Link, withRouter} from "react-router"
import {connect} from "react-redux"
import TextCard from "components/card/TextCard"
import KMCard from "components/card/KMCard"
import ImgCard from "components/card/ImgCard"
import ImgTextCard from "components/card/ImgTextCard"
import IconCard from "components/card/IconCard"
import AddCard from "components/card/AddCard"
import EditInfo from "components/editInfo"
import BroadSteps from "components/broadSteps"
import "assets/style/views/marketCampaign/extension/edit.less"
import "src/assets/style/views/marketCampaign/groupExtension/edit.less"
import {tools} from "utils"
import { Select } from 'antd';
import BatchUpload from "components/BatchUpload"
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const {RangePicker} = DatePicker;
const dateFormat = 'YYYY-MM-DD';
const pageImgs={
    img1:require('src/assets/image/u2776.png'),
    img2:require('src/assets/image/u2787.png'),
}
class GroupExtensionEdit extends Component {
    constructor(props) {
        super(props);
        this.state = {
            visible1: false,
            visible2: false,
            arrs:[
                {
                    arti:[],
                    imgs:[]
                }
                // ,
                // {
                //     arti:[],
                //     imgs:[]
                // },
            ],
            channelData: [
                {
                    id: 1,
                    icon: 1,
                    name: "杏仁医生",
                    checked: false
                },
                {
                    id: 2,
                    icon: 1,
                    name: "杏仁医生",
                    checked: false
                },
                {
                    id: 3,
                    icon: 1,
                    name: "杏仁医生",
                    checked: false
                },
                {
                    id: 4,
                    icon: 1,
                    name: "杏仁医生",
                    checked: false
                },
            ],
        }

        this.upLoadIndex=0
    }
    onSelectChange(valGet){
        console.log(valGet,'--valGet--');
    }
    render() {
        let {imgs,arrs}=this.state;
        let titleData={
                title: "新建推广项目－组合推广",
                creator: "小白菜",
                department: "市场部",
                product: "韦瑞德",
                field: "HIV",
                icon: "tuiguang",
                // color: "#FFFBE6",
                cancelTxt: "取 消",
                completeTxt: "完 成"
        }
        let arr1=[{
            id:'Noda1',
            des:'3 条解读 2017 年原发性骨质疏松诊疗指南',
            condition:[1,2]
        },{
            id:'Noda2',
            des:'儿童发热不推荐物理降温！这 6 点一定要悉知',
            condition:[1,2]
        },];

        let stepsJSX=arr1.map((item,i)=>{
            return(
                <BroadSteps edit key={i} {...item} onSelectChange={this.onSelectChange.bind(this)}/>
            )
        })
        return (
            <div className="marketCamp-detail">
                <EditInfo dataSource={titleData}/>
                <div className="page-content-border">
                    <div>
                        <Card>
                            <Row className="edit-input-box">
                                <Col span={6}></Col>
                                <Col span={3} className="text-align-right-label"><span>推广主题：</span></Col>
                                <Col span={7}><Input placeholder="给推广起个名字"/></Col>
                                <Col span={8}></Col>
                            </Row>
                            <Row className="edit-input-box">
                                <Col span={6}></Col>
                                <Col span={3} className="text-align-right-label"><span>推广有效期：</span></Col>
                                <Col span={7}>
                                    <RangePicker
                                        defaultValue={[moment('2015-06-06', dateFormat), moment('2015-06-06', dateFormat)]}/>
                                </Col>
                                <Col span={8}></Col>
                            </Row>
                            <Row className="edit-input-box" style={{marginBottom:"35px"}}>
                                <Col span={6}></Col>
                                <Col span={3} className="text-align-right-label"><span>费用阈值：</span></Col>
                                <Col span={7}><Input prefix={"￥"} placeholder="" style={{width:"50%"}} /></Col>
                                <Col span={8}></Col>
                            </Row>
                        </Card>
                    </div>
                    {/*<div>*/}
                        {/*<Card bordered={false}>*/}
                            {/*<Row>*/}
                                {/*<Col span={6}></Col>*/}
                                {/*<Col span={12}>*/}
                                    {/*<div className="edit-input-box">*/}
                                        {/*<span>推广主题：</span>*/}
                                        {/*<div className="edit-input"><Input placeholder="给推广起个名字"/></div>*/}
                                    {/*</div>*/}
                                    {/*<div className="edit-input-box"><span>推广有效期：</span>*/}
                                        {/*<div className="edit-input extension-edit-datapicker">*/}
                                            {/*<RangePicker*/}
                                                {/*defaultValue={[moment('2015-06-06', dateFormat), moment('2015-06-06', dateFormat)]}*/}
                                            {/*/>*/}
                                            {/*<Checkbox onChange={() => {*/}
                                            {/*}}>永久</Checkbox>*/}
                                        {/*</div>*/}
                                    {/*</div>*/}
                                {/*</Col>*/}
                                {/*<Col span={6}></Col>*/}
                            {/*</Row>*/}
                        {/*</Card>*/}
                    {/*</div>*/}
                    {/*设置目标人群*/}
                    <div className="base-info-card content-card-margin">
                        <Card bordered={false} title={<div>设置目标人群</div>}>
                            <Row>
                                <Col span={12}><AddCard lg onClick={() => {
                                    this.setState({visible1: true})
                                }}/></Col>
                                <Col span={12}><TextCard/></Col>
                                <Col span={12}><TextCard/></Col>
                            </Row>
                        </Card>
                    </div>
                    {/*设置互动内容*/}
                    <div className="base-info-card content-card-margin">
                        <Card bordered={false} title={<div>设置互动内容</div>} extra={<Popover placement="right" content={
                            <div style={{width: "200px"}}>
                                <p className="title"><Icon className="themeColor" type="info-circle-o"></Icon> 说明：</p>
                                <p className="title">素材包下载</p>
                            </div>
                        }>
                            <Icon type="info-circle-o" style={{margin: '0px 10px', color: "#2491FC"}}/>
                            <span>素材包下载</span>
                        </Popover>}>
                            {
                                arrs.map((item,i)=>{
                                    return(
                                        <Row key={i}>
                                            <Col span={24}>
                                                {/*文档卡*/}
                                                <ImgTextCard link/>
                                            </Col>
                                            {
                                                arrs[i].imgs.map((item,index)=>{
                                                    let data={
                                                        type:"img",
                                                        imgs:arrs[i].imgs,
                                                        name:"慢性乙型肝炎的抗病毒药物及靶点的研究进展",
                                                        message:"KM: 学术会议是重要的信息来源",
                                                        date:"2017-12-11"
                                                    };
                                                    return(
                                                        // 图片卡
                                                        <Col key={i} span={24}>
                                                            <Col className='imgCardWrap' span={1}>
                                                                <img src={pageImgs.img1}/>
                                                            </Col>
                                                            <Col span={23}>
                                                                <ImgTextCard link
                                                                             reUpload={()=>{this.refs.batchUploadCom.onClickUpload()}}
                                                                             delete={()=>{
                                                                                 let tem=arrs;
                                                                                 tem[i].imgs.length=0;
                                                                                 this.setState({arrs:tem})
                                                                             }}
                                                                             data={data}
                                                                />
                                                            </Col>
                                                        </Col>
                                                    )
                                                })
                                            }
                                            {/*已经上传了图片则隐藏上传框*/}
                                            <Col span={24} style={{display:arrs&&arrs[i].imgs.length>0?'none':'block'}}>
                                                <Col className='imgCardWrap' span={1}>
                                                    <img src={pageImgs.img2}/>
                                                </Col>
                                                <Col span={23}>
                                                    <BatchUpload  ref="batchUploadCom"
                                                                  extension=".jpg|.png"
                                                                  onSuccess={(imgs)=>{
                                                                      let tem=arrs;
                                                                      tem[this.upLoadIndex].imgs=imgs;
                                                                      this.setState({
                                                                          arrs:tem
                                                                      },()=>{
                                                                          console.log(this.state.arrs,'arrs');
                                                                      })
                                                                  }}
                                                                  onClick={this.onUpload.bind(this,i)}
                                                    />
                                                </Col>
                                            </Col>
                                        </Row>
                                    )
                                })
                            }


                            {/*关联文章卡片*/}
                            <Row className='upload-article'>
                                <Col span={24} className="extension-edit-materiel">
                                    <Card>
                                        <Icon type="ep--"/>
                                        <span>关联文章</span>
                                    </Card>
                                </Col>
                            </Row>
                        </Card>
                    </div>
                    {/*设置组合推广路径*/}
                    <div className="base-info-card content-card-margin">
                        <Card bordered={false} title={<div>设置组合推广路径</div>}>
                            <Row>
                                <Col>
                                    <div className='step'><span>Step 1：</span></div>
                                    <div className='step'><span>Step 2：</span><span>设置组合推广路径各节点文章及条件</span></div>
                                    <div className='base-info-head base-info-start'>START</div>
                                    <div className='base-info-line'></div>
                                </Col>
                            </Row>
                            {stepsJSX}
                            <Row>
                                <Col>
                                    <div className='base-info-head base-info-end'>END</div>
                                </Col>
                            </Row>
                            {/*<Row>*/}
                                {/*<Col span={8}><AddCard/></Col>*/}
                                {/*<Col span={8}><KMCard/></Col>*/}
                                {/*<Col span={8}><KMCard/></Col>*/}
                                {/*<Col span={8}><KMCard/></Col>*/}
                            {/*</Row>*/}
                        </Card>
                    </div>
                    {/*选择推广渠道*/}
                    <div className="base-info-card broad-method content-card-margin">
                        <Card bordered={false} title={<div>选择推广渠道</div>}>
                            <Row className="alert-row">
                                <Alert
                                    message="由于各媒体端受自有运营体制和第三方合并开放程度不统一，您设置的推广内容将展示在不同媒体端的不同展位，为最大提高曝光量，建议默认选择全部展位。系统会根据您配置的推广周期和内容自动匹配最合适的媒体及展位进行曝光"
                                    type="warning"
                                    // iconType="tuiguang"
                                    showIcon />
                            </Row>
                            <Row>
                                {
                                    this.state.channelData.map((item, index) => {
                                        return (
                                            <Col key={index} span={6}><IconCard data={item}
                                                                                onClick={this.onCheckChannel.bind(this, item.id)}
                                                                                inEdit/></Col>
                                        );
                                    })
                                }
                            </Row>
                            <Row>
                                <div className="extension-detail-tags">
                                    <span>媒体展位：</span>
                                    <Checkbox onChange={() => {
                                    }}>焦点图(Banner)</Checkbox>
                                    <Checkbox onChange={() => {
                                    }}>信息流(Feeds)</Checkbox>
                                    <Checkbox onChange={() => {
                                    }}>启动屏(Loading Page)</Checkbox>
                                </div>
                            </Row>
                        </Card>
                    </div>
                </div>
                <Modal
                    title="添加目标人群"
                    visible={this.state.visible1}
                    onOk={() => {
                        this.setState({visible1: false})
                    }}
                    okText="确定"
                    cancelText="取消"
                    width={1275}
                    onCancel={() => {
                        this.setState({visible1: false})
                    }}>
                    <Row>
                        <Col span={12}><TextCard/></Col>
                        <Col span={12}><TextCard/></Col>
                    </Row>
                </Modal>
            </div>
        );
    }
    onCheckChannel(id) {
        let data = this.state.channelData;
        let modifyData = [];
        data.forEach((item, index) => {
            if (item.id === id) {
                item.checked = !item.checked;
                modifyData.push(item);
            } else {
                modifyData.push(item)
            }
        })
        this.setState({channelData: modifyData});
    }
    onUpload(i){
        console.log(i,777);
        // this.setState({
        //     upLoadIndex:i
        // })
        this.upLoadIndex=parseInt(i);
    }
}

export default connect(
    (state) => {
        return {
            // $$newsList: state.$$newsList
        }
    },
    (dispatch) => {
        return {
            // newsActs: bindActionCreators(Actions, dispatch)
        }
    })(withRouter(GroupExtensionEdit))
