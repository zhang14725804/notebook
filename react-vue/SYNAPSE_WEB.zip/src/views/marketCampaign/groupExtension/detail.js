import React, {Component} from "react"
import {
    Card,
    Row,
    Col,
    Breadcrumb,
    Radio,
    Icon,
    Tag,
    Input,
    DatePicker,
    Checkbox,
    Modal,
    Popover
} from "antd"
import moment from "moment"
import {Link, withRouter} from "react-router"
import {connect} from "react-redux"
import TextCard from "components/card/TextCard"
import KMCard from "components/card/KMCard"
import ImgCard from "components/card/ImgCard"
import ImgTextCard from "components/card/ImgTextCard"
import IconCard from "components/card/IconCard"
import AddCard from "components/card/AddCard"
import EditInfo from "components/editInfo"
import BroadSteps from "components/broadSteps"
import "src/assets/style/views/marketCampaign/extension/edit.less"
import "src/assets/style/views/marketCampaign/groupExtension/edit.less"
import {tools} from "utils"
import { Select } from 'antd';
import {ColorEnum} from 'src/constants/customEnum'
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const {RangePicker} = DatePicker;
const dateFormat = 'YYYY-MM-DD';
const pageImgs={
    img1:require('src/assets/image/u2776.png'),
    img2:require('src/assets/image/u2787.png'),
}
class GroupExtensionDetail extends Component {
    constructor(props) {
        super(props);
        this.state = {
            visible1: false,
            visible2: false,
            channelData: [
                {
                    id: 1,
                    icon: 1,
                    name: "杏仁医生",
                    checked: false
                },
                {
                    id: 2,
                    icon: 1,
                    name: "杏仁医生",
                    checked: false
                },
                {
                    id: 3,
                    icon: 1,
                    name: "杏仁医生",
                    checked: false
                },
                {
                    id: 4,
                    icon: 1,
                    name: "杏仁医生",
                    checked: false
                },
            ],
        }
    }

    render() {
        let arr1=[{
            id:'Noda1',
            des:'3 条解读 2017 年原发性骨质疏松诊疗指南',
            condition:[1,2]
        },{
            id:'Noda2',
            des:'儿童发热不推荐物理降温！这 6 点一定要悉知',
            condition:[1,2]
        },];
        let stepsJSX=arr1.map((item,i)=>{
            return(
                <BroadSteps key={i} {...item}/>
            )
        })
        let cardIconStyle={
            color:'#999999',
            fontSize: '27px',
            verticalAlign: 'sub',
            marginRight: '5px'
        }
        // 顶部标题左侧图标随机色 0-4
        let colorType=ColorEnum.colorType;
        let colorId=parseInt(Math.random()*5,10);
        let titleIconStyle={
            width:'32px',
            height:'32px',
            lineHeight:'32px',
            fontSize:'17px',
            color:colorType[colorId].color,
            backgroundColor:colorType[colorId].bgColor,
            marginRight:'10px'
        }
        return (
            <div className="marketCamp-detail">
                <div className="page-header-box">
                <Breadcrumb>
                    <Breadcrumb.Item>市场推广</Breadcrumb.Item>
                    <Breadcrumb.Item><a href="#">营销战役</a></Breadcrumb.Item>
                    <Breadcrumb.Item><a href="#">推广项目</a></Breadcrumb.Item>
                </Breadcrumb>
                <Row style={{padding: "1rem 0rem"}}>
                    <Col span={16}><span className="camp-title"><Icon style={titleIconStyle} className='back-icon' type="rocket"/>一图看懂！韦瑞德为什么安全？</span></Col>
                    <Col span={8}>
                        <div className="baseBtn extension-detail-edit-btn">编辑</div>
                    </Col>
                </Row>
                <div className="create-info">
                    <Row>
                        <Col span={5}>项目分类：学术速递</Col>
                        <Col span={15}>项目格式：图文</Col>
                        <Col span={4}><span className="status-title">推广状态</span></Col>
                    </Row>
                    <Row>
                        <Col span={5}>唯一编号：CN-Q8314FAFEA</Col>
                        <Col span={15}>内容期限：2018-01-10～2019-01-10</Col>
                        <Col span={4}><span className="status-value">未开始</span></Col>
                    </Row>
                </div>
                </div>
                <div className="page-content-border">
                    {/*目标人群*/}
                    <div>
                        <Card bordered={false} title={<div><Icon type='qun' style={cardIconStyle}></Icon>目标人群</div>}>
                            <Row>
                                <Col span={12}><TextCard/></Col>
                                <Col span={12}><TextCard/></Col>
                            </Row>
                        </Card>
                    </div>
                    {/*设置Kemessage*/}
                    <div className="base-info-card content-card-margin">
                        <Card bordered={false} title={<div><Icon type='flag_fill' style={cardIconStyle}></Icon>Kemessage</div>}>
                            <Row>
                                <Col span={8}><KMCard/></Col>
                                <Col span={8}><KMCard/></Col>
                                <Col span={8}><KMCard/></Col>
                            </Row>
                        </Card>
                    </div>
                    {/*互动内容*/}
                    <div className="base-info-card content-card-margin">
                        <Card bordered={false} title={<div><Icon type='tuiguang' style={cardIconStyle}></Icon>互动内容</div>}>
                            <Row>
                                <Col span={24}><ImgTextCard/></Col>
                                <Col span={24}>
                                    <Col className='imgCardWrap' span={1}>
                                        <img src={pageImgs.img1}/>
                                    </Col>
                                    <Col span={23}>
                                    <ImgTextCard data={{
                                    type: "img",
                                    name: "推广渠道展位封面图",
                                    message: "",
                                    date: "2017-12-11"
                                }} imgs={[{name:"wx_img",url:"https://ss3.baidu.com/-rVXeDTa2gU2pMbgoY3K/it/u=3044192727,472157510&fm=202&src=764&mola=new&crop=v1"}]}
                                    />
                                    </Col>
                                </Col>
                            </Row>
                        </Card>
                    </div>
                    {/*推广渠道*/}
                    <div className="base-info-card content-card-margin">
                            <Card bordered={false} title={<div><Icon type='tuiguang' style={cardIconStyle}></Icon>推广渠道</div>} extra={<Popover placement="right" content={
                                <div style={{width: "200px"}}>
                                    <p className="title"><Icon className="themeColor" type="info-circle-o"></Icon> 说明：</p>
                                    <p className="title">推广计价说明</p>
                                </div>
                            }>
                                <Icon type="info-circle-o" style={{margin: '0px 10px', color: "#2491FC"}}/>
                                <span>推广位计价说明</span>
                            </Popover>}>
                                <Row>
                                    {
                                        this.state.channelData.map((item,index)=>{
                                            return(
                                                <Col key={index} span={6}><IconCard data={item}/></Col>
                                            );
                                        })
                                    }
                                </Row>
                                <Row>
                                    <div className="extension-detail-tags">
                                        <span>媒体展位：</span>
                                        <Tag>焦点图(Banner)</Tag>
                                        <Tag>信息流(Feeds)</Tag>
                                        <Tag>启动屏(Loading Page)</Tag>
                                    </div>
                                </Row>
                            </Card>
                        </div>
                    {/*组合推广路径*/}
                    <div className="base-info-card content-card-margin">
                        <Card bordered={false} title={<div><Icon type='tuiguang' style={cardIconStyle}></Icon>组合推广路径</div>}>
                           <Row>
                                <Col>
                                    {/*<div className='step'><span>Step 1：</span></div>*/}
                                    {/*<div className='step'><span>Step 2：</span><span>设置组合推广路径各节点文章及条件</span></div>*/}
                                    <div className='base-info-head base-info-start'>START</div>
                                    <div className='base-info-line'></div>
                                </Col>
                            </Row>
                            {stepsJSX}
                            <Row>
                                <Col>
                                    <div className='base-info-head base-info-end'>END</div>
                                </Col>
                            </Row>
                        </Card>
                    </div>

                </div>
                <Modal
                    title="添加目标人群"
                    visible={this.state.visible1}
                    onOk={() => {
                        this.setState({visible1: false})
                    }}
                    okText="确定"
                    cancelText="取消"
                    width={1275}
                    onCancel={() => {
                        this.setState({visible1: false})
                    }}>
                    <Row>
                        <Col span={12}><TextCard/></Col>
                        <Col span={12}><TextCard/></Col>
                    </Row>
                </Modal>
            </div>
        );
    }
    onEditGroupExtension() {
        this.props.router.push("/marketCampaign/groupExtension/edit")
    }
}

export default connect(
    (state) => {
        return {
            // $$newsList: state.$$newsList
        }
    },
    (dispatch) => {
        return {
            // newsActs: bindActionCreators(Actions, dispatch)
        }
    })(withRouter(GroupExtensionDetail))
