import React, {Component} from "react"
import {
    Card,
    Row,
    Col,
    Breadcrumb,
    Radio,
    Icon,
    Tabs,
    Input,
    Menu,
    Dropdown,
    Button,
    Table,
    Tooltip
} from "antd"
import $ from "jquery"
import {Link, withRouter} from "react-router"
import {connect} from "react-redux"
import TextCard from "components/card/TextCard"
import KMCard from "components/card/KMCard"
import "assets/style/views/marketCampaign/detail.less"
import {tools} from "utils"
import {EnumCn} from "enum"
import {ColorEnum} from "src/constants/customEnum"

const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const TabPane = Tabs.TabPane;
const Search = Input.Search;
const MenuItem = Menu.Item;
const BattleStatusColor=ColorEnum.BattleStatusColor;

class MarketCampDetail extends Component {
    constructor(props) {
        super(props);
        this.state = {
            peopleGroup: [
                {
                    id: "1",
                    checked: true,
                    name: "华北华中华西地区高级职称医生",
                    values: [
                        {title: "预计覆盖人数", value: "3129228"},
                        {title: "推广区域（3）", value: "华北 华西 华中"},
                        {title: "覆盖科室（2）", value: "内科 免疫课"},
                        {title: "医院等级（2）", value: "三级甲等 二级甲等"},
                        {title: "医生职称（4）", value: "住院医师 主治医师 副主任医师 主任医师"},
                    ]
                },
                {
                    id: "2",
                    checked: false,
                    name: "华北华中华西地区高级职称医生",
                    values: [
                        {title: "预计覆盖人数", value: "3129228"},
                        {title: "推广区域（3）", value: "华北 华西 华中"},
                        {title: "覆盖科室（2）", value: "内科 免疫课"},
                        {title: "医院等级（2）", value: "三级甲等 二级甲等"},
                        {title: "医生职称（4）", value: "住院医师 主治医师 副主任医师 主任医师"},
                    ]
                },
                {
                    id: "3",
                    checked: false,
                    name: "华北华中华西地区高级职称医生",
                    values: [
                        {title: "预计覆盖人数", value: "3129228"},
                        {title: "推广区域（3）", value: "华北 华西 华中"},
                        {title: "覆盖科室（2）", value: "内科 免疫课"},
                        {title: "医院等级（2）", value: "三级甲等 二级甲等"},
                        {title: "医生职称（4）", value: "住院医师 主治医师 副主任医师 主任医师"},
                    ]
                }
            ],
            km: [
                {
                    id: "ID:123123",
                    message: "疗效好！见效快",
                    link: 3
                },
                {
                    id: "ID:123124",
                    message: "疗效好！见效快",
                    link: 6
                },
                {
                    id: "ID:123125",
                    message: "疗效好！见效快",
                    link: 2
                }
            ],
            extensions: [
                {
                    id: '1',
                    name: '为什么要选择买韦瑞德',
                    km: "疗效好！见效快",
                    totalConsum: '￥123000',
                    startTime: "2018-01-21 10:00",
                    status: 0
                },
                {
                    id: '2',
                    name: '为什么要选择买韦瑞德',
                    km: "疗效好！见效快",
                    totalConsum: '￥123000',
                    startTime: "2018-01-21 10:00",
                    status: 1
                },
                {
                    id: '3',
                    name: '为什么要选择买韦瑞德',
                    km: "疗效好！见效快",
                    totalConsum: '￥123000',
                    startTime: "2018-01-21 10:00",
                    status: 1
                },
                {
                    id: '4',
                    name: '为什么要选择买韦瑞德',
                    km: "疗效好！见效快",
                    totalConsum: '￥123000',
                    startTime: "2018-01-21 10:00",
                    status: 2
                },
            ]
        }
    }

    render() {
        let {peopleGroup, km, extensions} = this.state;
        const menu = (
            <Menu onClick={::this.onAddExtension}>
                <MenuItem><Icon type="rocket"/><span>学术速递</span></MenuItem>
                <MenuItem><Icon type="shipinbofang"/><span>线上互动</span></MenuItem>
                <MenuItem><Icon type="shexiangtou"/><span>线上直播</span></MenuItem>
                <MenuItem><Icon type="shipinbofang"/><span>学术视频</span></MenuItem>
                <MenuItem><Icon type="edit"/><span>调研问卷</span></MenuItem>
                <MenuItem><Icon type="erji-lujingguanli"/><span>组合推广</span></MenuItem>
            </Menu>
        );
        let extra = <div style={{marginTop:"7px",marginRight:"25px"}}>
            <Row>
                <Col span={18}>
                    <Search
                        placeholder="请输入搜索内容"
                        onSearch={value => console.log(value)}
                        style={{width: 200}}
                    />
                </Col>
                <Col span={6}>
                    <Dropdown overlay={menu}>
                        <Button type="primary" className="marketCamp-detail-add-btn">
                            <span className="btn-text">新增</span>
                            <Icon type="down"/>
                        </Button>
                    </Dropdown>
                </Col>
            </Row>
        </div>;
        let cfg = {
            dataSource: extensions,
            rowKey: r => r.id,
            columns: [
                {
                    title: "推广项目",
                    dataIndex: "name",
                    width: '19%',
                    key: "name",
                    render: (text, r) => {
                        return (
                            <div>
                                <a onClick={this.onClickItem.bind(this,r.id)}>{text}</a>
                            </div>
                        )
                    }
                },
                {
                    title: "KM",
                    dataIndex: "km",
                    width: '13%',
                    key: "km",
                    render: (text, r) => {
                        return (
                            <div>
                                <Tooltip placement="top" title={text}>
                                    {text}
                                </Tooltip>
                            </div>
                        )
                    }
                },
                {
                    title: "总消耗",
                    dataIndex: "totalConsum",
                    width: '13%',
                    key: "totalConsum",
                    render: (text, r) => {
                        return (
                            <div>
                                {text}
                            </div>
                        )
                    }
                },
                {
                    title: "开始时间",
                    dataIndex: "startTime",
                    width: '13%',
                    key: "startTime",
                    render: (text, r) => {
                        return (
                            <div>
                                {text}
                            </div>
                        )
                    }
                },
                {
                    title: "推广状态",
                    dataIndex: "status",
                    width: '13%',
                    key: "status",
                    render: (text, r) => {
                        return (
                            <div>
                                <span style={{marginRight:"2px"}}><Icon style={{color:BattleStatusColor[Number(text)]}} type={'yuandianzhong'}></Icon></span>
                                <span>{EnumCn.BattleStatus[Number(text)]}</span>
                            </div>
                        )
                    }
                },
                {
                    title: "操作",
                    dataIndex: "operation",
                    width: '13%',
                    key: "operation",
                    render: (text, r) => {
                        return (
                            <div>
                                <Link to="/marketCamp/extension/edit">编辑</Link>
                            </div>
                        )
                    }
                },
            ],
            pagination: $.extend(true, {}, tools.config.pagination, {
                current: 1,
                pageSize: 5,
                total: 20
            }),
            /*rowSelection: {
                type: "radio",
                selectedRowKeys: checkedExps.map(d => d.id),
                onChange: (selectedRowKeys, selectedRows) => {
                    let {expSinActs} = this.props;
                    expSinActs.setCheckedExpSin(selectedRows);
                }
            }*/
        };
        let colorStyle={
            color:ColorEnum.colorType[2].color,
            backgroundColor:ColorEnum.colorType[2].bgColor,
        }
        return (
            <div className="marketCamp-detail">
                <div className="page-header-box">
                    <Breadcrumb>
                        <Breadcrumb.Item>市场推广</Breadcrumb.Item>
                        <Breadcrumb.Item><a href="#">营销战役</a></Breadcrumb.Item>
                    </Breadcrumb>
                    <Row style={{padding: "12px 0px"}}>
                        <Col span={16}>
                            <div className='battle-icon' style={{backgroundColor:colorStyle.backgroundColor}}>
                                <Icon style={{color:colorStyle.color,fontSize:'18px'}} type='tuiguang'></Icon>
                            </div>
                            <span className="camp-title">买韦瑞德！2千万用户的共同选择</span>
                        </Col>
                        <Col span={8}>
                            <div className="endCamp">结束战役</div>
                            <RadioGroup defaultValue="" style={{marginRight:"10px",fontSize:"14px",float:"right"}}>
                                <RadioButton value="a" onClick={::this.onEditCamp}>编&nbsp;辑</RadioButton>
                                <RadioButton value="b">操&nbsp;作</RadioButton>
                                {/*<RadioButton value="c"> ... </RadioButton>*/}
                            </RadioGroup>
                        </Col>
                    </Row>
                    <div className="create-info">
                        <p>我们是一家以科学为导向的全球医药保健公司，我们的使命是：帮助人们做到更多，感觉更舒适，生活更长久。</p>
                        <Row>
                            <Col span={5}>创建人：小白菜</Col>
                            <Col span={15}>所属部门：市场部</Col>
                            {/*<Col span={2}>费用阈值</Col>*/}
                            <Col span={4}><span className="status-title">战役状态</span></Col>
                        </Row>
                        <Row>
                            <Col span={5}>创建时间：2017-01-10</Col>
                            <Col span={15}>生效日期：2018-01-10～2019-01-10</Col>
                            {/*<Col span={2}><span>￥50000</span></Col>*/}
                            <Col span={4}><span className="status-value">进行中</span></Col>
                        </Row>
                    </div>
                </div>
                <div>
                    <Tabs defaultActiveKey="1">
                        <TabPane tab="基础信息" key="1">
                            <div className="page-content-border">
                                <div>
                                    <Card title={<div className="card-title"><Icon type="qun"/><span>目标人群</span></div>}>
                                        <Row>
                                            {
                                                peopleGroup.map((item, index) => {
                                                    return (
                                                        <Col key={index} span={12}><TextCard data={item}/></Col>
                                                    );
                                                })
                                            }
                                        </Row>
                                    </Card>
                                </div>
                                <div className="content-card-margin">
                                    <Card title={<div className="card-title"><Icon type="flag_fill"/><span>Keymessage</span></div>}>
                                        <Row>
                                            {
                                                km.map((item, index) => {
                                                    return (
                                                        <Col key={index} span={8}><KMCard data={item}/></Col>
                                                    );
                                                })
                                            }
                                        </Row>
                                    </Card>
                                </div>
                                <div className="content-card-margin">
                                    <Card title={<div className="card-title"><Icon type="tuiguang"/><span>推广项目</span></div>} extra={extra}>
                                        <Table {...cfg} className="extension-table"/>
                                    </Card>
                                </div>
                            </div>
                        </TabPane>
                        <TabPane tab="数据分析" key="2"></TabPane>
                    </Tabs>
                </div>
            </div>
        );
    }

    onClickItem(id){
        if(id==="1"||id==="2"){
            this.props.router.push("/marketCamp/extension/detail");
        }else {
            this.props.router.push("/marketCamp/groupExtension/detail");
        }
    }

    onEditCamp() {
        this.props.router.push("/marketCamp/edit")
    }

    onAddExtension(item) {
        if(item.key==="item_5"){
            this.props.router.push("/marketCamp/groupExtension/edit")
        }else {
            this.props.router.push("/marketCamp/extension/edit")
        }

    }
}

export default connect(
    (state) => {
        return {
            // $$newsList: state.$$newsList
        }
    },
    (dispatch) => {
        return {
            // newsActs: bindActionCreators(Actions, dispatch)
        }
    })(withRouter(MarketCampDetail))