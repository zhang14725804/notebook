import React, {Component} from "react"
import {
    Card,
    Row,
    Col,
    Breadcrumb,
    Radio,
    Icon,
    Tag,
    Popover
} from "antd"
import {Link, withRouter} from "react-router"
import {connect} from "react-redux"
import TextCard from "components/card/TextCard"
import KMCard from "components/card/KMCard"
// import ImgCard from "components/card/ImgCard"
import ImgTextCard from "components/card/ImgTextCard"
import IconCard from "components/card/IconCard"
import "assets/style/views/marketCampaign/extension/detail.less"
import {tools} from "utils"
import {ColorEnum} from "src/constants/customEnum"

const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;

class ExtensionDetail extends Component {
    constructor(props){
        super(props);
        this.state={
            channelData: [
                {
                    id: 1,
                    icon: 1,
                    name: "杏仁医生",
                    checked: false
                },
                {
                    id: 2,
                    icon: 1,
                    name: "杏仁医生",
                    checked: false
                },
                {
                    id: 3,
                    icon: 1,
                    name: "杏仁医生",
                    checked: false
                },
                {
                    id: 4,
                    icon: 1,
                    name: "杏仁医生",
                    checked: false
                },
            ],
            peopleGroup: [
                {
                    id: "1",
                    checked: true,
                    name: "华北华中华西地区高级职称医生",
                    isCamp: true,
                    values: [
                        {title: "预计覆盖人数", value: "3129228"},
                        {title: "推广区域（3）", value: "华北 华西 华中"},
                        {title: "覆盖科室（2）", value: "内科 免疫课"},
                        {title: "医院等级（2）", value: "三级甲等 二级甲等"},
                        {title: "医生职称（4）", value: "住院医师 主治医师 副主任医师 主任医师"},
                    ]
                },
                {
                    id: "2",
                    checked: false,
                    name: "华北华南华西地区高级职称医生",
                    isCamp: false,
                    values: [
                        {title: "预计覆盖人数", value: "3129228"},
                        {title: "推广区域（3）", value: "华北 华西 华中"},
                        {title: "覆盖科室（2）", value: "内科 免疫课"},
                        {title: "医院等级（2）", value: "三级甲等 二级甲等"},
                        {title: "医生职称（4）", value: "住院医师 主治医师 副主任医师 主任医师"},
                    ]
                },
                {
                    id: "3",
                    checked: false,
                    name: "华南华西地区高级职称医生",
                    isCamp: false,
                    values: [
                        {title: "预计覆盖人数", value: "3129228"},
                        {title: "推广区域（3）", value: "华北 华西 华中"},
                        {title: "覆盖科室（2）", value: "内科 免疫课"},
                        {title: "医院等级（2）", value: "三级甲等 二级甲等"},
                        {title: "医生职称（4）", value: "住院医师 主治医师 副主任医师 主任医师"},
                    ]
                }
            ],
            km: [
                {
                    id: "ID:123123",
                    message: "疗效好！见效快",
                    link: 3
                },
                {
                    id: "ID:123124",
                    message: "疗效好！见效快",
                    link: 6
                },
                {
                    id: "ID:123125",
                    message: "疗效好！见效快",
                    link: 2
                }
            ],
        }
    }
    render() {
        let colorStyle={
            color:ColorEnum.colorType[2].color,
            backgroundColor:ColorEnum.colorType[2].bgColor,
        }
        return (
            <div className="marketCamp-detail">
                <div className="page-header-box" style={{paddingBottom:"30px"}}>
                    <Breadcrumb>
                        <Breadcrumb.Item>市场推广</Breadcrumb.Item>
                        <Breadcrumb.Item><a href="#">营销战役</a></Breadcrumb.Item>
                        <Breadcrumb.Item><a href="#">推广项目</a></Breadcrumb.Item>
                    </Breadcrumb>
                    <Row style={{padding: "12px 0px"}}>
                        <Col span={16}>
                            <div className='battle-icon' style={{backgroundColor:colorStyle.backgroundColor}}>
                                <Icon style={{color:colorStyle.color,fontSize:'18px'}} type='tuiguang'></Icon>
                            </div>
                            <span className="camp-title">买韦瑞德！2千万用户的共同选择</span>
                        </Col>
                        <Col span={8}>
                            <div className="baseBtn extension-detail-edit-btn" onClick={::this.onEditExtension}>编辑</div>
                        </Col>
                    </Row>
                    <div className="create-info">
                        <Row>
                            <Col span={5}>项目分类：学术速递</Col>
                            <Col span={15}>项目格式：图文</Col>
                            <Col span={4}><span className="status-title">推广状态</span></Col>
                        </Row>
                        <Row>
                            <Col span={5}>唯一编号：CN-Q8314FAFEA</Col>
                            <Col span={15}>内容期限：2018-01-10～2019-01-10</Col>
                            <Col span={4}><span className="status-value">未开始</span></Col>
                        </Row>
                    </div>
                </div>
                <div className="page-content-border">
                    <div>
                        <Card title={<div className="card-title"><Icon type="qun"/><span>目标人群</span></div>}>
                            <Row>
                                {
                                    this.state.peopleGroup.map((item,index)=>{
                                        return(
                                            <Col key={index} span={12}><TextCard data={item}/></Col>
                                        );
                                    })
                                }
                            </Row>
                        </Card>
                    </div>
                    <div className="content-card-margin">
                        <Card title={<div className="card-title"><Icon type="flag_fill"/><span>Keymessage</span></div>}>
                            <Row>
                                {
                                    this.state.km.map((item,index)=>{
                                        return(
                                            <Col key={index} span={8}><KMCard data={item}/></Col>
                                        );
                                    })
                                }
                            </Row>
                        </Card>
                    </div>
                    <div className="content-card-margin">
                        <Card title={<div className="card-title"><Icon type="tuiguang"/><span>推广物料</span></div>}>
                            <Row>
                                <Col span={24}><ImgTextCard/></Col>
                                <Col span={24}><ImgTextCard data={{
                                    type: "img",
                                    name: "推广渠道展位封面图",
                                    message: "",
                                    date: "2017-12-11"
                                }} imgs={[{name:"wx_img",url:"https://ss3.baidu.com/-rVXeDTa2gU2pMbgoY3K/it/u=3044192727,472157510&fm=202&src=764&mola=new&crop=v1"}]}/></Col>
                            </Row>
                        </Card>
                    </div>
                    <div className="content-card-margin">
                        <Card title={<div className="card-title"><Icon type="tuiguang"/><span>推广渠道</span></div>} extra={<Popover placement="right" content={
                            <div style={{width: "200px"}}>
                                <p className="title"><Icon className="themeColor" type="tishi"></Icon> 说明：</p>
                                <p className="title">推广计价说明</p>
                            </div>
                        }>
                            <Icon type="tishi" style={{margin: '0px 10px', color: "#2491FC"}}/>
                            <span>推广位计价说明</span>
                        </Popover>}>
                            <Row>
                                {
                                    this.state.channelData.map((item,index)=>{
                                        return(
                                            <Col key={index} span={6}><IconCard data={item}/></Col>
                                        );
                                    })
                                }
                            </Row>
                            <Row>
                                <div className="extension-detail-tags">
                                    <span>媒体展位：</span>
                                    <Tag>焦点图(Banner)</Tag>
                                    <Tag>信息流(Feeds)</Tag>
                                    <Tag>启动屏(Loading Page)</Tag>
                                </div>
                            </Row>
                        </Card>
                    </div>
                </div>
            </div>
        );
    }

    onEditExtension() {
        this.props.router.push("/marketCamp/extension/edit")
    }
}

export default connect(
    (state) => {
        return {
            // $$newsList: state.$$newsList
        }
    },
    (dispatch) => {
        return {
            // newsActs: bindActionCreators(Actions, dispatch)
        }
    })(withRouter(ExtensionDetail))