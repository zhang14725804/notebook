import React, {Component} from "react"
import {
    Card,
    Row,
    Col,
    Breadcrumb,
    Radio,
    Icon,
    Tag,
    Input,
    DatePicker,
    Checkbox,
    Modal,
    Popover,
    Tabs,
    Alert,
    Button,
    Table,
} from "antd"
import moment from "moment"
import {Link, withRouter} from "react-router"
import {connect} from "react-redux"
import TextCard from "components/card/TextCard"
import KMCard from "components/card/KMCard"
import ImgCard from "components/card/ImgCard"
import IconCard from "components/card/IconCard"
import AddCard from "components/card/AddCard"
import "assets/style/views/marketCampaign/extension/edit.less"
import {tools} from "utils"
import CusModal from "components/CusModal";
import ImgTextCard from "components/card/ImgTextCard";
import BatchUpload from "components/BatchUpload"
import SearchBar from "components/searchBar"
import {ColorEnum} from "src/constants/customEnum"
import { Enum, EnumCn } from "enum"

const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const TabPane = Tabs.TabPane;
const Search = Input.Search;
const {RangePicker} = DatePicker;
const dateFormat = 'YYYY-MM-DD';

class ExtensionEdit extends Component {
    constructor(props) {
        super(props);
        this.state = {
            visible: false,
            artVisible: false,
            imgs: [],
            channelData: [
                {
                    id: 1,
                    icon: 1,
                    name: "杏仁医生",
                    checked: false
                },
                {
                    id: 2,
                    icon: 1,
                    name: "杏仁医生",
                    checked: false
                },
                {
                    id: 3,
                    icon: 1,
                    name: "杏仁医生",
                    checked: false
                },
                {
                    id: 4,
                    icon: 1,
                    name: "杏仁医生",
                    checked: false
                },
            ],
            allPeoples: [
                {
                    id: "1",
                    checked: true,
                    name: "华北华中华西地区高级职称医生",
                    isCamp: true,
                    values: [
                        {title: "预计覆盖人数", value: "3129228"},
                        {title: "推广区域（3）", value: "华北 华西 华中"},
                        {title: "覆盖科室（2）", value: "内科 免疫课"},
                        {title: "医院等级（2）", value: "三级甲等 二级甲等"},
                        {title: "医生职称（4）", value: "住院医师 主治医师 副主任医师 主任医师"},
                    ]
                },
                {
                    id: "2",
                    checked: false,
                    name: "华北华南华西地区高级职称医生",
                    isCamp: false,
                    values: [
                        {title: "预计覆盖人数", value: "3129228"},
                        {title: "推广区域（3）", value: "华北 华西 华中"},
                        {title: "覆盖科室（2）", value: "内科 免疫课"},
                        {title: "医院等级（2）", value: "三级甲等 二级甲等"},
                        {title: "医生职称（4）", value: "住院医师 主治医师 副主任医师 主任医师"},
                    ]
                },
                {
                    id: "3",
                    checked: false,
                    name: "华南华西地区高级职称医生",
                    isCamp: false,
                    values: [
                        {title: "预计覆盖人数", value: "3129228"},
                        {title: "推广区域（3）", value: "华北 华西 华中"},
                        {title: "覆盖科室（2）", value: "内科 免疫课"},
                        {title: "医院等级（2）", value: "三级甲等 二级甲等"},
                        {title: "医生职称（4）", value: "住院医师 主治医师 副主任医师 主任医师"},
                    ]
                }
            ],
            selectedArticle: null
        }
    }

    componentDidMount(){

    }

    onInputBlur(e){
        let s=e.target.value;
        if(s!==""){
            if(/[^0-9\.]/.test(s)) return "invalid value";
            s=s.replace(/^(\d*)$/,"$1.");
            s=(s+"00").replace(/(\d*\.\d\d)\d*/,"$1");
            s=s.replace(".",",");
            var re=/(\d)(\d{3},)/;
            while(re.test(s))
                s=s.replace(re,"$1,$2");
            s=s.replace(/,(\d\d)$/,".$1");
            e.target.value=s;
            // return "￥" + s.replace(/^\./,"0.")
        }
    }
    onInputChange(e){
        debugger
        let s=e.target.value;
        s=s.replace(/[^\d.]/g,"");
        e.target.value=s;
        /*let regp=/[^\d.]/g;
        if(s.test(regp)){
            e.target.value="";
        }*/
    }

    render() {
        let people_data = [];
        this.state.allPeoples.forEach((item, index) => {
            let obj = {...item};
            people_data.push(obj)
        });
        let colorStyle={
            color:ColorEnum.colorType[2].color,
            backgroundColor:ColorEnum.colorType[2].bgColor,
        }
        return (
            <div className="marketCamp-detail">
                <div className="page-header-box" style={{paddingBottom:"30px"}}>
                    <Row style={{paddingTop:"30px"}}>
                        <Col span={16}>
                            <div className='battle-icon' style={{backgroundColor:colorStyle.backgroundColor}}>
                                <Icon style={{color:colorStyle.color,fontSize:'18px'}} type='tuiguang'></Icon>
                            </div>
                            <span className="camp-title">买韦瑞德！2千万用户的共同选择</span>
                        </Col>
                        <Col span={8}>
                            <div style={{float:"right",marginRight:"55px"}}>
                                <div className="baseBtn" onClick={()=>{this.props.router.go(-1)}}>取 消</div>
                                <div className="baseBtn btn-blueBg" onClick={()=>{this.props.router.replace("/marketCamp/extension/detail")}}>完 成</div>
                            </div>
                        </Col>
                    </Row>
                    <div className="create-info">
                        <Row>
                            <Col span={5}>创建人：小白菜</Col>
                            <Col span={10}>所属部门：市场部</Col>
                        </Row>
                        <Row>
                            <Col span={5}>产品名：韦瑞德</Col>
                            <Col span={10}>关联领域：HIV</Col>
                        </Row>
                    </div>
                </div>
                <div className="page-content-border">
                    <div>
                        <Card>
                            <Row className="edit-input-box">
                                <Col span={6}></Col>
                                <Col span={3} className="text-align-right-label"><span>推广主题：</span></Col>
                                <Col span={7}><Input placeholder="给推广起个名字"/></Col>
                                <Col span={8}></Col>
                            </Row>
                            <Row className="edit-input-box">
                                <Col span={6}></Col>
                                <Col span={3} className="text-align-right-label"><span>推广有效期：</span></Col>
                                <Col span={7}>
                                    <RangePicker
                                    defaultValue={[moment('2015-06-06', dateFormat), moment('2015-06-06', dateFormat)]}/>
                                </Col>
                                <Col span={8}></Col>
                            </Row>
                            <Row className="edit-input-box" style={{marginBottom:"35px"}}>
                                <Col span={6}></Col>
                                <Col span={3} className="text-align-right-label"><span>费用阈值：</span></Col>
                                <Col span={7}><Input prefix={"￥"} placeholder="" style={{width:"50%"}} onBlur={this.onInputBlur.bind(this)} onChange={::this.onInputChange}/></Col>
                            <Col span={8}></Col>
                            </Row>
                                {/*<Col span={10} className="text-align-right-label">
                                    <div className="edit-input-box">
                                        <span>推广主题：</span>
                                        <div className="edit-input">
                                            <Input placeholder="给推广起个名字"/>
                                        </div>
                                    </div>
                                    <div className="edit-input-box">
                                        <span >推广有效期：</span>
                                        <div className="edit-input">
                                            <RangePicker
                                                defaultValue={[moment('2015-06-06', dateFormat), moment('2015-06-06', dateFormat)]}
                                            />
                                        </div>
                                        <div className="edit-input extension-edit-datapicker">
                                            <DatePicker
                                                defaultValue={moment('2015-06-06', dateFormat)}
                                                format={dateFormat}
                                            />
                                            <Checkbox onChange={() => {
                                            }}>永久</Checkbox>
                                        </div>
                                    </div>
                                    <div className="edit-input-box">
                                        <span>费用阈值：</span>
                                        <div className="edit-input">
                                            <Input prefix={"￥"} placeholder="" type="number"/>
                                        </div>
                                    </div>
                                </Col>*/}

                        </Card>
                    </div>
                    <div className="content-card-margin">
                        <Card title={<div>设置目标人群</div>}>
                            <Row>
                                <Col span={12}><AddCard lg onClick={() => {
                                    this.setState({visible: true})
                                }}/></Col>
                                {
                                    this.state.allPeoples.map((item, index) => {
                                        if (item.checked) {
                                            return (
                                                <Col key={index} span={12}><TextCard data={item}/></Col>
                                            )
                                        }
                                    })
                                }
                            </Row>
                        </Card>
                    </div>
                    <div className="content-card-margin">
                        <Card title={<div>设置推广物料</div>} extra={<Popover placement="right" content={
                            <div style={{width: "200px"}}>
                                <p className="title"><Icon className="themeColor" type="tishi"></Icon> 说明：</p>
                                <p className="title">素材包下载</p>
                            </div>
                        }>
                            <Icon type="tishi" style={{margin: '0px 10px', color: "#2491FC"}}/>
                            <span>素材包下载</span>
                        </Popover>}>
                            <Row>
                                {
                                    this.state.selectedArticle ?
                                        <Col span={24}>
                                            <ImgTextCard link reUpload={() => {
                                                this.setState({artVisible: true})
                                            }} delete={() => {
                                                this.setState({selectedArticle: null})
                                            }} data={this.state.selectedArticle}/>
                                        </Col> :
                                        <Col span={24} className="extension-edit-materiel">
                                            <div style={{padding:"10px"}}>
                                                <Card onClick={() => {
                                                    this.setState({artVisible: true})
                                                }}>
                                                    <Icon type="ep--"/>
                                                    <span>关联文章</span>
                                                </Card>
                                            </div>
                                        </Col>
                                }
                                {
                                    this.state.imgs.length>0&&[1].map((item, index) => {
                                        let data = {
                                            type: "img",
                                            name: "推广渠道展位封面图",
                                            message: "",
                                            date: "2017-12-11"
                                        };
                                        return (
                                            <Col span={24} key={index}>
                                                <ImgTextCard link reUpload={() => {
                                                    this.refs.batchUploadCom.onClickUpload()
                                                }} delete={() => {
                                                    this.setState({imgs: []})
                                                }} data={data} imgs={this.state.imgs}/>
                                            </Col>
                                        )
                                    })
                                }
                                <Col span={24}>
                                    <BatchUpload ref="batchUploadCom"
                                                 style={{display: this.state.imgs && this.state.imgs.length > 0 ? 'none' : 'block'}}
                                                 extension=".jpg|.png"
                                                 onSuccess={(imgs) => {
                                                     console.log(imgs);
                                                     let allImgs = imgs;
                                                     this.setState({imgs: allImgs})
                                                 }}/>
                                </Col>
                            </Row>
                        </Card>
                    </div>
                    <div className="content-card-margin">
                        <Card title={<div>选择推广渠道</div>}>
                            <Alert style={{marginBottom: "1rem",marginTop:"10px",marginLeft:"10px",marginRight:"10px"}}
                                   message="
由于各媒体端受自有运营体制和第三方合并开放程度不统一，您设置的推广内容将展示在不同媒体端的不同展位，为最大提高曝光量，建议默认选择全部展位。系统会根据您配置的推广周期和内容自动匹配最合适的媒体及展位进行曝光"
                                   type="warning"
                                   showIcon/>
                            <Row>
                                {
                                    this.state.channelData.map((item, index) => {
                                        return (
                                            <Col key={index} span={6}><IconCard data={item}
                                                                                onClick={this.onCheckChannel.bind(this, item.id)}
                                                                                inEdit/></Col>
                                        );
                                    })
                                }
                            </Row>
                            <Row>
                                <div className="extension-detail-tags">
                                    <span>媒体展位：</span>
                                    <Checkbox onChange={() => {
                                    }}>焦点图(Banner)</Checkbox>
                                    <Checkbox onChange={() => {
                                    }}>信息流(Feeds)</Checkbox>
                                    <Checkbox onChange={() => {
                                    }}>启动屏(Loading Page)</Checkbox>
                                </div>
                            </Row>
                        </Card>
                    </div>
                </div>
                <CusModal data={people_data} visible={this.state.visible} cancel={() => {
                    this.setState({visible: false})
                }} confirm={::this.confirmAddPeople} isShowTabs/>

                <_ListModal
                    visible={this.state.artVisible}
                    onCancel={() => {
                        this.setState({artVisible: false})
                    }}
                    onOk={::this.onConfirmAddArt}
                />
            </div>
        );
    }

    confirmAddPeople(arr) {
        this.setState({allPeoples: arr, visible: false});
    }

    onCheckChannel(id) {
        let data = this.state.channelData;
        let modifyData = [];
        data.forEach((item, index) => {
            if (item.id === id) {
                item.checked = !item.checked;
                modifyData.push(item);
            } else {
                modifyData.push(item)
            }
        })
        this.setState({channelData: modifyData});
    }

    onConfirmAddArt(data) {
        this.setState({artVisible: false, selectedArticle: data});
    }
}

//从素材库选素材弹框
class _ListModal extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [
                {id: 1, name: "慢性乙型肝炎的抗病毒药物及靶点的研究进展", expiryTime: "2016-09-21", size: "18.80KB",type:1 },
                {id: 2, name: "慢性乙型肝炎的抗病毒药物及靶点的研究进展", expiryTime: "2016-09-21", size: "18.80KB",type:2 },
                {id: 3, name: "慢性乙型肝炎的抗病毒药物及靶点的研究进展", expiryTime: "2016-09-21", size: "18.80KB",type:3 },
                {id: 4, name: "慢性乙型肝炎的抗病毒药物及靶点的研究进展", expiryTime: "2016-09-21", size: "18.80KB",type:1 },
            ],
            selectKey: ''
        }
    }


    render() {

        //表格配置
        let cfg = {
            dataSource: this.state.data,
            rowKey: r => r.id,
            columns: [
                {
                    title: "名称",
                    width: "60%",
                    dataIndex: "name",
                    key: "name",
                    render: (text,r) =>{
                        let DcColorIconItem = ColorEnum.DcColorIcon[Enum.ResourceType[r.type]];
                        let iconStyle = {
                            width: '30px',
                            height: '30px',
                            lineHeight: '30px',
                            fontSize: '24px',
                            color: DcColorIconItem.color,
                            backgroundColor: DcColorIconItem.bgColor,
                            marginRight: '10px'
                        }
                        return (
                            <div>
                                <Icon className='back-icon' type={DcColorIconItem.icon} style={iconStyle}></Icon>
                                <span>{text}</span>
                            </div>
                        );
                    }
                },
                {
                    title: "过期时间",
                    width: "20%",
                    dataIndex: "expiryTime",
                    key: "expiryTime",
                    sorter: true,
                    render: text => {
                        return (
                            <div>{text}</div>
                        );
                    }
                },
                {
                    title: "大小",
                    width: "20%",
                    dataIndex: "size",
                    key: "size",
                    sorter: true,
                    render: text => {
                        return (
                            <div>{text}</div>
                        );
                    }
                }
            ],
            // bordered: true,
            onChange: (page, filter, sort) => {
            },
            pagination: $.extend(true, {}, tools.config.pagination, {
                showSizeChanger: false,
                current: 1,
                pageSize: 5,
                total: 20
            }),
            rowSelection: {
                type: "radio",
                selectedRowKeys: [this.state.selectKey],
                onChange: (selectedKey, selectedRows) => {
                    this.setState({
                        selectKey: selectedKey[0]
                    })
                }
            }
        };
        return (
            <div>
                <Modal className="cusModal"
                    title="关联文章"
                    visible={this.props.visible}
                    onCancel={this.onCancel.bind(this)}
                    onOk={this.onOk.bind(this)}
                    cancelText="取消"
                    okText="确定"
                    width="800px">
                    <Tabs defaultActiveKey="1" onChange={() => {
                    }}>
                        <TabPane tab="全部文章" key="1">
                            <div className="extension-edit-article-modal-search">
                                <Search
                                    placeholder=""
                                    onSearch={::this.onSearch}
                                    style={{width: 200}}/>
                            </div>
                            <Row>
                                <Table className="modal-table"
                                    {...cfg} />
                            </Row>
                        </TabPane>
                        <TabPane tab="" key="2"></TabPane>
                    </Tabs>
                </Modal>
            </div>
        )
    }

    //点击【搜索】按钮
    onSearch(keyword) {
        console.log(keyword)
    }

    onCancel() {
        this.props.onCancel();
    }

    onOk() {
        debugger;
        let data = {
            type: "doc",
            name: "慢性乙型肝炎的抗病毒药物及靶点的研究进展",
            message: "KM: 学术会议是重要的信息来源",
            date: "2017-12-11"
        }
        this.props.onOk(data);
    }
};

export default connect(
    (state) => {
        return {
            // $$newsList: state.$$newsList
        }
    },
    (dispatch) => {
        return {
            // newsActs: bindActionCreators(Actions, dispatch)
        }
    })(withRouter(ExtensionEdit))
