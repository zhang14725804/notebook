import React, {Component} from "react"
import {
    Card,
    Row,
    Col,
    Breadcrumb,
    Radio,
    Icon,
    Tabs,
    Input,
    Menu,
    Dropdown,
    Button,
    Table,
    DatePicker,
    Modal,
    Tree
} from "antd"
import moment from "moment"
import {Link, withRouter} from "react-router"
import {connect} from "react-redux"
import TextCard from "components/card/TextCard"
import KMCard from "components/card/KMCard"
import "assets/style/views/marketCampaign/edit.less"
import {tools} from "utils"
import AddCard from "components/card/AddCard"
import CusModal from "components/CusModal"
import {ColorEnum} from "src/constants/customEnum"

const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const TabPane = Tabs.TabPane;
const Search = Input.Search;
const MenuItem = Menu.Item;
const TextArea = Input.TextArea;
const TreeNode = Tree.TreeNode;
const {RangePicker} = DatePicker;
const dateFormat = 'YYYY-MM-DD';

class MarketCampEdit extends Component {
    constructor(props) {
        super(props);
        this.state = {
            visible1: false,
            visible2: false,
            allPeoples: [
                {
                    id: "1",
                    checked: true,
                    name: "华北华中华西地区高级职称医生",
                    values: [
                        {title: "预计覆盖人数", value: "3129228"},
                        {title: "推广区域（3）", value: "华北 华西 华中"},
                        {title: "覆盖科室（2）", value: "内科 免疫课"},
                        {title: "医院等级（2）", value: "三级甲等 二级甲等"},
                        {title: "医生职称（4）", value: "住院医师 主治医师 副主任医师 主任医师"},
                    ]
                },
                {
                    id: "2",
                    checked: false,
                    name: "华北华南华西地区高级职称医生",
                    values: [
                        {title: "预计覆盖人数", value: "3129228"},
                        {title: "推广区域（3）", value: "华北 华西 华中"},
                        {title: "覆盖科室（2）", value: "内科 免疫课"},
                        {title: "医院等级（2）", value: "三级甲等 二级甲等"},
                        {title: "医生职称（4）", value: "住院医师 主治医师 副主任医师 主任医师"},
                    ]
                },
                {
                    id: "3",
                    checked: false,
                    name: "华南华西地区高级职称医生",
                    values: [
                        {title: "预计覆盖人数", value: "3129228"},
                        {title: "推广区域（3）", value: "华北 华西 华中"},
                        {title: "覆盖科室（2）", value: "内科 免疫课"},
                        {title: "医院等级（2）", value: "三级甲等 二级甲等"},
                        {title: "医生职称（4）", value: "住院医师 主治医师 副主任医师 主任医师"},
                    ]
                }
            ],
            checkedKm: []
        }
    }

    render() {
        let people_data = [];
        this.state.allPeoples.forEach((item, index) => {
            let obj = {...item};
            people_data.push(obj)
        });
        let colorStyle={
            color:ColorEnum.colorType[2].color,
            backgroundColor:ColorEnum.colorType[2].bgColor,
        }
        return (
            <div className="marketCamp-detail">
                <div className="page-header-box" style={{paddingBottom:"30px"}}>
                    <Row style={{paddingTop:"30px"}}>
                        <Col span={16}>
                            <div className='battle-icon' style={{backgroundColor:colorStyle.backgroundColor}}>
                                <Icon style={{color:colorStyle.color,fontSize:'18px'}} type='tuiguang'></Icon>
                            </div>
                            <span className="camp-title">买韦瑞德！2千万用户的共同选择</span>
                        </Col>
                        <Col span={8}>
                            <div style={{float:"right",marginRight:"55px"}}>
                                <div className="baseBtn" onClick={::this.goBack}>取 消</div>
                                <div className="baseBtn btn-blueBg" onClick={()=>{this.props.router.replace("/marketCamp/detail")}}>完 成</div>
                            </div>
                        </Col>
                    </Row>
                    <div className="create-info" style={{marginTop:"15px"}}>
                        <Row>
                            <Col span={5}>创建人：小白菜</Col>
                            <Col span={10}>所属部门：市场部</Col>
                        </Row>
                        <Row>
                            <Col span={5}>产品名：韦瑞德</Col>
                            <Col span={10}>关联领域：HIV</Col>
                        </Row>
                    </div>
                </div>
                <div className="page-content-border">
                    <div>
                        <Card>
                            <Row>
                                <Col span={7}></Col>
                                <Col span={10} style={{paddingBottom:"42px",paddingTop:"7px"}}>
                                    <div className="edit-input-box"><span>战役主题：</span>
                                        <div className="edit-input"><Input placeholder="给战役起个主题"/></div>
                                    </div>
                                    <div className="edit-input-box"><span>目的描述：</span>
                                        <div className="edit-input"><TextArea rows={4}/></div>
                                    </div>
                                    <div className="edit-input-box"><span>生效日期：</span>
                                        <div className="edit-input">
                                            <RangePicker
                                                defaultValue={[moment('2015-06-06', dateFormat), moment('2015-06-06', dateFormat)]}
                                            />
                                        </div>
                                    </div>
                                </Col>
                                <Col span={7}></Col>
                            </Row>
                        </Card>
                    </div>
                    <div className="content-card-margin">
                        <Card title={<div>设置目标人群</div>}>
                            <Row>
                                <Col span={12}><AddCard onClick={() => {
                                    this.setState({visible1: true})
                                }} lg/></Col>
                                {
                                    this.state.allPeoples.map((item, index) => {
                                        if (item.checked) {
                                            return (
                                                <Col key={index} span={12}><TextCard data={item}/></Col>
                                            );
                                        }
                                    })
                                }
                            </Row>
                        </Card>
                    </div>
                    <div className="content-card-margin">
                        <Card title={<div>设置Keymessage</div>}>
                            <Row>
                                <Col span={8}><AddCard onClick={() => {
                                    this.setState({visible2: true})
                                }}/></Col>
                                {
                                    this.state.checkedKm.map((item, index) => {
                                        return (
                                            <Col key={index} span={8}><KMCard/></Col>
                                        );
                                    })
                                }
                            </Row>
                            <p className="info-card-explain">*说明： 如上显示的 "KM 被传播的次数" , 仅是本次营销战役的推广结果</p>
                        </Card>
                    </div>
                </div>
                <CusModal data={people_data} visible={this.state.visible1}
                          cancel={() => {
                              this.setState({visible1: false})
                          }} confirm={::this.confirmAddPeople}/>

                <Modal className="cusModal"
                    title="添加Keymessage"
                    visible={this.state.visible2}
                    onOk={::this.confirmAddKm}
                    okText="确定"
                    cancelText="取消"
                    width={800}
                    onCancel={() => {
                        this.setState({visible2: false})
                    }}>
                    <CusTree ref="cusTree"/>
                </Modal>
            </div>
        );
    }

    goBack() {
        this.props.router.go(-1);
    }

    confirmAddPeople(arr) {
        this.setState({allPeoples: arr, visible1: false});
    }

    confirmAddKm() {
        let checkedKm = this.refs.cusTree.state.checkedKeys.checked;
        this.setState({visible2: false, checkedKm: checkedKm})
    }
}

//不带搜索的tree
/*class CusTree extends Component {
    constructor(props) {
        super(props);
        this.state = {
            expandedKeys: ['0-0-0', '0-0-1'],
            autoExpandParent: true,
            checkedKeys: ['0-0-0'],
            selectedKeys: [],
        }
    }

    onCheck(checkedKeys) {
        console.log('onCheck', checkedKeys);
        this.setState({checkedKeys});
    }

    onSelect(selectedKeys, info) {
        console.log('onSelect', info);
        this.setState({selectedKeys});
    }

    renderTreeNodes(data) {

        return data.map((item) => {
            if (item.children) {
                return (
                    <TreeNode title={item.title} key={item.key} dataRef={item}>
                        {this.renderTreeNodes(item.children)}
                    </TreeNode>
                );
            }
            return <TreeNode {...item} />;
        });
    };

    render() {
        const treeData = [{
            title: '0-0',
            key: '0-0',
            children: [{
                title: '0-0-0',
                key: '0-0-0',
                children: [
                    {title: '0-0-0-0', key: '0-0-0-0'},
                    {title: '0-0-0-1', key: '0-0-0-1'},
                    {title: '0-0-0-2', key: '0-0-0-2'},
                ],
            }, {
                title: '0-0-1',
                key: '0-0-1',
                children: [
                    {title: '0-0-1-0', key: '0-0-1-0'},
                    {title: '0-0-1-1', key: '0-0-1-1'},
                    {title: '0-0-1-2', key: '0-0-1-2'},
                ],
            }, {
                title: '0-0-2',
                key: '0-0-2',
            }],
        }, {
            title: '0-1',
            key: '0-1',
            children: [
                {title: '0-1-0-0', key: '0-1-0-0'},
                {title: '0-1-0-1', key: '0-1-0-1'},
                {title: '0-1-0-2', key: '0-1-0-2'},
            ],
        }, {
            title: '0-2',
            key: '0-2',
        }];
        return (
            <Tabs defaultActiveKey="1" onChange={() => {
            }}>
                <TabPane tab="战役目标" key="1">
                    <Search style={{ marginBottom: 8 }} placeholder="Search" onChange={()=>{}} />
                    <Tree
                        checkable
                        expandedKeys={this.state.expandedKeys}
                        autoExpandParent={this.state.autoExpandParent}
                        onCheck={::this.onCheck}
                        checkedKeys={this.state.checkedKeys}
                        onSelect={::this.onSelect}
                        checkStrictly={true}
                        selectedKeys={this.state.selectedKeys}>
                        {this.renderTreeNodes(treeData)}
                    </Tree>
                </TabPane>
            </Tabs>
        );
    }
}*/

class CusTree extends Component {
    state = {
        expandedKeys: [],
        searchValue: '',
        autoExpandParent: true,
        checkedKeys: [],
    }
    onExpand = (expandedKeys) => {
        this.setState({
            expandedKeys,
            autoExpandParent: false,
        });
    }
    onChange = (e) => {
        const value = e.target.value;
        const expandedKeys = dataList.map((item) => {
            if (item.title.indexOf(value) > -1) {
                return getParentKey(item.key, gData);
            }
            return null;
        }).filter((item, i, self) => item && self.indexOf(item) === i);
        this.setState({
            expandedKeys,
            searchValue: value,
            autoExpandParent: true,
        });
    };
    onCheck = (checkedKeys) => {
        console.log('onCheck', checkedKeys);
        this.setState({checkedKeys});
    }

    render() {
        const {searchValue, expandedKeys, autoExpandParent} = this.state;
        const loop = data => data.map((item) => {
            const index = item.title.indexOf(searchValue);
            const beforeStr = item.title.substr(0, index);
            const afterStr = item.title.substr(index + searchValue.length);
            const title = index > -1 ?
                (
                    <span>
                        {beforeStr}
                        <span style={{color: '#f50'}}>{searchValue}</span>
                        {afterStr}
                     </span>
                )
                : <span>{item.title}</span>;
            if (item.children) {
                return (
                    <TreeNode key={item.key} title={title}>
                        {loop(item.children)}
                    </TreeNode>
                );
            }
            return <TreeNode key={item.key} title={title}/>;
        });
        return (
            <div>
                <Tabs defaultActiveKey="1" onChange={() => {
                }}>
                    <TabPane tab="全部KM" key="1">
                        <div className="km-modal-search">
                            <Search placeholder="" onChange={this.onChange}/>
                        </div>
                        <Tree
                            checkable
                            checkStrictly={true}
                            onExpand={this.onExpand}
                            onCheck={this.onCheck}
                            expandedKeys={expandedKeys}
                            autoExpandParent={autoExpandParent}>
                            {loop(gData)}
                        </Tree>
                    </TabPane>
                    <TabPane tab="" key="2"></TabPane>
                </Tabs>
            </div>
        );
    }
}

const gData = [
    {
        title: 'A级菜单1',
        key: '0',
        children: [
            {title: 'B级菜单1', key: '2'},
            {title: 'B级菜单2', key: '3'},
            {title: 'B级菜单3', key: '4'},
        ],
    },
    {
        title: 'A级菜单2',
        key: '5',
    }
];

const dataList = [];
const generateList = (data) => {
    for (let i = 0; i < data.length; i++) {
        const node = data[i];
        const key = node.key;
        const title = node.title;
        dataList.push({key, title: title});
        if (node.children) {
            generateList(node.children, node.key);
        }
    }
};
generateList(gData);

const getParentKey = (key, tree) => {
    let parentKey;
    for (let i = 0; i < tree.length; i++) {
        const node = tree[i];
        if (node.children) {
            if (node.children.some(item => item.key === key)) {
                parentKey = node.key;
            } else if (getParentKey(key, node.children)) {
                parentKey = getParentKey(key, node.children);
            }
        }
    }
    return parentKey;
};

export default connect(
    (state) => {
        return {
            // $$newsList: state.$$newsList
        }
    },
    (dispatch) => {
        return {
            // newsActs: bindActionCreators(Actions, dispatch)
        }
    })(withRouter(MarketCampEdit))