import React from "react"
import ReactDOM from "react-dom"
import $ from "jquery"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import { Link, withRouter } from "react-router"

import * as Actions from "actions/layout"

import { tools } from "utils"
import Button from "antd/lib/button"
import Menu from "antd/lib/menu"
import Icon from "antd/lib/icon"
import Dropdown from "antd/lib/dropdown"
import Tooltip from "antd/lib/tooltip"
import navEnum from '../constants/navEnum'

import "src/assets/style/views/index.less"
import layoutData from "../mockdata/layoutData"
import { ColorEnum } from 'src/constants/customEnum'

const menuIcon = {
    "1": "manage",
    "2": "dynamic",
    "3": "supply",
}
// const menuIcon = {
//     "0": "heilongjiangtubiao01",
//     "1": "shouye",
//     "2": "wifi",
//     "3": "sucaikulishangchuan",
//     "4": "wenjianjia",
//     "5": "shezhi",
//     "6": "/admin/list"
// }
const Img = {
    avatar: require("../assets/image/15.png")
}

class Layout extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedKey: '1',
        }
    }

    componentWillMount() {
        let newNavNum = navEnum(this.props.location.pathname);
        this.setState({
            selectedKey: newNavNum,
        })
    }

    componentDidMount() {
        let { actions } = this.props;
        let { navNum } = this.state;
        actions.setIsLogin(true);
        // actions.getMenu();
    }

    render() {
        let { $$layout } = this.props;
        let { subMenu, navNum, selectedKey } = this.state;
        let layout = $$layout.toJS();

        // let menus = layout.menus || [];
        // let menus = layoutData.menulist || [];  // 假数据
        let menuData = [{
            id: '1',
            name: '业务推广',
            url: 'broadcast',
            separateSubchild: [{
                id: '1-1',
                name: '市场推广',
                url: 'marketBusi'
            }, {
                id: '1-2',
                name: '人群管理',
                url: 'peopleManagement/list'
            }, {
                id: '1-3',
                name: '资源中心',
                url: 'documentCenter/list'
            }, {
                id: '1-4',
                name: 'KM及标签管理',
                url:'KMManagement/detail'
            }]
        }, {
            id: '2',
            name: '数据洞察',
            url: 'dataInsight',
            separateSubchild: [{
                id: '2-1',
                name: '状态数据',
                url: '/statusData/commuEffect'
            }, {
                id: '2-2',
                name: '趋势变化',
                url: '/trendChange/commuEffect'
            }]
        }, {
            id: '3',
            name: '系统控制',
            url: 'broadcast',
        }]
        let menus = menuData || [];  // 假数据
        let isLogin = layout.isLogin;
        let { pathname } = this.props.location;
        const toolbarItemJSX = (
            <Menu>
                <Menu.Item>
                    <a onClick={this.logout.bind(this)}>退出</a>
                </Menu.Item>
            </Menu>
        )
        let moneyJSX = (
            <Menu className="costItem">
                <Menu.Item key="surplus">
                    <div className="title">账户余额</div>
                    <div className="cont"><span className="num">1200</span>元</div>
                </Menu.Item>
                <Menu.Item>
                    <div className="costItemLine"></div>
                </Menu.Item>
                <Menu.Item key="cost">
                    <div className="title">今日消耗</div>
                    <div className="cont"><span className="num">7.9</span>元</div>
                    <div className="cont">日限额9000元/天</div>
                </Menu.Item>
            </Menu>
        )
        let tagIconStyle = {
            fontSize: '17px',
            color: '#a0d911'
        }
        let subMenuJSX = menuData[0].separateSubchild.map((item, index) => {
            console.log('-- window.location.pathname.match(item.url) --',window.location.pathname, window.location.href, item.url)
            if(item.url && window.location.href.match(item.url)){
                return (
                    <div key={index} className='ant-tabs-tab-active ant-tabs-tab' onClick={this.onClickSubMenu.bind(this, item)}>{item.name}</div>
                )
            }else{
                return (
                    <div key={index} className='ant-tabs-tab' onClick={this.onClickSubMenu.bind(this, item)}>{item.name}</div>
                )
            }
        });
        let subMenuJSX2=menuData[1].separateSubchild.map((item, index) => {
            console.log('-- window.location.pathname.match(item.url) --',window.location.pathname, window.location.href, item.url)
            if(item.url && window.location.href.match(item.url)){
                return (
                    <div key={index} className='ant-tabs-tab-active ant-tabs-tab' onClick={this.onClickSubMenu.bind(this, item)}>{item.name}</div>
                )
            }else{
                return (
                    <div key={index} className='ant-tabs-tab' onClick={this.onClickSubMenu.bind(this, item)}>{item.name}</div>
                )
            }
        });
        //ant-tabs-tab-active
        return (
            <div>
                <div id="sy-ctnwrap">
                    <div id="sy-menuwrap">
                        <div className="sy-logo">
                            <h2>SYNAPSE</h2>
                        </div>
                        <div id="sy-menu">
                            {
                                pathname.match('broadcast|dataInsight') ?
                                    <_Menu
                                        {...this.props}
                                        dataSource={menus}
                                        dataValueField="_id"
                                        dataTextField="name"
                                        onClick={this.onClickMenu.bind(this)}
                                        selectedKeys={[`${selectedKey}`]}></_Menu>
                                    :
                                    <div>
                                        <div className='sy-menu-tag'>
                                            <div><span><Icon style={tagIconStyle} type="shouye"></Icon></span></div>
                                            <div>
                                                <p className='tag-title'>韦瑞德</p>
                                                <p>HIV</p>
                                            </div>
                                            <div className='enter-icon'>
                                                <Icon type="right"></Icon>
                                            </div>
                                        </div>
                                        <div className="sy-menu-back" onClick={() => this.props.router.go(-1)}>返回</div>
                                    </div>

                            }

                        </div>
                    </div>
                    <div style={{ height: "inherit" }}>
                        <div id="sy-header">
                            <div className="sy-header-app">
                                <Icon type="manage" />
                                <span>业务推广</span>
                            </div>
                            <Dropdown overlay={moneyJSX}>
                                <Icon type="remind" className="money" />
                            </Dropdown>
                            <img src={Img.avatar} className="sy-header-avatar" />
                            <span className="sy-header-name">{layout.login_user.nickname}</span>
                            <Dropdown overlay={toolbarItemJSX}>
                                <Icon type="ellipsis" className="sy-header-toolbar" />
                            </Dropdown>
                        </div>
                        {pathname.match('documentCenter\/list|marketBusi|peopleManagement\/list|KMManagement\/detail') ?
                            <div id="sy-submenu">
                                <div className="ant-tabs ant-tabs-top marketindex-tabs ant-tabs-large ant-tabs-line ant-tabs-no-animation">
                                    <div role="tablist" className="ant-tabs-bar">
                                        <div className="ant-tabs-nav-container">
                                            <div className="ant-tabs-nav-wrap">
                                                <div className="ant-tabs-nav-scroll">
                                                    <div className="ant-tabs-nav ant-tabs-nav-animated">
                                                        {subMenuJSX}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div> : <div></div>}
                        {pathname.match('statusData\/commuEffect|trendChange\/commuEffect') ?
                            <div id="sy-submenu">
                                <div className="ant-tabs ant-tabs-top marketindex-tabs ant-tabs-large ant-tabs-line ant-tabs-no-animation">
                                    <div role="tablist" className="ant-tabs-bar">
                                        <div className="ant-tabs-nav-container">
                                            <div className="ant-tabs-nav-wrap">
                                                <div className="ant-tabs-nav-scroll">
                                                    <div className="ant-tabs-nav ant-tabs-nav-animated">
                                                        {subMenuJSX2}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div> : <div></div>}
                        <div id="content" style={{ height: "inherit" }}>
                            <div id="sy-ctn" style={{ height: "inherit" }}>
                                {!isLogin || menus.length === 0 ? [] : this.props.children}
                            </div>
                        </div>
                    </div>
                </div>
                <span id="sy-window"></span>
            </div>
        )
    }

    onClickSubMenu(item) {
        this.props.router.replace({
            pathname: item.url,
        });
    }
    onClickMenu(key) {
        this.setState({
            selectedKey: key
        })
    }

    logout() {
        let { actions } = this.props;
        actions.logout();
        // //清除cookie
        // tools.setCookie("IDBLF", "", -1);
        // tools.setCookie("IDBLT", "", -1);
        //window.location.href = tools.javaApi("/account/logout");
    }
}

class _Menu extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            openKeys: [],
            collapsed: false,
        }
        this.isClick = false;
        this.rootSubmenuKeys = ['1', '2', '3', '4', '5', '6'];
    }

    componentWillReceiveProps(nextProps) {
        if (!this.isClick) {
            let newNavNum = navEnum(nextProps.location.pathname);
            let num = newNavNum.match(/(\d)/)[1];
            // 如果在首页，刷新后默认打开推广
            // if(num === '1'){
            //     this.setState({
            //         openKeys: [ '2', num]
            //     })
            // }else{
            //     this.setState({
            //         openKeys: [num]
            //     })
            // }
        }
    }

    render() {
        let { dataSource, dataTextField, dataValueField, selectedKeys } = this.props;
        let menuJsx = dataSource.map((menu, idx) => {
            if (menu.subchild && menu.subchild.length > 0) {
                var items = menu.subchild.map((item, i) => {
                    return (
                        <Menu.Item key={item[dataValueField] || `${idx + 1}${i + 1}`}>
                            <Link to={item.url}>
                                <Icon type={menuIcon[`${idx + 1}`]} />
                                {item[dataTextField]}
                            </Link>
                        </Menu.Item>
                    );
                });
            }
            return (
                menu.subchild && menu.subchild.length > 0 ?
                    <Menu.SubMenu
                        className="menu-title"
                        key={menu[dataValueField] || `${idx + 1}`}
                        title={<span><Icon
                            type={menuIcon[`${idx + 1}`][0]} /> <span>{menu[dataTextField]}</span></span>}
                        children={items}>
                    </Menu.SubMenu> :
                    <Menu.Item
                        className="menu-title"
                        key={menu[dataValueField] || `${idx + 1}`}
                    >
                        <Link to={menu.url}>
                            <span><Icon className="menu-icon" type={menuIcon[`${idx + 1}`]} /> <span>{menu[dataTextField]}</span><Icon style={{ display: selectedKeys.indexOf(menu.id) > -1 ? 'inline-block' : 'none' }} type="right" className="menu-right" /></span>
                        </Link>
                    </Menu.Item>
            )
        });
        return (
            <div>
                <Menu
                    mode="inline"
                    them="light"
                    selectedKeys={this.props.selectedKeys}
                    openKeys={this.state.openKeys}
                    onClick={this.onClick.bind(this)}
                    onOpenChange={this.onSwitch.bind(this)}>
                    {menuJsx}</Menu>
            </div>
        );
    }

    onClick(item) {
        // let key = item.id;
        // let it = null;
        // this.props.dataSource.map((data, idx) => {
        //     if(data.subchild){
        //         data.subchild.map((d, i) => {
        //             if ((idx + 1).toString() + (i + 1).toString() === key) it = d;
        //         })
        //     }else{
        //         if(data.id == item.id) it = key;
        //     }
        // })
        // console.log('-- it --', it)
        this.props.onClick.call(this, item.key);
        this.isClick = true;
    }

    onSwitch(openKeys) {
        const latestOpenKey = openKeys.find(key => this.state.openKeys.indexOf(key) === -1);
        if (this.rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
            this.setState({ openKeys });
        } else {
            this.setState({
                openKeys: latestOpenKey ? [latestOpenKey] : [],
            });
        }
    }
}


export default connect(
    (state) => {
        return {
            $$layout: state.$$layout,
        }
    },
    (dispatch) => {
        return {
            actions: bindActionCreators(Actions, dispatch)
        }
    }
)(withRouter(Layout))
