import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/documentCenter"
import { Enum, EnumCn } from "enum"
import { ColorEnum } from 'src/constants/customEnum'
import { tools } from "utils"
import Modal from "antd/lib/modal"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Form from "antd/lib/form"
import Button from "antd/lib/button"
import Radio from "antd/lib/radio"
import Steps from "antd/lib/steps"
import Upload from "antd/lib/upload"
import Checkbox from "antd/lib/checkbox"
import Icon from "antd/lib/icon"
import Tag from "antd/lib/tag"
import H5Demo from "components/demo/h5Demo"
import QaCard from "components/card/qaCard"
import dcQaData from "mockdata/dcQaData"
import dcImageTxtData from "mockdata/dcImageTxtData"

import "assets/style/views/documentCenter/detail.less"

const Step = Steps.Step;
const RadioGroup = Radio.Group;
const Dragger = Upload.Dragger;
const FormItem = Form.Item;
const CheckboxGroup = Checkbox.Group;
const confirm = Modal.confirm;

class DocumentCenterDetail extends React.Component {
    constructor(props) {
        super(props);
    }
    componentDidMount() {
        let { documentCenterEditActs } = this.props;
    }
    render() {
        // TODO 判断当前文档类型，demo 用，之后改成从接口返回数据中取
        let query = tools.getQuery();
        let documentType = query.documentType;
        let tagJSX = ['学术会', '信息来源'].map((item, index) => {
            return <Tag key={index}>{item}</Tag>
        })
        let resDetailJSX = '';
        switch (Number(documentType)) {
            case Enum.ResourceType.h5:
            case Enum.ResourceType.vol:
            case Enum.ResourceType.vod:
                resDetailJSX = <H5Demo style={{ margin: "0 auto" }} value="http://www.baidu.com" />;
                break;
            case Enum.ResourceType.imagetxt:
            case Enum.ResourceType.wximagetxt:
                resDetailJSX =
                    (<div style={{ textAlign: 'center' }}>
                        <div style={{ fontSize: '2rem', margin: '0 auto', color: '#000' }}>闽宁镇的故事</div>
                        <div style={{ width: '60%', margin: '0 auto' }} dangerouslySetInnerHTML={{ __html: dcImageTxtData.data }}></div>
                    </div>);
                break;
            case Enum.ResourceType.qa:
                resDetailJSX = dcQaData.data.map((item, index) => {
                    return <QaCard key={index} {...item} />
                })
                break;
            default:
                break;
        }
        return (
            <section className="dc-detail">
                <Row className="detail-title">
                    <Col span={4} xxl={3} style={{ paddingLeft: '20px', paddingTop: '5px' }}><img style={{ width: "144px", height: "80px" }} src={require("assets/image/imagetxtdemo.png")} /></Col>
                    <Col span={17} xxl={18}>
                        <Row>
                            <span className="doc-name">慢性乙型肝炎的抗病毒药物及靶点的研究进展</span>
                        </Row>
                        <div className="detail-info">
                            <Row>
                                <Col span={5}>内容形式：{EnumCn.ResourceType[documentType]}</Col>
                                <Col span={5}>唯一编号：CN-Q8314FAFEA</Col>
                            </Row>
                            <Row>
                                <Col span={5}>内容期限：2019-01-10</Col>
                                <Col span={5} style={{ display: documentType == Enum.ResourceType.normal ? 'block' : 'none' }}>资源详情：<a href="#">预览</a></Col>
                            </Row>
                        </div>
                    </Col>
                    <Col span={3}>
                        <Button onClick={this.onClickEdit.bind(this)}>编辑</Button>
                        <div className="resource-status">资源状态</div>
                        <div className="status">启用</div>
                    </Col>
                </Row>
                <div className="detail-content page-content-border" style={{ minHeight: 'calc(100% - 161px)' }}>
                    <div className="resource-detail" style={{ display: documentType == Enum.ResourceType.normal ? 'none' : 'block' }}>
                        <div className="content-title">
                            <Icon type="createtask_fill" /><span>资源详情</span>
                        </div>
                        <div className="content-fill">
                            {resDetailJSX}
                        </div>
                    </div>
                    <div className="line" style={{ display: documentType == Enum.ResourceType.normal ? 'none' : 'block' }}></div>
                    <div className="resource-attribute">
                        <div className="content-title">
                            <Icon type="order_fill" /><span>资源属性</span>
                        </div>
                        <div className="content-fill">
                            <Row>
                                <Col span={8}>
                                    <div className="m-margin-b">发布渠道：线上官方网站</div>
                                    <div className="m-margin-b">学术深度：普通</div>
                                    <div>水印：Synapse</div>
                                </Col>
                                <Col span={8}>
                                    <div className="m-margin-b">分享权限：内部分享</div>
                                    <div className="m-margin-b">内容作者：医生及KOL</div>
                                    <div>内容分类：病例论文</div>
                                </Col>
                                <Col span={8}>
                                    <div className="m-margin-b">产品相关度：紧密</div>
                                    <div>内容来源：原文</div>
                                </Col>
                            </Row>
                        </div>
                    </div>
                    <div className="line"></div>
                    <div className="resource-km">
                        <div className="content-title">
                            <Icon type="flag_fill" /><span>资源信息点</span>
                        </div>
                        <div className="content-fill">
                            <div className="m-margin-b">信息点：学术会议是重要的信息来源</div>
                            <div>标签：{tagJSX}</div>
                        </div>
                    </div>
                </div>
            </section>
        );
    }
    onClickEdit() {

    }
}

export default connect(
    (state) => {
        return {
        }
    },
    (dispatch) => {
        return {
        }
    })(withRouter(DocumentCenterDetail))
