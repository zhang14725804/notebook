import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/documentCenter"
import { Enum, EnumCn } from "enum"
import { tools } from "utils"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import Table from "antd/lib/table"
import Tag from "antd/lib/tag"
import Checkbox from "antd/lib/checkbox"
import Select from "antd/lib/select"
import DatePicker from "antd/lib/date-picker"
import UEditor from "components/ueditorForWx"
import DialogDemo from 'components/demo/dialogDemo'
import moment from "moment"
import Upload from "components/upload1"
import message from "antd/lib/message"
import TreeSelect from 'antd/lib/tree-select';

import "assets/style/views/documentCenter/edit.less"

const FormItem = Form.Item;
const Option = Select.Option;
const TreeNode = TreeSelect.TreeNode;
const TextArea = Input.TextArea;

//step1: 选择文档类型
class _SecondWX extends React.Component {
    constructor(props) {
        super(props);
        this.defValue = {
            editorAvatorImg: {
                first: require("assets/image/editor-default-avator-436-234.png"),
                other: require("assets/image/editor-default-avator-120-120.png"),
                addIcon: require("assets/image/editor-icon-adds.png"),
                xiumi: require("assets/image/xiumi.png")
            },
            isNoContentChange: false,
            isNoClickWxItem: false,
        }
        this.state = {
            fileName: '',
            isEdit: !!props.location.query.id,
            query: props.location.query,
            type: props.location.query.type,
            content: "",
            title: "",
            editor_id: `editor_${Math.random()}`,
            id: props.location.query.id,
            previewData: {},
            checked: false,
            expired: false,
            wxItemObj: {                           // 所有微信项的id标题和内容对象
                "0": {
                    title: "",
                    content: "",
                    // cover_image:"",
                }
            },
            curKey: 0,                             // 选中的微信内容项
            mouseMoveOptionId: -1,                  // 鼠标移过的项目id
            cover_image: "",
            expire_time: ""
        };
        this.dataList = [];
    }
    componentDidMount() {
        let _this = this;
        let { documentCenterEditActs } = this.props;
        let documentId = this.state.query.documentId;
        documentCenterEditActs.reset();
    }
    render() {
        let fieldDecorator = this.props.fieldDecorator;
        let { form } = this.props;
        let { previewData, platformArr, curKey, wxItemObj, mouseMoveOptionId } = this.state;
        const formItemLayout = {
            labelCol: { span: 5 },
            wrapperCol: { span: 19 }
        };
        let originUrl = encodeURIComponent(tools.getOriginUrl());
        //预览数据
        let dataSource = [
            {
                // platform: contentType,
                content: {
                    title: previewData.title,
                    author: previewData.author,
                    // time: previewData.ctime,
                    content_text: previewData.content
                },
                qrcode: tools.previewApi(`/infoAppDemo?resource_id=${previewData.resource_id}&originUrl=${originUrl}&isEdit=true`),
            }
        ]
        //微信列表
        let wxListJSX = [];
        // 微信图文列表
        if (Object.getOwnPropertyNames(wxItemObj).length > 0) {
            let classNames = {
                firstWxItem: 'first-wx-item',
                selectedWxItem: 'selected-wx-item',
                wxItem: 'wx-item',
                firstWxItemTitle: 'first-wx-item-title',
                wxItemTitle: 'wx-item-title'
            }
            let firstSelectedClass = `${classNames.firstWxItem} ${classNames.selectedWxItem}`;
            let otherSelectedClass = `${classNames.wxItem} ${classNames.selectedWxItem}`;
            $.each(wxItemObj, (key, value) => {
                // 插入微信项
                wxListJSX.push(<div
                    onMouseEnter={this.onMouseEnterHandler.bind(this, key)}
                    onMouseLeave={this.onMouseLeaveHandler.bind(this, key)}
                    key={key}
                    onClick={this.onClickWxListItem.bind(this, key)}
                    className={curKey == key ?
                        key == 0 ? `${firstSelectedClass}` : `${otherSelectedClass}`
                        : key == 0 ? `${classNames.firstWxItem}` : `${classNames.wxItem}`}
                >
                    <img src={form.getFieldsValue()[`cover_plan_$${key}`] || value.cover_image || (key == 0 ? this.defValue.editorAvatorImg.first : this.defValue.editorAvatorImg.other)} />
                    {/* <img src={wxItemObj[key].cover_image||(key==0 ? this.defValue.editorAvatorImg.first : this.defValue.editorAvatorImg.other)}/> */}
                    <span className={key == 0 ? classNames.firstWxItemTitle : classNames.wxItemTitle}>{value.title || "未命名"}</span>
                    <WxItemOperate
                        id={key}
                        wxItemObj={wxItemObj}
                        onClickDelete={this.onClickDelete.bind(this)}
                        onClickUp={this.onClickUp.bind(this)}
                        onClickDown={this.onClickDown.bind(this)}
                        style={{ display: mouseMoveOptionId === key ? 'flex' : 'none' }}
                    />
                </div>)
            })
        }
        return (
            <div className="first-wximage-txt">
                <div><span style={{ display: "inline-block", color: '#f04134', fontFamily: 'SimSun', fontSize: '12px', marginRight: '4px', lineHeight: 2 }}>*</span>注：正文最多可输入2万字。</div>
                <Row className="m-edit-content">
                    <div className="m-edit-content-col" style={{ width: "calc(100% - 250px)" }}>
                        <UEditor
                            id={this.state.editor_id}
                            onKeyup={this.onKeyup.bind(this)}
                            onEditorReady={this.onEditorReady.bind(this)}
                            curKey={curKey}
                            content={this.state.content}
                            title={this.state.title} />
                    </div>
                    <div className="m-edit-content-col" style={{ width: "250px", padding: "10px 15px 0", background: "#F7F7F7" }}>
                        <div>
                            <div className="wx-item-container">
                                {wxListJSX}
                            </div>
                            <div
                                className="wx-btn-plus"
                                style={{ display: Object.getOwnPropertyNames(wxItemObj).length >= 8 ? 'none' : 'block' }}
                                onClick={this.onClickBtnPlus.bind(this)}>
                                <img src={this.defValue.editorAvatorImg.addIcon} />
                            </div>
                        </div>
                    </div>
                </Row>
                <TextArea className="copy-textarea" rows={12} placeholder="粘贴纯文本（可选）" />
            </div>
        )
    }
    // 鼠标进入显示选项
    onMouseEnterHandler(key) {
        this.setState({
            mouseMoveOptionId: key
        })
    }
    // 鼠标移出选项消失
    onMouseLeaveHandler(key) {
        this.setState({
            mouseMoveOptionId: -1
        })
    }
    // 点击微信列表的某一项
    onClickWxListItem(key) {
        if (this.defValue.isNoClickWxItem) {
            this.defValue.isNoClickWxItem = false;
            return;
        }
        let { wxItemObj } = this.state;
        const { documentCenterEditActs, form } = this.props;
        this.defValue.isNoContentChange = true;
        // 切换为当前项的标题和内容
        this.setState({
            curKey: key,
            title: wxItemObj[key].title,
            content: wxItemObj[key].content
        })
    }
    // 点击微信列表上的加号
    onClickBtnPlus() {
        // 点击加号给列表加条件
        let { curKey, wxItemObj } = this.state;
        let { wx_news, brands, therapeutic, allkp } = this.props.$$documentCenterEdit.toJS();
        let key = Object.getOwnPropertyNames(wxItemObj).length;

        // 往编辑器内容里面加项，改变curKey，content，title
        wxItemObj[key] = {
            title: "",
            content: "",
            avatar: ""
        }
        this.defValue.isNoContentChange = true;
        this.setState({
            wxItemObj: wxItemObj,
            curKey: key,
            title: "",
            content: "",
        })
    }
    // 点击操作框的删除
    onClickDelete(key) {
        if (Object.getOwnPropertyNames(this.state.wxItemObj).length <= 1) {
            message.error("您不能删除素材中的所有文章");
            return;
        }
        tools.showDialog.confirm("确定删除该图文？", () => {
            this.defValue.isNoClickWxItem = true;
            this.defValue.isNoContentChange = true;
            let { wx_news, brands, therapeutic, allkp } = this.props.$$documentCenterEdit.toJS();
            let { documentCenterEditActs } = this.props;
            let { wxItemObj } = this.state;
            let { form } = this.props;
            let tempObj = {};
            let index = 0;
            let wxtemp = [];
            let idx = 0;
            let wx = wx_news;
            // 处理form表单
            if (parseInt(key) + 1 !== Object.getOwnPropertyNames(tempObj).length) {
                $.map(form.getFieldsValue(), (v, k) => {
                    if (k.match(/.+_\$\d+/)) {
                        var matchRes = k.match(/(.+)_\$(\d+)/)
                        let prefix = matchRes[1];
                        let keyIndex = matchRes[2];
                        let tempValue = '';
                        if (parseInt(keyIndex) >= parseInt(key) && parseInt(keyIndex) + 1 < Object.getOwnPropertyNames(wxItemObj).length) {
                            tempValue = form.getFieldsValue()[k];   // 取出i的值
                            form.setFieldsValue({
                                [k]: form.getFieldsValue()[`${prefix}_$${parseInt(keyIndex) + 1 + ""}`]
                            });
                            form.setFieldsValue({
                                [`${prefix}_$${parseInt(keyIndex) + 1 + ""}`]: tempValue
                            });
                        }
                        //删除最后一个对象（bug号：http://10.90.0.49:88/zentao/bug-view-12277.html）
                        if (parseInt(keyIndex) >= parseInt(key) && parseInt(keyIndex) + 1 == Object.getOwnPropertyNames(wxItemObj).length) {
                            delete wx_news[key];
                        }
                    }
                })
            }
            documentCenterEditActs.updateWXIndex(wx_news)//删除后的数组更新到reducers
            $.each(wxItemObj, (i, o) => {
                if (i !== key) {
                    tempObj[index] = o;
                    index++;
                }
            })
            let curKey = parseInt(key) < Object.getOwnPropertyNames(tempObj).length - 1 ? parseInt(key) + "" : Object.getOwnPropertyNames(tempObj).length - 1 + "";
            this.setState({
                wxItemObj: tempObj,
                curKey: curKey,
                title: tempObj[curKey].title,
                content: tempObj[curKey].content
            })

        }, () => { })
    }
    // 点击操作框的上移
    onClickUp(key) {
        this.defValue.isNoClickWxItem = true;
        this.defValue.isNoContentChange = true;
        let { wx_news, brands, therapeutic, allkp } = this.props.$$documentCenterEdit.toJS();
        let { documentCenterEditActs } = this.props;
        let { wxItemObj } = this.state;
        let { form } = this.props;
        let tempValue = '';
        let extendValue = [];
        let wx = wx_news;
        $.each(wxItemObj, (i, o) => {
            if (i === key) {
                // 更换title等字段
                tempValue = wxItemObj[parseInt(i) - 1 + ""];
                wxItemObj[parseInt(i) - 1 + ""] = wxItemObj[i];
                wxItemObj[i] = tempValue;
                // 更换表单内字段
                $.map(form.getFieldsValue(), (value, key) => {
                    if (key.indexOf("_$" + i + "") > -1) {
                        let prefix = key.match(/(.+)_\$/)[1];
                        tempValue = form.getFieldsValue()[key];   // 取出i的值
                        form.setFieldsValue({
                            [key]: form.getFieldsValue()[`${prefix}_$${parseInt(i) - 1 + ""}`]
                        });
                        form.setFieldsValue({
                            [`${prefix}_$${parseInt(i) - 1 + ""}`]: tempValue
                        });
                    }
                })
                return;
            }
        })
        $.each(wx, (i, o) => {
            if (i == key) {
                // 更换author等字段
                extendValue = wx[parseInt(i) - 1];
                wx[parseInt(i) - 1] = wx[i];
                wx[i] = extendValue;
            }
            return wx;
        })
        this.setState({
            wxItemObj: wxItemObj,
            curKey: parseInt(key) + "",
            title: wxItemObj[parseInt(key) + ""].title,
            content: wxItemObj[parseInt(key) + ""].content,
        })
    }
    // 点击操作框的下移
    onClickDown(key) {
        this.defValue.isNoClickWxItem = true;
        this.defValue.isNoContentChange = true;
        let { wx_news, brands, therapeutic, allkp } = this.props.$$documentCenterEdit.toJS();
        let { documentCenterEditActs } = this.props;
        let { wxItemObj } = this.state;
        let { form } = this.props;
        let tempValue = '';
        let extendValue = [];
        let wx = wx_news;
        $.each(wxItemObj, (i, o) => {
            if (i === key) {
                // 更换title等字段
                tempValue = wxItemObj[parseInt(i) + 1 + ""];
                wxItemObj[parseInt(i) + 1 + ""] = wxItemObj[i];
                wxItemObj[i] = tempValue;
                // 更换表单内字段
                $.map(form.getFieldsValue(), (value, key) => {
                    if (key.indexOf("_$" + i + "") > -1) {
                        let prefix = key.match(/(.+)_\$/)[1];
                        tempValue = form.getFieldsValue()[key];   // 取出i的值
                        form.setFieldsValue({
                            [key]: form.getFieldsValue()[`${prefix}_$${parseInt(i) + 1 + ""}`]
                        });
                        form.setFieldsValue({
                            [`${prefix}_$${parseInt(i) + 1 + ""}`]: tempValue
                        });
                    }
                })
                return;
            }
        })
        $.each(wx, (i, o) => {
            if (i == key) {
                // 更换author等字段
                extendValue = wx[parseInt(i) + 1];
                wx[parseInt(i) + 1] = wx[i];
                wx[i] = extendValue;
            }
            return wx;
        })
        this.setState({
            wxItemObj: wxItemObj,
            curKey: parseInt(key) + "",
            title: wxItemObj[parseInt(key) + ""].title,
            content: wxItemObj[parseInt(key) + ""].content,
        })
    }
    // 编辑器失去焦点
    onBlur(value) {
        this.setState({ content: value });
    }
    // 编辑器加载完成获取数据
    onEditorReady() {
        let { documentCenterEditActs, commonActs, form, $$layout } = this.props;
        let newsId = this.state.query.detailId;
        if (this.state.isEdit) {
            // 如果是编辑页，获取图文详情
            // 1. 详情赋值
            // 2. set 到详情进来的那一项
            // 3. title content 赋值
            documentCenterEditActs.getWXNews(this.state, true).done(resp => {
                let { news } = this.props;
                let { wx_news } = this.props.$$documentCenterEdit.toJS();
                let tempWxItemObj = {};             
                let data = wx_news;
                this.defValue.isNoContentChange = true;
                data.map((item, index) => {
                    tempWxItemObj[index] = item.material;
                    tempWxItemObj[index].cover_image = item.cover_image;
                })
                this.setState({
                    wxItemObj: tempWxItemObj,
                    curKey: 0,
                    title: wx_news[0].material.title,
                    content: tempWxItemObj[0].content
                })
                if (this.props.location.query.type == 5) {
                    this.setState({
                        // expired: wx_news[0].expire_time == 946656001000 ? true : false
                        expired: wx_news[0].expire_time == null ? true : false
                    })
                }
            });
        }
    }
    //图文预览
    onClickPreview() {
        let { documentCenterEditActs, form } = this.props;
        let { title, content, curKey } = this.state;
        const { wx_news } = this.props.$$documentCenterEdit.toJS();
        // title
        const fields = $.extend(true,
            {},
            {
                title,
                author: wx_news[curKey] ? wx_news[curKey].author : "",
                time: wx_news.ctime,
                content
            }
        );
        documentCenterEditActs.savePreview(fields).done((resp) => {
            let resource_id = resp.data;
            documentCenterEditActs.getNewsPreviewDetail(resp.data).done((resp) => {
                if (!resp.data) return;
                this.setState({
                    previewData: $.extend({}, { resource_id: resource_id }, JSON.parse(resp.data))
                })
            });
        })
    }
    //编辑器失去焦点
    onKeyup(argObj) {
        if (this.defValue.isNoContentChange) {
            this.defValue.isNoContentChange = false;
            return;
        }
        let { wxItemObj, curKey } = this.state;
        wxItemObj[curKey].title = argObj.title,
            wxItemObj[curKey].content = argObj.content
        this.setState({
            title: argObj.title,
            content: argObj.content,
            wxItemObj: wxItemObj,
        })
    }
    //点击保存按钮
    onClickSave(operation) {
        let documentId = this.state.query.documentId;
        let { documentCenterEditActs, form } = this.props;
        let valiFields = $.map(form.getFieldsValue(), (val, key) => key);
        let finalFields = [];
        valiFields.map((obj) => {
            if (obj.indexOf('$') > 0) {
                finalFields.push(obj);
            }
        })
        finalFields.push("expire_time");
        let { wxItemObj, isEdit } = this.state;
        let extendTitle = '';
        if (document.getElementById('editor-extend-title-input')) {
            extendTitle = document.getElementById('editor-extend-title-input').value;
        }
        // 检查微信的每一篇文章的标题和内容是否填写完整
        let isExtendError = false;
        $.each(wxItemObj, (key, value) => {
            if (!(value.title && value.content)) {
                isExtendError = true;
                // 将选项切换到出错的地方
                this.setState({
                    curKey: key,
                    title: value.title,
                    content: value.content
                })
                return false;
            }
        })
        this.defValue.isNoContentChange = true;

        let { wx_news, brands, therapeutic, allkp } = this.props.$$documentCenterEdit.toJS();


        form.validateFieldsAndScroll(finalFields, { force: true }, (errors, values) => {
            if (!!isExtendError) {
                tools.showDialog.error("标题和内容不能为空");
                // this.defValue.isNoContentChange = false;
                return;
            }
            if (!!errors) {
                $.each(errors, (key, value) => {
                    if (key.match(/.+_\$(\d+)/)) {
                        var errorKey = key.match(/.+_\$(\d+)/)[1];
                        this.setState({
                            curKey: errorKey,
                            title: wxItemObj[errorKey].title,
                            content_wx: wxItemObj[errorKey].content_wx
                        })
                        return false;
                    }
                })
                tools.showDialog.error("请补全提交信息");
                return;
            }
            this._save(operation)
        })
    }
    //保存表单
    _save(operation) {
        // 调用保存接口
        const { documentCenterEditActs, form } = this.props;
        let documentId = this.state.query.documentId;
        // const newsId = this.state.query.newsId;

        let { wxItemObj, isEdit, query } = this.state;
        let resArr = [];
        let tempObj = {};
        $.each(wxItemObj, (key, value) => {
            let allFields = form.getFieldsValue();
            let { wx_news, brands, therapeutic, allkp, relatedTreeTrue, equalTreeData, relaAreaAndBrand } = this.props.$$documentCenterEdit.toJS();
            tempObj = {
                brands: [],
                cover_image: '',
                feedback: true,
                introduction: '',
                key_messages: [],
                labels: [],
                material: {
                    author: '',
                    title: '',
                    content: ''
                },
                therapeutic_areas: [],
                share_scope: '',
                use_scope: '',
                water_mark: ''
            };
            // 产品
            let brand_ids = [];
            // 治疗领域
            let therapeuticId = [];
            relaAreaAndBrand.brand.map(item => {
                brand_ids.push(item.id);
            })
            relaAreaAndBrand.therapeutic_area.map(item => {
                therapeuticId.push(item.id);
            })
            // 信息点
            let kmId = [];
            if (allFields[`km_ids_$${key}`] != undefined) {
                allFields[`km_ids_$${key}`].map((item) => {
                    allkp.map((obj) => {
                        if (item == obj.name) {
                            kmId.push(obj.id)
                        }
                    })
                })
            }
            // 标签
            let tag = [];
            if (allFields[`tag_ids_$${key}`] != undefined) {
                allFields[`tag_ids_$${key}`].map((item) => {
                    if (equalTreeData != null) {
                        equalTreeData.map((obj) => {
                            if (item == obj.name) {
                                tag.push(obj.id)
                            }
                        })
                    }
                })
            }
            // 基础信息
            tempObj.id = this.state.isEdit ? allFields[`id_$${key}`] : "";
            tempObj.material.title = value.title;
            tempObj.material.content = value.content;

            // 关联信息
            let arr = allFields[`cover_plan_$${key}`].split('/')
            tempObj.cover_image = arr[arr.length - 1];//var arr = a.split('\\');alert(arr[arr.length-1]);
            tempObj.introduction = allFields[`digest_$${key}`] == undefined ? '' : allFields[`digest_$${key}`];
            tempObj.material.author = allFields[`author_$${key}`] == undefined ? '' : allFields[`author_$${key}`];
            tempObj.brands = brand_ids;
            tempObj.therapeutic_areas = therapeuticId;
            tempObj.key_messages = kmId;
            tempObj.labels = tag;

            resArr.push(tempObj);
        })
        let allFields = form.getFieldsValue();
        var time = new Date(allFields["expire_time"]);
        var time_year;
        var time_month;
        var time_date;
        var expire_time;
        // if (time.getTime() == 946656001000) {
        //     expire_time = 946656001000;
        if (time.getTime() == 0) {
            expire_time = null;
        } else {
            time_year = time.getFullYear();
            time_month = time.getMonth() + 1;
            time_date = time.getDate();
            expire_time = new Date(time_year + "/" + time_month + "/" + time_date + " " + "00:00:01").getTime();
        }
        const fields = resArr;
        let newsValue = {
            parent_id: Number(documentId),
            type: 5,
            expire_time: expire_time,
            materials: fields
        }
        // newsActs.saveNewsWx(fields, this.state.isEdit).done((res) => {
        //     if(res.code === 10000){
        //         let {query} = this.props.location;
        //         if (query.isCreateMaterial || query.isCreateMaterial === "true") {
        //             this.props.router.replace({
        //                 pathname: "/express/edit",
        //                 query: $.extend({}, query, {
        //                     material_id: isEdit ? fields.id : res.data,
        //                     material_type: Enum.DocumentType.news,
        //                     docType: this.props.location.query.docType,
        //                     isEdit: !!isEdit
        //                 })
        //             });
        //         }else {
        //             this.props.router.push({
        //                 pathname: "/news/list"
        //             });
        //         }
        //     }
        // });
        console.log("-- newsValue --",newsValue)
        if (this.state.isEdit) {
            newsValue.id = Number(this.state.id);
            documentCenterEditActs.savePreviewEdit(newsValue)
        } else {
            documentCenterEditActs.saveNewsPreview(newsValue)
        }
    }
    //比较两对象中对应key值否相等
    _equals(next, prev, keyArr) {
        if (!($.isPlainObject(prev)) && ($.isPlainObject(next))) return false;
        if (keyArr instanceof Array === false) return false;
        prev = Immutable.fromJS(prev);
        next = Immutable.fromJS(next);
        let isEquals = true;
        $.each(keyArr, (i, key) => {
            isEquals = false;
            let d1 = prev.get(key), d2 = next.get(key);
            if (Immutable.List.isList(d1) && Immutable.List.isList(d2) && d1.equals(d2)) {
                //array
                isEquals = true;
            } else if (Immutable.Map.isMap(d1) && Immutable.Map.isMap(d2) && d1.equals(d2)) {
                //object
                isEquals = true;
            } else if (d1 === d2) {
                //other
                isEquals = true;
            }
            return isEquals;
        });
        return isEquals;
    }
}

class WxItemOperate extends React.Component {
    render() {
        let { id, wxItemObj, style } = this.props;
        return (
            <div className="wx-item-operate" style={{ ...style }}>
                <div className="wx-item-operate-col" style={{ display: id == 0 ? 'none' : 'block' }} onClick={this.onClickUp.bind(this, undefined, false)}>上移</div>
                <div className="wx-item-operate-col" style={{ display: id == Object.getOwnPropertyNames(wxItemObj).length - 1 ? 'none' : 'block' }} onClick={this.onClickDown.bind(this, undefined, false)}>下移</div>
                <div className="wx-item-operate-col" onClick={this.onClickDelete.bind(this, undefined, false)}>删除</div>
            </div>
        )
    }
    // 点击上移
    onClickUp() {
        let { id, onClickUp } = this.props;
        if (typeof onClickUp === 'function') {
            onClickUp.call(this, id);
        }
    }
    // 点击下移
    onClickDown() {
        let { id, onClickDown } = this.props;
        if (typeof onClickDown === 'function') {
            onClickDown.call(this, id);
        }
    }
    // 点击删除
    onClickDelete() {
        // !!!TODO 未能阻止冒泡，会进当前项的click事件导致title和content无法正常更新
        let { id, onClickDelete } = this.props;
        if (typeof onClickDelete === 'function') {
            onClickDelete.call(this, id);
        }
    }
}

export default _SecondWX
