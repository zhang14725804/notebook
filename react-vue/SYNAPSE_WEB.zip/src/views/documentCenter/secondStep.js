import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/documentCenter"
import { Enum, EnumCn } from "enum"
import { tools } from "utils"
import Icon from "antd/lib/icon"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import Tag from "antd/lib/tag"
import Radio from "antd/lib/radio"
import Collapse from "antd/lib/collapse"
import Checkbox from "antd/lib/checkbox"
import Select from "antd/lib/select"
import DatePicker from "antd/lib/date-picker"
import moment from "moment"
import Slider from 'react-slick';
import TreeSelect from 'antd/lib/tree-select';
import Upload from "components/upload"


const RadioGroup = Radio.Group;
const Panel = Collapse.Panel;
const FormItem = Form.Item;
const CheckboxGroup = Checkbox.Group;
const Option = Select.Option;
const TreeNode = TreeSelect.TreeNode;

class _SecondStep extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        }
    }
    componentDidMount() {
    }
    render() {
        let fieldDecorator = this.props.fieldDecorator;
        let { documentCenterEditActs } = this.props;
        const formItemLayout = null;
        // TODO type 的含义
        let cookie = tools.getCookies();
        //上传文件配置
        let uploadCfg = {
            url: tools.javaApi("/uploadpic"),
            previewUrl: this.props.form.getFieldsValue().cover_image,
            width: '180px',
            height: '100px',
            description: '上传封面<br /><div style="margin-top: -4px">360*200</div>',
            onSuccess: (data) => {
                message.success("上传成功");
                this.props.form.cover_image({
                    image: data.imageurl
                })
            },
            onErrorMessage: (error) => {
                tools.showDialog.error(error);
            }
        }
        // 内容形式
        const contentTypeJSX = this.getRelaJSX({
            id: "content_type",
            title: "内容形式",
            dataSource: [{
                key: 0,
                text: '传统图文'
            },{
                key: 1,
                text: 'infography'
            },{
                key: 2,
                text: 'video'
            },{
                key: 3,
                text: 'shortvideo'
            },{
                key: 4,
                text: 'LIVE'
            },{
                key: 5,
                text: 'H5'
            }]
        })
        // 产品相关度
        const relatePdtJSX = this.getRelaJSX({
            id: "relate_pdt",
            title: "产品相关度",
            dataSource: [{
                key: 0,
                text: '1'
            },{
                key: 1,
                text: '2'
            },{
                key: 2,
                text: '3'
            },{
                key: 3,
                text: '4'
            }]
        })
        // 发布渠道
        const publicTypeJSX = this.getRelaJSX({
            id: "public_type",
            title: "发布渠道",
            dataSource: [{
                key: 0,
                text: '线上官方网站'
            },{
                key: 1,
                text: '线上微信渠道'
            },{
                key: 2,
                text: '线下CRM - 拜访'
            },{
                key: 3,
                text: '线下CRM - 会议'
            },{
                key: 4,
                text: '第三方互联网推广渠道'
            }]
        })
        // 分享权限
        const shareScopeJSX = this.getRelaJSX({
            id: "share_scope",
            title: "分享权限",
            dataSource: [{
                key: 0,
                text: '内部分享'
            },{
                key: 1,
                text: '外部分享'
            }]
        })
        // 学术深度
        const aceDeapJSX = this.getRelaJSX({
            id: "ace_deap",
            title: "学术深度",
            dataSource: [{
                key: 0,
                text: '1'
            },{
                key: 1,
                text: '2'
            },{
                key: 2,
                text: '3'
            },{
                key: 3,
                text: '4'
            }]
        })
        // 内容来源
        const contentSourceJSX = this.getRelaJSX({
            id: "content_source",
            title: "内容来源",
            dataSource: [{
                key: 0,
                text: '本土'
            },{
                key: 1,
                text: '翻译'
            },{
                key: 2,
                text: '海外原文'
            }]
        })
        // 水印
        const waterMarkJSX = this.getRelaJSX({
            id: "water_mark",
            title: "水印",
            dataSource: [{
                key: 0,
                text: '客户端显示用户名信息水印'
            }]
        })
        // 内容分类
        const contentDataTypeJSX = this.getRelaJSX({
            id: "relate_pdt",
            title: "产品相关度",
            dataSource: [{
                key: 0,
                text: '新闻资讯'
            },{
                key: 1,
                text: '科普文章'
            },{
                key: 2,
                text: '病例论文'
            },{
                key: 3,
                text: '指南共识'
            },{
                key: 4,
                text: '会议报导'
            },{
                key: 5,
                text: '调研'
            }]
        })
        return (
            <div className="second-step">
                <Row className="m-margin-t">
                    <Col span="6"  xxl={4}>
                        <FormItem label=""
                            style={{ clear: "both" }}
                            {...formItemLayout}>
                            {fieldDecorator.cover_image(
                                <Upload {...uploadCfg} >
                                    <Button>
                                        <Icon type="upload" />点击上传
                                    </Button>
                                </Upload>
                            )}
                        </FormItem>
                    </Col>
                    <Col span="17"  xxl={19}>
                        <FormItem label=""
                            {...formItemLayout}>
                            {fieldDecorator.name(
                                <Input
                                    style={{marginTop: '30px'}}
                                    type="text"
                                    placeholder="文档名称" />
                            )}
                        </FormItem>
                    </Col>
                </Row>
                <hr />
                <Row>
                    <Col span="7">
                        <FormItem label="有效期至"
                            {...formItemLayout}>
                            {fieldDecorator.expire_time_basic(
                                <DatePicker
                                    style={{ width: "70%" }}
                                    showToday={false} />
                            )}
                            <Checkbox className="m-margin-l neverOutDate">永久</Checkbox>
                        </FormItem>
                    </Col>
                    <Col span="7" offset="1">
                        <FormItem label="内容形式"
                            {...formItemLayout}>
                            {contentTypeJSX}
                        </FormItem>
                    </Col>
                    <Col span="7" offset="1">
                        <FormItem label="产品相关度"
                            {...formItemLayout}>
                            {relatePdtJSX}
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="7">
                        <FormItem label="发布渠道"
                            {...formItemLayout}>
                            {publicTypeJSX}
                        </FormItem>
                    </Col>
                    <Col span="7" offset="1">
                        <FormItem label="分享权限"
                            {...formItemLayout}>
                            {shareScopeJSX}
                        </FormItem>
                    </Col>
                    <Col span="7" offset="1">
                        <FormItem label="学术深度"
                            {...formItemLayout}>
                            {aceDeapJSX}
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="7">
                        <FormItem label="作者"
                            {...formItemLayout}>
                            {fieldDecorator.name(
                                <Input
                                    type="text"
                                    placeholder="请输入内容" />
                            )}
                        </FormItem>
                    </Col>
                    <Col span="7" offset="1">
                        <FormItem label="内容来源"
                            {...formItemLayout}>
                            {contentSourceJSX}
                        </FormItem>
                    </Col>
                    <Col span="7" offset="1">
                        <FormItem label="水印"
                            {...formItemLayout}>
                            {waterMarkJSX}
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="7">
                        <FormItem label="内容分类"
                            {...formItemLayout}>
                            {contentDataTypeJSX}
                        </FormItem>
                    </Col>
                </Row>
            </div>
        )
    }
    // 生成关联项的JSX对象
    getRelaJSX(cfg) {
        let fieldDecorator = this.props.fieldDecorator;
        const { id, title, dataSource, isMulti } = cfg;
        const jsx = dataSource.map((item) => {
            return <Option key={item.key} value={item.key}>{item.text}</Option>
        })
        return (<Select
            mode={isMulti ? 'multiple' : ''}
            placeholder="请选择"
        >{jsx}</Select>)
    }
}

export default _SecondStep



