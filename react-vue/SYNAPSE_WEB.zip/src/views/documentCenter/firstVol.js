import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/documentCenter"
import { Enum, EnumCn } from "enum"
import { tools } from "utils"
import Modal from "antd/lib/modal"
import Icon from "antd/lib/icon"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import Dropdown from "antd/lib/dropdown"
import Table from "antd/lib/table"
import Menu from "antd/lib/menu"
import Tag from "antd/lib/tag"
import Radio from "antd/lib/radio"
import Steps from "antd/lib/steps"
import Upload from "antd/lib/upload"
import Collapse from "antd/lib/collapse"
import Checkbox from "antd/lib/checkbox"
import Select from "antd/lib/select"
import DatePicker from "antd/lib/date-picker"
import Alert from "antd/lib/alert"

const Step = Steps.Step;
const RadioGroup = Radio.Group;
const Dragger = Upload.Dragger;
const Panel = Collapse.Panel;
const FormItem = Form.Item;
const CheckboxGroup = Checkbox.Group;
const Option = Select.Option;
const TextArea = Input.TextArea;

//step2: 上传文档
class _FirstVol extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            current: 0
        }
    }
    componentDidMount() {
        let { documentCenterEditActs } = this.props;
        documentCenterEditActs.getVolMuduAccount();
    }
    render() {
        let { fieldDecorator, $$documentCenterEdit } = this.props;
        let { muduAccount } = $$documentCenterEdit.toJS();
        let firstStepJSX = (
            <div>
                <p className="vol-room-row"><Button onClick={this.onClickEnterControl.bind(this)}>点击登录 tv.synapse.xin</Button></p>
                <div className="vol-name-container">
                    <p>账号：{muduAccount.mudu_username || tools.emptyInfo}</p>
                    <p>密码：{muduAccount.mudu_password || tools.emptyInfo}</p>
                </div>
            </div>
        );
        let secondStepJSX = (
            <div>
                <FormItem
                    className="vol-room-row"
                    style={{ marginBottom: 0 }}
                    label="直播链接："
                    labelCol={{ span: 2, xxl: 1 }}
                    wrapperCol={{ span: 9 }}>
                    {fieldDecorator.live_url(
                        <Input
                            type="small"
                            className="m-margin-l"
                            style={{ width: "300px", display: 'inline-block' }}
                            placeholder="请输入内容" />
                    )}
                </FormItem>
                <Row>
                    <Col span={2} xxl={1}></Col>
                    <Col span={9} className="m-margin-l">
                        <Alert className="vol-room-row" message="说明: 将控制台中的直播详情页，粘贴至此处，用于后续推广" type="warning" showIcon style={{ width: '400px' }} />
                    </Col>
                </Row>
                <p className="vol-room-desc vol-room-row">，</p>
                <p className="vol-room-desc"></p>
            </div>
        )
        return (
            <div className="first-vol">
                <Steps direction="vertical" size="small" progressDot current={this.state.current}>
                    <Step title="STEP1：登录直播控制台" description={firstStepJSX} />
                    <Step title="STEP2：录入直播详情页" description={secondStepJSX} />
                </Steps>
                <TextArea className="copy-textarea" rows={12} placeholder="粘贴纯文本（可选）" />
            </div>
        )
    }
    // 点击进入直播控制台
    onClickEnterControl() {
        let { current } = this.state;
        window.open('http://tv.synapse.xin/managerlogin/32277');
        this.setState({
            current: !isNaN(Number(current)) ? Number(current) + 1 : 0
        })
    }
}

export default _FirstVol
