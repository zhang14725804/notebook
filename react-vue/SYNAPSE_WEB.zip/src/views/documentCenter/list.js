import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/documentCenter"
import { Enum, EnumCn } from "enum"
import { ColorEnum } from 'src/constants/customEnum'
import { tools } from "utils"

import Modal from "antd/lib/modal"
import Icon from "antd/lib/icon"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import Table from "antd/lib/table"
import Alert from "antd/lib/alert"
import Tooltip from "antd/lib/tooltip"
import Popconfirm from "antd/lib/popconfirm"
import BreadCrumb from "antd/lib/breadcrumb"
import Select from "antd/lib/select"
import Menu from "antd/lib/menu"
import Dropdown from "antd/lib/dropdown"

import AdvSearch from "components/advSearch"
import "assets/style/views/documentCenter/list.less"

const MenuItem = Menu.Item;
const Search = Input.Search;
const ButtonGroup = Button.Group;
const FormItem = Form.Item;
const Option = Select.Option;
const BreadCrumbItem = BreadCrumb.Item;

//文档类型: 0-文件夹 1-普通文档  2-外部链接  3-h5  4-单图文  5-多图文
// 列表页图标地址
const Img = {
    folder: require("../../assets/image/folder.png"),
    Graphic: require("../../assets/image/Graphic.png"),
    h5: require("../../assets/image/h5.png"),
    image: require("../../assets/image/image.png"),
    pdf: require("../../assets/image/pdf.png"),
    mp4: require("../../assets/image/play.png"),
    ppt: require("../../assets/image/ppt.png"),
    word: require("../../assets/image/word.png"),
    WX: require("../../assets/image/WX.png")
}
let imgStyle = {
    marginRignt: "5px",
    verticalAlign: "middle"
}
let DocIconEnum = {
    //文件夹
    folder: 'wenjianjia1',
    //普通文档
    normal: 'document',
    //HTML5
    h5: 'yasuowenjian',
    //图文消息
    imagetxt: 'pic',
    //微信图文
    wximagetxt: 'weixin',
    //调研问卷
    qa: 'edit',
    //在线直播
    vol: 'shexiangtou',
    //录播视频
    vod: 'shipinbofang',
}

class DocumentCenterList extends React.Component {
    constructor(props) {
        super(props);
        let query = props.location.query;
        this.state = {
            selectRowId: -1,        // 是否为重命名状态
            dataSourceList: [],     // 列表的数据源
            query: props.location.query,
            isEditName: false,      // 是否为重命名
            visible: false,         // 新增文件夹Modal
            isEditFolder: false,    // 是否为编辑文件夹
            isDisabledLoad: query.documentId && query.documentId != '0' ? false : true,  // 上传功能
        }
    }

    componentDidMount() {
        let { documentCenterActs } = this.props;
        let query = tools.getQuery();
        // id在全部文件夹下为0或null，否则为文档id
        documentCenterActs.reset();

        // 获取列表数据（注：搜索的时候与列表并不是一个方法，分为两个接口）
        documentCenterActs.getDocumentCenterList({
            id: query.documentId,
        })

        // 根据当前的文件夹id获取上一级文件路径（面包屑导航）
        documentCenterActs.getAncestorList(query.documentId);

    }

    render() {
        let { documentCenterList, conditions, selectedKeys, ancestorList } = this.props.$$documentCenterList.toJS();
        debugger;
        let formItemLayout = {
            labelCol: { span: 7 },
            wrapperCol: { span: 17 }
        };
        let { form } = this.props;
        let { dataSourceList, selectRowId, isEditName, isDisabledLoad, isEditFolder, visible, query } = this.state;
        let { documentId } = query;

        // 面包屑导航
        let breadcrumbJSX = [];
        ancestorList.map((item, index) => {
            // 面包屑最后一个不放链接，前面几个都放链接
            if (index == 0) {
                breadcrumbJSX.push(<BreadCrumbItem className="ellipsis" style={{ fontWeight: "normal", width: item.name.length > 5 ? 50 : '', display: "inline-block", height: 14 }} key={index}>
                    <Tooltip placement="topLeft" title={item.name}>
                        {item.name}
                    </Tooltip>
                </BreadCrumbItem>)
            } else {
                breadcrumbJSX.push(<BreadCrumbItem className="ellipsis" style={{ cursor: "pointer", color: "#2db7f5", width: item.name.length > 5 ? 50 : '', display: "inline-block", height: 14 }} onClick={this.onClickBread.bind(this, item.id)} key={index}>
                    <Tooltip placement="topLeft" title={item.name}>
                        {item.name}
                    </Tooltip>
                </BreadCrumbItem>)
            }
        })
        breadcrumbJSX.reverse();
        if (breadcrumbJSX.length > 3) {
            breadcrumbJSX.splice(1, breadcrumbJSX.length - 3, <BreadCrumbItem key='-1' style={{ fontWeight: "normal", display: breadcrumbJSX.length > 3 ? 'inline-block' : 'none' }}>...</BreadCrumbItem>);
        }

        let cfg = {
            dataSource: documentCenterList.list,
            // dataSource: dataSourceList,
            rowKey: r => r.id,
            columns: [
                {
                    title: "名称",
                    dataIndex: "name",
                    key: "name",
                    width: "46%",
                    render: (text, r, index) => {
                        let suffix = text.substring(text.lastIndexOf('.'));
                        let onlyName = text.substring(0, text.lastIndexOf('.'));
                        console.log('-- r.type --', r.type)
                        let DcColorIconItem = ColorEnum.DcColorIcon[Enum.ResourceType[r.type]];
                        let iconStyle = {
                            width: '30px',
                            height: '30px',
                            lineHeight: '30px',
                            fontSize: '20px',
                            color: DcColorIconItem.color,
                            backgroundColor: DcColorIconItem.bgColor,
                            marginRight: '10px'
                        }
                        return (
                            <div className="item-name-container">
                                <Icon className='back-icon' type={DcColorIconItem.icon} style={iconStyle}></Icon>
                                {selectRowId == r.id ?
                                    <div className="item-edit">
                                        <div className="item-edit-col1">
                                            <Input ref="renametext" addonAfter={text.lastIndexOf('.') == -1 ? '' : suffix} id={r.id} onPressEnter={this.onPressChange.bind(this, r)} onChange={this._onInputChange.bind(this)} defaultValue={text.lastIndexOf('.') == -1 ? text : onlyName} />
                                        </div>
                                        <div className="item-edit-col2">
                                            <Icon type="check-circle" onClick={this.onClickFinishRename.bind(this, r)} className="m-text-success m-margin-l" />
                                            <Icon type="close-circle" onClick={this.onClickCancelRename.bind(this, r)} className="m-text-error m-margin-l" />
                                        </div>
                                    </div>
                                    :
                                    r.isAdd ?
                                        <div className="item-add">
                                            <Input ref="renametext" id={r.id} onPressEnter={this.onPressChange.bind(this, r)} onChange={this._onInputChange.bind(this)} defaultValue="新建文件夹" />
                                            <Icon type="check-circle" onClick={this.onClickFinishRename.bind(this, r)} className="m-text-success m-margin-l" />
                                            <Icon type="close-circle" onClick={this.onClickCancelRename.bind(this, r)} className="m-text-error m-margin-l" />
                                        </div>
                                        :
                                        <Tooltip placement="topLeft" title={text}>
                                            <a className="ellipsis item-txt" id="docName" onClick={this.onClickReadFolder.bind(this, r)}>{text}</a>
                                        </Tooltip>}
                            </div>
                        )
                    }
                }, {
                    title: "过期时间",
                    dataIndex: "expire_time",
                    key: "expire_time",
                    width: "15%",
                    render: (text, value) => {
                        // 文件夹 text 为空的是 - , 其他为永不过期？不用判断特定时间戳              
                        return (
                            <div>
                                {text ?
                                    <Tooltip placement="topLeft" title={(new hDate(text).format(`${tools.dateFormat}`))}>
                                        <div className="ellipsis" style={{ color: (text < new Date().getTime()) ? 'red' : '#666' }}>{(new hDate(text).format(`${tools.dateFormat}`))}</div>
                                    </Tooltip> :
                                    value.type == Enum.ResourceType.folder ? <div>-</div> : <Tooltip placement="topLeft" title="永不过期">永不过期</Tooltip>
                                }
                            </div>
                        )
                    }
                }, {
                    title: "文件大小",
                    dataIndex: "size",
                    key: "size",
                    width: "10%",
                    render: (text, value) => {
                        return (
                            <div>
                                {text ?
                                    <Tooltip placement="topLeft" title={this.formatByte(text)}>
                                        <div className="ellipsis">{this.formatByte(text)}</div>
                                    </Tooltip> :
                                    <div>-</div>
                                }
                            </div>
                        )
                    }
                }, {
                    title: "状态",
                    width: "10%",
                    dataIndex: "enabled",
                    key: "enabled",
                    render: (text, r) => {
                        let iconMap = {
                            state_false: { icon: "yuandianzhong", color: '#F9403C', className: "m-text-error", text: "禁用" },
                            state_true: { icon: "yuandianzhong", color: '#52C41A', className: "m-text-success", text: "启用" }
                        };
                        return (
                            <Tooltip placement="topLeft" title={iconMap["state_" + text].text}>
                                <div>
                                    <Icon
                                        style={{color: iconMap["state_" + text].color}}
                                        type={iconMap["state_" + text].icon}
                                        className={iconMap["state_" + text].className} />
                                    <span>{iconMap["state_" + text].text}</span>
                                </div>
                            </Tooltip>
                        )
                    }
                }, {
                    title: "操作",
                    width: "19%",
                    render: (text, r) => {
                        // 当前文件或者文件夹类型不同，显示的按钮不同
                        return (
                            <div>
                                <div className="item-opt">
                                    <a className="m-margin-r" onClick={this.onClickEdit.bind(this, r)} disabled={isDisabledLoad || isEditName || (r.type === Enum.ResourceType.folder && (documentId != 0 && documentId))}>编辑</a>
                                </div>
                                <div onMouseOut={this.onMouseOutFunc.bind(this, r)} onMouseOver={this.onMouseOverFunc.bind(this, r)} className="opt-menu">
                                    <a>更多</a>
                                    <ul className={'more_' + r.id} style={{width: '90px'}}>
                                        <li><a className="m-margin-r" disabled>分享链接</a></li>
                                        <li>
                                            <Popconfirm title="确认删除此项" okText="确定" cancel="取消" onConfirm={this.onClickDelete.bind(this, r)}>
                                                <a className="m-margin-r" disabled={isEditName}>删除</a>
                                            </Popconfirm>
                                        </li>
                                        <li>
                                            <a className="m-margin-r" onClick={this.onClickRename.bind(this, r)} disabled={isEditName || r.type == Enum.ResourceType.imagetxt || r.type == Enum.ResourceType.wximagetxt}>重命名</a>
                                        </li>
                                        <li>
                                            <a className="m-margin-r" disabled={r.type === Enum.ResourceType.folder || isEditName || r.type == Enum.ResourceType.imagetxt || r.type == Enum.ResourceType.wximagetxt || (r.type == Enum.ResourceType.h5 && r.name.indexOf(".zip") == -1)} onClick={this.onClickDownload.bind(this, r)}>下载</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        )
                    }
                }],
            bordered: false,
            onChange: (page, filter, sort) => {
                let { documentCenterActs } = this.props;
                documentCenterActs.getDocumentCenterList({
                    page_index: page.current,
                    page_size: page.pageSize,
                })
            },
            pagination: isEditName ? false :
                $.extend(true, {}, tools.config.pagination, {
                    current: conditions.page_index,
                    pageSize: conditions.page_size,
                    total: documentCenterList.total
                }),
            rowSelection: isDisabledLoad ? null : {
                width: '10px',
                selectedRowKeys: selectedKeys,
                onChange: (selectedRowKeys, selectedRows) => {
                    // TODO selectedKeys 为什么要存进 reducer
                    let { documentCenterActs } = this.props;
                    documentCenterActs.setSelectKeys(selectedRowKeys);
                },
            }
        }

        // 首页不显示操作列
        if (isDisabledLoad) {
            cfg = {
                dataSource: documentCenterList.list,
                // dataSource: dataSourceList,
                rowKey: r => r.id,
                columns: [
                    {
                        title: "名称",
                        dataIndex: "name",
                        key: "name",
                        width: "46%",
                        render: (text, r, index) => {
                            let suffix = text.substring(text.lastIndexOf('.'));
                            let onlyName = text.substring(0, text.lastIndexOf('.'));
                            console.log('-- r.type --', r.type)
                            let DcColorIconItem = ColorEnum.DcColorIcon[Enum.ResourceType[r.type]];
                            let iconStyle = {
                                width: '30px',
                                height: '30px',
                                lineHeight: '30px',
                                fontSize: '22px',
                                color: DcColorIconItem.color,
                                backgroundColor: DcColorIconItem.bgColor,
                                marginRight: '10px'
                            }
                            return (
                                <div className="item-name-container">
                                    <Icon className='back-icon' type={DcColorIconItem.icon} style={iconStyle}></Icon>
                                    {selectRowId == r.id ?
                                        <div className="item-edit">
                                            <div className="item-edit-col1">
                                                <Input ref="renametext" addonAfter={text.lastIndexOf('.') == -1 ? '' : suffix} id={r.id} onPressEnter={this.onPressChange.bind(this, r)} onChange={this._onInputChange.bind(this)} defaultValue={text.lastIndexOf('.') == -1 ? text : onlyName} />
                                            </div>
                                            <div className="item-edit-col2">
                                                <Icon type="check-circle" onClick={this.onClickFinishRename.bind(this, r)} className="m-text-success m-margin-l" />
                                                <Icon type="close-circle" onClick={this.onClickCancelRename.bind(this, r)} className="m-text-error m-margin-l" />
                                            </div>
                                        </div>
                                        :
                                        r.isAdd ?
                                            <div className="item-add">
                                                <Input ref="renametext" id={r.id} onPressEnter={this.onPressChange.bind(this, r)} onChange={this._onInputChange.bind(this)} defaultValue="新建文件夹" />
                                                <Icon type="check-circle" onClick={this.onClickFinishRename.bind(this, r)} className="m-text-success m-margin-l" />
                                                <Icon type="close-circle" onClick={this.onClickCancelRename.bind(this, r)} className="m-text-error m-margin-l" />
                                            </div>
                                            :
                                            <Tooltip placement="topLeft" title={text}>
                                                <a className="ellipsis item-txt" id="docName" onClick={this.onClickReadFolder.bind(this, r)}>{text}</a>
                                            </Tooltip>}
                                </div>
                            )
                        }
                    }, {
                        title: "过期时间",
                        dataIndex: "expire_time",
                        key: "expire_time",
                        width: "15%",
                        render: (text, value) => {
                            // 文件夹 text 为空的是 - , 其他为永不过期？不用判断特定时间戳              
                            return (
                                <div>
                                    {text ?
                                        <Tooltip placement="topLeft" title={(new hDate(text).format(`${tools.dateFormat}`))}>
                                            <div className="ellipsis" style={{ color: (text < new Date().getTime()) ? 'red' : '#666' }}>{(new hDate(text).format(`${tools.dateFormat}`))}</div>
                                        </Tooltip> :
                                        value.type == Enum.ResourceType.folder ? <div>-</div> : <Tooltip placement="topLeft" title="永不过期">永不过期</Tooltip>
                                    }
                                </div>
                            )
                        }
                    }, {
                        title: "文件大小",
                        dataIndex: "size",
                        key: "size",
                        width: "10%",
                        render: (text, value) => {
                            return (
                                <div>
                                    {text ?
                                        <Tooltip placement="topLeft" title={this.formatByte(text)}>
                                            <div className="ellipsis">{this.formatByte(text)}</div>
                                        </Tooltip> :
                                        <div>-</div>
                                    }
                                </div>
                            )
                        }
                    }, {
                        title: "状态",
                        width: "10%",
                        dataIndex: "enabled",
                        key: "enabled",
                        render: (text, r) => {
                            let iconMap = {
                                state_false: { icon: "cross-circle", className: "m-text-error", text: "禁用" },
                                state_true: { icon: "check-circle", className: "m-text-success", text: "启用" }
                            };
                            return (
                                <Tooltip placement="topLeft" title={iconMap["state_" + text].text}>
                                    <div>
                                        <Icon
                                            type={iconMap["state_" + text].icon}
                                            className={"m-margin-r " + iconMap["state_" + text].className} />
                                        <span>{iconMap["state_" + text].text}</span>
                                    </div>
                                </Tooltip>
                            )
                        }
                    }],
                bordered: false,
                onChange: (page, filter, sort) => {
                    let { documentCenterActs } = this.props;
                    documentCenterActs.getDocumentCenterList({
                        page_index: page.current,
                        page_size: page.pageSize,
                    })
                },
                pagination: isEditName ? false :
                    $.extend(true, {}, tools.config.pagination, {
                        current: conditions.page_index,
                        pageSize: conditions.page_size,
                        total: documentCenterList.total
                    }),
                rowSelection: isDisabledLoad ? null : {
                    selectedRowKeys: selectedKeys,
                    onChange: (selectedRowKeys, selectedRows) => {
                        // TODO selectedKeys 为什么要存进 reducer
                        let { documentCenterActs } = this.props;
                        documentCenterActs.setSelectKeys(selectedRowKeys);
                    },
                }
            }
        }

        let resourceTypeArr = Object.getOwnPropertyNames(EnumCn.ResourceType)
            .filter(name => !isNaN(Number(name)) && name != Enum.ResourceType.folder)
            .map(key => ({ name: EnumCn.ResourceType[key], value: key }));

        let advSearchDataSource = {
            dataItem: [
                {
                    name: "全部",
                    value: "0"
                }
            ],
            resourceType: resourceTypeArr,
            type: 'document'
        }
        const menuitemJSX = Object.getOwnPropertyNames(EnumCn.ResourceType)
            .filter(name => !isNaN(Number(name)) && name != Enum.ResourceType.folder)
            .map(key => {
                let DcColorIconItem = ColorEnum.DcColorIcon[Enum.ResourceType[key]];
                return <MenuItem key={key}><span><Icon type={DcColorIconItem.icon} />{EnumCn.ResourceType[key]}&nbsp;&nbsp;</span></MenuItem>
            })
        const menu = (
            <Menu onClick={this.onClickMenuItem.bind(this)}>
                {menuitemJSX}
            </Menu>
        );
        return (
            <section id="dc-list" style={{ backgroundColor: '#fff' }} >
                <AdvSearch dataSource={advSearchDataSource} />
                <div className="line"></div>
                <div style={{ padding: '12px', backgroundColor: "#fff" }}>
                    <Row className="m-margin-b">
                        <Col span="8">
                            <div style={{ marginLeft: '10px', marginTop: '8px' }}>
                                <BreadCrumb>
                                    <BreadCrumbItem className="item-breadcrumb"><Icon style={{position: "relative",fontSize: "18px",top: "2px", color: '#999'}} type="wenjianjia1" /> <a onClick={this.onClickAllFile.bind(this)} style={{ color: isEditName ? "" : "#2db7f5" }} disabled={isEditName}>全部资源</a></BreadCrumbItem>
                                    {breadcrumbJSX}
                                </BreadCrumb>
                            </div>
                        </Col>
                        <Col span={4} xxl={8}></Col>
                        <Col span={12} xxl={8}>
                            <div>
                                <Search className="searchbar" placeholder="请输入搜索内容" onSearch={value => console.log(value)} />
                                <Button
                                    type="primary"
                                    className="m-margin-r-10"
                                    onClick={this.onClickAddFolder.bind(this)} disabled={isEditName || isDisabledLoad}>新增文件夹</Button>
                                <Dropdown className="dc-dropdown" overlay={menu} disabled={isDisabledLoad || isEditName}>
                                    <Button type="primary" className="m-margin-r-10">
                                        <span className="btn-text">新建</span>
                                        <Icon type="down" />
                                    </Button>
                                </Dropdown>
                                <ButtonGroup>
                                    <Button type="ghost" disabled={selectedKeys.length === 0}
                                        onClick={this.onClickEnable.bind(this)}>启用</Button>
                                    <Button type="ghost" disabled={selectedKeys.length === 0}
                                        onClick={this.onClickDisable.bind(this)}>禁用</Button>
                                </ButtonGroup>
                            </div>
                        </Col>
                    </Row>
                    <hr />
                    <Row>
                        <Col span="24">
                            <Table {...cfg} />
                        </Col>
                    </Row>
                </div>
            </section>
        );
    }
    //点击菜单
    onClickMenuItem(item) {
        let query = tools.getQuery();
        this.props.router.push({
            pathname: "/documentCenter/edit",
            query: {
                documentId: query.documentId || 0,
                documentType: item.key
            }
        });
    }
    // 转换字节
    formatByte(text) {
        return text < (1024 * 1024) ? (text / 1024).toFixed(2) + "KB" : (2 ^ 20 < text < 2 ^ 30 ? (text / (1024 * 1024)).toFixed(2) + "MB" : '-')
    }
    // 点击【新增文件夹】
    onClickAddFolder(obj) {
        let { documentCenterActs } = this.props;
        let { documentCenterList, conditions } = this.props.$$documentCenterList.toJS();
        let query = tools.getQuery();
        let documentId = query.documentId;

        // 新建文件夹的时候，手动操作后台返回的数据，setState
        // TODO 不调接口，直接操纵 reducer
        documentCenterActs.getDocumentCenterList(conditions).done((obj) => {
            obj.data.list.unshift({
                enabled: true,
                expire_time: null,
                id: "data-" + parseInt(Math.random() * 100),
                parent_id: conditions.id,
                name: "新建文件夹",
                size: null,
                type: Enum.ResourceType.folder,
                isAdd: true
            });
            this.setState({
                dataSourceList: obj.data.list,
                isEditName: true,
                value: "新建文件夹",
            })
        })
    }
    // 点击文件夹或文件名称
    onClickReadFolder(obj) {
        let { documentCenterActs } = this.props;
        if (obj.type == Enum.ResourceType.folder) {
            console.log('-- obj.id --', obj.id)
            documentCenterActs.getDocumentCenterList({
                id: obj.id
            })
            this.setState({
                isEditName: false,
                selectRowId: -1,
                isDisabledLoad: false
            })
            documentCenterActs.getAncestorList(obj.id);
            this.props.router.replace({
                pathname: "/documentCenter/list",
                query: { documentId: obj.id }
            });
        } else {
            this.props.router.push({
                pathname: "/documentCenter/detail",
                query: { documentType: obj.type }
            });
        }
        // else if (obj.type == Enum.ResourceType.imagetxt || obj.type === Enum.ResourceType.wximagetxt) {
        //     tools.showDialog.info("图文详情暂未开放")
        // } else {
        //     let documentId = parseInt(obj.id);
        //     let name = obj.name;
        //     let cookies = tools.getCookies();
        //     document.cookie = `token=${cookies.token}; path=/account`;
        //     if (obj.type == Enum.ResourceType.h5) {
        //         let tempwindow = window.open("", '_blank');
        //         documentCenterActs.getDCPreviewH5(documentId).done((res) => {
        //             tempwindow.location = res.data.data[0];
        //         })
        //     } else {
        //         window.open("/account/documentPreview" + "?documentId=" + documentId + "&name=" + encodeURIComponent(name))
        //     }
        // }
    }
    // 点击路径
    onClickLocation(id) {
        let { documentCenterActs } = this.props;

        this.props.router.push({
            pathname: "/documentCenter/list",
            query: { documentId: id }
        });

    }
    //点击【全部文件】
    onClickAllFile() {
        let { documentCenterActs } = this.props;
        documentCenterActs.reset();
        documentCenterActs.getDocumentCenterList({
            id: 0,
            page_index: 1
        })
        this.setState({
            isDisabledLoad: true
        })
        documentCenterActs.getAncestorList(0);
        this.props.router.push({
            pathname: "/documentCenter/list",
            query: { documentId: 0 }
        });
    }
    //点击面包屑导航
    onClickBread(id) {
        let { documentCenterActs } = this.props;
        documentCenterActs.getDocumentCenterList({
            id: id
        }).done((obj) => {
            this.setState({
                dataSourceList: obj.data.list,
                isEditName: false,
            })
        })
        documentCenterActs.getAncestorList(id);
        this.props.router.replace({
            pathname: "/documentCenter/list",
            query: { documentId: id }
        });
    }
    //鼠标移至更多
    onMouseOverFunc(obj) {
        // TODO setState
        $(".more_" + obj.id).css("display", "block")
    }
    //鼠标移出更多
    onMouseOutFunc(obj) {
        $(".more_" + obj.id).css("display", "none")
    }

    // 点击【重命名】
    onClickRename(obj) {
        let onlyName = obj.name.lastIndexOf('.') == -1 ? obj.name : obj.name.substring(0, obj.name.lastIndexOf('.'));
        this.setState({
            selectRowId: obj.id,
            isAdd: false,
            isEditName: true,
            value: onlyName
        })
    }
    // 点击【编辑】
    onClickEdit(obj) {
        let query = tools.getQuery();
        this.props.router.push({
            pathname: "/documentCenter/edit",
            query: {
                documentId: obj.parent_id,
                documentType: obj.type,
                id: obj.id,
                type: obj.type
            },
        });
    }
    // 重命名后回车
    onPressChange(obj, e) {
        if (e.keyCode === 13) {
            this.onClickFinishRename(obj)
        }
    }
    // 【新增文件夹/重命名】完成
    onClickFinishRename(obj) {
        let { documentCenterActs } = this.props;
        let { value } = this.state;
        let suffix = obj.name.lastIndexOf('.') == -1 ? '' : obj.name.substring(obj.name.lastIndexOf('.'));
        if (obj.isAdd) {
            documentCenterActs.addFolder(obj.parent_id, value).done((res) => {
                if (res.code === 10000) {
                    obj.isAdd = false;
                    documentCenterActs.getDocumentCenterList();
                    this.setState({
                        isEditName: false,
                    })
                }
            });
        } else {
            if ($.trim(value) === "") {
                tools.showDialog.error("文件的名称不能为空")
            } else if ($.trim(value).split(".").length > 1) {
                tools.showDialog.error("文件的名称不能包含“.”")
            } else {
                documentCenterActs.renameDocument(obj.id, value + suffix).done((res) => {
                    if (res.code === 10000) {
                        documentCenterActs.getDocumentCenterList();
                        this.setState({
                            isEditName: false,
                            selectRowId: -1,
                        })
                    }
                })
            }
        }
    }
    // 重命名取消按钮
    onClickCancelRename(obj) {
        let { documentCenterActs } = this.props;
        if (obj.isAdd) {
            documentCenterActs.getDocumentCenterList();
            this.setState({
                isEditName: false,
            })
        } else {
            documentCenterActs.getDocumentCenterList();
            this.setState({
                selectRowId: -1,
                isEditName: false,
            })
        }
    }
    // 点击【删除】
    onClickDelete(obj) {
        let { documentCenterActs } = this.props;
        let { documentCenterList } = this.props.$$documentCenterList.toJS();
        documentCenterActs.deleteDocument(obj.id).done((res) => {
            if (res.code === 10000) {
                documentCenterActs.getDocumentCenterList();
            }
        });
    }

    //下载文件的方法
    // funDownLoad(content,fileName) {
    //     var aLink = document.createElement('a');
    //     var blob = new Blob([content]); //内容不能为url
    //     var evt = document.createEvent("HTMLEvents");
    //     evt.initEvent("click", false, false);//initEvent 不加后两个参数在FF下会报错, 感谢 Barret Lee 的反馈
    //     aLink.download = fileName;
    //     aLink.href = URL.createObjectURL(blob);
    //     aLink.dispatchEvent(evt);
    // }
    download(src, name) {
        let $a = $("<a></a>").attr("href", src).attr("download", name);
        $a[0].click();
    }

    //点击下载（使用ajax进行下载的话，一些图片MP4）
    onClickDownload(obj) {
        let docId = obj.id;
        let cookies = tools.getCookies();
        window.location.href = tools.javaApi("/api/doc/download2") + "/" + obj.id + "?token=" + cookies.token;
    }

    //获取input框中的输入值
    _onInputChange(e) {
        this.setState({
            value: e.target.value
        });
    }

    // 点击【启用】按钮
    onClickEnable() {
        let { documentCenterActs, $$documentCenterList } = this.props;
        let selectedKeys = $$documentCenterList.toJS().selectedKeys;
        // TODO 这个 action 的 action_type 有问题
        documentCenterActs.setCheckedDocumentCenterState(selectedKeys).done((data) => {
            documentCenterActs.getDocumentCenterList();
        });
    }
    // 点击【禁用】按钮
    onClickDisable() {
        let { documentCenterActs, $$documentCenterList } = this.props;
        let selectedKeys = $$documentCenterList.toJS().selectedKeys;
        // TODO 这个 action 的 action_type 有问题
        documentCenterActs.setCheckedDisabled(selectedKeys).done((data) => {
            documentCenterActs.getDocumentCenterList();
        });
    }
    //文档前的图片
    getDocumentImg(obj) {
        let documentImg;
        let suffix;
        if (obj.type == Enum.ResourceType.normal) {
            if (obj.name) {
                suffix = obj.name.substring(obj.name.lastIndexOf('.') + 1);
            }
            switch (suffix) {
                // 普通文档
                case "doc":
                case "DOC":
                case "docx":
                case "DOCX":
                    documentImg = Img.word;
                    break;
                case "mp4":
                case "MP4":
                    documentImg = Img.mp4;
                    break;
                case "pdf":
                case "PDF":
                    documentImg = Img.pdf;
                    break;
                case "ppt":
                case "PPT":
                case "pptx":
                case "PPTX":
                    documentImg = Img.ppt;
                    break;
                // 图片
                case "jpg":
                case "JPG":
                case "jpeg":
                case "JPEG":
                case "png":
                case "PNG":
                case "bmp":
                case "BMP":
                    documentImg = Img.image;
                    break;
            }
        } else {
            switch (obj.type) {
                //文件夹
                case Enum.ResourceType.folder:
                    documentImg = Img.folder;
                    break;
                //外部链接
                // case 2:
                //多图文
                case Enum.ResourceType.wximagetxt:
                    documentImg = Img.WX;
                    break;
                //h5
                case Enum.ResourceType.h5:
                    documentImg = Img.h5;
                    break;
                //单图文
                case Enum.ResourceType.imagetxt:
                    documentImg = Img.Graphic;
                    break;
            }
        }
        return documentImg;
    }
}
DocumentCenterList = Form.create()(DocumentCenterList);

export default connect(
    (state) => {
        return {
            $$documentCenterList: state.$$documentCenterList,
            $$layout: state.$$layout
        }
    },
    (dispatch) => {
        return {
            documentCenterActs: bindActionCreators(Actions, dispatch)
        }
    })(withRouter(DocumentCenterList))
