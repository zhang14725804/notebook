import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/documentCenter"
import { Enum, EnumCn } from "enum"
import { tools } from "utils"
import Modal from "antd/lib/modal"
import Icon from "antd/lib/icon"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import Dropdown from "antd/lib/dropdown"
import Table from "antd/lib/table"
import Menu from "antd/lib/menu"
import Tag from "antd/lib/tag"
import Radio from "antd/lib/radio"
import Steps from "antd/lib/steps"
import Upload from "antd/lib/upload"
import Collapse from "antd/lib/collapse"
import Checkbox from "antd/lib/checkbox"
import Select from "antd/lib/select"
import DatePicker from "antd/lib/date-picker"

const Step = Steps.Step;
const RadioGroup = Radio.Group;
const Dragger = Upload.Dragger;
const Panel = Collapse.Panel;
const FormItem = Form.Item;
const CheckboxGroup = Checkbox.Group;
const Option = Select.Option;

//step4: 发布文档
class _FourthStep extends React.Component {
    constructor(props) {
        super(props);
    }
    componentDidMount() {

    }
    render() {
        let cfg = {
            dataSource: [{"id": 1, "name": "133645"}],
            rowKey: r => r.id,
            columns: [
                {
                    title: "名称",
                    dataIndex: "name",
                    key: "name",
                }
            ]
        }
        return (
            <div className="m-margin-t">
               <Table {...cfg}></Table> 
            </div>
        )
    }
}

export default _FourthStep
