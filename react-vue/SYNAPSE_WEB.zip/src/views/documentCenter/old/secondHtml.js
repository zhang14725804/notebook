import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/documentCenter"
import { Enum, EnumCn } from "enum"
import { tools } from "utils"
import Modal from "antd/lib/modal"
import Icon from "antd/lib/icon"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import Dropdown from "antd/lib/dropdown"
import Table from "antd/lib/table"
import Menu from "antd/lib/menu"
import Tag from "antd/lib/tag"
import Radio from "antd/lib/radio"
import Steps from "antd/lib/steps"
import Upload from "antd/lib/upload"
import Collapse from "antd/lib/collapse"
import Checkbox from "antd/lib/checkbox"
import Select from "antd/lib/select"
import DatePicker from "antd/lib/date-picker"

const Step = Steps.Step;
const RadioGroup = Radio.Group;
const Dragger = Upload.Dragger;
const Panel = Collapse.Panel;
const FormItem = Form.Item;
const CheckboxGroup = Checkbox.Group;
const Option = Select.Option;
//step2: 上传文档
class _SecondHtml extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isToLong: false,
            value: 1,
            inputValue: "",
            fileName: ""
        }
    }
    componentDidMount() {
    }
    render() {
        let fieldDecorator = this.props.fieldDecorator;
        var _this = this;
        let {documentCenterEditActs} = this.props;
        // console.log("---this.props----",this.props)
        const formItemLayout = {
            labelCol: { span: 4 },
            wrapperCol: { span: 16 }
        };
        let {fileName} = this.state;
        let nowTime = (new Date()).getTime();
        let fileNameSuffix = fileName.substring(fileName.indexOf("."));
        let fileNameOnly = fileName.replace(fileName.substring(fileName.indexOf(".")),"")
        let finalName= fileNameOnly + "-" + nowTime + fileNameSuffix;
        let cookie = tools.getCookies();
        const cfg = {
            name: 'file',
            showUploadList: true,
            multiple: false,
            action: tools.javaApi("/api/doc/upload"),
            data: {
                "type": 3,
                "name": finalName
            },
            headers:{'token':cookie.token},
            onChange(info) {
                const status = info.file.status;
                if (info.fileList.length == 1) {
                    let isToLong = _this.state.isToLong;
                    _this.setState({
                        isToLong: true
                    });
                }
                if (status == 'uploading') {
                    documentCenterEditActs.saveUploadStatus(true)
                }
                if (status === 'done') {
                    documentCenterEditActs.saveUploadStatus(false)
                    if (info.file.response.code === 10000) {
                        console.log("-- info.file.response.data --",info.file.response.data)
                        tools.showDialog.success("上传成功");
                        documentCenterEditActs.saveFile(info.file.response.data)                     
                    } else {
                        // tools.showDialog.error("文档名称包含非法字符")
                        tools.showDialog.error(info.file.response.msg);
                    }
                }
                if (status === "removed") {
                    _this.setState({
                        isToLong: false
                    })
                    documentCenterEditActs.saveUploadStatus(false);
                    documentCenterEditActs.saveFile([]);  //清除上一个文件的信息
                }
                 else if (status === 'error') {
                }
            }
        };
        return (
            <div>
                <Row style={{marginTop:"80px"}}> 
                    <Col span="8"></Col>
                    <Col span="10">
                        <FormItem>
                            <RadioGroup onChange={this.onChangeStyle.bind(this)} value={this.state.value}>
                                <Radio key="0" value={1} style={{marginRight:"100px"}}>上传HTML5文件包</Radio>
                                <Radio key="1" value={2}>使用URL外部链接</Radio>
                            </RadioGroup>
                        </FormItem>
                    </Col>
                </Row>
                { this.state.value == 1 ? 
                    <Row>
                        <div style={{textAlign:"center"}}>
                            HTML5  压缩包（.zip）， 请您将文件打包为 ZIP 文件再进行拖入或上传，H5文件需包含 index 文件及使用相对路径
                        </div>
                        <div style={{ margin: "2rem auto", height: 400, width:1000 }}>
                            <Dragger {...cfg} beforeUpload={this.beforeUpload.bind(this)} disabled={this.state.isToLong}>
                                <p className="ant-upload-drag-icon">
                                    <Icon type="inbox" />
                                </p>
                                <p className="ant-upload-text">点击或将文件拖拽到这里上传</p>
                            </Dragger>
                        </div>
                    </Row> : 
                    <Row>
                        <FormItem label="URL"
                            {...formItemLayout}>
                                <Input
                                    type="text"
                                    placeholder="http:// 或 https://" value={this.state.inputValue} onChange={this.onChangeURL.bind(this)} />
                                <Button type="primary" onClick={this.onClickTestURL.bind(this)} style={{float:"Right",marginTop:"1rem"}}>测试 URL</Button>
                        </FormItem>
                        {/*<FormItem label="作者（选填）"
                            {...formItemLayout}>
                                <Input
                                    type="text"
                                    placeholder="请输入" />
                        </FormItem>
                        <FormItem label="导语（选填）"
                            {...formItemLayout}>
                                <Input
                                    type="textarea"
                                    placeholder="请输入" />
                        </FormItem>*/}
                    </Row>}
                
            </div>
        )
    }
    onChangeStyle(e) {
        // console.log("----e.target.value----",e.target.value)
        let {documentCenterEditActs} = this.props;
        documentCenterEditActs.getHtmlType(e.target.value);
        this.setState({
            value: e.target.value
        });

    }
    onChangeURL(e) {
        // console.log("----e.target.value----",e.target.value)
        let {documentCenterEditActs} = this.props;
        documentCenterEditActs.saveHtmlURL($.trim(e.target.value));
        this.setState({
            inputValue: e.target.value
        });
    }
    onClickTestURL() {
        let {inputValue} = this.state;
        if(inputValue.indexOf("http") == -1) {
            window.open("http://" + $.trim(this.state.inputValue));
        }else {
            window.open($.trim(this.state.inputValue));
        }
    }
    beforeUpload(file,fileList) {
        this.setState({
            fileName: file.name
        })
        if(file.name.indexOf("zip") === -1) {
            tools.showDialog.error('不支持该类型文件上传');
            return false;
        }
    }
}

export default _SecondHtml
