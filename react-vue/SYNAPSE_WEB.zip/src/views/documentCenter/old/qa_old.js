import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/qa"
import * as CommonActions from "actions/common"
import { tools } from "utils"
import { Enum, EnumCn } from "enum"
import Upload from "components/upload"
import Button from "antd/lib/button"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Collapse from "antd/lib/collapse"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Select from "antd/lib/select"
import Checkbox from "antd/lib/checkbox"
import Modal from "antd/lib/modal"
import Radio from "antd/lib/radio"
import Icon from "antd/lib/icon"
import Switch from "antd/lib/switch"
const Option = Select.Option
const FormItem = Form.Item
const Panel = Collapse.Panel
const RadioGroup = Radio.Group

class _FirstQa extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isAddShow: false, //添加习题
            isScore: false,   //设置分值
            query: props.location.query,
            isEdit: !!props.location.query.qaId,
        }
    }
    componentDidMount() {
        let { commonActs, documentCenterEditActs, form } = this.props;
        let { query, isEdit } = this.state;
        // documentCenterEditActs.reset()
        if (isEdit) {
            // 编辑页面
        }
    }
    render() {
        const { documentCenterEditActs, form } = this.props;
        const { qa } = this.props.$$documentCenterEdit.toJS();
        const fieldProps = this._getFieldProps();
        //题目列表
        const optProps = {
            style: {
                display: "block",
                lineHeight: "32px",
                whiteSpace: 'normal'
            }
        };
        const qaListJSX = $.map(form.getFieldValue("question"), (item, i) => {
            let optJSX = null;
            const optProps = {
                style: {
                    display: "block",
                    lineHeight: "32px",
                    whiteSpace: 'normal'
                },
                disabled: true
            };
            if (item.type == Enum.QuestionType.answer) {
                //问答
                optJSX = (<div></div>);
            } else if (item.type == Enum.QuestionType.radio) {
                //单选
                optJSX = $.map(item.options, (opt) => {
                    return <Radio
                        key={opt.id}
                        checked={opt.isRight}
                        {...optProps}>{opt.content}</Radio>
                });
            } else if (item.type == Enum.QuestionType.checkbox) {
                //多选
                optJSX = $.map(item.options, (opt) => {
                    return <Checkbox
                        key={opt.id}
                        checked={opt.isRight}
                        {...optProps}>{opt.content}</Checkbox>
                });
            }
            return (
                <li key={i}>
                    <Row>
                        <Col span="22">
                            <div>Q{i + 1}.{item.head} {item.score ? `（${item.score}分）` : null}</div>
                            <div>{optJSX}</div>
                        </Col>
                        <Col span="2" className="qa-operate">
                            <div className="qa-operate-btn" onClick={this.onClickUp.bind(this, i)}><Icon type="up" /></div>
                            <div className="qa-operate-btn" onClick={this.onClickDown.bind(this, i)}><Icon type="down" /></div>
                            <div className="qa-operate-btn" onClick={this.onClickEdit.bind(this, item.question_id)}><Icon type="edit" /></div>
                            <div className="qa-operate-btn" onClick={this.onClickDelete.bind(this, item.question_id)}><Icon type="delete" /></div>
                        </Col>
                    </Row>
                </li>
            );
        });

        return (
            <section id="qa-edit">
                <Form>
                    <Row className="m-margin-b m-edit-header">
                        <Col span="24">
                            <Col span="4" className="m-edit-title">{this.state.isEdit ? "编辑问卷" : "新增问卷"}</Col>
                        </Col>
                    </Row>
                    <Collapse defaultActiveKey={["1", "2", "3"]}>
                        <Panel key="1" header={
                            <span>
                                <span>撰写问卷</span>
                                <a
                                    className="qa-btn-add"
                                    onClick={this.onClickAdd.bind(this)}>新增一题
                                </a>
                            </span>}>
                            <FormItem>
                                {fieldProps.question(
                                    <ul className="qa-content">
                                        {qaListJSX}
                                    </ul>
                                )}
                            </FormItem>
                        </Panel>
                    </Collapse>
                </Form>
                <div className="m-handle-btn">
                    <div className="wrap">
                        <Button type="primary" onClick={this.onClickSave.bind(this)}>保存</Button>
                    </div>
                </div>
                <Modal
                    visible={this.state.isAddShow}
                    title="新增问题"
                    width="800px"
                    onCancel={this.onAddClose.bind(this)}
                    footer={[
                        <Button key={tools.getRandom()} type="primary" onClick={this.onAddConfirm.bind(this)}>确定</Button>
                    ]}>
                    <_Form_Add {...this.props} />
                </Modal>
            </section>
        )
    }

    //保存问卷
    onClickSave() {
        let { documentCenterEditActs, form } = this.props;
        let { query, isEdit } = this.state;
        form.validateFieldsAndScroll((errors, values) => {
            if (!!errors) {
                tools.showDialog.error("请补全提交信息");
                return;
            }
            const fields = $.extend(true,
                {},
                form.getFieldsValue(),
                isEdit ? $.extend(true, { id: query.qaId }, this._getQuesUpdate()) : {},
            );
            documentCenterEditActs.saveDcQA(fields, isEdit).done((res) => {
                if (res.code === 10000) {
                    if (query.isCreateMaterial === "true") {
                        this.props.router.push({
                            pathname: "/expQa/edit",
                            query: $.extend({}, query, {
                                material_id: isEdit ? fields.id : res.data,
                                material_type: Enum.DocumentType.qa,
                                docType: Enum.NewsPlatform.both,
                                material_title: fields.title,
                            })
                        });
                    } else {
                        this.props.router.push({
                            pathname: "/qa/detail",
                            query: {
                                qaId: isEdit ? fields.id : res.data
                            }
                        });
                    }
                }
            });
        });
    }
    //获取编辑状态下，新增、删除、修改的题目
    _getQuesUpdate() {
        let { $$documentCenterEdit, form } = this.props;
        let prevList = $$documentCenterEdit.toJS().qa.question;
        let curList = form.getFieldsValue().question;
        let add = [], up = [], del = [];
        //获取add、up
        $.map(curList, cur => {
            $.map(prevList, prev => {
                if (cur.question_id === prev.question_id && !Immutable.fromJS(cur).equals(Immutable.fromJS(prev))) {
                    //更新
                    up.push(cur);
                }
            });
            if ($.inArray(cur.question_id, prevList.map(item => item.question_id)) < 0) add.push(cur);
        });

        //获取del
        $.map(prevList, prev => {
            if ($.inArray(prev.question_id, curList.map(item => item.question_id)) < 0) del.push(prev);
        });
        return {
            add: add,
            del: del,
            up: up
        }
    }
    //排序题目
    _orderQues(arr) {
        return arr.map((item, i) => $.extend(true, {}, item, {
            order: i.toString()
        }));
    }

    //添加一题
    onClickAdd(e) {
        e.stopPropagation();
        this._openAddWindow();
    }
    //上移一题
    onClickUp(i) {
        let { getFieldValue, setFieldsValue } = this.props.form;
        let arr = getFieldValue("question");
        if (i <= 0) return;
        arr[i] = arr.splice(i - 1, 1, arr[i])[0];
        setFieldsValue({
            question: this._orderQues(arr)
        });
    }
    //下移一题
    onClickDown(i) {
        let { getFieldValue, setFieldsValue } = this.props.form;
        let arr = getFieldValue("question");
        if (i >= arr.length - 1) return;
        arr[i] = arr.splice(i + 1, 1, arr[i])[0];
        setFieldsValue({
            question: this._orderQues(arr)
        });
    }
    //编辑题目
    onClickEdit(quesId) {
        let { form, documentCenterEditActs } = this.props;
        let ques = null;
        $.map(form.getFieldValue("question"), q => {
            if (q.question_id === quesId) ques = q;
        });
        if (ques != null) {
            this._openAddWindow(ques);
            documentCenterEditActs.setDcQuestion(ques);
        }
    }
    //删除题目
    onClickDelete(quesId) {
        tools.showDialog.confirm("确认删除选中的题目？",
            () => {
                let { getFieldValue, setFieldsValue } = this.props.form;
                let arr = getFieldValue("question");
                setFieldsValue({
                    question: this._orderQues($.grep(arr, item => item.question_id != quesId))
                })
            });
    }
    //点击【添加题目】弹窗确定按钮
    onAddConfirm() {
        //校验
        if (this._getQuesVali() === false) return;
        let { $$documentCenterEdit, form } = this.props;
        let ques = $$documentCenterEdit.toJS().question;//单个题目
        let questionList = form.getFieldValue("question");//题目列表
        let isEdit = $.grep(questionList, q => q.question_id === ques.question_id).length > 0;

        form.setFieldsValue({
            question: isEdit ?
                this._orderQues($.map(questionList, q => q.question_id === ques.question_id ? ques : q)) :
                this._orderQues(questionList.concat(ques))
        });
        this._closeAddWindow();
    }
    //关闭添加题目弹窗
    onAddClose() {
        this._closeAddWindow();
    }
    //校验字段
    _getQuesVali() {
        let res = false;
        let { $$documentCenterEdit } = this.props;
        let ques = $$documentCenterEdit.toJS().question;//单个题目
        const patt = /^[0-9]+$/;
        console.log("校验字段：：", ques);

        if (ques.head == null || ques.head.length === 0) {
            tools.showDialog.error("请填写题目");
        } else if (ques.head.length > 150) {
            tools.showDialog.error("题目不得超过150个字符");
        } else if (ques.score == null || ques.score.length === 0) {
            tools.showDialog.error("请填写分值");
        } else if (ques.score != null && !patt.test(parseFloat(ques.score))) {
            tools.showDialog.error("分值格式需为正整数");
        } else if (ques.type != Enum.QuestionType.answer) {
            if (ques.options == null || ques.options.length < 2) {
                tools.showDialog.error("选择题备选项数目需大于1");
            } else if ($.grep(ques.options, opt => opt.content.length > 0).length < ques.options.length) {
                tools.showDialog.error("请补全选项");
            } else if ($.grep(ques.options, (opt, i) => $.inArray(opt.content, $.map(ques.options.slice(i + 1), o => o.content)) > -1).length > 0) {
                tools.showDialog.error("存在相同的选项");
            } else if (ques.type == Enum.QuestionType.checkbox) {
                var Rtotal = 0;
                for (var i = 0; i < ques.options.length; i++) {
                    ques.options[i].isRight ? Rtotal++ : '';
                }
                Rtotal < 2 ? tools.showDialog.error("多选题正确答案数需大于1") : res = true;
            } else if (ques.type == Enum.QuestionType.radio) {
                var Rtotal = 0;
                for (var i = 0; i < ques.options.length; i++) {
                    ques.options[i].isRight ? Rtotal++ : '';
                }
                Rtotal < 1 ? tools.showDialog.error("单选题正确答案数需大于0") : res = true;
            } else {
                res = true;
            }
        } else {
            res = true;
        }
        return res;
    }
    //打开弹窗
    _openAddWindow(ques) {
        this.setState({
            isAddShow: true
        });
        //设置当前题目id
        let { documentCenterEditActs } = this.props;
        documentCenterEditActs.setDcQuestion({
            question_id: tools.getRandom()
        });
    }
    //关闭弹窗
    _closeAddWindow() {
        let { documentCenterEditActs } = this.props;
        documentCenterEditActs.resetDcQuestion();
        this.setState({
            isAddShow: false
        });
    }
    //获取存在的信息点id
    _getExistKm(kmIds) {
        let { $$common, form } = this.props;
        let allKmIds = $.map($$common.toJS().kms, item => item.id);
        //检查信息点是否存在
        let dstKmIds = $.grep(kmIds, id => {
            return $.inArray(id, allKmIds) >= 0;
        });
        form.setFieldsValue({
            km_ids: dstKmIds
        });
    }
    //获取字段属性
    _getFieldProps() {
        let { getFieldDecorator } = this.props.form;
        let qa = this.props.$$documentCenterEdit.toJS().qa;
        return {
            //编辑qa时，获取新增的题目
            add: getFieldDecorator("qa_add", {
                initialValue: qa.add
            }),
            //编辑qa时，获取修改的题目
            up: getFieldDecorator("qa_up", {
                initialValue: qa.up
            }),
            //编辑qa时，获取删除的题目
            del: getFieldDecorator("qa_del", {
                initialValue: qa.del
            }),
            //题目列表
            question: getFieldDecorator("question", {
                initialValue: qa.question,
                rules: [
                    {
                        validator: (rule, value, cb) => {
                            value == null || value.length === 0 ? cb("请添加题目") : cb();
                        }
                    }
                ]
            }),
        };
    }
}


//添加题目
class _Form_Add extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        let { question } = this.props.$$documentCenterEdit.toJS();
        //类型下拉选选项
        let typeOptJSX = $.map(EnumCn.QuestionType, (val, key) => { if ($.isNumeric(key)) return (<Option key={key} value={key}>{val}</Option>) });
        //选项
        let optsJSX = $.map(question.options || [], item => (
            <li key={item.id} >
                <span className="qe-opt-wrap">
                    <Input
                        className="qe-opt-input"
                        value={item.content}
                        onChange={function (e) { this.onChangeOpt.call(this, item.id, e.target.value) }.bind(this)} />
                    <Icon
                        type="cross"
                        className="qe-opt-cross"
                        onClick={this.onRemoveOpt.bind(this, item.id)} />
                </span>
                {
                    question.type == Enum.QuestionType.radio ?
                        <Radio
                            value={item.id}
                            checked={item.isRight}
                            onChange={this.onChangeRadio.bind(this)}>正确答案</Radio> :
                        <Checkbox
                            value={item.id}
                            checked={item.isRight}
                            onChange={this.onChangeCheckbox.bind(this)}>正确答案</Checkbox>
                }
            </li>
        ));
        //是否显示选项
        let isShowOption = question.type == Enum.QuestionType.answer ? false : true;
        return (
            <Form className="qe-ques-wrap">
                <Row>
                    <Col span="6">
                        <FormItem>
                            <div>选择问题类型：</div>
                            <Select
                                value={question.type.toString()}
                                placeholder="请选择"
                                onChange={this.onChangeType.bind(this)}>
                                {typeOptJSX}
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="16" offset="2">
                        <FormItem>
                            <div>设置-题目：</div>
                            <Input.TextArea
                                placeholder="输入题目"
                                value={question.head}
                                onChange={this.onChangeContent.bind(this)} />
                        </FormItem>

                        <FormItem style={this.props.isScore ? { "display": "block" } : { "display": "none" }}>
                            <div>设置-分值：</div>
                            <Input
                                placeholder="输入正整数"
                                type="number"
                                value={question.score}
                                onChange={this.onChangeScore.bind(this)} />
                        </FormItem>

                        <div style={{ display: isShowOption ? "block" : "none" }}>
                            <hr />
                            <FormItem>
                                <div>设置-备选项：</div>
                                <ul>{optsJSX}</ul>
                                <div className="qe-ques-add" onClick={this.onAddOpt.bind(this)} >
                                    <Icon type="plus" /><span>添加</span>
                                </div>
                            </FormItem>
                        </div>
                    </Col>
                </Row>
            </Form>
        );
    }
    //切换问题类型时执行
    onChangeType(key) {
        let { documentCenterEditActs } = this.props;
        documentCenterEditActs.setDcQuestion({
            type: key
        });
    }
    //变更题目内容时执行
    onChangeContent(e) {
        let { documentCenterEditActs } = this.props;
        documentCenterEditActs.setDcQuestion({
            head: e.target.value
        });
    }
    //变更分值时执行  
    onChangeScore(e) {
        let { documentCenterEditActs } = this.props;
        documentCenterEditActs.setDcQuestion({
            score: e.target.value
        });
    }
    //切换单选钮时执行
    onChangeRadio(e) {
        let { documentCenterEditActs } = this.props;
        documentCenterEditActs.updateDcQaRadioState(e.target.value);
    }
    //切换复选钮时执行
    onChangeCheckbox(e) {
        let { documentCenterEditActs } = this.props;
        documentCenterEditActs.updateDcQaCheckboxState(e.target.value);
    }
    //点击添加选项执行
    onAddOpt() {
        let opt = {
            id: tools.getRandom(),
            content: "",
            isRight: false
        }
        let { documentCenterEditActs, $$documentCenterEdit } = this.props;
        documentCenterEditActs.setDcQuestion({
            options: ($$documentCenterEdit.toJS().question.options || []).concat(opt)
        });
    }
    //点击删除选项执行
    onRemoveOpt(optId) {
        let { documentCenterEditActs } = this.props;
        documentCenterEditActs.removeDcQaOption(optId);
    }
    //变更选项输入框内容
    onChangeOpt(id, value) {
        let { documentCenterEditActs } = this.props;
        documentCenterEditActs.updateDcQaOptContent(id, value);
    }
}



export default _FirstQa;
