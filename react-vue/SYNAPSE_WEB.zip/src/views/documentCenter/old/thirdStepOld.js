import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/documentCenter"
import { Enum, EnumCn } from "enum"
import { tools } from "utils"
import Icon from "antd/lib/icon"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import Tag from "antd/lib/tag"
import Radio from "antd/lib/radio"
import Upload from "antd/lib/upload"
import Collapse from "antd/lib/collapse"
import Checkbox from "antd/lib/checkbox"
import Select from "antd/lib/select"
import DatePicker from "antd/lib/date-picker"
import moment from "moment"
import Slider from 'react-slick';
import TreeSelect from 'antd/lib/tree-select';

const RadioGroup = Radio.Group;
const Panel = Collapse.Panel;
const FormItem = Form.Item;
const CheckboxGroup = Checkbox.Group;
const Option = Select.Option;
const TreeNode = TreeSelect.TreeNode;

const checkboxShareLimit = [
    { label: "内部分享", value: "1" },
    { label: "外部分享", value: "3" },
]
const checkboxWatermark = [
    { label: "客户端显示用户名信息水印", value: "1" },
    { label: "客户端自定义显示水印", value: "3" } 
]

//step3: 配置详情
class _ThirdStep extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isEdit: !!props.location.query.id,
            visible: false,
            checkedDate: false,
            query: props.location.query,
            checkedId:[],
            currentPage: 1,
            keyValue: 1,
            checkedKeyMsg: [],
            fileName: "",
            selectVal: [],
            previewImage: ''
        }
        this.dataList = [];
    }
    componentDidMount() {
        let {file,relatedTreeTrue,DCConfig} = this.props.$$documentCenterEdit.toJS();        
        let _this = this;
        let { documentCenterEditActs } = this.props;
        let documentId = this.state.query.documentId;
        let docId = this.state.query.id;
        let docType = this.state.query.type;
        documentCenterEditActs.getDCRelatedBrand();
        documentCenterEditActs.getTherapeuticArea();
        if(!this.state.isEdit) {
            documentCenterEditActs.getPreviewImg(file.file_name); 
        }
        this.generateList(relatedTreeTrue);
        documentCenterEditActs.getDCRelatedTreeTrue().done((obj) => {
            _this.generateList(obj.data)
        });
        if(this.state.isEdit) {
            let docId = this.state.query.id;
            let docType = this.state.query.type;
            documentCenterEditActs.getDCConfigDetail(docId,docType).done((resp) => {
                let {DCConfig} = this.props.$$documentCenterEdit.toJS();
                
                if(this.props.location.query.type==1 || this.props.location.query.type==3){
                    this.setState({
                        checkedDate: DCConfig[0].expire_time==null ? true : false,
                        keyValue: DCConfig[0].key_messages.length > 0 ? (DCConfig[0].key_messages[0].page_index == 0 ? 1 : 2) : 1  
                    })
                }
            })
        }
        
    }
    render() {
        const formItemLayout = {
            labelCol: { span: 6 },
            wrapperCol: { span: 18 }
        };
        const formItemLayoutMark = {
            labelCol: { span: 5 },
            wrapperCol: { span: 15 }
        };
        let documentLimitEnum = {
            "1": "工作中心",
            "3": "活动中心",
            "5": "知识中心",
            "7": "Synapse"
        }
        let cookie = tools.getCookies();
        const uploadCfg = {
            multiple: false,
            action: tools.javaApi("/api/doc/upload"),
            listType: 'picture',
            data: {
                "type": 101,
            },
            headers:{'token':cookie.token}
        }
        let fieldDecorator = this.props.fieldDecorator;
        let { brands, therapeutic, allkp,previewImg,relatedTreeTrue,checked,file,tagkeys,equalTreeData,DCConfig } = this.props.$$documentCenterEdit.toJS();
        const documentLimitJSX = Object.getOwnPropertyNames(documentLimitEnum).map((item, index) => {
            return <Option key={item} value={item}>{documentLimitEnum[item]}</Option>
        })
        let brandsJSX = [];
        let therapeuticJSX = [];
        let keyMessageJSX = [];
        let tagViewArr = [];
        let previewImgJSX = [];
        let previewImgs = null;
        tagkeys.map((item,index) => {
            tagViewArr.push(<Tag closable key={index}>{item.name}</Tag>)
        })
        brands.map((item, index) => {
            brandsJSX.push(
                <Option value={item.name} key={index + Math.random()}>{item.name}</Option>
            )
        });
        therapeutic.map((item, index) => {
            therapeuticJSX.push(
                <Option key={item.id + Math.random()} value={item.name}>{item.name}</Option>
            )
        });
        (allkp || []).map((item, index) => {
            keyMessageJSX.push(
                <Option key={item.id + Math.random()} value={item.id.toString()}>{item.name}</Option>
            )
        });
        let previewImgCfg = {
            infinite: false,
			initialSlide: 0,
            speed: 500,
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows:true
        };
        if(Array.isArray(previewImg.data)){
            previewImg.data.map((item, index) => {
                previewImgJSX.push(
                    <div key={index}>
                        <img width="100%"
                            src={item} />
                    </div>
                )
            });
        }
        previewImgs = (
            <Slider {...previewImgCfg}
                beforeChange={this.onBeforeChange.bind(this)}>
                {previewImgJSX.length === 0 ? (
                    <div style={{ visibility: "hidden" }}>
                        <img width="400" height="300" />
                    </div>
                ) : previewImgJSX}
            </Slider>
        )
        let tagTreeNodes = this.loop(relatedTreeTrue ? relatedTreeTrue : []);
        let { checkedId } = this.state;
        let keyLable = this.state.keyValue === 1 ? "信息点" : `第${this.state.currentPage}页信息点`;
        let allPage = Array.isArray(previewImg.data) ? previewImg.data.length : null;
        const { getFieldDecorator } = this.props.form;
        let documentSuffix = this.state.isEdit ? (DCConfig.length > 0 ? (DCConfig[0].document_name.lastIndexOf(".") == -1 ? "" : DCConfig[0].document_name.substring(DCConfig[0].document_name.lastIndexOf("."))) : "") : (file.file_name ? file.file_name.substring(file.file_name.lastIndexOf(".")) : "");
        let keyInfoItemJSX = [];
        let keymessageIds = [];
        if(DCConfig.length > 0 && DCConfig[0].key_messages.length > 0) {
            DCConfig[0].key_messages.map((item) => {
                keymessageIds.push(item.keymessage_id.toString());
            });
        }
        if(this.state.keyValue == 1) {
            keyInfoItemJSX.push(
                <FormItem label="" key="key_info"
                    {...formItemLayout}>
                    {getFieldDecorator("key_info",{
                        // initialValue: (DCConfig.length > 0 && DCConfig[0].key_messages.length > 0) ? (DCConfig[0].key_messages[0].page_index == 0 ? [DCConfig[0].key_messages[0].keymessage_id.toString()] : []) : [],
                        initialValue: (DCConfig.length > 0 && DCConfig[0].key_messages.length > 0) ? (DCConfig[0].key_messages[0].page_index == 0 ? keymessageIds : []) : [],
                    })(
                        <Select onChange={this.onChangeKeyMsg.bind(this,this.state.currentPage)} multiple placeholder="请选择">
                            {keyMessageJSX}
                        </Select>
                    )}
                </FormItem>
            )
        }else {
            for(let i=1; i<=allPage; i++) {
                let keyMsgId = [];
                if(this.state.isEdit) {
                    DCConfig[0].key_messages.map((obj) => {
                        if(obj.page_index == i) {
                            keyMsgId.push(obj.keymessage_id.toString())
                        }
                    })
                }
                keyInfoItemJSX.push(
                    <FormItem label="" key={i}
                        style={{display: i==this.state.currentPage ? 'block' : 'none'}}
                        {...formItemLayout}>
                        {getFieldDecorator(`key_info_${i}`,{
                            initialValue: keyMsgId
                        })(
                            <Select onChange={this.onChangeKeyMsg.bind(this,this.state.currentPage)} multiple placeholder="请选择">
                                {keyMessageJSX}
                            </Select>
                        )}
                    </FormItem>
                )
            }
        }
        return (
            <div>
                <div className="m-handle-btn" style={{marginTop: "-120px"}}>
                    <Button 
                        type="primary" 
                        className="m-margin-r" 
                        onClick={this.onClickSave.bind(this)}>保存</Button>
                </div>
                <Collapse className="m-margin-t" defaultActiveKey={["1"]}>
                    <Panel header="配置文档详情" key="1">
                        <Row>
                            <Col span="12">
                                <Col span="18">
                                    <div className="m-edit-title m-margin-b">设置基本信息</div>
                                    <FormItem label="文档名称："
                                        {...formItemLayout}>
                                        {fieldDecorator.name(
                                            <Input
                                                type="text"
                                                addonAfter={documentSuffix}
                                                placeholder="请输入内容" />
                                        )}
                                    </FormItem>
                                    <FormItem label="关联产品："
                                        {...formItemLayout}>
                                        {fieldDecorator.brand_ids(
                                            <Select showSearch placeholder="请选择" disabled>
                                                {brandsJSX}
                                            </Select>
                                        )}
                                    </FormItem>
                                    <FormItem label="治疗领域："
                                        {...formItemLayout}>
                                        {fieldDecorator.therapeutic_areas(
                                            <Select multiple placeholder="请选择" disabled>
                                                {therapeuticJSX}
                                            </Select>
                                        )}
                                    </FormItem>
                                    <FormItem label="过期时间："
                                        {...formItemLayout}>
                                        {fieldDecorator.expire_time_basic(
                                            <DatePicker
                                                style={{width: "60%"}}
                                                showToday={false}
                                                disabled={this.state.checkedDate}
                                                disabledDate={this.disabledDate.bind(this)} />
                                        )}
                                        <Checkbox className="m-margin-l neverOutDate" 
                                            checked={this.state.checkedDate}
                                            onClick={this.onClickNeverOutdate.bind(this)}>永不过期</Checkbox>
                                    </FormItem>
                                    <FormItem label="上传封面："
                                        style={{ clear: "both" }}
                                        {...formItemLayout}>
                                        {fieldDecorator.cover_image(
                                            <Upload {...uploadCfg} onChange={this.onChangeCoverImg.bind(this)} beforeUpload={this.beforeUpload.bind(this)}>
                                                <Button>
                                                    <Icon type="upload" />点击上传
                                                </Button>
                                            </Upload>
                                        )}
                                    </FormItem>
                                    <FormItem label="文档权限："
                                        {...formItemLayout}>
                                        {fieldDecorator.use_scopes(
                                            <Select
                                                multiple
                                                placeholder="请选择">
                                                {documentLimitJSX}
                                            </Select>
                                        )}
                                    </FormItem>
                                    <FormItem label="分享权限："
                                        {...formItemLayout}>
                                        {fieldDecorator.share_scopes(
                                            <CheckboxGroup options={checkboxShareLimit} />
                                        )}
                                    </FormItem>
                                    <FormItem label="文档介绍"
                                        {...formItemLayout}>
                                        {fieldDecorator.introduction(
                                            <Input
                                                type="textarea"
                                                placeholder="请输入内容" />
                                        )}
                                    </FormItem>
                                    <FormItem label="水印"
                                        {...formItemLayoutMark}>
                                        <CheckboxGroup options={checkboxWatermark} />
                                        {fieldDecorator.water_mark(
                                            <Input type="text" placeholder="水印内容" />
                                        )}
                                    </FormItem>
                                </Col>
                            </Col>
                            <Col span="12">
                                <Col span="18">
                                    <div className="m-edit-title m-margin-b">设置页面信息点</div>
                                    <FormItem {...formItemLayout}>
                                        {fieldDecorator.key_type(
                                            <RadioGroup onChange={this.onChangeKeytype.bind(this)}>
                                                <Radio value={1}>统一设置文档信息点</Radio>
                                                <Radio value={2}>分别设置文档信息点</Radio>
                                            </RadioGroup>
                                        )}
                                    </FormItem>
                                    {checked == 1 && (file.document_name ? file.document_name.indexOf(".mp4") == -1  : false )?
                                        <Row>
                                            <Col span="20">
                                                <div className="m-margin-b" style={{ width: "90%", background: "#ddd"}}>
                                                    {previewImgs}
                                                </div>
                                                <div>页面 {this.state.currentPage}/{allPage}</div>
                                            </Col>
                                        </Row> : ((this.state.isEdit && DCConfig.length>0) && DCConfig[0].file_name.indexOf(".mp4") == '-1' && DCConfig[0].file_name.indexOf(".zip") == '-1' && DCConfig[0].file_name.indexOf("://") == '-1' ?
                                        <Row>
                                            <Col span="20">
                                                <div className="m-margin-b" style={{ width: "90%", background: "#ddd"}}>
                                                    {previewImgs}
                                                </div>
                                                <div>页面 {this.state.currentPage}/{allPage}</div>
                                            </Col>
                                        </Row>
                                         : null)
                                    }
                                    <FormItem label={keyLable}>
                                        <Checkbox className="m-fr" style={{position:"absolute",top:"-30px",right:"115px"}}>必须包含页</Checkbox>
                                    </FormItem>
                                    {keyInfoItemJSX}
                                    <FormItem label="标签：">
                                        {fieldDecorator.label_id(
                                            <TreeSelect 
                                                style={{ width: "75%"}}
                                                dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                                                multiple={true}
                                                allowClear
                                                treeDefaultExpandAll
                                                onChange={this.onChangeNodes.bind(this)}
                                                >
                                                {tagTreeNodes}
                                            </TreeSelect>
                                        )}
                                    </FormItem>
                                </Col>
                            </Col>
                        </Row>
                    </Panel>
                </Collapse>
            </div>
        )
    }
    /**
     * 标签部分
    */
    handleOk() {
        this.setState({
            visible: false
        });
    }
    handleCancel() {
        this.setState({
            visible: false
        });
    }
    onClickAddTag() {
        this.setState({
            visible: true,
            selectVal:[]
        });
    }
    //点击永不过期
    onClickNeverOutdate(e) {
        let checkedDate = this.state.checkedDate;
        let {documentCenterEditActs} = this.props;
        this.props.form.setFieldsValue({ expire_time_basic: moment() });
        this.props.form.setFieldsValue({ expire_time_basic: null });

        this.setState({
            checkedDate: !checkedDate
        });
        documentCenterEditActs.saveExpire(!checkedDate);
    }
    disabledDate(current) {
        return current && current.valueOf() < Date.now();
    }
    //选择设置信息点的类型
    onChangeKeytype(e) {
        this.setState({
            keyValue: e.target.value
        });
    }
    //上传封面图片之前
    beforeUpload(file) {

        this.setState({
            fileName: file.name
        })
        let documentType = ['image/jpg','image/jpeg','image/png','image/bmp']
        if(documentType.indexOf(file.type) < 0){
            tools.showDialog.error('不支持该类型文件上传');
            return false;
        }
    }
    onChangeCoverImg(info) {
        const status = info.file.status;
        if (status !== 'uploading') {
            console.log(info.file, info.fileList);
        }
        if (status === 'done') {
            if(info.fileList.length > 1){
                info.fileList.shift();
            }else if (status === 'error') {
                tools.showDialog.error(`${info.file.name} file upload failed.`);
            }
        }
    }
    /**
     * 预览图片关联信息点
     */
    onChangeKeyMsg(index,value) {
        let {documentCenterEditActs} = this.props;
        this.setState({
            checkedKeyMsg: value
        })
    }
    onBeforeChange(index,val) {
        let {documentCenterEditActs} = this.props;
        let {keyMessage} = this.props.$$documentCenterEdit.toJS()
        this.setState({
            currentPage: val + 1
        })
    }

    //树处理
    loop(data) {
        let nodes = [];
        let cssStyle = null;
        nodes = (data || []).map((item, index) => {  
            if (item.child_list.length > 0) {
                return (
                    <TreeNode key={item.id} 
                        title={item.name}
                        value={item.name || ''}>
                        {this.loop(item.child_list)}
                    </TreeNode>
                )
            } else{
                return (
                    <TreeNode key={item.id}
                        isLeaf={true}
                        title={item.name}
                        value={item.name || ''}></TreeNode>
                )
            }
        });
        return nodes;
    }
    //选中树节点时调用
    onChangeNodes(value,label,extra) {
        let {documentCenterEditActs} = this.props;
        let {relatedTreeTrue } = this.props.$$documentCenterEdit.toJS();
        this.dataList = [];
        let selectArr = [];
        this.generateList(relatedTreeTrue);
        this.dataList.map((item) => {
            value.map((obj,index) => {
                if(obj === item.id){
                    selectArr.push(item.name)
                }
            })
        });
        this.setState({
            checkedId: value,
            selectVal: selectArr
        })
    }
    // 将树结构按照单一节点存入输入
    generateList(data) {
        let {documentCenterEditActs} = this.props;        
        for (let i = 0; i < data.length; i++) {
            const node = data[i];
            const key = node.name;
            this.dataList.push({ id: node.id, name: node.name, parent_id: node.parent_id });
            if (node.child_list.length>0) {
                this.generateList(node.child_list);
            }
        }
        documentCenterEditActs.saveEqualTreeData(this.dataList);
    }
    //点击modal框中的添加
    onClickFinishAddTag() { 
        let {documentCenterEditActs} = this.props;
        this.setState({
            visible: false
        })
        documentCenterEditActs.saveCheckedTagkeys(this.state.selectVal);
    }
    //点击保存
    onClickSave() {
        let { documentCenterEditActs } = this.props;
        let { file, brands, therapeutic, tagkeys, news, checked, htmlURL, htmlType, previewImg, equalTreeData, keyMessage, DCConfig, relaAreaAndBrand, expire } = this.props.$$documentCenterEdit.toJS();
        let allPage = Array.isArray(previewImg.data) ? previewImg.data.length : null;
        let typeEnum = {
            "1": 1,    //office文档
            "2": 3     //html5
        }
        let saveValues = ["brand_ids", "cover_image", "expire_time_basic", "feedback", "introduction", "name", "share_scopes", "therapeutic_areas", "use_scopes", "water_mark", "label_id", "key_messages", "key_type", "key_info"]
        let documentId = this.state.query.documentId;
        this.props.form.validateFieldsAndScroll(saveValues, (errors, values) => {
            let allFields = this.props.form.getFieldsValue();
            if (!!errors) {
                return console.log("save error!!!", values);
            }
            let brandId = [];
            let areaId = [];
            let labelId = [];
            relaAreaAndBrand.brand.map(item => {
                brandId.push(item.id);
            })
            relaAreaAndBrand.therapeutic_area.map(item => {
                areaId.push(item.id);
            })
            values.label_id.map((item) => {
                equalTreeData.map((obj) => {
                    if (item == obj.name) {
                        labelId.push(obj.id);
                    }
                })
            })
            let coverImg;
            //TODO
            if (this.state.isEdit && values.cover_image.length > 0) {
                if ((DCConfig[0].cover_image == values.cover_image[0].url) && DCConfig[0].cover_image) {
                    coverImg = DCConfig[0].cover_image.substring(DCConfig[0].cover_image.lastIndexOf('/cover/') + 7);
                } else {
                    if (values.cover_image && values.cover_image.length !== 0) {
                        coverImg = values.cover_image[0].response.data.file_name;
                    }
                }
            } else {
                if (values.cover_image && values.cover_image.length !== 0) {
                    coverImg = values.cover_image[0].response.data.file_name;
                }
            }
            let km = {};
            if (values.key_type == 1) {
                km[0] = allFields["key_info"]
            } else {
                for (let i = 1; i <= allPage; i++) {
                    if (!allFields[`key_info_${i}`]) {
                        allFields[`key_info_${i}`] = []
                    }
                    km[i] = allFields[`key_info_${i}`]
                }
            }
            if (htmlURL.indexOf("http") == -1) {
                htmlURL = "http://" + htmlURL
            }
            let addSuffix = file.file_name ? file.file_name.substring(file.file_name.lastIndexOf(".")) : "";
            let editSuffix = DCConfig.length > 0 ? (DCConfig[0].document_name.lastIndexOf(".") == -1 ? "" : DCConfig[0].document_name.substring(DCConfig[0].document_name.lastIndexOf("."))) : "";
            let docId = this.state.query.id;
            let data = {
                "brand_ids": brandId,
                "cover_image": coverImg || null,
                "expire": expire,
                "expire_time": values.expire_time_basic ? values.expire_time_basic._d : null,
                "feedback": values.feedback,
                "file_name": htmlType === 2 ? htmlURL : file.file_name,
                "file_size": file.size,
                "folder_id": parseInt(documentId),
                "introduction": values.introduction,
                "name": values.name + addSuffix,
                "share_scope": values.share_scopes > 0 ? values.share_scopes : null,
                "therapeutic_area_ids": areaId,
                "use_scope": (values.use_scopes && values.use_scopes.length > 0) ? values.use_scopes : null,
                "water_mark": values.water_mark,
                "type": typeEnum[checked],
                "label_id": labelId,
                "key_messages": km
            }
            let editData = {
                "brand_ids": brandId,
                "cover_image": coverImg || null,
                "expire": (values.expire_basic || !values["expire_time_basic"] ? null : (values.expire_time_basic ? values.expire_time_basic._d : DCConfig[0].expire_time)) ? false : true,
                "expire_time": values.expire_basic || !values["expire_time_basic"] ? null : (values.expire_time_basic ? values.expire_time_basic._d : DCConfig[0].expire_time),
                "feedback": values.feedback,
                "file_name": DCConfig.length > 0 ? DCConfig[0].file_name : null,
                "file_size": DCConfig.length > 0 ? DCConfig[0].file_size : null,
                "folder_id": parseInt(documentId),
                "introduction": values.introduction,
                "name": values.name + editSuffix,
                "share_scope": values.share_scopes ? values.share_scopes : null,
                "therapeutic_area_ids": areaId,
                "use_scope": values.use_scopes && values.use_scopes > 0 ? values.use_scopes : null,
                "water_mark": values.water_mark,
                "type": DCConfig.length > 0 ? DCConfig[0].type : null,
                "label_id": labelId,
                "key_messages": km
            }
            if (values.name.indexOf(".") > -1) {
                tools.showDialog.error("文件的名称不能包含“.”")
            } else {
                if (this.state.isEdit) {
                    documentCenterEditActs.saveDCConfig(editData, this.state.isEdit, docId);     
                } else {
                    documentCenterEditActs.saveDCConfig(data, this.state.isEdit, docId);        
                }
            }
        });
    }
}

export default _ThirdStep
