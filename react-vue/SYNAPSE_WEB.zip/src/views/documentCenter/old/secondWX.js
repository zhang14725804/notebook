import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/documentCenter"
import { Enum, EnumCn } from "enum"
import { tools } from "utils"
import Modal from "antd/lib/modal"
import Icon from "antd/lib/icon"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import Dropdown from "antd/lib/dropdown"
import Table from "antd/lib/table"
import Menu from "antd/lib/menu"
import Tag from "antd/lib/tag"
import Radio from "antd/lib/radio"
import Steps from "antd/lib/steps"
import Collapse from "antd/lib/collapse"
import Checkbox from "antd/lib/checkbox"
import Select from "antd/lib/select"
import DatePicker from "antd/lib/date-picker"
import UEditor from "components/ueditorForWx"
import DialogDemo from 'components/demo/dialogDemo'
import moment from "moment"
import ReactQRCode from 'components/QRCode'
import Upload from "components/upload1"
import message from "antd/lib/message"
import TreeSelect from 'antd/lib/tree-select';

import "assets/style/views/documentCenter/edit.less"

const Step = Steps.Step;
const RadioGroup = Radio.Group;
// const Dragger = Upload.Dragger;
const Panel = Collapse.Panel;
const FormItem = Form.Item;
const CheckboxGroup = Checkbox.Group;
const Option = Select.Option;
const TreeNode = TreeSelect.TreeNode;


//step1: 选择文档类型
class _SecondWX extends React.Component {
    constructor(props) {
        super(props);
        this.defValue = {
            editorAvatorImg: {
                first: require("assets/image/editor-default-avator-436-234.png"),
                other: require("assets/image/editor-default-avator-120-120.png"),
                addIcon: require("assets/image/editor-icon-adds.png"),
                xiumi: require("assets/image/xiumi.png")
            },
            isNoContentChange: false,
            isNoClickWxItem: false,
        }
        this.state = {
            fileName: '',
            isEdit: !!props.location.query.id,
            query: props.location.query,
            type: props.location.query.type,
            content: "",
            title: "",
            editor_id: `editor_${Math.random()}`,
            id: props.location.query.id,
            previewData: {},
            checked: false,
            expired: false,
            wxItemObj: {                           // 所有微信项的id标题和内容对象
                "0": {
                    title: "",
                    content: "",
                    // cover_image:"",
                }
            },
            curKey: 0,                             // 选中的微信内容项
            mouseMoveOptionId: -1,                  // 鼠标移过的项目id
            cover_image: "",
            expire_time: ""
        };
        this.dataList = [];
    }
    componentDidMount() {
        // let {newsActs, commonActs, form, $$layout} = this.props;
        // newsActs.getAllTa(),          //获取所有治疗领域1
        let _this = this;
        let { documentCenterEditActs } = this.props;
        let documentId = this.state.query.documentId;
        documentCenterEditActs.reset();
        documentCenterEditActs.getTopFolderRelation(documentId).done((resp) => {
            // let relaBrandId = [];
            // let relaAreaId = [];
            // resp.data.brand.map(item => {
            //     relaBrandId.push(item.id.toString())
            // })
            // resp.data.therapeutic_area.map(item => {
            //     relaAreaId.push(item.id.toString())
            // })
            let relaArg = {
                'product_id': resp.data.brand.length > 0 ? resp.data.brand[0].id : null,
                'therapeutic_area_id': resp.data.therapeutic_area.length > 0 ? resp.data.therapeutic_area[0].id : null,
            }
            documentCenterEditActs.getKmByPdtAndTa(relaArg);
        });
        $.when(
            // documentCenterEditActs.getAllProduct(),     //获取所有产品
            documentCenterEditActs.getDCRelatedBrand(),     //获取所有品牌
            documentCenterEditActs.getTherapeuticArea(),//治疗领域
            // documentCenterEditActs.getAllKeyMsg(),//信息点
            documentCenterEditActs.getDCRelatedTreeTrue().done((obj) => {
                _this.generateList(obj.data)
            })//标签树下拉
        ).done(() => {

        });
        // if(this.state.isEdit){
        //     let id = this.state.query.id;
        //     let { documentCenterEditActs } = this.props;
        //     documentCenterEditActs.getWXNews(this.state, true).done(()=>{
        //         let {wx_news} = this.props.$$documentCenterEdit.toJS();
        //         if(this.props.location.query.type==5){
        //                 this.setState({
        //                     expired: wx_news[0].expire_time==946656001000 ? true:false

        //             })
        //         }
        //     })
        // }
    }
    componentWillReceiveProps(next) {
        // let {id, curKey, wx_news, commonActs, form} = next;
        // if(!Immutable.fromJS(this.props).equals(Immutable.fromJS(next))){
        //     if(curKey == id){
        //         let drug_ids = form.getFieldsValue()[`drug_ids_$${id}`];
        //         let ta_ids = form.getFieldsValue()[`ta_ids_$${id}`];
        //         let km_ids = form.getFieldsValue()[`km_ids_$${id}`];

        //         // commonActs.getKmByPdtAndTa([].concat(drug_ids), [].concat(ta_ids)).done(() => {
        //         //     // this._getExistKm(km_ids, `km_ids_$${id}`);
        //         // });
        //     }
        // }

        let prev = this.props;
        let prevNews = prev.$$documentCenterEdit.get("wx_news");
        let nextNews = next.$$documentCenterEdit.get("wx_news");
        // if (!nextNews.equals(prevNews)) {
        //     //赋值详情数据
        //     const {brands, therapeutic, allkp} = prev.$$documentCenterEdit.toJS();
        // }
    }
    render() {
        let fieldDecorator = this.props.fieldDecorator;
        let { form } = this.props;
        let { previewData, platformArr, curKey, wxItemObj, mouseMoveOptionId } = this.state;
        const formItemLayout = {
            labelCol: { span: 5 },
            wrapperCol: { span: 19 }
        };
        let { brands, therapeutic, allkp, wx_news, relatedTreeTrue, equalTreeData } = this.props.$$documentCenterEdit.toJS();

        //产品
        let brandsJSX = [];
        brands.map((item, index) => {
            brandsJSX.push(
                <Option key={item.id + Math.random()} value={item.name}>{item.name}</Option>
            )
        });
        let useScopeJSX = [];
        //治疗领域
        let therapeuticJSX = [];
        therapeutic.map((item, index) => {
            therapeuticJSX.push(
                <Option key={item.id + Math.random()} value={item.name}>{item.name}</Option>
            )
        });
        //信息点
        let kmJSX = [];
        allkp.map((item, index) => {
            kmJSX.push(
                <Option key={item.id + Math.random()} value={item.name}>{item.name}</Option>
            )
        });
        // }
        let tagJSX = [];
        // let cookie = tools.getCookies();
        let originUrl = encodeURIComponent(tools.getOriginUrl());
        //预览数据
        let dataSource = [
            {
                // platform: contentType,
                content: {
                    title: previewData.title,
                    author: previewData.author,
                    // time: previewData.ctime,
                    content_text: previewData.content
                },
                qrcode: tools.previewApi(`/infoAppDemo?resource_id=${previewData.resource_id}&originUrl=${originUrl}&isEdit=true`),
            }
        ]
        //微信列表
        let wxListJSX = [];
        let NewsExtendFieldsJSX = [];
        // 微信图文列表
        if (Object.getOwnPropertyNames(wxItemObj).length > 0) {
            let classNames = {
                firstWxItem: 'first-wx-item',
                selectedWxItem: 'selected-wx-item',
                wxItem: 'wx-item',
                firstWxItemTitle: 'first-wx-item-title',
                wxItemTitle: 'wx-item-title'
            }
            let firstSelectedClass = `${classNames.firstWxItem} ${classNames.selectedWxItem}`;
            let otherSelectedClass = `${classNames.wxItem} ${classNames.selectedWxItem}`;
            $.each(wxItemObj, (key, value) => {
                {/* !!!编辑赋数据bug */ }
                NewsExtendFieldsJSX.push(
                    <NewsExtendFields
                        style={{ display: key == curKey ? 'block' : 'none' }}
                        key={key}
                        id={key}
                        curKey={curKey}
                        news={wx_news[key]}
                        news_0={wx_news[0]}
                        wxItemObj={wxItemObj}
                        {...this.props}
                    />
                )
                // 插入微信项
                wxListJSX.push(<div
                    onMouseEnter={this.onMouseEnterHandler.bind(this, key)}
                    onMouseLeave={this.onMouseLeaveHandler.bind(this, key)}
                    key={key}
                    onClick={this.onClickWxListItem.bind(this, key)}
                    className={curKey == key ?
                        key == 0 ? `${firstSelectedClass}` : `${otherSelectedClass}`
                        : key == 0 ? `${classNames.firstWxItem}` : `${classNames.wxItem}`}
                >
                    <img src={form.getFieldsValue()[`cover_plan_$${key}`] || value.cover_image || (key == 0 ? this.defValue.editorAvatorImg.first : this.defValue.editorAvatorImg.other)} />
                    {/* <img src={wxItemObj[key].cover_image||(key==0 ? this.defValue.editorAvatorImg.first : this.defValue.editorAvatorImg.other)}/> */}
                    <span className={key == 0 ? classNames.firstWxItemTitle : classNames.wxItemTitle}>{value.title || "未命名"}</span>
                    <WxItemOperate
                        id={key}
                        wxItemObj={wxItemObj}
                        onClickDelete={this.onClickDelete.bind(this)}
                        onClickUp={this.onClickUp.bind(this)}
                        onClickDown={this.onClickDown.bind(this)}
                        style={{ display: mouseMoveOptionId === key ? 'flex' : 'none' }}
                    />
                </div>)
            })
        }
        return (
            <div id="news-edit">
                {/* <MatterSteps stepList={[{ title: "推广落地页" }, { title: "推广物料" }]} current={0}/> */}
                {/* <Row className="m-margin-b m-edit-header">
                    <Col span="24">
                        <Col span="4" className="m-edit-title">{this.state.isEdit ? "编辑图文" : "新增图文"}</Col>
                    </Col>
                </Row> */}
                <div className="m-handle-btn">
                    <div className="wrap">
                        {
                            // <Button type="primary" onClick={this.onClickSave.bind(this,"save")}>保存</Button>
                        }
                        <Button type="primary" className="m-margin-r" onClick={this.onClickSave.bind(this, "save")}>保存</Button>
                        <DialogDemo onBeforeShowModal={this.onClickPreview.bind(this)} dataSource={dataSource} />
                    </div>
                </div>
                <div><span style={{ display: "inline-block", color: '#f04134', fontFamily: 'SimSun', fontSize: '12px', marginRight: '4px', lineHeight: 2 }}>*</span>注：正文最多可输入2万字。</div>
                <Row className="m-edit-content">
                    <div className="m-edit-content-col" style={{ width: "250px", padding: "10px 15px 0", background: "#F7F7F7" }}>
                        <div>
                            <div>
                                <p style={{ display: "inline-block" }} className="m-margin-b menu-title">图文列表</p>
                                <a href="https://xiumi.us/studio/v5#/paper/for/new" target="_blank">
                                    <img
                                        style={{ float: "right", width: "22px", height: "22px", pointer: "cursor" }}
                                        src={this.defValue.editorAvatorImg.xiumi}
                                    />
                                </a>
                            </div>
                            <div className="wx-item-container">
                                {wxListJSX}
                            </div>
                            <div
                                className="wx-btn-plus"
                                style={{ display: Object.getOwnPropertyNames(wxItemObj).length >= 8 ? 'none' : 'block' }}
                                onClick={this.onClickBtnPlus.bind(this)}>
                                <img src={this.defValue.editorAvatorImg.addIcon} />
                            </div>
                        </div>
                    </div>
                    <div className="m-edit-content-col" style={{ width: "calc(100% - 550px)" }}>
                        <UEditor
                            id={this.state.editor_id}
                            onKeyup={this.onKeyup.bind(this)}
                            onEditorReady={this.onEditorReady.bind(this)}
                            curKey={curKey}
                            /* contentType={this.state.contentType} */
                            /* content={this.state.content} */
                            content={this.state.content}
                            title={this.state.title} />
                    </div>
                    <div className="m-edit-content-col m-ta-l" style={{ width: "280px", position: 'relative' }}>
                        {NewsExtendFieldsJSX}
                        <div style={{ "padding": "10px", "position": "absolute", "bottom": "140px" }}>
                            <span className="ant-form-item-required">过期时间</span>
                            <FormItem>
                                {fieldDecorator.expire_time(
                                    <DatePicker
                                        showToday={false}
                                        disabled={this.state.expired}
                                        disabledDate={this.disabledDate.bind(this)} />
                                )}
                                <Checkbox
                                    checked={this.state.expired}
                                    className="m-margin-l neverOutDate"
                                    onClick={this.onClickNeverOutdate.bind(this)} >永不过期</Checkbox>
                            </FormItem>
                        </div>
                    </div>
                </Row>
            </div>
        )
    }
    //点击永不过期
    onClickNeverOutdate(e) {
        let expired = this.state.expired;
        let tempObj = {};
        let { form } = this.props;
        let checked = this.state.checked;
        // this.props.form.setFieldsValue({ expire_time: moment(946656001000) });//946656001000
        this.props.form.setFieldsValue({ expire_time: null });

        this.setState({
            expired: !expired
        });

    }
    disabledDate(current) {
        return current && current.valueOf() < Date.now();
    }
    // 将树结构按照单一节点存入输入
    generateList(data) {
        let { documentCenterEditActs } = this.props;
        for (let i = 0; i < data.length; i++) {
            const node = data[i];
            const key = node.name;
            this.dataList.push({ id: node.id, name: node.name, parent_id: node.parent_id });
            if (node.child_list.length > 0) {
                this.generateList(node.child_list);
            }
        }
        documentCenterEditActs.saveEqualTreeData(this.dataList);
        // return dataList;
    }
    //update摘要
    changeIntroduction(index, e) {
        let { documentCenterEditActs, $$documentCenterEdit } = this.props;
        const { brands, therapeutic, allkp, wx_news } = this.props.$$documentCenterEdit.toJS();
        let introduction = e.target.value;
        documentCenterEditActs.UpdateWXNews({ value: introduction, index: index, type: 'introduction' });
    }
    //update作者
    changeAuthor(index, e) {
        let { documentCenterEditActs, $$documentCenterEdit } = this.props;
        const { brands, therapeutic, allkp, wx_news } = this.props.$$documentCenterEdit.toJS();
        let author = e.target.value;
        documentCenterEditActs.UpdateWXNews({ value: author, index: index, type: 'author' });
    }
    //update品牌
    changeBrand(index, value) {
        let { documentCenterEditActs, $$documentCenterEdit } = this.props;
        const { brands, therapeutic, allkp, wx_news } = this.props.$$documentCenterEdit.toJS();
        let brand = [];
        brands.map((obj) => {
            if (obj.name == value) {
                brand.push(obj.id)
            }
        })
        documentCenterEditActs.UpdateWXNews({ value: brand, index: index, type: 'brand' });
    }
    //update治疗领域
    ChangeTherapeutic(index, value) {
        let { documentCenterEditActs, $$documentCenterEdit } = this.props;
        const { brands, therapeutic, allkp, wx_news } = this.props.$$documentCenterEdit.toJS();
        let therapeutic_area = [];
        therapeutic.map((obj) => {
            if (obj.name == value) {
                therapeutic_area.push(obj.id)
            }
        })
        documentCenterEditActs.UpdateWXNews({ value: therapeutic_area, index: index, type: 'therapeutic' });
    }
    //update信息点
    changeKM(index, value) {
        let { documentCenterEditActs, $$documentCenterEdit } = this.props;
        const { brands, therapeutic, allkp, wx_news } = this.props.$$documentCenterEdit.toJS();
        let km = [];
        allkp.list.map((obj) => {
            if (obj.name == value) {
                km.push(obj.id)
            }
        })
        documentCenterEditActs.UpdateWXNews({ value: km, index: index, type: 'km' });
    }
    //update标签
    changeLabels(index, value) {
        let { documentCenterEditActs, $$documentCenterEdit } = this.props;
        const { brands, therapeutic, allkp, wx_news } = this.props.$$documentCenterEdit.toJS();
        let label = [];
        documentCenterEditActs.UpdateWXNews({ value: label, index: index, type: 'label' });
    }

    // 鼠标进入显示选项
    onMouseEnterHandler(key) {
        this.setState({
            mouseMoveOptionId: key
        })
    }
    // 鼠标移出选项消失
    onMouseLeaveHandler(key) {
        this.setState({
            mouseMoveOptionId: -1
        })
    }
    // 点击微信列表的某一项
    onClickWxListItem(key) {
        if (this.defValue.isNoClickWxItem) {
            this.defValue.isNoClickWxItem = false;
            return;
        }
        let { wxItemObj } = this.state;
        let { wx_news, brands, therapeutic, allkp } = this.props.$$documentCenterEdit.toJS();
        const { documentCenterEditActs, form } = this.props;
        this.defValue.isNoContentChange = true;
        // 切换为当前项的标题和内容
        this.setState({
            curKey: key,
            title: wxItemObj[key].title,
            content: wxItemObj[key].content
        })

        let brands_ids = form.getFieldsValue()[`drug_ids_$${key}`];
        let therapeutic_areas_ids = form.getFieldsValue()[`ta_ids_$${key}`];
        let key_messages = form.getFieldsValue()[`km_ids_$${key}`];
        let labels = form.getFieldsValue()[`tag_ids_$${key}`];

        brands.map((o) => {
            if (brands_ids == o.name) {
                brands_ids = o.id;
            }
        })
        let theraid = []
        therapeutic.map((obj, index) => {
            therapeutic_areas_ids.map((o, i) => {
                if (o == obj.name) {
                    theraid.push(obj.id);
                }
            })
        })

        // documentCenterEditActs.getKmByPdtAndTa([].concat(brands_ids), [].concat(theraid)).done(() => {
        //     // this._getExistKm(km_ids, `km_ids_$${id}`);
        // });

        // let brand_name=[];
        // wx_news[key].brands.map((item)=>{
        //     brands.map((obj)=>{
        //         if(item==obj.id){
        //             brand_name.push(obj.name)
        //         }
        //     })
        // })
        // let therapeutic_name=[];
        // wx_news[key].therapeutic_areas.map((item)=>{
        //     therapeutic.map((obj)=>{
        //         if(item==obj.id){
        //             therapeutic_name.push(obj.name)
        //         }
        //     })
        // })
        // let km_name=[];
        // wx_news[key].key_messages.map((item)=>{
        //     allkp.list.map((obj)=>{
        //         if(item==obj.id){
        //             km_name.push(obj.name)
        //         }
        //     })
        // })
        // this.props.form.setFieldsValue({
        //     introduction_wx:wx_news[key].introduction,//摘要
        //     author:wx_news[key].material.author,//作者
        //     brand_ids:brand_name,//产品
        //     therapeutic_areas:therapeutic_name,//治疗领域
        //     key_messages:km_name,//信息点
        //     labels:wx_news[key].labels,//标签
        //     // expire_time:wx_news[key].expire_time,//过期时间
        //     use_scope:wx_news[key].use_scope,//文档权限
        //     share_scope:wx_news[key].share_scope,//分享权限
        // })
    }
    // 点击微信列表上的加号
    onClickBtnPlus() {
        // 点击加号给列表加条件
        let { curKey, wxItemObj } = this.state;
        let { wx_news, brands, therapeutic, allkp } = this.props.$$documentCenterEdit.toJS();
        let key = Object.getOwnPropertyNames(wxItemObj).length;

        // 往编辑器内容里面加项，改变curKey，content，title
        wxItemObj[key] = {
            title: "",
            content: "",
            avatar: ""
        }
        this.defValue.isNoContentChange = true;
        this.setState({
            wxItemObj: wxItemObj,
            curKey: key,
            title: "",
            content: "",
        })
        // let {documentCenterEditActs} = this.props;
        // documentCenterEditActs.addImageText();
        // this.props.form.setFieldsValue({
        //     introduction_wx:'',//摘要
        //     author:'',//作者
        //     brand_ids:[],//产品
        //     therapeutic_areas:[],//治疗领域
        //     key_messages:[],//信息点
        //     labels:[],//标签
        //     use_scope:'',//文档权限
        //     share_scope:'',//分享权限
        // })
    }
    // 点击操作框的删除
    onClickDelete(key) {
        if (Object.getOwnPropertyNames(this.state.wxItemObj).length <= 1) {
            message.error("您不能删除素材中的所有文章");
            return;
        }
        tools.showDialog.confirm("确定删除该图文？", () => {
            this.defValue.isNoClickWxItem = true;
            this.defValue.isNoContentChange = true;
            let { wx_news, brands, therapeutic, allkp } = this.props.$$documentCenterEdit.toJS();
            let { documentCenterEditActs } = this.props;
            let { wxItemObj } = this.state;
            let { form } = this.props;
            let tempObj = {};
            let index = 0;
            let wxtemp = [];
            let idx = 0;
            let wx = wx_news;
            // 处理form表单
            if (parseInt(key) + 1 !== Object.getOwnPropertyNames(tempObj).length) {
                $.map(form.getFieldsValue(), (v, k) => {
                    if (k.match(/.+_\$\d+/)) {
                        var matchRes = k.match(/(.+)_\$(\d+)/)
                        let prefix = matchRes[1];
                        let keyIndex = matchRes[2];
                        let tempValue = '';
                        if (parseInt(keyIndex) >= parseInt(key) && parseInt(keyIndex) + 1 < Object.getOwnPropertyNames(wxItemObj).length) {
                            tempValue = form.getFieldsValue()[k];   // 取出i的值
                            form.setFieldsValue({
                                [k]: form.getFieldsValue()[`${prefix}_$${parseInt(keyIndex) + 1 + ""}`]
                            });
                            form.setFieldsValue({
                                [`${prefix}_$${parseInt(keyIndex) + 1 + ""}`]: tempValue
                            });
                        }
                        //删除最后一个对象（bug号：http://10.90.0.49:88/zentao/bug-view-12277.html）
                        if (parseInt(keyIndex) >= parseInt(key) && parseInt(keyIndex) + 1 == Object.getOwnPropertyNames(wxItemObj).length) {
                            delete wx_news[key];
                        }
                    }
                })
            }
            documentCenterEditActs.updateWXIndex(wx_news)//删除后的数组更新到reducers
            $.each(wxItemObj, (i, o) => {
                if (i !== key) {
                    tempObj[index] = o;
                    index++;
                }
            })
            let curKey = parseInt(key) < Object.getOwnPropertyNames(tempObj).length - 1 ? parseInt(key) + "" : Object.getOwnPropertyNames(tempObj).length - 1 + "";
            this.setState({
                wxItemObj: tempObj,
                curKey: curKey,
                title: tempObj[curKey].title,
                content: tempObj[curKey].content
            })

        }, () => { })
    }
    // 点击操作框的上移
    onClickUp(key) {
        this.defValue.isNoClickWxItem = true;
        this.defValue.isNoContentChange = true;
        let { wx_news, brands, therapeutic, allkp } = this.props.$$documentCenterEdit.toJS();
        let { documentCenterEditActs } = this.props;
        let { wxItemObj } = this.state;
        let { form } = this.props;
        let tempValue = '';
        let extendValue = [];
        let wx = wx_news;
        $.each(wxItemObj, (i, o) => {
            if (i === key) {
                // 更换title等字段
                tempValue = wxItemObj[parseInt(i) - 1 + ""];
                wxItemObj[parseInt(i) - 1 + ""] = wxItemObj[i];
                wxItemObj[i] = tempValue;
                // 更换表单内字段
                $.map(form.getFieldsValue(), (value, key) => {
                    if (key.indexOf("_$" + i + "") > -1) {
                        let prefix = key.match(/(.+)_\$/)[1];
                        tempValue = form.getFieldsValue()[key];   // 取出i的值
                        form.setFieldsValue({
                            [key]: form.getFieldsValue()[`${prefix}_$${parseInt(i) - 1 + ""}`]
                        });
                        form.setFieldsValue({
                            [`${prefix}_$${parseInt(i) - 1 + ""}`]: tempValue
                        });
                    }
                })
                return;
            }
        })
        $.each(wx, (i, o) => {
            if (i == key) {
                // 更换author等字段
                extendValue = wx[parseInt(i) - 1];
                wx[parseInt(i) - 1] = wx[i];
                wx[i] = extendValue;
            }
            return wx;
        })
        // documentCenterEditActs.updateWXIndex(wx)
        this.setState({
            wxItemObj: wxItemObj,
            curKey: parseInt(key) + "",
            title: wxItemObj[parseInt(key) + ""].title,
            content: wxItemObj[parseInt(key) + ""].content,
        })
        // let brand_name=[];
        // wx[key].brands.map((item)=>{
        //     brands.map((obj)=>{
        //         if(item==obj.id){
        //             brand_name.push(obj.name)
        //         }
        //     })
        // })
        // let therapeutic_name=[];
        // wx[key].therapeutic_areas.map((item)=>{
        //     therapeutic.map((obj)=>{
        //         if(item==obj.id){
        //             therapeutic_name.push(obj.name)
        //         }
        //     })
        // })
        // let km_name=[];
        // wx[key].key_messages.map((item)=>{
        //     allkp.list.map((obj)=>{
        //         if(item==obj.id){
        //             km_name.push(obj.name)
        //         }
        //     })
        // })
        // this.props.form.setFieldsValue({
        //     introduction_wx:wx[key].introduction,//摘要
        //     author:wx[key].material.author,//作者
        //     brand_ids:brand_name,//产品
        //     therapeutic_areas:therapeutic_name,//治疗领域
        //     key_messages:km_name,//信息点
        //     labels:wx[key].labels,//标签
        //     // expire_time:wx_news[key].expire_time,//过期时间
        //     use_scope:wx[key].use_scope,//文档权限
        //     share_scope:wx[key].share_scope,//分享权限
        // })
    }
    // 点击操作框的下移
    onClickDown(key) {
        this.defValue.isNoClickWxItem = true;
        this.defValue.isNoContentChange = true;
        let { wx_news, brands, therapeutic, allkp } = this.props.$$documentCenterEdit.toJS();
        let { documentCenterEditActs } = this.props;
        let { wxItemObj } = this.state;
        let { form } = this.props;
        let tempValue = '';
        let extendValue = [];
        let wx = wx_news;
        $.each(wxItemObj, (i, o) => {
            if (i === key) {
                // 更换title等字段
                tempValue = wxItemObj[parseInt(i) + 1 + ""];
                wxItemObj[parseInt(i) + 1 + ""] = wxItemObj[i];
                wxItemObj[i] = tempValue;
                // 更换表单内字段
                $.map(form.getFieldsValue(), (value, key) => {
                    if (key.indexOf("_$" + i + "") > -1) {
                        let prefix = key.match(/(.+)_\$/)[1];
                        tempValue = form.getFieldsValue()[key];   // 取出i的值
                        form.setFieldsValue({
                            [key]: form.getFieldsValue()[`${prefix}_$${parseInt(i) + 1 + ""}`]
                        });
                        form.setFieldsValue({
                            [`${prefix}_$${parseInt(i) + 1 + ""}`]: tempValue
                        });
                    }
                })
                return;
            }
        })
        $.each(wx, (i, o) => {
            if (i == key) {
                // 更换author等字段
                extendValue = wx[parseInt(i) + 1];
                wx[parseInt(i) + 1] = wx[i];
                wx[i] = extendValue;
            }
            return wx;
        })
        // documentCenterEditActs.updateWXIndex(wx)
        this.setState({
            wxItemObj: wxItemObj,
            curKey: parseInt(key) + "",
            title: wxItemObj[parseInt(key) + ""].title,
            content: wxItemObj[parseInt(key) + ""].content,
        })
        // let brand_name=[];
        // wx[key].brands.map((item)=>{
        //     brands.map((obj)=>{
        //         if(item==obj.id){
        //             brand_name.push(obj.name)
        //         }
        //     })
        // })
        // let therapeutic_name=[];
        // wx[key].therapeutic_areas.map((item)=>{
        //     therapeutic.map((obj)=>{
        //         if(item==obj.id){
        //             therapeutic_name.push(obj.name)
        //         }
        //     })
        // })
        // let km_name=[];
        // wx[key].key_messages.map((item)=>{
        //     allkp.list.map((obj)=>{
        //         if(item==obj.id){
        //             km_name.push(obj.name)
        //         }
        //     })
        // })
        // this.props.form.setFieldsValue({
        //     introduction_wx:wx[key].introduction,//摘要
        //     author:wx[key].material.author,//作者
        //     brand_ids:brand_name,//产品
        //     therapeutic_areas:therapeutic_name,//治疗领域
        //     key_messages:km_name,//信息点
        //     labels:wx[key].labels,//标签
        //     // expire_time:wx_news[key].expire_time,//过期时间
        //     use_scope:wx[key].use_scope,//文档权限
        //     share_scope:wx[key].share_scope,//分享权限
        // })
    }
    //信息点接口
    // ChangeTherapeutic(){
    //     let { documentCenterEditActs } = this.props;
    //     this.setState({
    //         therapeutic:this.value
    //     })
    //     let data = {
    //         product_id:"",
    //         therapeutic_area_ids:""
    //     }
    //     //信息点接口
    //     documentCenterEditActs.getAllKeyMsg()
    // }

    //编辑器失去焦点
    onBlur(value) {
        this.setState({ content: value });
    }

    // 编辑器加载完成获取数据
    onEditorReady() {
        let { documentCenterEditActs, commonActs, form, $$layout } = this.props;
        let newsId = this.state.query.detailId;
        if (this.state.isEdit) {
            // 如果是编辑页，获取图文详情
            // 1. 详情赋值
            // 2. set 到详情进来的那一项
            // 3. title content 赋值
            documentCenterEditActs.getWXNews(this.state, true).done(resp => {
                let { news } = this.props;
                let { wx_news } = this.props.$$documentCenterEdit.toJS();
                let tempWxItemObj = {};
                // let selItem = {};
                // let sort = null;               
                let data = wx_news;
                this.defValue.isNoContentChange = true;
                data.map((item, index) => {
                    tempWxItemObj[index] = item.material;
                    tempWxItemObj[index].cover_image = item.cover_image;
                })
                this.setState({
                    wxItemObj: tempWxItemObj,
                    curKey: 0,
                    title: wx_news[0].material.title,
                    content: tempWxItemObj[0].content
                })
                if (this.props.location.query.type == 5) {
                    this.setState({
                        // expired: wx_news[0].expire_time == 946656001000 ? true : false
                        expired: wx_news[0].expire_time == null ? true : false
                    })
                }

                // const {product, ta} = resp.data.relates;
                // // TODO 编辑器初始化赋值
                // const {commonActs, form} = this.props;
                // commonActs.getKmByPdtAndTa((product || []).map(o => o.id), (ta || []).map(o => o.id))
                // const {product, ta} = resp.data.relates;
                // const {commonActs} = this.props;
                // commonActs.getKmByPdtAndTa((product || []).map(o => o.id), (ta || []).map(o => o.id))
            });
        }
    }
    //图文预览
    onClickPreview() {
        let { documentCenterEditActs, form } = this.props;
        let { title, content, curKey } = this.state;
        const { wx_news } = this.props.$$documentCenterEdit.toJS();
        // title
        // let contentType = Enum.NewsPlatform.weixin;
        const fields = $.extend(true,
            {},
            {
                // content_type: contentType,
                title,
                author: wx_news[curKey] ? wx_news[curKey].author : "",
                time: wx_news.ctime,
                content
            }
        );
        documentCenterEditActs.savePreview(fields).done((resp) => {
            let resource_id = resp.data;
            documentCenterEditActs.getNewsPreviewDetail(resp.data).done((resp) => {
                if (!resp.data) return;
                this.setState({
                    previewData: $.extend({}, { resource_id: resource_id }, JSON.parse(resp.data))
                })
            });
        })
    }
    //编辑器失去焦点
    onKeyup(argObj) {
        // debugger
        // argObj 因为 bind 函数参数只能传一个
        if (this.defValue.isNoContentChange) {
            this.defValue.isNoContentChange = false;
            return;
        }
        let { wxItemObj, curKey } = this.state;
        wxItemObj[curKey].title = argObj.title,
            wxItemObj[curKey].content = argObj.content
        this.setState({
            title: argObj.title,
            content: argObj.content,
            wxItemObj: wxItemObj,
        })
    }



    //点击保存按钮
    onClickSave(operation) {
        let documentId = this.state.query.documentId;
        let { documentCenterEditActs, form } = this.props;
        let valiFields = $.map(form.getFieldsValue(), (val, key) => key);
        let finalFields = [];
        valiFields.map((obj) => {
            if (obj.indexOf('$') > 0) {
                finalFields.push(obj);
            }
        })
        finalFields.push("expire_time");
        let { wxItemObj, isEdit } = this.state;
        let extendTitle = '';
        if (document.getElementById('editor-extend-title-input')) {
            extendTitle = document.getElementById('editor-extend-title-input').value;
        }
        // 检查微信的每一篇文章的标题和内容是否填写完整
        let isExtendError = false;
        $.each(wxItemObj, (key, value) => {
            if (!(value.title && value.content)) {
                isExtendError = true;
                // 将选项切换到出错的地方
                this.setState({
                    curKey: key,
                    title: value.title,
                    content: value.content
                })
                return false;
            }
        })
        this.defValue.isNoContentChange = true;

        let { wx_news, brands, therapeutic, allkp } = this.props.$$documentCenterEdit.toJS();


        form.validateFieldsAndScroll(finalFields, { force: true }, (errors, values) => {
            if (!!isExtendError) {
                tools.showDialog.error("标题和内容不能为空");
                // this.defValue.isNoContentChange = false;
                return;
            }
            if (!!errors) {
                $.each(errors, (key, value) => {
                    if (key.match(/.+_\$(\d+)/)) {
                        var errorKey = key.match(/.+_\$(\d+)/)[1];
                        this.setState({
                            curKey: errorKey,
                            title: wxItemObj[errorKey].title,
                            content_wx: wxItemObj[errorKey].content_wx
                        })
                        return false;
                    }
                })
                tools.showDialog.error("请补全提交信息");
                return;
            }
            this._save(operation)
        })
    }

    //保存表单
    _save(operation) {
        // 调用保存接口
        const { documentCenterEditActs, form } = this.props;
        let documentId = this.state.query.documentId;
        // const newsId = this.state.query.newsId;

        let { wxItemObj, isEdit, query } = this.state;
        let resArr = [];
        let tempObj = {};
        $.each(wxItemObj, (key, value) => {
            let allFields = form.getFieldsValue();
            let { wx_news, brands, therapeutic, allkp, relatedTreeTrue, equalTreeData, relaAreaAndBrand } = this.props.$$documentCenterEdit.toJS();
            tempObj = {
                brands: [],
                cover_image: '',
                feedback: true,
                introduction: '',
                key_messages: [],
                labels: [],
                material: {
                    author: '',
                    title: '',
                    content: ''
                },
                therapeutic_areas: [],
                share_scope: '',
                use_scope: '',
                water_mark: ''
            };
            // 产品
            let brand_ids = [];
            // 治疗领域
            let therapeuticId = [];
            relaAreaAndBrand.brand.map(item => {
                brand_ids.push(item.id);
            })
            relaAreaAndBrand.therapeutic_area.map(item => {
                therapeuticId.push(item.id);
            })
            // 信息点
            let kmId = [];
            if (allFields[`km_ids_$${key}`] != undefined) {
                allFields[`km_ids_$${key}`].map((item) => {
                    allkp.map((obj) => {
                        if (item == obj.name) {
                            kmId.push(obj.id)
                        }
                    })
                })
            }
            // 标签
            let tag = [];
            if (allFields[`tag_ids_$${key}`] != undefined) {
                allFields[`tag_ids_$${key}`].map((item) => {
                    if (equalTreeData != null) {
                        equalTreeData.map((obj) => {
                            if (item == obj.name) {
                                tag.push(obj.id)
                            }
                        })
                    }
                })
            }
            // 基础信息
            tempObj.id = this.state.isEdit ? allFields[`id_$${key}`] : "";
            tempObj.material.title = value.title;
            tempObj.material.content = value.content;

            // 关联信息
            let arr = allFields[`cover_plan_$${key}`].split('/')
            tempObj.cover_image = arr[arr.length - 1];//var arr = a.split('\\');alert(arr[arr.length-1]);
            tempObj.introduction = allFields[`digest_$${key}`] == undefined ? '' : allFields[`digest_$${key}`];
            tempObj.material.author = allFields[`author_$${key}`] == undefined ? '' : allFields[`author_$${key}`];
            tempObj.brands = brand_ids;
            tempObj.therapeutic_areas = therapeuticId;
            tempObj.key_messages = kmId;
            tempObj.labels = tag;

            resArr.push(tempObj);
        })
        let allFields = form.getFieldsValue();
        var time = new Date(allFields["expire_time"]);
        var time_year;
        var time_month;
        var time_date;
        var expire_time;
        // if (time.getTime() == 946656001000) {
        //     expire_time = 946656001000;
        if (time.getTime() == 0) {
            expire_time = null;
        } else {
            time_year = time.getFullYear();
            time_month = time.getMonth() + 1;
            time_date = time.getDate();
            expire_time = new Date(time_year + "/" + time_month + "/" + time_date + " " + "00:00:01").getTime();
        }
        const fields = resArr;
        let newsValue = {
            parent_id: Number(documentId),
            type: 5,
            expire_time: expire_time,
            materials: fields
        }
        // newsActs.saveNewsWx(fields, this.state.isEdit).done((res) => {
        //     if(res.code === 10000){
        //         let {query} = this.props.location;
        //         if (query.isCreateMaterial || query.isCreateMaterial === "true") {
        //             this.props.router.replace({
        //                 pathname: "/express/edit",
        //                 query: $.extend({}, query, {
        //                     material_id: isEdit ? fields.id : res.data,
        //                     material_type: Enum.DocumentType.news,
        //                     docType: this.props.location.query.docType,
        //                     isEdit: !!isEdit
        //                 })
        //             });
        //         }else {
        //             this.props.router.push({
        //                 pathname: "/news/list"
        //             });
        //         }
        //     }
        // });
        console.log("-- newsValue --",newsValue)
        if (this.state.isEdit) {
            newsValue.id = Number(this.state.id);
            documentCenterEditActs.savePreviewEdit(newsValue)
        } else {
            documentCenterEditActs.saveNewsPreview(newsValue)
        }
    }
    //比较两对象中对应key值否相等
    _equals(next, prev, keyArr) {
        if (!($.isPlainObject(prev)) && ($.isPlainObject(next))) return false;
        if (keyArr instanceof Array === false) return false;
        prev = Immutable.fromJS(prev);
        next = Immutable.fromJS(next);
        let isEquals = true;
        $.each(keyArr, (i, key) => {
            isEquals = false;
            let d1 = prev.get(key), d2 = next.get(key);
            if (Immutable.List.isList(d1) && Immutable.List.isList(d2) && d1.equals(d2)) {
                //array
                isEquals = true;
            } else if (Immutable.Map.isMap(d1) && Immutable.Map.isMap(d2) && d1.equals(d2)) {
                //object
                isEquals = true;
            } else if (d1 === d2) {
                //other
                isEquals = true;
            }
            return isEquals;
        });
        return isEquals;
    }
}

class NewsExtendFields extends React.Component {
    constructor(props) {
        super(props);
        this.defValue = {
            newsObj: {
                id: "",
                brands: [],
                feedback: false,
                introduction: "",//导语
                key_messages: [],
                labels: [],
                material: {
                    title: "",
                    author: "",
                    content: ""
                },
                share_scope: [],
                therapeutic_areas: [],
                use_scope: '',
                water_mark: '',
                cover_image: ""//封面
            },
        }
        this.state = {
            fileName: '',
            expired: false
        }
    }
    componentDidMount() {
        let { news_0, news, documentCenterEditActs, isEdit, brands, therapeutic_areas } = this.props;
        let resNews = news || {};
        let resNews0 = news_0 || {};
        let tids = [];
        (resNews0.therapeutic_areas || []).map((o) => {
            tids.push(o.id)
        })
    }
    componentWillReceiveProps(next) {
        let { id, curKey, news, documentCenterEditActs, form, wxItemObj } = next;
        // let {brands,therapeutic_areas} = next.news;
        if (!Immutable.fromJS(this.props).equals(Immutable.fromJS(next))) {
            if (curKey == id) {
                let brands_ids = form.getFieldsValue()[`drug_ids_$${id}`];
                let therapeutic_areas_ids = form.getFieldsValue()[`ta_ids_$${id}`];
                let key_messages = form.getFieldsValue()[`km_ids_$${id}`];
                let labels = form.getFieldsValue()[`tag_ids_$${id}`];
            }
        }
    }
    render() {
        let fieldDecorator = this.props.fieldDecorator;
        let { form } = this.props;
        let { brands, therapeutic, allkp, wx_news, relatedTreeTrue, relaAreaAndBrand } = this.props.$$documentCenterEdit.toJS();
        let { fieldProps, $$documentCenterEdit, id, style, curKey, news, documentCenterEditActs, wxItemObj } = this.props;
        let { getFieldDecorator } = form;
        const fields = form.getFieldsValue();
        if (!news) {
            news = this.defValue.newsObj;
        };
        let key_messages = [];
        // let brand_ids=[];
        let labels_ids = [];
        news.key_messages.map((item) => {
            key_messages.push(item.name)
        })
        // news.brands.map((item)=>{
        //     brand_ids.push(item.name)
        // })
        news.labels.map((item) => {
            labels_ids.push(item.name)
        })
        let cookie = tools.getCookies();
        // 上传封面配置
        let uploadCfg = {
            url: tools.javaApi("/api/doc/upload") + "?type=101",
            data: {
                "type": 101,
            },
            headers: { 'token': cookie.token },
            previewUrl: form.getFieldsValue()[`cover_plan_$${id}`] || news.cover_plan,
            width: curKey == 0 ? 180 : 100,
            height: curKey == 0 ? 100 : 100,
            onSuccess: (data, res) => {
                message.success("上传成功");
                let newFieldProp = {};
                newFieldProp[`cover_plan_$${id}`] = data.absolute_url;
                this.props.form.setFieldsValue(newFieldProp);
            },
            onErrorMessage: (error) => {
                tools.showDialog.error(error);
            }
        }
        //获取顶级文件夹的产品和治疗领域
        let therapeutic_areas = [];
        let brand_ids = [];
        relaAreaAndBrand.therapeutic_area.map(item => {
            therapeutic_areas.push(item.name);
        })
        relaAreaAndBrand.brand.map(item => {
            brand_ids.push(item.name);
        })

        // fieldProps
        const idProps = getFieldDecorator(`id_$${id}`, {
            initialValue: news.id
        })
        const coverPlanProps = getFieldDecorator(`cover_plan_$${id}`, {
            initialValue: news.cover_image,
            rules: [
                { required: true, message: "请上传封面" },
            ]
        })
        const digestProps = getFieldDecorator(`digest_$${id}`, {
            initialValue: news.introduction,
            rules: [
                { required: false },
                { max: 120, message: "摘要不得超过120个字符" },
            ]
        })
        const authorProps = getFieldDecorator(`author_$${id}`, {
            initialValue: news.material.author,
            rules: [
                { required: false },
                { max: 8, message: "作者不得超过8个字符" },
            ]
        })
        // const linkProps = getFieldDecorator(`link_$${id}`, {
        //     initialValue: news.link,
        // })
        const drugIdsProps = getFieldDecorator(`drug_ids_$${id}`, {
            initialValue: brand_ids,
            rules: [{
                required: false
            }],
            // onChange: (key) => {
            //     const {brands, therapeutic} = this.props.$$documentCenterEdit.toJS();
            //     const {documentCenterEditActs, form} = this.props;
            //     let ta_ids = form.getFieldsValue()[`ta_ids_$${id}`];//治疗领域
            //     // let km_ids = form.getFieldsValue()[`km_ids_$${id}`];
            //     // const {ta_ids, km_ids} = form.getFieldsValue();
            //     brands.map((o)=>{
            //         if(key==o.name){
            //             key = o.id;
            //         }
            //     })
            //     let taids=[]
            //     therapeutic.map((obj,index)=>{
            //         ta_ids.map((o,i)=>{
            //             if(o==obj.name){
            //                 taids.push(obj.id);
            //             }
            //         })
            //     })
            //     documentCenterEditActs.getKmByPdtAndTa([].concat(key), [].concat(taids)).done(() => {
            //         this._getExistKm(key_messages, `km_ids_$${id}`);
            //     });
            // },
        })
        const taIdsProps = getFieldDecorator(`ta_ids_$${id}`, {
            initialValue: therapeutic_areas,
            rules: [
                { required: false }
            ],
            // onChange: (key) => {
            //     const {brands, therapeutic} = this.props.$$documentCenterEdit.toJS();
            //     const {documentCenterEditActs, form} = this.props;
            //     let drug_ids = form.getFieldsValue()[`drug_ids_$${id}`];//产品
            //     // let km_ids = form.getFieldsValue()[`km_ids_$${id}`];//信息点
            //     // let ta_ids = form.getFieldsValue()[`ta_ids_$${id}`];//治疗领域
            //     // const {drug_ids, km_ids} = form.getFieldsValue();
            //     let brandids=[]
            //     brands.map((o)=>{
            //         if(brand_ids==o.name){
            //             brandids = o.id;
            //         }
            //     })
            //     let theraid = [];
            //     therapeutic.map((obj,index)=>{
            //         key.map((o,i)=>{
            //             if(o==obj.name){
            //                 theraid.push(obj.id);
            //             }
            //         })
            //     })
            //     documentCenterEditActs.getKmByPdtAndTa([].concat(brandids), [].concat(theraid)).done(() => {
            //         this._getExistKm(key_messages, `km_ids_$${id}`);
            //     });
            // },
        })
        const kmIdsProps = getFieldDecorator(`km_ids_$${id}`, {
            initialValue: key_messages || [],
        })
        const tagIdsProps = getFieldDecorator(`tag_ids_$${id}`, {
            initialValue: labels_ids || [],
        })
        // const expireTimeProps = getFieldDecorator(`expire_time_$${id}`, {
        //     initialValue: news.expire_time == null ? null: moment(news.expire_time),
        //     rules: [
        //         { required: true, message: "请填写过期时间" },
        //     ]
        // })
        const useScopeProps = getFieldDecorator(`use_scope_$${id}`, {
            initialValue: news.use_scope || [],
        })
        const shareScopeProps = getFieldDecorator(`share_scope_$${id}`, {
            initialValue: news.share_cope || [],
        })
        //产品
        let brandsJSX = [];
        brands.map((item, index) => {
            brandsJSX.push(
                <Option key={item.id + Math.random()} value={item.name}>{item.name}</Option>
            )
        });
        let useScopeJSX = [];
        //治疗领域
        let therapeuticJSX = [];
        therapeutic.map((item, index) => {
            therapeuticJSX.push(
                <Option key={item.id + Math.random()} value={item.name}>{item.name}</Option>
            )
        });
        //信息点
        let kmJSX = [];
        allkp.map((item, index) => {
            kmJSX.push(
                <Option key={item.id + Math.random()} value={item.name}>{item.name}</Option>
            )
        });
        // 标签
        // let tagJSX = [];
        let tagJSX = this.loop(relatedTreeTrue ? relatedTreeTrue : []);
        // const tagJSX = this.getRelaJSX({
        //     id: `tag_ids_$${id}`,
        //     dataSource: allTagTree,
        //     key: "id",
        //     value: "tag",
        //     isMulti: true,
        //     relaProps: tagIdsProps
        // });
        // let { position_tree } = this.props.$$labelList.toJS();
        // let tagTreeNodes = allTagTree ? this.loopPosition(allTagTree) : [];
        return (
            <Row style={{ ...style }}>
                <div style={{ borderLeft: "1px solid #e9e9e9" }}>
                    <FormItem style={{ marginBottom: 0 }}>
                        {idProps(
                            <div></div>
                        )}
                    </FormItem>
                    <div style={{ background: "#FFF", padding: "10px 10px 0 10px", borderBottom: "1px solid #e9e9e9" }}>
                        <p className="m-margin-b menu-title">发布设置</p>
                        封面
                        <span style={{ display: "inline-block", marginBottom: "5px" }} className="m-text-minor">
                            {curKey == 0 ? "（建议尺寸：900像素*500像素）" : "（建议尺寸：200像素*200像素）"}
                        </span>
                        <FormItem>
                            {coverPlanProps(
                                <Upload
                                    {...uploadCfg}
                                />
                            )}
                        </FormItem>
                    </div>
                    <div style={{ padding: "10px" }}>
                        摘要
                        <span style={{ display: "inline-block" }} className="m-text-minor">（选填）</span>
                        <FormItem style={{ display: "block" }}>
                            {digestProps(
                                <Input
                                    type="textarea"
                                /* onChange={this.changeIntroduction.bind(this, curKey)} */
                                />
                            )}
                        </FormItem>
                        作者<span className="m-text-minor">（选填）</span>
                        <FormItem>
                            {authorProps(
                                <Input
                                /* onChange={this.changeAuthor.bind(this, curKey)} */
                                />
                            )}
                        </FormItem>
                        {/* 原文链接<span className="m-text-minor">（选填）</span>
                        <FormItem>
                            {linkProps(
                                <Input
                                onChange={this.changeAuthor.bind(this, curKey)}
                                />
                            )}
                        </FormItem>  */}
                        <p className="m-margin-b" style={{ fontSize: "14px", color: "#000" }}>关联属性设置</p>
                        产品
                        <FormItem>
                            {drugIdsProps(
                                <Select placeholder="请选择" disabled
                                /* onChange={this.changeBrand.bind(this, curKey)} */
                                >
                                    {brandsJSX}
                                </Select>
                            )}
                        </FormItem>
                        治疗领域
                        {/* <FormItem>{taJSX}</FormItem> */}
                        <FormItem>
                            {taIdsProps(
                                <Select multiple placeholder="请选择" disabled
                                /* onChange={this.ChangeTherapeutic.bind(this,curKey)}  */
                                >
                                    {therapeuticJSX}
                                </Select>
                            )}
                        </FormItem>
                        信息点
                        <FormItem>
                            {kmIdsProps(
                                <Select multiple placeholder="请选择"
                                /* onChange={this.changeKM.bind(this, curKey)} */
                                >
                                    {kmJSX}
                                </Select>
                            )}
                        </FormItem>
                        标签
                        <FormItem>
                            {tagIdsProps(
                                <TreeSelect multiple placeholder="请选择"
                                    dropdownStyle={{ maxHeight: 200, overflow: 'auto' }}
                                /* onChange={this.changeLabels.bind(this, curKey)} */
                                >
                                    {tagJSX}
                                </TreeSelect>
                            )}
                        </FormItem>
                        <div style={{ "height": "70px" }}></div>
                        文档权限
                        <FormItem>
                            {useScopeProps(
                                <Select placeholder="请选择" allowClear={true}>
                                    {useScopeJSX}
                                </Select>
                            )}
                        </FormItem>
                        分享权限
                        <FormItem>
                            {shareScopeProps(
                                <div>
                                    <Checkbox
                                        checked={true}
                                        className="m-margin-l"
                                    >内部分享</Checkbox>
                                    <Checkbox
                                        className="m-margin-l"
                                    >外部分享</Checkbox>
                                </div>
                            )}
                        </FormItem>
                    </div>
                </div>
            </Row>
        )
    }
    //树处理
    loop(data) {
        let nodes = [];
        let cssStyle = null;
        nodes = (data || []).map((item, index) => {
            if (item.child_list.length > 0) {
                return (
                    <TreeNode key={item.id}
                        title={item.name}
                        value={item.name}>
                        {this.loop(item.child_list)}
                    </TreeNode>
                )
            } else {
                return (
                    <TreeNode key={item.id}
                        isLeaf={true}
                        title={item.name}
                        value={item.name}></TreeNode>
                )
            }
        });
        return nodes;
    }
    //选中树节点时调用
    onChangeNodes(value, label, extra) {
        let { documentCenterEditActs } = this.props;
        let { relatedTreeTrue } = this.props.$$documentCenterEdit.toJS();
        this.dataList = [];
        let selectArr = [];
        this.generateList(relatedTreeTrue);
        this.dataList.map((item) => {
            value.map((obj, index) => {
                if (obj === item.id) {
                    selectArr.push(item.name)
                }
            })
        });
        this.setState({
            checkedId: value,
            selectVal: selectArr
        })
    }

    //改变时间
    changeTime(value) {
        let { form } = this.props;
        let valiFields = $.map(form.getFieldsValue(), (val, key) => key);
        let finalFields = [];
        valiFields.map((obj) => {
            if (obj.indexOf('$') > 0) {
                finalFields.push(obj);
            }
        })
        finalFields.map((o, i) => {
            if (o.indexOf('expire_time') == 0) {
                this.props.form.setFieldsValue({
                    [o]: moment(value)
                });
            }
        })

    }
    //获取存在的信息点id
    _getExistKm(key_messages, key) {
        let { $$documentCenterEdit, form } = this.props;
        let allKmIds = $.map($$documentCenterEdit.toJS().allkp, item => item.name);
        //获取存在的信息点
        let km_ids = []
        $.grep(key_messages, id => {
            key_messages.map((o) => {
                km_ids = $.inArray(o, allKmIds) >= 0 ? key_messages : [];
            })
        });
        form.setFieldsValue({
            [key]: km_ids
        });
    }
    loopPosition(data) {
        let nodes = [];
        nodes = (data || []).map((item, index) => {
            if (item.leafs.length > 0) {
                return (
                    <TreeNode
                        key={item.id}
                        value={item.name}
                        title={item.name}>
                        {this.loopPosition(item.leafs)}
                    </TreeNode>
                )
            } else {
                return (
                    <TreeNode
                        key={item.id}
                        value={item.name}
                        isLeaf={true}
                        title={item.name}></TreeNode>
                )
            }
        });
        return nodes;
    }
}


class WxItemOperate extends React.Component {
    render() {
        let { id, wxItemObj, style } = this.props;
        return (
            <div className="wx-item-operate" style={{ ...style }}>
                <div className="wx-item-operate-col" style={{ display: id == 0 ? 'none' : 'block' }} onClick={this.onClickUp.bind(this, undefined, false)}>上移</div>
                <div className="wx-item-operate-col" style={{ display: id == Object.getOwnPropertyNames(wxItemObj).length - 1 ? 'none' : 'block' }} onClick={this.onClickDown.bind(this, undefined, false)}>下移</div>
                <div className="wx-item-operate-col" onClick={this.onClickDelete.bind(this, undefined, false)}>删除</div>
            </div>
        )
    }
    // 点击上移
    onClickUp() {
        let { id, onClickUp } = this.props;
        if (typeof onClickUp === 'function') {
            onClickUp.call(this, id);
        }
    }
    // 点击下移
    onClickDown() {
        let { id, onClickDown } = this.props;
        if (typeof onClickDown === 'function') {
            onClickDown.call(this, id);
        }
    }
    // 点击删除
    onClickDelete() {
        // !!!TODO 未能阻止冒泡，会进当前项的click事件导致title和content无法正常更新
        let { id, onClickDelete } = this.props;
        if (typeof onClickDelete === 'function') {
            onClickDelete.call(this, id);
        }
    }
}

export default _SecondWX
