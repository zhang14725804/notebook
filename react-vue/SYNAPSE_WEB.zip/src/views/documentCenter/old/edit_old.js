import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/documentCenter"
import { Enum, EnumCn } from "enum"
import { tools } from "utils"
import Modal from "antd/lib/modal"
import Icon from "antd/lib/icon"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import Dropdown from "antd/lib/dropdown"
import Table from "antd/lib/table"
import Menu from "antd/lib/menu"
import Tag from "antd/lib/tag"
import Radio from "antd/lib/radio"
import Steps from "antd/lib/steps"
import Upload from "antd/lib/upload"
import Collapse from "antd/lib/collapse"
import Checkbox from "antd/lib/checkbox"
import Select from "antd/lib/select"
import DatePicker from "antd/lib/date-picker"
import _FirstStep from "./firstStep"
import _SecondStep from "./secondStep"
import _ThirdStep from "./thirdStep"
import _SecondApp from "./secondApp"
import _SecondHtml from "./secondHtml"
import _SecondWX from "./secondWX"
import moment from "moment"
import ReactQRCode from 'components/QRCode'

const Step = Steps.Step;
const RadioGroup = Radio.Group;
const Dragger = Upload.Dragger;
const Panel = Collapse.Panel;
const FormItem = Form.Item;
const CheckboxGroup = Checkbox.Group;
const Option = Select.Option;
const confirm = Modal.confirm;

const checkboxShareLimit = [
    { label: "内部分享", value: 1 },
    { label: "外部分享", value: 2 },
]
const checkboxWatermark = [
    { label: "客户端自定义显示水印", value: 1},
    { label: "客户端显示用户名信息水印", value: 2}
]

class DocumentCenterEdit extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            current: 0,
            checked: true,
            cover_image: "111",
            query: props.location.query,
            preStep: false,
            check:1,
            isEdit: !!props.location.query.id,
            type:props.location.query.type,
            pageCode: 1,
            curKey:0
        }
    }
    componentDidMount() {
        let { documentCenterEditActs } = this.props;
        let documentId = this.state.query.documentId;
        documentCenterEditActs.getTopFolderRelation(documentId).done((resp) => {
            let relaArg = {
                'product_id': resp.data.brand.length>0 ? resp.data.brand[0].id : null ,
                'therapeutic_area_id': resp.data.therapeutic_area.length>0 ? resp.data.therapeutic_area[0].id : null,
            }
            documentCenterEditActs.getKmByPdtAndTa(relaArg);
        });
        if(this.state.isEdit){
            let {news,wx_news} = this.props.$$documentCenterEdit.toJS();
            if(this.props.location.query.type==4){
                    this.setState({
                        current:1,
                        check:3,
                        expired: news[0].expire_time==null ? true:false
                    
                })
            }else if(this.props.location.query.type==5){
                    this.setState({
                        current:1,
                        check:4,
                        expired: wx_news[0].expire_time==null ? true:false
                    
                })
            }else if(this.props.location.query.type==1){
                    this.setState({
                        current:2,
                        check:1
                })
                let docId = this.state.query.id;
                let docType = this.state.query.type;
                documentCenterEditActs.getDCConfigDetail(docId,docType).done((data) => {
                    if(this.state.isEdit && data.data.length > 0) {
                        documentCenterEditActs.getPreviewImg(data.data[0].file_name);
                    }
                });
            }else if(this.props.location.query.type==3){
                    this.setState({
                        current:2,
                        check:2
                })
                let docId = this.state.query.id;
                let docType = this.state.query.type;
                documentCenterEditActs.getDCConfigDetail(docId,docType);
            }
        }else {
            this.setState({
                current:0,
                check:1
            })
        }
    }
    render() {
        let fieldDecorator = this._getFieldDecorator();
        let {file,tagkeys,checked,news,htmlType,htmlURL,previewImg,expire} = this.props.$$documentCenterEdit.toJS();
        let steps=[];
        //选择文档类型
        if(this.state.check==1){
            steps = [{
                title: "选择文档类型",
            }, {
                title: "上传文档",
            }, {
                title: "配置文档及保存",
            }];
        }else if(this.state.check == 2){
            steps = [{
                title: "选择文档类型",
            }, {
                title: "导入HTML5",
            }, {
                title: "配置文档及保存"
            }];
        }else if(this.state.check == 3){
            steps = [{
                title: "选择文档类型",
            }, {
                title: "上传文档",
            }];
        }else if(this.state.check == 4){
            steps = [{
                title: "选择文档类型",
            }, {
                title: "创建微信多图文",
            }];
        }
        const radioStyle = {
            display: 'block',
            height: '30px',
            lineHeight: '30px',
            fontSize: "14px",
            marginTop: "25px",
            marginLeft: "50px"
        };
        const formItemLayout = {
            labelCol: { span: 5 },
            wrapperCol: { span: 19 }
        };
        let value=[1,2,3,4];
        
        return (
            <section>
                {this.state.current===1 && this.state.check==4?
                    <Row>
                        <Col span="24">
                            <Row className="m-margin-b">
                                <Col span="10"></Col>
                                <Col span="14">
                                    <Button
                                        type="ghost"
                                        className="m-margin-r m-fr"
                                        onClick={this.onClickGoBack.bind(this)}>返回</Button>
                                    {
                                        this.state.isEdit ? null :(
                                            this.state.current==1 && this.state.check == 3 ? null :
                                            this.state.current==2 && this.state.check == 1? null :
                                            this.state.current==2 && this.state.check == 2? null :
                                            this.state.current==1 && this.state.check == 4? null : 
                                            <Button type="primary"
                                                className="m-margin-r m-fr"
                                                onClick={this.onClickNext.bind(this)}>下一步</Button>
                                        )
                                    }
                                    {
                                        this.state.isEdit ? null :
                                        this.state.check == 3 ? null :
                                        this.state.check == 4 ? null :
                                        (this.state.current === steps.length - 1
                                        &&
                                        <Button type="primary" className="m-margin-r m-fr" onClick={this.onClickSave.bind(this)}>保存</Button>)
                                    }
                                    {   this.state.isEdit ? null : 
                                        this.state.check == 3 ? null :
                                        this.state.check == 4 ? null :
                                        (this.state.current > 0
                                            && (checked!=3 || checked!=4) ?
                                            <Button type="primary"
                                                className="m-margin-r m-fr"
                                                onClick={this.onClickPrev.bind(this)}>上一步</Button>:null
                                        )
                                    }
                                </Col>
                                {/*<Col span="2"></Col>*/}
                            </Row>
                        </Col>
                    </Row>
                    :
                    <Row>
                        <Col span="2"></Col>
                        <Col span="20">
                            <Row className="m-margin-b">
                                <Col span="10"></Col>
                                <Col span="14">
                                    <Button
                                        type="ghost"
                                        className="m-margin-r m-fr"
                                        onClick={this.onClickGoBack.bind(this)}>返回</Button>
                                    {
                                        this.state.isEdit ? null :(
                                            this.state.current==1 && this.state.check == 3 ? null :
                                            this.state.current==2 && this.state.check == 1? null :
                                            this.state.current==2 && this.state.check == 2? null :
                                            this.state.current==1 && this.state.check == 4? null : 
                                            <Button type="primary"
                                                className="m-margin-r m-fr"
                                                onClick={this.onClickNext.bind(this)}>下一步</Button>
                                        )
                                    }
                                    {
                                        (this.state.isEdit && this.state.check !== 1) && (this.state.isEdit &&this.state.check !== 2) ? null :
                                        this.state.check == 3 ? null :
                                        this.state.check == 4 ? null :
                                        (this.state.current === steps.length - 1
                                        &&
                                        <Button type="primary" className="m-margin-r m-fr" onClick={this.onClickSave.bind(this)}>保存</Button>)
                                    }
                                    {   this.state.isEdit ? null : 
                                        this.state.check == 3 ? null :
                                        this.state.check == 4 ? null :
                                        (this.state.current > 0
                                            && (checked!=3 || checked!=4) ?
                                            <Button type="primary"
                                                className="m-margin-r m-fr"
                                                onClick={this.onClickPrev.bind(this)}>上一步</Button>:null
                                        )
                                    }
                                </Col>
                            </Row>
                        </Col>
                        <Col span="2"></Col>
                    </Row>
                }
                
                <Row className="m-margin-b">
                    <Col span="2"></Col>
                    <Col span="20">
                        <Steps current={this.state.current}>
                            {steps.map((item, index) => <Step key={index} title={item.title} />)}
                        </Steps>
                    </Col>
                </Row>
                {
                    this.state.current===1 && this.state.check==4 ? (
                        <Row className="m-margin-b">
                            <Col span="24">
                                <Form>
                                    {this.state.current===0 ? 
                                        <div>
                                            <FormItem {...formItemLayout}> 
                                                <RadioGroup>
                                                    <Radio style={radioStyle} key="0" value={value[0]} checked={value[0]==checked} onClick={this.onClickStyle.bind(this,value[0])}>普通文档</Radio>
                                                    <Radio style={radioStyle} key="1" value={value[1]} checked={value[1]==checked} onClick={this.onClickStyle.bind(this,value[1])}>HTML5 文档</Radio>
                                                    <Radio style={radioStyle} key="2" value={value[2]} checked={value[2]==checked} onClick={this.onClickStyle.bind(this,value[2])}>图文消息</Radio>
                                                    <Radio style={radioStyle} key="3" value={value[3]} checked={value[3]==checked} onClick={this.onClickStyle.bind(this,value[3])}>微信图文消息</Radio>
                                                </RadioGroup>
                                            </FormItem>
                                        </div>
                                        : null }
                                    {this.state.current===1 ? 
                                        (this.state.check==1 ?
                                            <div>
                                                <_SecondStep {...this.props} fieldDecorator={fieldDecorator} />
                                            </div> : (this.state.check==2 ? 
                                            <div>
                                                <_SecondHtml {...this.props} fieldDecorator={fieldDecorator} />
                                            </div> : (this.state.check==3 ? <_SecondApp {...this.props} fieldDecorator={fieldDecorator}/> : (this.state.check==4 ? 
                                            <div>
                                                <_SecondWX {...this.props} fieldDecorator={fieldDecorator} />
                                            </div> : null)) ))
                                        : null }
                                    {this.state.current===2 ? 
                                        <div>
                                            <_ThirdStep {...this.props} fieldDecorator={fieldDecorator} />
                                        </div> : null }
                                </Form>
                            </Col>
                        </Row>):(
                        <Row className="m-margin-b">
                            <Col span="2"></Col>
                            <Col span="20">
                                <Form>
                                    {this.state.current===0 ? 
                                        <div>
                                            <FormItem {...formItemLayout}> 
                                                <RadioGroup>
                                                    <Radio style={radioStyle} key="0" value={value[0]} checked={value[0]==checked} onClick={this.onClickStyle.bind(this,value[0])}>普通文档</Radio>
                                                    <Radio style={radioStyle} key="1" value={value[1]} checked={value[1]==checked} onClick={this.onClickStyle.bind(this,value[1])}>HTML5 文档</Radio>
                                                    <Radio style={radioStyle} key="2" value={value[2]} checked={value[2]==checked} onClick={this.onClickStyle.bind(this,value[2])}>图文消息</Radio>
                                                    <Radio style={radioStyle} key="3" value={value[3]} checked={value[3]==checked} onClick={this.onClickStyle.bind(this,value[3])}>微信图文消息</Radio>
                                                </RadioGroup>
                                            </FormItem>
                                        </div>
                                        : null }
                                    {this.state.current===1 ? 
                                        (this.state.check==1 ?
                                            <div>
                                                <_SecondStep {...this.props} fieldDecorator={fieldDecorator} />
                                            </div> : (this.state.check==2 ? 
                                            <div>
                                                <_SecondHtml {...this.props} fieldDecorator={fieldDecorator} />
                                            </div> : (this.state.check==3 ? <_SecondApp {...this.props} fieldDecorator={fieldDecorator}/> : (this.state.check==4 ? 
                                            <div>
                                                <_SecondWX {...this.props} fieldDecorator={fieldDecorator} />
                                            </div> : null)) ))
                                        : null }
                                    {this.state.current===2 ? 
                                        <div>
                                            <_ThirdStep {...this.props} fieldDecorator={fieldDecorator} />
                                        </div> : null }
                                </Form>
                            </Col>
                        </Row>
                        )
                }
                
            </section>
        );
    }
    onClickStyle(value){
        console.log("-- value --",value)
        let {documentCenterEditActs, $$documentCenterEdit} = this.props;
        documentCenterEditActs.UpdateChecked(value);
        this.setState({
            check:value
        })
    }
    
    onClickGoBack() {
        this.props.router.push({
            pathname: "/documentCenter/list",
            query: { documentId: this.state.query.documentId }
        });
    }
    //点击上一步
    onClickPrev() {
        const current = this.state.current - 1;
        let _this = this;
        let {documentCenterEditActs} = this.props;
        confirm({
            title: "确定中断当前操作吗？",
            onOk() {
                _this.setState({ 
                    current: current,
                    preStep: true
                });
                documentCenterEditActs.saveFile([]);  //清空已缓存的文件
            },
            oncansel() {
                console.log("---取消----")
            }
        });
        
    }
    //点击下一步
    onClickNext() {
        let {file,htmlType,uploadStatus} = this.props.$$documentCenterEdit.toJS();
        const current = this.state.current + 1;
        this.setState({ current });
        if(this.state.current===1 && file.length===0 && uploadStatus && (this.state.check===1 || (this.state.check===2 && htmlType===1))){
            if(uploadStatus){
                tools.showDialog.info("文件上传中，请稍等...")
            }else{
                tools.showDialog.info("请选择文件...")
            }
            this.setState({
                current: current-1
            })
        }
    }
    //点击保存
    onClickSave() {
        let {documentCenterEditActs} = this.props;
        let {file,brands,therapeutic,tagkeys,news,checked,htmlURL,htmlType,previewImg,equalTreeData,keyMessage,DCConfig,relaAreaAndBrand,expire} = this.props.$$documentCenterEdit.toJS();
        let allPage = Array.isArray(previewImg.data) ? previewImg.data.length : null;
        let typeEnum = {
            "1": 1,    //office文档
            "2": 3     //html5
        }
        let saveValues = ["brand_ids","cover_image","expire_time_basic","feedback","introduction","name","share_scopes","therapeutic_areas","use_scopes","water_mark","label_id","key_messages","key_type","key_info"]
        let documentId = this.state.query.documentId;
        this.props.form.validateFieldsAndScroll(saveValues,(errors,values) => {
            let allFields = this.props.form.getFieldsValue();
            if (!!errors) {
                return console.log("save error!!!", values);
            }
            let brandId = [];
            let areaId = [];
            let labelId = [];
            relaAreaAndBrand.brand.map(item => {
                brandId.push(item.id);
            })
            relaAreaAndBrand.therapeutic_area.map(item => {
                areaId.push(item.id);
            })
            values.label_id.map(( item) => {
                equalTreeData.map((obj) => {
                    if(item == obj.name){
                        labelId.push(obj.id);
                    }
                })
            })
            let coverImg;
            //TODO
            if(this.state.isEdit && values.cover_image.length>0) {
                if((DCConfig[0].cover_image==values.cover_image[0].url) && DCConfig[0].cover_image) {
                    coverImg = DCConfig[0].cover_image.substring(DCConfig[0].cover_image.lastIndexOf('/cover/')+7);
                }else{
                    if(values.cover_image && values.cover_image.length !== 0) {
                        coverImg = values.cover_image[0].response.data.file_name;
                    }
                }
            }else{
                if(values.cover_image && values.cover_image.length !== 0) {
                    coverImg = values.cover_image[0].response.data.file_name;
                }
            }
            
            let km={};
            if(values.key_type == 1) {
                km[0] = allFields["key_info"]
            }else {
                for(let i=1; i<=allPage; i++ ) {
                    if(!allFields[`key_info_${i}`]){
                        allFields[`key_info_${i}`] = []
                    }
                    km[i] = allFields[`key_info_${i}`]
                }
            }
            
            if(htmlURL.indexOf("http") == -1) {
                htmlURL = "http://" + htmlURL
            }
            let addSuffix =  file.file_name ? file.file_name.substring(file.file_name.lastIndexOf(".")) : "";
            let editSuffix = DCConfig.length > 0 ? (DCConfig[0].document_name.lastIndexOf(".") == -1 ? "" : DCConfig[0].document_name.substring(DCConfig[0].document_name.lastIndexOf("."))) : "";
            let docId = this.state.query.id;
            let data = {
                "brand_ids": brandId,
                "cover_image": coverImg || null,
                "expire": expire,
                // "expire": false,
                "expire_time": values.expire_time_basic ? values.expire_time_basic._d : null,
                "feedback": values.feedback,
                "file_name": htmlType ===2 ? htmlURL : file.file_name,
                "file_size": file.size,
                "folder_id": parseInt(documentId),
                "introduction": values.introduction,
                "name": values.name+addSuffix,
                "share_scope": values.share_scopes> 0 ? values.share_scopes : null,
                "therapeutic_area_ids": areaId,
                "use_scope": (values.use_scopes && values.use_scopes.length > 0) ? values.use_scopes : null,
                "water_mark": values.water_mark,
                "type": typeEnum[checked],
                "label_id": labelId,
                "key_messages": km
            }
            let editData = {
                "brand_ids": brandId,
                "cover_image": coverImg || null,
                "expire": (values.expire_basic || !values["expire_time_basic"] ? null : (values.expire_time_basic ? values.expire_time_basic._d : DCConfig[0].expire_time)) ? false : true,
                // "expire": expire,
                // "expire_time": values.expire_time_basic ? values.expire_time_basic._d : null,
                "expire_time": values.expire_basic || !values["expire_time_basic"] ? null : (values.expire_time_basic ? values.expire_time_basic._d : DCConfig[0].expire_time),
                "feedback": values.feedback,
                "file_name": DCConfig.length>0 ?DCConfig[0].file_name : null,
                "file_size": DCConfig.length>0 ? DCConfig[0].file_size : null,
                "folder_id": parseInt(documentId),
                "introduction": values.introduction,
                "name": values.name+editSuffix,
                "share_scope": values.share_scopes ? values.share_scopes : null,
                "therapeutic_area_ids": areaId,
                "use_scope": values.use_scopes && values.use_scopes>0 ? values.use_scopes : null,
                "water_mark": values.water_mark,
                "type": DCConfig.length>0 ? DCConfig[0].type : null,
                "label_id": labelId,
                "key_messages": km
            }
            if(this.state.isEdit){
                documentCenterEditActs.saveDCConfig(editData,this.state.isEdit,docId);
            } else {
                documentCenterEditActs.saveDCConfig(data,this.state.isEdit,docId);   
            }
        });
        
        
    }
    normFile(e) {
        let _this=this;
        if (Array.isArray(e)) {
            return e;
        }
        return e && e.fileList;
    }
    _getFieldDecorator() {
        const { form } = this.props;
        const { getFieldDecorator } = this.props.form;
        let {file,news,expire, wx_news, equalTreeData,DCConfig,relaAreaAndBrand} = this.props.$$documentCenterEdit.toJS();
        //获取文件夹带产品及治疗领域属性
        let relaArea = [];
        let relaBrand = [];
        relaAreaAndBrand.therapeutic_area.map(item => {
            relaArea.push(item.name);
        })
        relaAreaAndBrand.brand.map(item => {
            relaBrand.push(item.name);
        })
        let key_messages=[];
        let lable_ids=[];
        //TODO
        const fileList = [{
            uid: '-1',
            name: DCConfig.length>0 && DCConfig[0].cover_image && DCConfig[0].cover_image.substring(DCConfig[0].cover_image.lastIndexOf('/cover/')+7),
            status: 'done',
            url: DCConfig.length>0 && DCConfig[0].cover_image,
            thumbUrl: DCConfig.length>0 && DCConfig[0].cover_image
        }]

        if(this.state.type==4){
            news[0].key_messages.map((item)=>{
                key_messages.push(item.name)
            })
            news[0].labels.map((item)=>{
                lable_ids.push(item.name)
            })
        }else if(this.state.type==5){
            news[0].key_messages.map((item)=>{
                key_messages.push(item.name)
            })
        }else if(this.state.type==1 || this.state.type==3){
            if(DCConfig.length>0) {
                if(Array.isArray(DCConfig[0].labels)) {
                    DCConfig[0].labels.map((item)=>{
                        lable_ids.push(item.name)
                    })
                } 
                if(Array.isArray(DCConfig[0].key_messages)) {
                    DCConfig[0].key_messages.map((item)=>{
                        key_messages.push(item.name)
                    })
                } 
            }
        }
        //多图文的过期时间 bug编号：12605
        var wxExpireTimeArr = [];
        for(var i=0; i<wx_news.length; i++) {
            if(wx_news[i] !== undefined) {
                wxExpireTimeArr.push(wx_news[i].expire_time)
            }
        }
        return {
            /**
             * step2: 创建图文消息
             */
            "use_scope": getFieldDecorator("use_scope", {
                initialValue: "",
            }),
            "share_scope": getFieldDecorator("share_scope", {
                initialValue: "",
            }),
            "author": getFieldDecorator("author", {
                initialValue: this.state.isEdit && this.state.type==4 ? news[0].material.author :"",
                rules: [
                    { max: 8, message: "作者不得超过8个字符" }
                ]
            }),
            //过期时间(单多图文)
            "expire_time": getFieldDecorator("expire_time", {
                initialValue: this.state.isEdit && this.state.type==4 ?(news[0].expire_time == null?null: moment(news[0].expire_time))
                                :this.state.type==5 ? moment(wxExpireTimeArr[0]) : null,
                rules: [
                    {
                        required: true,
                        validator: this.onCheckedExpireTime
                    }
                ]
            }),
            //导语
            "introduction_app": getFieldDecorator("introduction_app", {
                initialValue: this.state.isEdit && this.state.type==4 ? news[0].introduction :"",
                rules: [
                    { max: 120, message: "导语不得超过120个字符" }
                ]
            }),
            //关联品牌
            "brand_ids": getFieldDecorator("brand_ids", {
                initialValue: relaBrand,
            }),
            //关联治疗领域
            "therapeutic_areas": getFieldDecorator("therapeutic_areas", {
                initialValue: relaArea
            }),
            //关联信息点
            "key_messages": getFieldDecorator("key_messages", {
                initialValue: this.state.isEdit && this.state.type==4 ? key_messages :[],
            }),
            //关联标签
            "labels": getFieldDecorator("labels", {
                initialValue: this.state.isEdit && this.state.type==4 ? lable_ids :[],
            }),
            /**
             * step3: 配置文档
             */
            //文档名称
            "name": getFieldDecorator("name", {
                initialValue: file.document_name ? file.document_name.substring(0,file.document_name.lastIndexOf(".")) : (DCConfig.length > 0 && DCConfig[0].document_name ? (DCConfig[0].document_name.lastIndexOf(".")==-1 ? DCConfig[0].document_name :DCConfig[0].document_name.substring(0,DCConfig[0].document_name.lastIndexOf("."))) : ""),
                rules: [
                    { max: 200, message: "文档名称不得超过200个字符" },
                    { required: true, validator: function (rule, value, callback) {
                        if ($.trim(value) === "") {
                            return callback("请填写文档名称");
                        }
                        callback();
                    } }
                ]
            }),
            //过期时间H5/office
            "expire_time_basic": getFieldDecorator("expire_time_basic", {
                initialValue:  (DCConfig.length >0 && DCConfig[0].expire_time) ? moment(DCConfig[0].expire_time) : null,
                rules: [
                    {
                        required: true,
                        validator: this.onCheckedExpireTimeBasic
                    }
                ]
            }),
            //支持平台（1期不做）
            //上传封面
            //TODO
            "cover_image": getFieldDecorator("cover_image", {
                initialValue: this.state.isEdit &&  DCConfig.length > 0 && DCConfig[0].cover_image ? [...fileList] : [],
                valuePropName: 'fileList',
                getValueFromEvent: this.normFile
            }),

            //文档权限
            "use_scopes": getFieldDecorator("use_scopes", {
                initialValue: DCConfig.length > 0 ? (DCConfig[0].use_scopes || []) : []
            }),
            //分享权限
            "share_scopes": getFieldDecorator("share_scopes", {
                initialValue: DCConfig.length > 0 ? DCConfig[0].share_scopes : [],
            }),
            //客户反馈
            "feedback": getFieldDecorator("feedback", {
                initialValue: true,
            }),
            //文档评级（1期不做）
            //文档介绍
            "introduction": getFieldDecorator("introduction", {
                initialValue: (this.state.isEdit && DCConfig.length > 0) ? DCConfig[0].introduction : "",
            }),
            //水印
            "water_mark": getFieldDecorator("water_mark", {
                initialValue: (this.state.isEdit && DCConfig.length > 0) ? DCConfig[0].water_mark : "",
            }),
            "label_id": getFieldDecorator("label_id", {
                initialValue: this.state.isEdit ? lable_ids : [],
            }),
            "key_type": getFieldDecorator("key_type", {
                initialValue: (this.state.isEdit && DCConfig.length > 0 && DCConfig[0].key_messages.length > 0) ? (DCConfig[0].key_messages[0].page_index == 0 ? 1 : 2) : 1,
            }),
            "key_info": getFieldDecorator("key_info", {
                initialValue: key_messages || [],
            })
        }
    }
    //自定义校验时间
    onCheckedExpireTime = (rule, value, callback) => {
        let {expire} = this.props.$$documentCenterEdit.toJS();
        const { form } = this.props;
        if (value == null) {
            callback("请选择过期时间");
            return;
        }
        callback();
    }
    //自定义校验时间
    onCheckedExpireTimeBasic = (rule, value, callback) => {
        let expire = $(".neverOutDate span:first").hasClass("ant-checkbox-checked");
        const { form } = this.props;
        if (!expire && value == null) {
            callback("请选择过期时间");
            return;
        }
        callback();
    }
    


}

DocumentCenterEdit = Form.create()(DocumentCenterEdit);

export default connect(
    (state) => {
        return {
            $$documentCenterEdit: state.$$documentCenterEdit
        }
    },
    (dispatch) => {
        return {
            documentCenterEditActs: bindActionCreators(Actions, dispatch)
        }
    })(withRouter(DocumentCenterEdit))
