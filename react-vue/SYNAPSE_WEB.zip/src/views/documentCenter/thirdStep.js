import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/documentCenter"
import { Enum, EnumCn } from "enum"
import { tools } from "utils"
import Icon from "antd/lib/icon"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import Tag from "antd/lib/tag"
import Radio from "antd/lib/radio"
import Collapse from "antd/lib/collapse"
import Checkbox from "antd/lib/checkbox"
import Select from "antd/lib/select"
import DatePicker from "antd/lib/date-picker"
import moment from "moment"
import Slider from 'react-slick';
import TreeSelect from 'antd/lib/tree-select';
import Tooltip from 'antd/lib/tooltip'
import Upload from "components/upload"

const RadioGroup = Radio.Group;
const Panel = Collapse.Panel;
const FormItem = Form.Item;
const CheckboxGroup = Checkbox.Group;
const Option = Select.Option;
const TreeNode = TreeSelect.TreeNode;

// TODO
import dcKmListData from "mockdata/dcKmListData"


class _ThirdStep extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            tags: [],
        }
        this.treeDataList = [];
        // this.relatedTreeTrue = dcKmListData.data;
        this.relatedTreeTrue = [];
    }
    componentDidMount() {
    }
    render() {
        let fieldDecorator = this.props.fieldDecorator;
        // let { relatedTreeTrue } = this.props.$$documentCenterEdit.toJS();
        let { documentCenterEditActs } = this.props;
        const { tags } = this.state;
        const formItemLayout = {
            labelCol: { span: 5 },
            wrapperCol: { span: 19 }
        };
        let kmTreeNodesJSX = this.renderTreeNodes(this.relatedTreeTrue ? this.relatedTreeTrue : []);
        return (
            <div className="third-step">
                <FormItem label="信息点"
                    {...formItemLayout}>
                    {fieldDecorator.label_id(
                        <TreeSelect
                            style={{ width: "75%" }}
                            dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                            multiple={true}
                            // allowClear
                            treeDefaultExpandAll
                            onChange={this.onChangeTreeNodes.bind(this)}
                        >
                            {kmTreeNodesJSX}
                        </TreeSelect>
                    )}
                </FormItem>
                <FormItem label="标签"
                    {...formItemLayout}>
                    {fieldDecorator.share_scopes(
                        <EditableTagGroup tags={tags} handleTagsChange={this.handleTagsChange.bind(this)} />
                    )}
                </FormItem>
            </div>
        )
    }
    //树处理
    renderTreeNodes(data) {
        let nodes = [];
        nodes = data.map((item, index) => {
            if (item.child_list.length > 0) {
                return (
                    <TreeNode key={item.id}
                        title={item.name}
                        value={item.name || ''}>
                        {this.renderTreeNodes(item.child_list)}
                    </TreeNode>
                )
            } else {
                return (
                    <TreeNode key={item.id}
                        isLeaf={true}
                        title={item.name}
                        value={item.name || ''}></TreeNode>
                )
            }
        });
        return nodes;
    }
    //选中树节点时调用
    onChangeTreeNodes(value, label, extra) {
        // let { relatedTreeTrue } = this.props.$$documentCenterEdit.toJS();
        console.log('-- onChangeTreeNodes --', value, label, extra)
        this.treeDataList = [];
        let selectArr = [];
        this.generateList(this.relatedTreeTrue);
        this.treeDataList.map((item) => {
            value.map((obj, index) => {
                if (obj === item.id) {
                    selectArr.push(item.name)
                }
            })
        });
        this.setState({
            checkedId: value,
            selectVal: selectArr
        })
    }
    // 将树结构按照单一节点存入输入
    generateList(data) {
        let { documentCenterEditActs } = this.props;
        for (let i = 0; i < data.length; i++) {
            const node = data[i];
            const key = node.name;
            this.treeDataList.push({ id: node.id, name: node.name, parent_id: node.parent_id });
            if (node.child_list.length > 0) {
                this.generateList(node.child_list);
            }
        }
        // console.log('-- this.treeDataList --', this.treeDataList)
        // documentCenterEditActs.saveEqualTreeData(this.treeDataList);
    }
    // tags 变化
    handleTagsChange(tags) {
        this.setState({ tags })
    }
}

// 标签输入展示框
// tags array 
// handleTagsChange(tags) function
class EditableTagGroup extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            inputVisible: false,
            inputValue: '',
        };
    }

    render() {
        const { inputVisible, inputValue } = this.state;
        let { tags } = this.props;
        console.log('-- tags --', tags)
        return (
            <div>
                {tags && tags.map((tag, index) => {
                    const isLongTag = tag.length > 20;
                    const tagElem = (
                        <Tag key={tag} closable={index !== 0} afterClose={() => this.handleClose(tag)}>
                            {isLongTag ? `${tag.slice(0, 20)}...` : tag}
                        </Tag>
                    );
                    return isLongTag ? <Tooltip title={tag} key={tag}>{tagElem}</Tooltip> : tagElem;
                })}
                {inputVisible && (
                    <Input
                        ref={this.saveInputRef}
                        type="text"
                        size="small"
                        style={{ width: 78 }}
                        value={inputValue}
                        onChange={this.handleInputChange.bind(this)}
                        onBlur={this.handleInputConfirm.bind(this)}
                        onPressEnter={this.handleInputConfirm.bind(this)}
                    />
                )}
                {!inputVisible && (
                    <Tag
                        onClick={this.showInput.bind(this)}
                        style={{ background: '#fff', borderStyle: 'dashed' }}
                    >
                        <Icon type="plus" /> 标签
                    </Tag>
                )}
            </div>
        );
    }

    // 点击关闭标签
    handleClose(removedTag) {
        let { tags, handleTagsChange } = this.props;
        const resTags = tags.filter(tag => tag !== removedTag);
        if (typeof handleTagsChange === 'function') {
            handleTagsChange.call(this, resTags);
        }
    }

    // 显示输入框
    showInput() {
        this.setState({ inputVisible: true }, () => this.input.focus());
    }

    // input 变化
    handleInputChange(e) {
        this.setState({ inputValue: e.target.value });
    }

    // 完成 tag 输入
    handleInputConfirm() {
        let { tags, handleTagsChange } = this.props;
        let resTags = tags;
        const state = this.state;
        const inputValue = state.inputValue;
        if (inputValue && tags.indexOf(inputValue) === -1) {
            resTags = [...tags, inputValue];
        }
        this.setState({
            inputVisible: false,
            inputValue: '',
        });
        if (typeof handleTagsChange === 'function') {
            handleTagsChange.call(this, resTags);
        }
    }

    // 获取 Input 的 ref
    saveInputRef = input => this.input = input

}

class Demo extends React.Component {
    state = {
      value: undefined,
    }
    onChange = (value) => {
      console.log(arguments);
      this.setState({ value });
    }
    render() {
      return (
        <TreeSelect
          showSearch
          style={{ width: 300 }}
          value={this.state.value}
          dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
          placeholder="Please select"
          allowClear
          multiple
          treeDefaultExpandAll
          onChange={this.onChange}
        >
          <TreeNode value="parent 1" title="parent 1" key="0-1">
            <TreeNode value="parent 1-0" title="parent 1-0" key="0-1-1">
              <TreeNode value="leaf1" title="my leaf" key="random" />
              <TreeNode value="leaf2" title="your leaf" key="random1" />
            </TreeNode>
            <TreeNode value="parent 1-1" title="parent 1-1" key="random2">
              <TreeNode value="sss" title={<b style={{ color: '#08c' }}>sss</b>} key="random3" />
            </TreeNode>
          </TreeNode>
        </TreeSelect>
      );
    }
  }

export default _ThirdStep



