import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/documentCenter"
import { Enum, EnumCn } from "enum"
import {ColorEnum} from 'src/constants/customEnum'
import { tools } from "utils"
import Modal from "antd/lib/modal"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Form from "antd/lib/form"
import Button from "antd/lib/button"
import Radio from "antd/lib/radio"
import Steps from "antd/lib/steps"
import Upload from "antd/lib/upload"
import Checkbox from "antd/lib/checkbox"

import _FirstNormal from "./firstNormal"
import _FirstH5 from "./firstH5"
import _FirstImageTxt from "./firstImageTxt"
import _FirstQa from "./firstQa"
import _FirstWxImageTxt from "./firstWxImageTxt"
import _FirstVol from "./firstVol"
import _FirstVod from "./firstVod"

import _SecondStep from "./secondStep"
import _ThirdStep from "./thirdStep"
import moment from "moment"
import ReactQRCode from 'components/QRCode'
import EditInfo from 'components/editInfo'
import "assets/style/views/documentCenter/edit.less"

const Step = Steps.Step;
const RadioGroup = Radio.Group;
const Dragger = Upload.Dragger;
const FormItem = Form.Item;
const CheckboxGroup = Checkbox.Group;
const confirm = Modal.confirm;

class DocumentCenterEdit extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            current: 0,       // step当前值
            cover_image: "",  // 封面
            query: props.location.query,
            preStep: false,   // 上一步
            check: 1,         //选中的上传文档类型
            isEdit: !!props.location.query.id,
            type: props.location.query.type // 文档类型: 0-文件夹 1-普通文档  2-外部链接  3-h5  4-单图文  5-多图文
        }
    }
    componentDidMount() {
        let { documentCenterEditActs } = this.props;
        let { isEdit } = this.state;
        let documentId = this.state.query.documentId;
        // TODO 获取所有信息点
        // documentCenterEditActs.getKmByPdtAndTa(relaArg);

        // TODO 不同类型在编辑时获取详情
        // if(isEdit)
    }
    render() {
        let fieldDecorator = this._getFieldDecorator();
        let { file, tagkeys, news, htmlType, htmlURL, previewImg, expire } = this.props.$$documentCenterEdit.toJS();
        let query = tools.getQuery();
        let { current, isEdit } = this.state;

        let step1Txt = '';  // 步骤一显示文字
        let step1JSX = '';
        switch (Number(query.documentType)) {
            case Enum.ResourceType.normal:
                step1Txt = '上传文档';
                step1JSX = <_FirstNormal {...this.props} fieldDecorator={fieldDecorator} />;
                break;
            case Enum.ResourceType.h5:
                step1Txt = '上传文档';
                step1JSX = <_FirstH5 {...this.props} fieldDecorator={fieldDecorator} />
                break;
            case Enum.ResourceType.imagetxt:
                step1JSX = <_FirstImageTxt {...this.props} fieldDecorator={fieldDecorator} />;
                step1Txt = '内容录入';
                break;
            case Enum.ResourceType.wximagetxt:
                step1JSX = <_FirstWxImageTxt {...this.props} fieldDecorator={fieldDecorator} />;
                step1Txt = '内容录入';
                break;
            case Enum.ResourceType.qa:
                step1JSX = <_FirstQa {...this.props} fieldDecorator={fieldDecorator} />;
                step1Txt = '撰写问卷';
                break;
            case Enum.ResourceType.vol:
                step1JSX = <_FirstVol {...this.props} fieldDecorator={fieldDecorator} />;
                step1Txt = '装修直播间';
                break;
            case Enum.ResourceType.vod:
                step1JSX = <_FirstVod {...this.props} fieldDecorator={fieldDecorator} />
                step1Txt = '内容录入';
                break;
            default:
                step1Txt = '默认';
                step1JSX = <div>第一步哈哈哈</div>;
                break;
        }
        // 步骤条文字
        let steps = [{
            title: step1Txt,
        }, {
            title: "配置文档属性",
        }, {
            title: "设置信息点",
        }];

        // 文档抬头信息
        let DcColorIconItem = ColorEnum.DcColorIcon[Enum.ResourceType[query.documentType]];
        let editInfoData = {
            title: `${isEdit ? '编辑' : '新建'} - ${EnumCn.ResourceType[query.documentType]}`,
            creator: "小白菜",
            department: "市场部",
            product: "韦瑞德",
            field: "HIV",
            icon: DcColorIconItem.icon,
            color: DcColorIconItem.color,
            bgColor: DcColorIconItem.bgColor,
            cancelTxt: "取 消",
            completeTxt: `${current !== steps.length - 1 ? '下一步' : '保 存'}`,
        }

        return (
            <section id="dc-edit">
                {/* <Row className="m-margin-b">
                    <Col span="8"></Col>
                    <Col span="14">
                        <Button
                            type="host"
                            className="m-margin-r m-fr"
                            onClick={this.onClickGoBack.bind(this)}>取消</Button>
                        {current !== steps.length - 1 ?
                            <Button
                                type="primary"
                                className="m-margin-r m-fr"
                                onClick={this.onClickNext.bind(this)}>下一步</Button> :
                            <Button
                                type="primary"
                                className="m-margin-r m-fr"
                                onClick={this.onClickSave.bind(this)}>保存</Button>}
                    </Col>
                    <Col span="2"></Col>
                </Row> */}
                <EditInfo 
                    dataSource={editInfoData} 
                    onComplete={current !== steps.length - 1 ? this.onClickNext.bind(this) : this.onClickSave.bind(this)}
                    onCancel={this.onClickGoBack.bind(this)}
                />
                <div className="page-content-border" style={{minHeight: 'calc(100% - 172px)'}}>
                    <Row className="m-margin-b">
                        <Col span="2"></Col>
                        <Col span="20">
                            <Steps current={this.state.current}>
                                {steps.map((item, index) => <Step key={index} title={item.title} />)}
                            </Steps>
                        </Col>
                    </Row>

                    <Row className="m-margin-b">
                        <Col span="2"></Col>
                        <Col span="20">
                            <Form >
                                {this.state.current === 0 ?
                                    step1JSX : null
                                }
                                {this.state.current === 1 ?
                                    <_SecondStep {...this.props} fieldDecorator={fieldDecorator} /> : null
                                }
                                {this.state.current === 2 ?
                                    <_ThirdStep {...this.props} fieldDecorator={fieldDecorator} /> : null
                                }
                            </Form>
                        </Col>
                    </Row>
                </div>
            </section>
        );
    }
    //点击取消
    onClickGoBack() {
        this.props.router.go(-1);
    }
    //点击下一步
    onClickNext() {
        let { file, htmlType, uploadStatus } = this.props.$$documentCenterEdit.toJS();
        const current = this.state.current + 1;
        this.setState({ current });
        // if (this.state.current === 1 && file.length === 0 && (this.state.check === 1 || (this.state.check === 2 && htmlType === 1))) {
        //     if (uploadStatus) {
        //         tools.showDialog.info("文件上传中，请稍等...")
        //     } else {
        //         tools.showDialog.info("请选择文件...")
        //     }
        //     this.setState({
        //         current: current - 1
        //     })
        // }
    }
    //点击保存
    onClickSave() {
        console.log('-- 点击保存！！！ --');
        let query = tools.getQuery();
        this.props.router.replace({
            pathname: "/documentCenter/detail",
            query: {
                documentType: query.documentType
            }
        });
    }
    normFile(e) {
        let _this = this;
        if (Array.isArray(e)) {
            return e;
        }
        return e && e.fileList;
    }
    _getFieldDecorator() {
        const { form } = this.props;
        const { getFieldDecorator } = this.props.form;
        let { file, news, expire, wx_news, equalTreeData, DCConfig, relaAreaAndBrand } = this.props.$$documentCenterEdit.toJS();
        //获取文件夹带产品及治疗领域属性
        let relaArea = [];
        let relaBrand = [];
        relaAreaAndBrand.therapeutic_area.map(item => {
            relaArea.push(item.name);
        })
        relaAreaAndBrand.brand.map(item => {
            relaBrand.push(item.name);
        })
        let key_messages = [];
        let lable_ids = [];
        // 上传封面
        const fileList = [{
            uid: '-1',
            name: DCConfig.length > 0 && DCConfig[0].cover_image && DCConfig[0].cover_image.substring(DCConfig[0].cover_image.lastIndexOf('/cover/') + 7),
            status: 'done',
            url: DCConfig.length > 0 && DCConfig[0].cover_image,
            thumbUrl: DCConfig.length > 0 && DCConfig[0].cover_image
        }]

        if (this.state.type == 4) {
            news[0].key_messages.map((item) => {
                key_messages.push(item.name)
            })
            news[0].labels.map((item) => {
                lable_ids.push(item.name)
            })
        } else if (this.state.type == 5) {
            news[0].key_messages.map((item) => {
                key_messages.push(item.name)
            })
        } else if (this.state.type == 1 || this.state.type == 3) {
            if (DCConfig.length > 0) {
                if (Array.isArray(DCConfig[0].labels)) {
                    DCConfig[0].labels.map((item) => {
                        lable_ids.push(item.name)
                    })
                }
                if (Array.isArray(DCConfig[0].key_messages)) {
                    DCConfig[0].key_messages.map((item) => {
                        key_messages.push(item.name)
                    })
                }
            }
        }
        //多图文的过期时间 bug编号：12605
        var wxExpireTimeArr = [];
        for (var i = 0; i < wx_news.length; i++) {
            if (wx_news[i] !== undefined) {
                wxExpireTimeArr.push(wx_news[i].expire_time)
            }
        }
        return {
            /**
             * step2: 创建图文消息
             */
            "use_scope": getFieldDecorator("use_scope", {
                initialValue: "",
            }),
            "share_scope": getFieldDecorator("share_scope", {
                initialValue: "",
            }),
            "author": getFieldDecorator("author", {
                initialValue: this.state.isEdit && this.state.type == 4 ? news[0].material.author : "",
                rules: [
                    { max: 8, message: "作者不得超过8个字符" }
                ]
            }),
            //过期时间(单多图文)
            "expire_time": getFieldDecorator("expire_time", {
                // initialValue: this.state.isEdit && this.state.type == 4 ? (news[0].expire_time == null ? null : moment(news[0].expire_time))
                //     : this.state.type == 5 ? moment(wxExpireTimeArr[0]) : null,
                initialValue: this.state.isEdit && this.state.type == 4 ? (news[0].expire_time == null ? null : moment(news[0].expire_time))
                    : this.state.type == 5 ? (wxExpireTimeArr[0] == null ? null : moment(wxExpireTimeArr[0])) : null,
                rules: [
                    {
                        required: true,
                        validator: this.onCheckedExpireTime
                    }
                ]
            }),
            //导语
            "introduction_app": getFieldDecorator("introduction_app", {
                initialValue: this.state.isEdit && this.state.type == 4 ? news[0].introduction : "",
                rules: [
                    { max: 120, message: "导语不得超过120个字符" }
                ]
            }),
            //关联品牌
            "brand_ids": getFieldDecorator("brand_ids", {
                initialValue: relaBrand,
            }),
            //关联治疗领域
            "therapeutic_areas": getFieldDecorator("therapeutic_areas", {
                initialValue: relaArea
            }),
            //关联信息点
            "key_messages": getFieldDecorator("key_messages", {
                initialValue: this.state.isEdit && this.state.type == 4 ? key_messages : [],
            }),
            //关联标签
            "labels": getFieldDecorator("labels", {
                initialValue: this.state.isEdit && this.state.type == 4 ? lable_ids : [],
            }),
            /**
             * step3: 配置文档
             */
            //文档名称
            "name": getFieldDecorator("name", {
                initialValue: file.document_name ? file.document_name.substring(0, file.document_name.lastIndexOf(".")) : (DCConfig.length > 0 && DCConfig[0].document_name ? (DCConfig[0].document_name.lastIndexOf(".") == -1 ? DCConfig[0].document_name : DCConfig[0].document_name.substring(0, DCConfig[0].document_name.lastIndexOf("."))) : ""),
                rules: [
                    { max: 200, message: "文档名称不得超过200个字符" },
                    {
                        required: true, validator: function (rule, value, callback) {
                            if ($.trim(value) === "") {
                                return callback("请填写文档名称");
                            }
                            callback();
                        }
                    }
                ]
            }),
            //过期时间H5/office
            "expire_time_basic": getFieldDecorator("expire_time_basic", {
                initialValue: (DCConfig.length > 0 && DCConfig[0].expire_time) ? moment(DCConfig[0].expire_time) : null,
                rules: [
                    {
                        required: true,
                        validator: this.onCheckedExpireTimeBasic
                    }
                ]
            }),
            //支持平台（1期不做）
            //上传封面
            "cover_image": getFieldDecorator("cover_image", {
                initialValue: '',
                valuePropName: 'fileList',
                getValueFromEvent: this.normFile
            }),

            //文档权限
            "use_scopes": getFieldDecorator("use_scopes", {
                initialValue: DCConfig.length > 0 ? (DCConfig[0].use_scopes || []) : []
            }),
            //分享权限
            "share_scopes": getFieldDecorator("share_scopes", {
                initialValue: DCConfig.length > 0 ? DCConfig[0].share_scopes : [],
            }),
            //客户反馈
            "feedback": getFieldDecorator("feedback", {
                initialValue: true,
            }),
            //文档评级（1期不做）
            //文档介绍
            "introduction": getFieldDecorator("introduction", {
                initialValue: (this.state.isEdit && DCConfig.length > 0) ? DCConfig[0].introduction : "",
            }),
            //水印
            "water_mark": getFieldDecorator("water_mark", {
                initialValue: (this.state.isEdit && DCConfig.length > 0) ? DCConfig[0].water_mark : "",
            }),
            "label_id": getFieldDecorator("label_id", {
                initialValue: this.state.isEdit ? lable_ids : [],
            }),
            "key_type": getFieldDecorator("key_type", {
                initialValue: (this.state.isEdit && DCConfig.length > 0 && DCConfig[0].key_messages.length > 0) ? (DCConfig[0].key_messages[0].page_index == 0 ? 1 : 2) : 1,
            }),
            "key_info": getFieldDecorator("key_info", {
                initialValue: key_messages || [],
            }),
            //直播链接
            live_url: getFieldDecorator("live_url", {
                initialValue: '',
                rules: [
                    { required: true, message: "请填写直播链接" },
                    { type: 'url', message: "直播链接格式不正确" }
                ]
            })
        }
    }
    //自定义校验时间
    onCheckedExpireTime = (rule, value, callback) => {
        // let { expire } = this.props.$$documentCenterEdit.toJS();
        let expire = $(".neverOutDate span:first").hasClass("ant-checkbox-checked");
        const { form } = this.props;
        if (!expire && value == null) {
            callback("请选择过期时间");
            return;
        }
        callback();
    }
    //自定义校验时间
    onCheckedExpireTimeBasic = (rule, value, callback) => {
        let expire = $(".neverOutDate span:first").hasClass("ant-checkbox-checked");
        const { form } = this.props;
        if (!expire && value == null) {
            callback("请选择过期时间");
            return;
        }
        callback();
    }
}

DocumentCenterEdit = Form.create()(DocumentCenterEdit);

export default connect(
    (state) => {
        return {
            $$documentCenterEdit: state.$$documentCenterEdit
        }
    },
    (dispatch) => {
        return {
            documentCenterEditActs: bindActionCreators(Actions, dispatch)
        }
    })(withRouter(DocumentCenterEdit))
