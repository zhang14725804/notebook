import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/documentCenter"
import { Enum, EnumCn } from "enum"
import { tools } from "utils"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import UEditor from "components/ueditor"//编辑器组件
import DialogDemo from 'components/demo/dialogDemo'
import moment from "moment"

const FormItem = Form.Item;
const TextArea = Input.TextArea;

const saveFields = { //key和currentIndex对应，value和要保存的字段名对应
    0: [],
    // 其中type和temp_id字段只有在提交校验的时候会从query中取值填充，其他时候保持空值无用状态，id字段在初始化的时候赋值
    1: ["author", "introduction_app", "brand_ids", "therapeutic_areas", "key_messages", "labels","expire_time"],
    2: ["threshold", "promotion_time"],
}


//点播页面
// 直接从直播复制过来的
class _FirstVod extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isEdit: !!props.location.query.id,
            query: props.location.query,
            type: props.location.query.type,
            content: "",
            title: "",
            editor_id: `editor_${Math.random()}`,
            id: props.location.query.id,
            previewData: {},
            checked: false,
            expired: false
        };
        this.dataList = [];
    }
    componentDidMount() {
        // 今天 TODO
        // 想保存部分逻辑
        // TODO ueditor sfa 在 ueditor.all.js 改过东西，上传图片那里

        let { documentCenterEditActs } = this.props;
        documentCenterEditActs.reset();
        if (this.state.isEdit) {
            // 编辑页获取详情，不同类型的详情用一个接口
            // documentCenterEditActs.getAppNews(this.state, true)
        }
    }
    render() {
        let fieldDecorator = this.props.fieldDecorator;
        const { previewData } = this.state;
        const formItemLayout = {
            labelCol: { span: 5 },
            wrapperCol: { span: 19 }
        };
        let originUrl = encodeURIComponent(tools.getOriginUrl());
        //预览数据
        let dataSource = [
            {
                // platform: contentType,
                content: {
                    title: previewData.title,
                    author: previewData.author,
                    // time: previewData.ctime,
                    content_text: previewData.content
                },
                qrcode: tools.previewApi(`/infoAppDemo?resource_id=${previewData.resource_id}&originUrl=${originUrl}&isEdit=true`),
            }
        ]
        return (
            <div className="first-image-txt">
                {/* <div className="m-handle-btn">
                    <div className="wrap">
                        <Button type="primary" className="m-margin-r" onClick={this.onClickSave.bind(this, "next")}>保存</Button>
                        <DialogDemo onBeforeShowModal={this.onClickPreview.bind(this)} dataSource={dataSource} />
                    </div>
                </div> */}
                <div><span className="tooltip-desc">*</span>注：正文最多可输入2万字。</div>
                <Row className="m-edit-content">
                    <div className="m-edit-content-col" style={{ width: "100%" }}>
                        <UEditor
                            id={this.state.editor_id}
                            onBlur={this.onBlur.bind(this)}
                            onEditorReady={this.onEditorReady.bind(this)}
                            content={this.state.content}
                            title={this.state.title}
                        />
                    </div>
                </Row>
                <TextArea className="copy-textarea" rows={12} placeholder="粘贴纯文本（可选）" />
            </div>
        )
    }
    //编辑器加载完成获取数据
    onEditorReady() {
        // let {newsActs, commonActs, form, $$layout} = this.props;
        let { documentCenterEditActs } = this.props;
        let id = this.state.query.id;
        if (this.state.isEdit) {
            // 如果是编辑页，获取图文详情
            documentCenterEditActs.getAppNews(this.state, true).done(resp => {//取this.state的type和id调接口
                const { documentCenterEditActs } = this.props;
                const { brands, therapeutic_areas } = resp.data[0];
                const content = resp.data[0].material.content;
                const title = resp.data[0].material.title;
                // const {commonActs, form} = this.props;
                this.setState({
                    content,
                    title
                })
                // if(document.getElementById('editor-extend-title-input')){
                //   document.getElementById('editor-extend-title-input').value = title;
                // }
                // documentCenterEditActs.getKmByPdtAndTa((brands || []).map(o => o.id), (therapeutic_areas || []).map(o => o.id))
            });
        }
    }
    //编辑器失去焦点
    onBlur(value) {
        this.setState({ content: value });
    }
    //图文预览
    onClickPreview() {
        let { documentCenterEditActs, form } = this.props;
        let { content } = this.state;
        const { news } = this.props.$$documentCenterEdit.toJS();
        let extendTitle = '';
        if (document.getElementById('editor-extend-title-input')) {
            extendTitle = document.getElementById('editor-extend-title-input').value;
        }
        const fields = $.extend(true,
            {},
            {
                title: extendTitle,
                author: news[0].material.author,
                content: content,
            }
        );
        documentCenterEditActs.savePreview(fields).done((resp) => {

            let resource_id = resp.data;
            documentCenterEditActs.getNewsPreviewDetail(resp.data).done((resp) => {
                if (!resp.data) return;
                this.setState({ previewData: $.extend({}, { resource_id: resource_id }, JSON.parse(resp.data)) })
            });
        })
    }
    //点击保存按钮
    // TODO 保存这里逻辑还没想
    onClickSave(operation) {
        let documentId = this.state.query.documentId;
        let { documentCenterEditActs, form } = this.props;
        let { news } = this.props.$$documentCenterEdit.toJS();
        let valiFields = $.map(form.getFieldsValue(), (val, key) => key);
        let { content, isEdit } = this.state;
        let extendTitle = '';
        if (document.getElementById('editor-extend-title-input')) {
            extendTitle = document.getElementById('editor-extend-title-input').value;
        }
        let isExtendError = (extendTitle && content) ? false : true;//判断标题和内容是否为空
        form.validateFieldsAndScroll(saveFields[1], (errors, values) => {
            if (!!errors || !!isExtendError) {
                tools.showDialog.error("请补全提交信息");
                return;
            }
            let { brands, therapeutic, allkp, equalTreeData, relaAreaAndBrand } = this.props.$$documentCenterEdit.toJS();
            //产品
            let brand_ids = [];
            //治疗领域
            let therapeuticId = [];
            relaAreaAndBrand.brand.map(item => {
                brand_ids.push(item.id);
            })
            relaAreaAndBrand.therapeutic_area.map(item => {
                therapeuticId.push(item.id);
            })

            //信息点
            let kmId = [];
            if (values.key_messages != undefined) {
                values.key_messages.map((item) => {
                    allkp.map((obj) => {
                        if (item == obj.name) {
                            kmId.push(obj.id)
                        }
                    })
                })
            }
            //标签
            let tagId = [];
            if (values.labels != undefined) {
                values.labels.map((item) => {
                    if (equalTreeData != null) {
                        equalTreeData.map((obj) => {
                            if (item == obj.name) {
                                tagId.push(obj.id)
                            }
                        })
                    }
                })
            }

            // var time = new Date(values["expire_time"]);
            var time = new Date(form.getFieldValue('expire_time'));
            var time_year;
            var time_month;
            var time_date;
            var expire_time;
            // if (time.getTime() != 946656001000) {
            if (time.getTime() != 0) {
                time_year = time.getFullYear();
                time_month = time.getMonth() + 1;
                time_date = time.getDate();
                expire_time = new Date(time_year + "/" + time_month + "/" + time_date + " " + "00:00:01").getTime();
            }
            else {
                // expire_time = 946656001000;
                expire_time = null;
            }

            var newValue = {
                "parent_id": Number(documentId),
                "type": 4,
                "expire_time": expire_time,
                "materials": [{
                    "id": this.state.isEdit ? news[0].id : null,
                    "brands": brand_ids,
                    "introduction": values.introduction_app,//摘要
                    "key_messages": kmId,//关联信息点
                    "labels": tagId,//关联标签
                    "therapeutic_areas": therapeuticId,//关联治疗领域
                    "material": {
                        "author": values.author,   //作者
                        "content": this.state.content, //富文本内容字符串（正文）
                        "title": extendTitle         //标题
                    },
                    "share_scope": "1",  //分享权限
                    "use_scope": "1",     //适用范围
                    "water_mark": "1"  //水印
                }]

            }
            if (this.state.isEdit) {
                newValue.id = this.state.id;
                documentCenterEditActs.savePreviewEdit(newValue)
            } else {
                documentCenterEditActs.saveNewsPreview(newValue)
            }

        })
    }
}

export default _FirstVod
