import React from "react"
import ReactDOM from "react-dom"
import { connect } from "react-redux"
import { withRouter } from "react-router"
import { bindActionCreators } from "redux"
import * as KMActions from 'src/actions/km.js';
import {Card,Icon,Row,Col,Input,Button,Tabs,Radio,List,Avatar,Modal,Select,Tree,TreeSelect } from 'antd'
import Form from "antd/lib/form"
import Popconfirm from "antd/lib/popconfirm"
import 'src/assets/style/views/kmManagement/detail.less'
import {ColorEnum} from 'src/constants/customEnum'
const Search = Input.Search;
const TabPane = Tabs.TabPane;
const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const Option = Select.Option;
const TreeNode = Tree.TreeNode;
const FormItem = Form.Item
class KMdetail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            visible2:false,
            value:undefined,//弹框下拉树的值
            ifLeftSelTreeNode:undefined,//左侧选择树的值
            isEdit:undefined,
            leftTreeData:[{
                title: 'Node1',
                key: '1',
                value: '1',
                status:true,
                children: [{
                    title: 'Child Node1',
                    key: '2',
                    value: '2',
                    status:true
                }, {
                    title: 'Child Node2',
                    key: '3',
                    value: '3',
                    status:true
                }],
            }, {
                title: 'Node2',
                key: '4',
                value: '4',
                status:true
            }]
        }
    }
    componentWillReceiveProps(nextProps) {
        console.log('进来props',nextProps.location,this.props);
        // if(nextProps.visible !== this.props.visible) {
        //     this.setState({
        //         visible:nextProps.visible
        //     })
        // }

    }
    componentDidMount(){
        let {KMActs}=this.props;
        //reset接口
        KMActs.resetkmTreelist();
        //获取整棵树接口 存入state leftTreeData
        KMActs.getkmTreeList({block_id:1});
    }
    render() {
        let {visible2,isEdit,ifLeftSelTreeNode}=this.state;
        let { $$kmtreelist } = this.props;
        let {kmtreelist}=$$kmtreelist.toJS();
        let btnAble=ifLeftSelTreeNode?false:true;//选择树节点后才能启用禁用
        console.log(kmtreelist,'treedata');
        let extra=(
            <div>
                <Row gutter={16}>
                    <Col span={9}>
                        <Search
                            placeholder="请输入搜索内容"
                            onSearch={value => console.log(value)}
                            onChange={::this.searchChange}
                            style={{ width: 200 }}
                        />
                    </Col>
                    <Col span={3}>
                        <Button onClick={::this.KMadd} type="primary">
                            <Icon type='plus'></Icon>
                            <span>新增</span>
                        </Button>
                    </Col>
                    <Col span={6}>
                        {/*<RadioGroup onChange={::this.operateStart}>*/}
                            {/*<RadioButton value={true}>启用</RadioButton>*/}
                            {/*<RadioButton value={false}>禁用</RadioButton>*/}
                        {/*</RadioGroup>*/}
                        <div className='openBtn'>
                        <Button disabled={btnAble} onClick={this.operateStart.bind(this,true)}>启用</Button>
                        <Button disabled={btnAble} onClick={this.operateStart.bind(this,false)}>禁用</Button>
                        </div>
                    </Col>
                    <Col span={3}>
                        <Button disabled={btnAble} onClick={::this.KMedit}>编辑</Button>
                    </Col>
                    <Col span={3}>
                        <Popconfirm title="确认删除此节点？" okText="确定" cancel="取消" onConfirm={this.onKMDelete.bind(this)}>
                            <Button disabled={btnAble}>删除</Button>
                        </Popconfirm>

                    </Col>
                </Row>
            </div>
        )
        let aa=4;
        let tabsExtra=(
            <div>被引用{aa}</div>
        )
        const data=[{
            title:'a1'
        },{
            title:'a2'
        },{
            title:'a3'
        },{
            title:'a4'
        },]

        return (
            <section className='km-detail' >
                <Card bordered={false} title={<span className='km-title'><Icon type='flag_fill'></Icon><span>Keymessage</span></span>} extra={extra}>
                    <Row>
                        <Col span={14}>
                            <div className='tree-wrap'>
                                {
                                    kmtreelist?
                                        <Tree
                                        showLine
                                        defaultExpandAll={true}
                                        onSelect={::this.onSelectTree}
                                        autoExpandParent={false}
                                        >
                                            {this.renderTreeNodes(kmtreelist)}
                                        </Tree>
                                        :'loading tree'
                                }

                            </div>
                        </Col>
                        <Col span={10} style={{height:document.documentElement.clientHeight-160}}>
                            <div><Tabs tabBarExtraContent={tabsExtra} className="km-tabs" defaultActiveKey="1">
                                <TabPane tab="关联资源" key="1">
                                    <List itemLayout="horizontal"
                                            dataSource={data}
                                            renderItem={item=>{
                                                let colorType=ColorEnum.colorType;
                                                let colorId=parseInt(Math.random()*5,10);
                                                let iconStyle={
                                                    fontSize:'20px',
                                                    color:colorType[colorId].color,
                                                    backgroundColor:colorType[colorId].bgColor
                                                }
                                                return(
                                                <List.Item>
                                                    <List.Item.Meta
                                                        avatar={<Avatar style={iconStyle}  icon='shouye'/>}
                                                        title=''
                                                        description={item.title}
                                                    />
                                                </List.Item>
                                            )}}
                                    >

                                    </List>
                                </TabPane>
                                <TabPane tab="标签云" key="2"></TabPane>
                            </Tabs></div>

                        </Col>
                    </Row>
                </Card>
                {
                    visible2?
                        <AddOrEditModal {...this.props} visible={visible2} isEdit={isEdit} onCancle={::this.onCancle}/>
                    :null
                }

            </section>
        );
    }
    searchChange(e){
        let val=e.target.value;
        console.log(val,8888);
    }
    onCancle(){
        this.setState({visible2: false})
    }

    renderTreeNodes(data){
        // data.map((item)=>{
        //     const index = item.name.indexOf(searchValue);
        //     const beforeStr = item.name.substr(0, index);
        //     const afterStr = item.name.substr(index + searchValue.length);
        // })
        return data.map((item) => {
            let itemStyle={color:item.enabled?"#666":"#ccc"};
            if (item.child_list) {
                return (
                    <TreeNode title={<div style={itemStyle}>{item.name}</div>} value={item.id || ''} key={item.id} dataRef={item} isLeaf={item.leaf}>
                        {this.renderTreeNodes(item.child_list)}
                    </TreeNode>
                );
            }
            return <TreeNode title={<div style={itemStyle}>{item.name}</div>} value={item.id || ''} key={item.id} dataRef={item} isLeaf={item.leaf}/>;
        })
    }

    // 左侧树选择
    onSelectTree(a){
        this.setState({ ifLeftSelTreeNode:a[0] });
    }

    KMadd(){
        this.setState({
            visible2:true,
            isEdit:false
        })
        console.log('新增');
    }
    // 编辑
    KMedit(){
        let {ifLeftSelTreeNode}=this.state;
        if(!ifLeftSelTreeNode){
            console.log('请选择要编辑的节点');
            return;
        }
        this.setState({
            visible2:true,
            isEdit:ifLeftSelTreeNode
        })
        console.log('点击编辑');
    }
    // 启用禁用
    operateStart(state){
        let {KMActs}=this.props;
        let {ifLeftSelTreeNode}=this.state;
        //调启用禁用接口
        this.setState({
            leftTreeData:[{
                title: 'Node1',
                key: '1',
                value: '1',
                status:false,
                children: [{
                    title: 'Child Node1',
                    key: '2',
                    value: '2',
                    status:true
                }, {
                    title: 'Child Node2',
                    key: '3',
                    value: '3',
                    status:true
                }],
            }, {
                title: 'Node2',
                key: '4',
                value: '4',
                status:true
            }]
        })
        KMActs.changeStatus(state,ifLeftSelTreeNode);
        console.log(state,ifLeftSelTreeNode,'调接口传给后台操作id后重新获取列表setState');

    }

    onKMDelete(){
        let {KMActs}=this.props;
        let {ifLeftSelTreeNode}=this.state;
            KMActs.deleteTreeTag(ifLeftSelTreeNode);
        console.log('调删除接口，不是末级节点不能删除');
    }
}

class AddOrEditModal extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            visible:props.visible,
            value:undefined,//下拉树的值
            leftTreeData:[{
                title: 'Node1',
                id: '1',
                value: '1',
                status:true,
                children: [{
                    title: 'Child Node1',
                    id: '2',
                    value: '2',
                    status:true
                }, {
                    title: 'Child Node2',
                    id: '3',
                    value: '3',
                    status:true
                }],
            }, {
                title: 'Node2',
                id: '4',
                value: '4',
                status:true
            }]
        }
    }
    componentDidMount(){
        let {KMActs,isEdit}=this.props;
        console.log(isEdit,'isEdit');
        KMActs.resetkmTreelist();
        KMActs.getkmTreeList({block_id:1});
        //判断如果是编辑状态则调编辑接口
        KMActs.resetTreeDetail();
        if(isEdit){
            KMActs.getTreeDetail(isEdit);
        }
    }
    // componentWillReceiveProps(nextProps) {
    //     console.log(this.props,'props',nextProps);
    //     if(nextProps.visible !== this.props.visible) {
    //         this.setState({
    //             visible:nextProps.visible
    //         })
    //     }
    //
    // }
    render(){
        const { getFieldDecorator } = this.props.form;
        let { visible,isEdit,$$kmtreelist,$$kmtreeDetail } = this.props;
        let {kmtreelist}=$$kmtreelist.toJS();
        let {kmtreeDetail}=$$kmtreeDetail.toJS();
        let {leftTreeData}=this.state;
        let fieldProps = this._getFieldDecorator();
        let modalTitle=isEdit?'编辑':'新增';
        const formItemLayout = {
            labelCol: { span: 4 },
            wrapperCol: { span: 20 }
        };
        return(
            <div>
                <Modal
                    visible={visible}
                       title={`${modalTitle}Keymessage`}
                       onOk={::this.confirmEditKm}
                       okText="确定"
                       cancelText="取消"
                       width={700}
                       onCancel={() => {
                           this.props.onCancle()
                       }}
                >
                    <Row style={{padding:"30px 20px"}}>
                        <Form>
                            <Col span={20}>
                                <FormItem {...formItemLayout} label="KM名称：">
                                    {fieldProps.name(
                                        <Input placeholder='请输入' />
                                    )}
                                </FormItem>
                            </Col>
                            <Col span={20}>
                                <FormItem {...formItemLayout} label="父级节点：">
                                    {fieldProps.parent_name(
                                        <TreeSelect
                                            dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                                            // treeData={leftTreeData}
                                            placeholder="请选择"
                                            treeDefaultExpandAll
                                            onChange={this.editSelectChange.bind(this)}
                                            onSelect={this.editSelectTree.bind(this)}
                                        >
                                            {this.renderTreeNodes(kmtreelist)}
                                        </TreeSelect>
                                    )}
                                </FormItem>
                            </Col>
                        </Form>
                    </Row>
                </Modal>
            </div>
        )
    }
    //设置字段属性
    _getFieldDecorator() {
        const { getFieldDecorator } = this.props.form;
        let { visible,isEdit,$$kmtreeDetail } = this.props;
        let {kmtreeDetail}=$$kmtreeDetail.toJS();
        //接口获取要编辑的数据
        return {
            //标签名称
            name: getFieldDecorator("name", {
                initialValue: kmtreeDetail.name,
                rules: [{required: true, message:'请输入节点名称'},
                    {message:"不得超过12位字符",max:12}
                ]
            }),
            //父级标签
            parent_name: getFieldDecorator("parent_name", {
                initialValue: kmtreeDetail.parent_id&&kmtreeDetail.parent_id.toString()
            })
        }
    }
    renderTreeNodes(data){
        return data.map((item) => {
            let itemStyle={color:item.enabled?"#666":"#ccc"};
            if (item.child_list) {
                return (
                    <TreeNode title={<div style={itemStyle}>{item.name}</div>} value={item.id.toString() || ''} key={item.id} dataRef={item} isLeaf={item.leaf}>
                        {this.renderTreeNodes(item.child_list)}
                    </TreeNode>
                );
            }
            return <TreeNode title={<div style={itemStyle}>{item.title}</div>} value={item.id.toString() || ''} key={item.id} dataRef={item} isLeaf={item.leaf}/>;
        })
    }
    // 弹框编辑确认按钮
    confirmEditKm(){
        let {KMActs,isEdit}=this.props;
        this.props.form.validateFieldsAndScroll((errors, values) => {
            if (!!errors) return;
            console.log(values,'编辑确认接口传不同参数编辑还是新增isEdit',this.state.value,isEdit);
            let data=isEdit?{
                id:isEdit,
                name:values.name,
                parent_id:Number(values.parent_name),
                block_id:1
            }:{
                name:values.name,
                parent_id:Number(values.parent_name),
                block_id:1
            }
            let that=this;
            KMActs.saveKMTree(data,isEdit).done(res=>{
                if (res.code == 10000){
                    that.props.onCancle();

                }
            });
        })
    }
    // 编辑树选择
    editSelectChange(val){
        this.setState({ value:val });
        console.log(val,'选择值');
    }
    editSelectTree(val){
        this.setState({ value:val });
        console.log(val,'编辑树选择值');
    }
}

KMdetail = Form.create()(KMdetail);
export default connect(
    (state) => {
        return {
            $$kmtreelist:state.$$kmtreelist,
            $$kmtreeDetail:state.$$kmtreeDetail
        }
    },
    (dispatch) => {
        return {
            KMActs: bindActionCreators(KMActions, dispatch)
        }
    }
)(withRouter(KMdetail))