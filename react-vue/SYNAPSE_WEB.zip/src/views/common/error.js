import React from "react"
import ReactDOM from "react-dom"
import {connect} from "react-redux"
import { bindActionCreators } from "redux"


class Error extends React.Component {
    render() {
        return (
            <h1>Error</h1>
        );
    }
}

export default connect(
    (state) => {
        return {
            $$error: state.$$error
        }
    },
    (dispatch) => {
        return {
            //actions: bindActionCreators(Actions, dispatch)
        }
    })(Error)
