import React from "react"
import ReactDOM from "react-dom"



export default class Home extends React.Component {
    render() {
        return (
            <h1>Welcome</h1>
        );
    }
}