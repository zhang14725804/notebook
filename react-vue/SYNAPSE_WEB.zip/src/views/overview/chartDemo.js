import Immutable from "immutable"
import React from "react"
import ReactDOM from "react-dom"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/overview"
import { tools } from "utils"
import { EnumCn, Enum } from "enum"

import Chart from "components/chart"
import TextCheckbox from "components/textCheckbox"

import Chart_TreeMap from "components/chart/treemap"
import Chart_HeatMap from "components/chart/heatmap"
import Chart_CalenderHeatmapHor from "components/chart/calendarHeatmapHor"
import Chart_ScatterSingleAxis from "components/chart/scatterSingleAxis"
import Chart_LineRainfall from "components/chart/lineRainfall"
import Chart_RadarBasic from "components/chart/radarBasic"
import Chart_BarYCategoryStack from "components/chart/barYCategoryStack"
import Chart_GraphLesMiserables from "components/chart/graphLesMiserables"
import Chart_GraphLesMiserablesCircle from "components/chart/graphLesMiserablesCircle"
import Chart_ScatterPunchCard from "components/chart/scatterPunchCard"
import Chart_MapChinaDataRange from "components/chart/mapChinaDataRange"
import Chart_Scatter3D from "components/chart/scatter3D"
import Chart_WordCloud from "components/chart/wordCloud"

import Tag from "antd/lib/tag"

import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Radio from "antd/lib/radio"
import Select from "antd/lib/select"
import Form from "antd/lib/form"
import Popover from "antd/lib/popover"
import Icon from "antd/lib/icon"
import Button from "antd/lib/button"
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const Option = Select.Option;
const FormItem = Form.Item;
const ButtonGroup = Button.Group
import "assets/style/views/overview/overview.less"
import TextCard from "components/card/TextCard"


let provinces = ["北京", "天津", "河北", "山西", "内蒙古", "辽宁", "吉林", "黑龙江", "上海", "江苏", "浙江", "安徽", "福建", "江西", "山东", "河南", "湖北", "广东", "广西", "海南", "重庆", "四川", "贵州", "湖南", "云南", "西藏", "陕西", "甘肃", "青海", "宁夏", "新疆", "台湾", "香港", "澳门"]
let distributeData = provinces.map((v, i) => {
    return {
        name: v,
        value: parseInt(Math.random() * 1000),
        id: (i + 1)
    }
})
let freqRelateData = [
    { id: 1, name: "副主任", value: 3 },
    { id: 2, name: "主任", value: 2 },
    { id: 3, name: "主治", value: 2 },
    { id: 4, name: "医师", value: 8 },
    { id: 5, name: "其他", value: 4 }
]
let freqIncludingData = [
    { id: 1, name: "未覆盖", value: 2 },
    { id: 2, name: "已覆盖", value: 8 },
]
let state = {
    distribute_data: distributeData,
    freq_relate_data: freqRelateData,
    freq_including_data: freqIncludingData
}

const statisticTime = { "0": "全部", "1": "昨天", "2": "近7天", "3": "近30天" };
const pdtList = [{ id: "0", name: "全部产品" }, { id: "1", name: "达克宁" }, { id: "2", name: "善思达" }, { id: "3", name: "专注达" }];
const taList = [{ id: "0", name: "全部适应症" }, { id: "1", name: "消化" }, { id: "2", name: "呼吸" }, { id: "3", name: "心血管" }];
const kmList = [{ id: "0", name: "信息点1" }, { id: "1", name: "信息点2" }, { id: "2", name: "信息点3" }];

class Overview extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isShowState: false,
            isShowKm: true,
            initFinish: {
                overViewState: false,
                trendState: false,
                distributeState: false,
                relateFreqState: false,
                includingFreqState: false,
                concentrateState: false
            }
        }
    }
    componentDidMount() {
        let { overviewActs, $$overview, $$layout } = this.props;
        let { initFinish } = this.state;
        let overview = $$overview.toJS();
        let loginUser = $$layout.toJS().login_user;
        overviewActs.reset();
        // overviewActs.getOverView({
        //     company_id: loginUser.company_id,
        //     range: Enum.StatisticTime.today
        // }).done(() => {
        //     initFinish.overViewState = true;
        //     this.setState({
        //         initFinish
        //     })
        // });
        // overviewActs.getTrend({
        //     company_id: loginUser.company_id,
        //     range: Enum.ChartTime.today,
        //     type: [Enum.ChartTarget.pv]
        // }).done(() => {
        //     initFinish.trendState = true;
        //     this.setState({
        //         initFinish
        //     })
        // });
        // overviewActs.getDistribute({
        //     company_id: loginUser.company_id,
        //     range: Enum.ChartTime.today,
        //     type: Enum.ChartTarget.pv
        // }).done(() => {
        //     initFinish.distributeState = true;
        //     this.setState({
        //         initFinish
        //     })
        // });
        // overviewActs.getRelateFreq({
        //     company_id: loginUser.company_id,
        //     type: Enum.ChartRelateType.product
        // }).done(() => {
        //     initFinish.relateFreqState = true;
        //     this.setState({
        //         initFinish
        //     })
        // });
        // overviewActs.getIncludingFreq({
        //     company_id: loginUser.company_id,
        //     type: Enum.ChartCoverageType.docLevel
        // }).done(() => {
        //     initFinish.includingFreqState = true;
        //     this.setState({
        //         initFinish
        //     })
        // });
        // overviewActs.getConcentrate({
        //     company_id: loginUser.company_id
        // }).done(() => {
        //     initFinish.concentrateState = true;
        //     this.setState({
        //         initFinish
        //     })
        // });
    }
    // shouldComponentUpdate(nextProps, nextState) {
    //     let initFinishValues = [];
    //     for (let i in nextState.initFinish) {
    //         initFinishValues.push(nextState.initFinish[i])
    //     }
    //     if (initFinishValues.indexOf(false) == -1) {
    //         return true
    //     } else {
    //         return false
    //     }
    // }
    render() {
        // 时间范围
        const infoTimeJSX = Object.getOwnPropertyNames(statisticTime)
            // .filter(name => !isNaN(Number(name)))
            .map(key => {
                return <RadioButton key={key} value={key}>{statisticTime[key]}</RadioButton>
            });
        // 产品
        const pdtJSX = this.getRelaJSX({
            id: "pdt_ids",
            // title: "产品：",
            dataSource: pdtList
        })
        // 适应症
        const taJSX = this.getRelaJSX({
            id: "ta_ids",
            // title: "适应症：",
            dataSource: taList
        })
        // 信息点
        const kmJSX = this.getRelaJSX({
            id: "km_ids",
            // title: "信息点：",
            dataSource: kmList
        })
        const { isShowState, isShowKm } = this.state;
        let fieldProps = this._getFieldProps();
        const { pdt_ids, ta_ids, km_ids } = this.props.form.getFieldsValue()
        let pdt_names = [];
        pdtList.map(item => {
            pdt_ids.map(pdt_id => {
                if (item.id == pdt_id.toString()) {
                    pdt_names.push(item.name)
                }
            })
        })
        let ta_names = [];
        taList.map(item => {
            ta_ids.map(ta_id => {
                if (item.id == ta_id.toString()) {
                    ta_names.push(item.name);
                }
            })
        })
        let km_names = [];
        kmList.map(item => {
            km_ids.map(km_id => {
                if (item.id == km_id.toString()) {
                    km_names.push(item.name)
                }
            })
        })
        const selPdtJSX = (pdt_names || []).map((obj, index) => <Tag key={index}>{obj}</Tag>);
        const selTaJSX = (ta_names || []).map((obj, index) => <Tag key={index}>{obj}</Tag>);
        const selKmJSX = (km_names || []).map((obj, index) => <Tag key={index}>{obj}</Tag>);


        const { form } = this.props;
        // let state = this.props.$$overview.toJS();
        // let initFinishValues = [];
        // for (let i in this.state.initFinish) {
        //     initFinishValues.push(this.state.initFinish[i])
        // }
        // console.log(isShowState)
        return (
            <section>
                <div className="m-margin-b">
                    <Form>
                        <FormItem>
                            <Row>
                                <Col span={12}>
                                    <RadioGroup {...fieldProps.info_range} size="large">
                                        {infoTimeJSX}
                                    </RadioGroup>
                                </Col>
                                <Col span={12} style={{ textAlign: 'right' }}>
                                    <a onClick={this.onClickChangeState.bind(this)}>{isShowState ? "收起条件" : "展开条件"}</a>
                                </Col>
                            </Row>
                        </FormItem>
                        <div style={{ display: isShowState ? "block" : "none" }}>
                            <Row>产&nbsp;&nbsp;&nbsp;&nbsp;品：<FormItem style={{ display: 'inline-block', marginBottom: 0 }}>{pdtJSX}</FormItem></Row>
                            <Row>适应症：<FormItem style={{ display: 'inline-block', marginBottom: 0 }}>{taJSX}</FormItem></Row>
                            <Row>信息点：<FormItem style={{ display: isShowKm ? "inline-block" : "none", marginBottom: 0 }}>{kmJSX}</FormItem></Row>
                            <div><b className="green">已选：</b>
                                <Row>产品：{selPdtJSX}</Row>
                                <Row>适应症：{selTaJSX}</Row>
                                <Row>信息点：{selKmJSX}</Row>
                            </div>
                        </div>
                    </Form>

                </div>

                <p style={{ color: "#999", fontSize: "16px" }}>概览</p>
                <br />
                <Row style={{ height: '100px', border: '1px solid #ccc', padding: '20px 0' }}>
                    <Col span={3} offset={1} style={{ height: '100%', borderRight: '1px solid #ccc' }}>
                        <div style={{ color: '#999', paddingBottom: '8px' }}>推广次数</div>
                        <div className="orange" style={{ fontSize: '20px' }}>{100 + parseInt(Math.random() * 100)}</div>
                    </Col>
                    <Col span={4} offset={1} style={{ height: '100%', borderRight: '1px solid #ccc' }}>
                        <div style={{ color: '#999', paddingBottom: '8px' }}>推广费用</div>
                        <div className="orange" style={{ fontSize: '20px' }}>¥ {50000 + parseInt(Math.random() * 50000)}</div>
                    </Col>
                    <Col span={4} offset={1} style={{ height: '100%', borderRight: '1px solid #ccc' }}>
                        <div style={{ color: '#999', paddingBottom: '8px' }}>覆盖人次</div>
                        <div className="orange" style={{ fontSize: '20px' }}>{500000 + parseInt(Math.random() * 500000)}</div>
                    </Col>
                    <Col span={4} offset={1} style={{ height: '100%', borderRight: '1px solid #ccc' }}>
                        <div style={{ color: '#999', paddingBottom: '8px' }}>覆盖人数<Popover placement="right" content={
                            <div style={{ width: "200px" }}>
                                <p className="title">1. 仅包含精准推广渠道统计，不含微信端；</p>
                                <p className="title">2. 数据未去重；</p>
                            </div>
                        }>
                            <Icon type="question-circle-o" style={{ marginLeft: '10px' }} />
                        </Popover></div>
                        <div className="orange" style={{ fontSize: '20px' }}>{500000 + parseInt(Math.random() * 500000)}</div>
                    </Col>
                    <Col span={4} offset={1}>
                        <div style={{ color: '#999', paddingBottom: '8px' }}>新增用户<Popover placement="right" content={
                            <div style={{ width: "200px" }}>
                                <p className="title">1. 仅包含精准推广渠道统计，不含微信端；</p>
                                <p className="title">2. 数据未去重；</p>
                            </div>
                        }>
                            <Icon type="question-circle-o" style={{ marginLeft: '10px' }} />
                        </Popover></div>
                        <div className="orange" style={{ fontSize: '20px' }}>{500000 + parseInt(Math.random() * 500000)}</div>
                    </Col>
                </Row>
                <br />
                {
                    // <Row className="m-margin-b">
                    //     <div className="m-stb">
                    //         <div className="m-tb-title"> 推广次数</div>
                    //         <div className="m-tb-text">187</div>
                    //     </div>
                    //     <div className="m-stb">
                    //         <div className="m-tb-title">推广费用</div>
                    //         <div className="m-tb-text">¥ 94,568</div>
                    //     </div>
                    //     <div className="m-stb">
                    //         <div className="m-tb-title">覆盖人次</div>
                    //         <div className="m-tb-text">894,568</div>
                    //     </div>
                    //     <div className="m-stb">
                    //         <div className="m-tb-title">覆盖人数</div>
                    //         <div className="m-tb-text">894,568<Popover placement="right" content={
                    //             <div style={{ width: "200px" }}>
                    //                 <p className="title">1. 仅包含精准推广渠道统计，不含微信端；</p>
                    //                 <p className="title">2. 数据未去重；</p>
                    //             </div>
                    //         }>
                    //             <Icon type="question-circle-o" style={{ marginLeft: '20px' }} />
                    //         </Popover></div>
                    //     </div>
                    //     <div className="m-stb">
                    //         <div className="m-tb-title">新增用户</div>
                    //         <div className="m-tb-text">894,568</div>
                    //     </div>
                    // </Row>
                }
                <p className="orange">* 说明：受微信公众平台限制，如下报告仅包含 APP 渠道统计；</p>
                {
                    // initFinishValues.indexOf(false) == -1 && 
                    <div>
                        {/* <_Chart_Trend
                            {...this.props}
                            fieldProps={fieldProps} />
                        <_Chart_Distribute
                            {...this.props}
                            fieldProps={fieldProps} />                             */}
                        <Row className="chart-box">
                            <Col span="11">
                                <Chart_TreeMap
                                    {...this.props}
                                    fieldProps={fieldProps} />
                            </Col>
                            <Col span="11" offset="2">
                                <Chart_HeatMap
                                    {...this.props}
                                    fieldProps={fieldProps} />
                            </Col>
                        </Row>
                        <Row className="chart-box">
                            <Col span="11">
                                <Chart_CalenderHeatmapHor
                                    {...this.props}
                                    fieldProps={fieldProps} />
                            </Col>
                            <Col span="11" offset="2">
                            <Chart_ScatterSingleAxis
                                    {...this.props}
                                    fieldProps={fieldProps} />
                            </Col>
                        </Row>
                        <Row>
                            <Col span="11">
                                <Chart_LineRainfall
                                    {...this.props}
                                    fieldProps={fieldProps} />
                            </Col>
                            <Col span="11" offset="2">
                                <Chart_RadarBasic
                                    {...this.props}
                                    fieldProps={fieldProps} />
                            </Col>
                        </Row>
                        <Row>
                            <Col span="11">
                                <Chart_BarYCategoryStack
                                    {...this.props}
                                    fieldProps={fieldProps} />
                            </Col>
                            <Col span="11" offset="2">
                                <Chart_GraphLesMiserables
                                    {...this.props}
                                    fieldProps={fieldProps} />
                            </Col>
                        </Row>
                        <Row>
                            <Col span="11">
                                <Chart_GraphLesMiserablesCircle
                                    {...this.props}
                                    fieldProps={fieldProps} />
                            </Col>
                            <Col span="11" offset="2">
                                <Chart_ScatterPunchCard
                                    {...this.props}
                                    fieldProps={fieldProps} />
                            </Col>
                        </Row>
                        <Row>
                            <Col span="11">
                                <Chart_MapChinaDataRange
                                    {...this.props}
                                    fieldProps={fieldProps} />
                            </Col>
                            <Col span="11" offset="2">
                                <Chart_Scatter3D
                                    {...this.props}
                                    fieldProps={fieldProps} />
                            </Col>
                        </Row>
                        <Row>
                            <Col span="11">
                            <Chart_WordCloud
                                    {...this.props}
                                    fieldProps={fieldProps} />
                            </Col>
                        </Row>                         
                    </div>
                }
                <TextCard/>
            </section>
        );

    }
    // 展开条件
    onClickChangeState() {
        console.log('-- 点击展开条件 --')
        this.props.form.setFieldsValue({
            pdt_ids: ["0"],
            ta_ids: ["0"],
            km_ids: []
        })
        this.setState({
            isShowState: !this.state.isShowState
        })
    }
    // 生成关联项的JSX对象
    getRelaJSX(cfg) {
        const fieldProps = this._getFieldProps();
        const { id, title, dataSource } = cfg;
        const textCheckboxOptions = dataSource.map((item) => {
            return {
                key: item.id,
                text: item.name
            }
        })
        return <TextCheckbox
            title={title}
            options={textCheckboxOptions}
            {...fieldProps[id]}
        />
    }

    //获取字段属性
    _getFieldProps() {
        let { form, $$overview, $$layout } = this.props;
        let state = $$overview.toJS();
        let loginUser = $$layout.toJS().login_user;

        return {
            //详情时间范围
            info_range: form.getFieldProps("info_range", {
                initialValue: "0",
                onchange: (item) => {
                    console.info(item)
                }
            }),
            //关联产品
            pdt_ids: form.getFieldProps("pdt_ids", {
                initialValue: ["0"],
                onChange: (key) => {
                    const { form } = this.props;
                    // const {pdt_ids} = form.getFieldsValue();
                    // console.log('-- pdt_ids --', pdt_ids, pdt_ids.length, this.state.isShowKm)
                    if (key && key.length > 0 && this.state.isShowKm === false) {
                        this.setState({ isShowKm: true })
                    } else if (key.length == 0 && this.state.isShowKm === true) {
                        this.setState({ isShowKm: false })
                    }
                },
            }),
            //关联治疗领域
            ta_ids: form.getFieldProps("ta_ids", {
                initialValue: ["0"],
                onChange: (key) => {
                    const { form } = this.props;
                    // const {ta_ids} = form.getFieldsValue();
                    if (key && key.length > 0 && this.state.isShowKm === false) {
                        this.setState({ isShowKm: true })
                    } else if (key.length == 0 && this.state.isShowKm === true) {
                        this.setState({ isShowKm: false })
                    }
                },
            }),
            //关联信息点
            km_ids: form.getFieldProps("km_ids", {
                initialValue: [],
                onChange: (key) => {
                    const { form } = this.props;
                    const { km_ids } = form.getFieldsValue();
                },
            }),
            //趋势时间范围
            trend_range: form.getFieldProps("trend_range", {
                initialValue: state.trend_condition.range,
                onChange: (range) => {
                    let fields = form.getFieldsValue();
                    let { overviewActs } = this.props;
                    console.log(range)
                    // overviewActs.getTrend({
                    //     company_id: loginUser.company_id,
                    //     range: range,
                    //     type: fields.trend_type
                    // })
                }
            }),
            //趋势折线类型
            trend_type: form.getFieldProps("trend_type", {
                initialValue: state.trend_condition.type,
                onChange: (type) => {
                    let fields = form.getFieldsValue();
                    let { overviewActs } = this.props;
                    // overviewActs.getTrend({
                    //     company_id: loginUser.company_id,
                    //     type: type,
                    //     range: fields.trend_range
                    // })
                }
            }),
            //分布时间范围
            distribute_range: form.getFieldProps("distribute_range", {
                initialValue: state.distribute_condition.range,
                onChange: (range) => {
                    let fields = form.getFieldsValue();
                    let { overviewActs } = this.props;
                    // overviewActs.getDistribute({
                    //     company_id: loginUser.company_id,
                    //     range: range,
                    //     type: fields.distribute_type
                    // })
                }
            }),
            //分布类型
            distribute_type: form.getFieldProps("distribute_type", {
                initialValue: state.distribute_condition.type,
                onChange: (type) => {
                    let fields = form.getFieldsValue();
                    let { overviewActs } = this.props;
                    // overviewActs.getDistribute({
                    //     company_id: loginUser.company_id,
                    //     type: type,
                    //     range: fields.distribute_range
                    // })
                }
            }),
            //频次关联类型
            freq_relate: form.getFieldProps("freq_relate", {
                initialValue: state.freq_relate,
                onChange: (type) => {
                    console.log('频次关联类型', type)
                    let fields = form.getFieldsValue();
                    let { overviewActs } = this.props;
                    // overviewActs.getRelateFreq({
                    //     company_id: loginUser.company_id,
                    //     type: type
                    // });
                }
            }),
            //频次覆盖类型
            freq_including: form.getFieldProps("freq_including", {
                // initialValue: state.freq_including,
                initialValue: "1",
                onChange: (type) => {
                    console.log('频次覆盖类型', type)
                    let fields = form.getFieldsValue();
                    let { overviewActs } = this.props;
                    // overviewActs.getIncludingFreq({
                    //     company_id: loginUser.company_id,
                    //     type: type
                    // });
                }
            })
        }
    }

}

//趋势图
class _Chart_Trend extends React.Component {
    constructor(props) {
        super(props);
    }
    shouldComponentUpdate(nextProps, nextState) {
        let prevSel = this.props.$$overview.toJS().trend_condition;
        let nextSel = nextProps.$$overview.toJS().trend_condition;
        // 判断趋势图的筛选条件变化，更新趋势图
        if (prevSel.range !== nextSel.range || prevSel.type.toString() != nextSel.type.toString()) {
            console.log('趋势图变了')
            return true;
        } else {
            return false;
        }
    }
    render() {
        let { $$overview, fieldProps } = this.props;
        let state = $$overview.toJS();
        let axisXLength = Math.max.apply(Math, state.trend_data.map(o => (o.data || []).length));
        //趋势
        let trendCfg = {
            grid: {
                left: "0%",
                right: "0%",
                bottom: "0%",
                top: "10%",
                containLabel: true
            },
            tooltip: {
                trigger: "axis"
            },
            xAxis: {
                splitLine: { show: false },
                data: [2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017]
            },
            yAxis: {
                minInterval: 1,
                max: 20,
                min: 0,
                axisLine: { show: false },
                splitLine: { lineStyle: { color: "rgb(230,230,230)" } }
            },
            series: [1, 2, 3].map(o => {
                // 整体格式
                // [
                //     {
                //         name:'邮件营销',
                //         type:'line',
                //         stack: '总量',
                //         data:[120, 132, 101, 134, 90, 230, 210]
                //     },
                //     {
                //         name:'联盟广告',
                //         type:'line',
                //         stack: '总量',
                //         data:[220, 182, 191, 234, 290, 330, 310]
                //     },
                // ]
                // 其中如果设置相同 stark 后一个系列的值将会在前一个基础上叠加
                let mathArr = [];
                for (let i = 0; i < 10; i++) {
                    mathArr.push(parseInt(Math.random() * 10 + 5))
                }
                return {
                    name: o,
                    type: "line",
                    data: mathArr,
                }
            }),
            legend: {
                orient: "horizontal",
                left: "left",
                top: 0,
                data: state.trend_data.map(o => o.name)
            },
            color: tools.chartColor
        }
        //时间范围
        //筛选出对象的key不是数字的，如果key是数字，正常，渲染下拉框

        const rangeJSX = Object.getOwnPropertyNames(EnumCn.ChartTime)
            .filter(name => !isNaN(Number(name)))
            .map(key => <Option key={key} value={key}>{EnumCn.ChartTime[key]}</Option>);
        //数据类型
        const targetJSX = Object.getOwnPropertyNames(EnumCn.ChartTarget)
            .filter(name => !isNaN(Number(name)))
            .map(key => <Option key={key} value={key}>{EnumCn.ChartTarget[key]}</Option>);
        return (
            <Row className="chart-box">
                <div className="chart-cdt">
                    <div>趋势图</div>
                    <br />
                    <Select
                        mode='multiple'
                        placeholder="请选择"
                        style={{ width: 400 }}
                        {...fieldProps.trend_type}>{targetJSX}</Select>
                </div>
                <Chart {...trendCfg} />
            </Row>
        )
    }
}
class _Chart_Distribute extends React.Component {
    constructor(props) {
        super(props);
    }
    shouldComponentUpdate(nextProps, nextState) {
        let prevSel = this.props.$$overview.toJS().distribute_condition;
        let nextSel = nextProps.$$overview.toJS().distribute_condition;
        if (prevSel.range !== nextSel.range || prevSel.type.toString() != nextSel.type.toString()) {
            console.log('地区访问分布变了')
            return true;
        } else {
            return false;
        }
    }
    render() {
        let { $$overview, fieldProps } = this.props;
        // let state=this.props.$$overview.toJS();
        //地区分布-地图
        const max = state.distribute_data.length === 0 ? 0 : Math.max.apply(Math, state.distribute_data.map(d => d.value));
        const min = state.distribute_data.length === 0 ? 0 : Math.min.apply(Math, state.distribute_data.map(d => d.value));
        let distributeCfg = {
            //浮标
            tooltip: {
                trigger: "item",
                formatter: "{b}：{c}"
            },
            //图例
            legend: {
                left: "left",
                data: []
            },
            visualMap: {
                min: min,
                max: max <= min ? min + 1 : max,//注意此处max和min不能相等（插件问题）
                top: "top",
                left: "center",
                type: "piecewise",
                splitNumber: 7,
                orient: "horizontal",
                color: ["rgb(10,93,132)", "rgb(71,191,237)", "rgb(240,240,240)"],
                text: ["高", "低"]
            },
            series: [
                {
                    type: "map",
                    mapType: "china",
                    itemStyle: {
                        normal: {
                            borderColor: "rgb(230,230,230)"
                        }
                    },
                    data: state.distribute_data
                }
            ],
            color: tools.chartColor
        }
        //地区分布-饼图
        let data_pie = state.distribute_data.sort((a, b) => a.value > b.value ? -1 : 1);
        //值大于0的前十数据（data_prev.length<=10）
        let data_prev = data_pie.filter((item, i) => i < 10 && item.value > 0);
        //其他数据
        let data_obj = { name: "其他", value: 0 };
        data_pie.slice(data_prev.length).map(d => data_obj.value = data_obj.value + d.value);
        let distributePieCfg = {
            tooltip: {
                trigger: "item",
                formatter: "{b}: {c} ({d}%)"
            },
            legend: {
                orient: "vertical",
                x: "left"
            },
            series: [
                {
                    name: "",
                    type: "pie",
                    selectedMode: "single",
                    radius: ["25%", "55%"],
                    avoidLabelOverlap: true,
                    label: {
                        normal: {
                            show: true,
                            formatter: function (obj) {
                                if (obj.name.length > 5) {
                                    obj.name = obj.name.slice(0, 5) + '...';
                                }
                                return obj.name
                            },
                            textStyle: {
                                color: "black"
                            }
                        },
                        emphasis: {
                            show: true,
                            textStyle: {
                                fontWeight: "bold"
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            lineStyle: {
                                color: "rgb(185,185,185)"
                            },
                            length: 17,
                            length2: 5
                        }
                    },
                    data: [].concat(data_prev).concat([data_obj])
                }
            ],
            color: tools.chartColor
        }
        //时间范围
        const rangeJSX = Object.getOwnPropertyNames(EnumCn.ChartTime)
            .filter(name => !isNaN(Number(name)))
            .map(key => <Option key={key} value={key}>{EnumCn.ChartTime[key]}</Option>);
        //数据类型
        const targetJSX = Object.getOwnPropertyNames(EnumCn.ChartTarget)
            .filter(name => !isNaN(Number(name)))
            .map(key => <Option key={key} value={key}>{EnumCn.ChartTarget[key]}</Option>);
        return (
            <Row className="chart-box">
                <div className="chart-cdt">
                    <div>地域分布</div>
                    <br />
                    <Select
                        placeholder="请选择"
                        style={{ width: 170 }}
                        {...fieldProps.distribute_type}>{targetJSX}</Select>
                </div>
                <Col span="11">
                    <Chart {...distributeCfg} />
                </Col>
                <Col span="11" offset="2">
                    <Chart {...distributePieCfg} />
                </Col>
            </Row>
        )
    }
}
class _Chart_Frequency_Relate extends React.Component {
    constructor(props) {
        super(props);
    }
    shouldComponentUpdate(nextProps, nextState) {
        let prevSel = this.props.$$overview.toJS().freq_relate;
        let nextSel = nextProps.$$overview.toJS().freq_relate;
        if (prevSel != nextSel) {
            console.log('访问频次relate变了')
            return true;
        } else {
            return false;
        }
    }
    render() {
        let { $$overview, fieldProps } = this.props;
        // let state = $$overview.toJS();
        let freqRelaCfg = {
            tooltip: {
                trigger: "item",
                formatter: '{b}: {c}({d}%)'
            },
            series: [
                {
                    name: "",
                    type: "pie",
                    selectedMode: "single",
                    radius: "55%",
                    avoidLabelOverlap: true,
                    label: {
                        normal: {
                            show: true,
                            formatter: function (obj) {
                                if (obj.name.length > 5) {
                                    obj.name = obj.name.slice(0, 5) + '...';
                                }
                                return obj.name
                            },
                            textStyle: {
                                color: "black"
                            }
                        },
                        emphasis: {
                            show: true,
                            textStyle: {
                                fontWeight: "bold"
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            lineStyle: {
                                color: "rgb(185,185,185)"
                            },
                            length: 17,
                            length2: 5
                        }
                    },
                    data: state.freq_relate_data
                }
            ],
            color: tools.chartColor
        }

        //产品、ta
        const relateJSX = Object.getOwnPropertyNames(EnumCn.ChartRelateType)
            .filter(name => !isNaN(Number(name)))
            .map(key => <Option key={key} value={key}>{EnumCn.ChartRelateType[key]}</Option>);
        return (
            <div>
                <div>职称分布</div>
                <Chart {...freqRelaCfg} />
            </div>
        )
    }
}
class _Chart_Frequency_Include extends React.Component {
    constructor(props) {
        super(props);
    }
    shouldComponentUpdate(nextProps, nextState) {
        let prevSel = this.props.$$overview.toJS().freq_including;
        let nextSel = nextProps.$$overview.toJS().freq_including;
        if (prevSel != nextSel) {
            console.log('访问频次include变了')
            return true;
        } else {
            return false;
        }
    }
    render() {
        let { $$overview, fieldProps } = this.props;
        // let state = $$overview.toJS();
        let freqIncludingCfg = {
            tooltip: {
                trigger: "item",
                formatter: "{b}: {c} ({d}%)"
            },
            series: [
                {
                    name: "",
                    type: "pie",
                    selectedMode: "single",
                    radius: "55%",
                    avoidLabelOverlap: true,
                    label: {
                        normal: {
                            show: true,
                            formatter: function (obj) {
                                if (obj.name.length > 5) {
                                    obj.name = obj.name.slice(0, 5) + '...';
                                }
                                return obj.name
                            },
                            textStyle: {
                                color: "black"
                            }
                        },
                        emphasis: {
                            show: true,
                            textStyle: {
                                fontWeight: "bold"
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            lineStyle: {
                                color: "rgb(185,185,185)"
                            },
                            length: 17,
                            length2: 5
                        }
                    },
                    data: state.freq_including_data
                }
            ],
            color: tools.chartColor
        }
        //医生分级、医院分级
        const includingJSX = Object.getOwnPropertyNames(EnumCn.ChartCoverageType)
            .filter(name => !isNaN(Number(name)))
            .map(key => <Option key={key} value={key}>{EnumCn.ChartCoverageType[key]}</Option>);
        return (
            <div>
                <div className="chart-cdt">
                    <Select
                        placeholder="请选择"
                        style={{ width: 170 }}
                        className="m-margin-r"
                        {...fieldProps.freq_including}>
                        {includingJSX}
                    </Select>
                </div>
                <Chart {...freqIncludingCfg} />
            </div>
        )
    }
}
class _Chart_Concentrate extends React.Component {
    constructor(props) {
        super(props)
    }
    shouldComponentUpdate(nextProps, nextState) {
        let prevData = this.props.$$overview.toJS().concentrate_data.length > 0 ? this.props.$$overview.toJS().concentrate_data[0].id : undefined;
        let nextData = nextProps.$$overview.toJS().concentrate_data.length > 0 ? nextProps.$$overview.toJS().concentrate_data[0].id : undefined;
        if (prevData !== nextData) {
            return true
        } else {
            return false
        }
    }
    render() {
        let { $$overview, fieldProps } = this.props;
        let state = $$overview.toJS();
        let labelRight = {
            normal: {
                position: 'right'
            }
        };
        let concenCfg = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                    type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            grid: {
                top: 80,
                bottom: 30
            },
            xAxis: {
                type: 'value',
                position: 'top',
                splitLine: { lineStyle: { type: 'dashed' } },
            },
            yAxis: {
                type: 'category',
                axisLine: { show: false },
                axisLabel: { show: false },
                axisTick: { show: false },
                splitLine: { show: false },
                data: ['三级医院', '三级丙等', '三级乙等', '三级甲等']
            },
            series: [
                {
                    type: 'bar',
                    label: {
                        normal: {
                            show: true,
                            formatter: '{b}'
                        }
                    },
                    data: [0.44, 0.28, 0.47, 0.18]
                }
            ]
        };
        return (
            <Row className="chart-box">
                <div>医院级别</div>
                <Chart {...concenCfg} />
            </Row>
        )
    }
}
class _Chart_Department extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        let dataAxis = ['儿科', '外科', '内分泌科', '普外科', '呼吸科'];
        let data = [40, 162, 191, 84, 20];
        let yMax = 200;
        let dataShadow = [];

        for (let i = 0; i < data.length; i++) {
            dataShadow.push(yMax);
        }
        let departmentCfg = {
            xAxis: {
                data: dataAxis,
                axisTick: {
                    show: false
                },
                axisLine: {
                    show: false
                },
                z: 10
            },
            yAxis: {
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                axisLabel: {
                    textStyle: {
                        color: '#999'
                    }
                }
            },
            dataZoom: [
                {
                    type: 'inside'
                }
            ],
            series: [
                { // For shadow
                    type: 'bar',
                    itemStyle: {
                        normal: { color: 'rgba(0,0,0,0.05)' }
                    },
                    barGap: '-100%',
                    barCategoryGap: '40%',
                    data: dataShadow,
                    animation: false
                },
                {
                    type: 'bar',
                    itemStyle: {
                        normal: {
                            color: new echarts.graphic.LinearGradient(
                                0, 0, 0, 1,
                                [
                                    { offset: 0, color: '#83bff6' },
                                    { offset: 0.5, color: '#188df0' },
                                    { offset: 1, color: '#188df0' }
                                ]
                            )
                        },
                        emphasis: {
                            color: new echarts.graphic.LinearGradient(
                                0, 0, 0, 1,
                                [
                                    { offset: 0, color: '#2378f7' },
                                    { offset: 0.7, color: '#2378f7' },
                                    { offset: 1, color: '#83bff6' }
                                ]
                            )
                        }
                    },
                    data: data
                }
            ]
        };
        return (
            <div>
                <div>科室</div>
                <br /><br />
                <Chart {...departmentCfg} />
            </div>
        )
    }
}

Overview = Form.create()(Overview);


export default connect(
    (state) => {
        return {
            $$layout: state.$$layout,
            $$overview: state.$$overview
        }
    },
    (dispatch) => {
        return {
            overviewActs: bindActionCreators(Actions, dispatch)
        }
    })(Overview)
