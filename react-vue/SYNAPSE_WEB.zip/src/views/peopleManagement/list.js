import Immutable from "immutable"
import React, {Component} from "react"
import ReactDOM from "react-dom"
import {Link, withRouter} from "react-router"
import {connect} from "react-redux"
import {bindActionCreators} from "redux"
import * as Actions from "actions/peopleManagement"
import {tools} from "utils"
import {EnumCn, Enum} from "enum"
import {
    Card,
    Row,
    Col,
    Input,
    Button,
    Menu,
    Dropdown,
    Icon,
    Alert
} from "antd"
import moment from "moment"
import AdvSearch from "components/advSearch"
import "src/assets/style/views/peopleManagement/list.less"
import TextCard from "components/card/TextCard"

const Search = Input.Search;

class PeopleMgtList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            mockdata: [0, 1, 2, 3, 4],
            avdSearchData: {
                dataItem: [
                    {
                        name: "全部",
                        value: "0"
                    }, {
                        name: "华北",
                        value: "1"
                    }, {
                        name: "华南",
                        value: "2"
                    }
                ]
            }
        }
    }

    componentDidMount() {
        let {peopleAct} = this.props;
        peopleAct.getPeopleGroup({key: "a"});
    }

    render() {
        let {peopleGroupData} = this.props.$$peopleGroupList.toJS();
        console.log(peopleGroupData);
        let _peopleList = [];
        if (peopleGroupData.length > 0) {
            peopleGroupData.forEach((item, index) => {
                let obj = [];
                obj.id = item.id;
                obj.name = item.name;
                let region = [], hosp = [], dep = [], doct = [];
                item.includings.forEach((item, index) => {
                    switch (item.category) {
                        case 1:
                            region.push(item.name);
                            break;
                        case 2:
                            hosp.push(item.name);
                            break;
                        case 3:
                            dep.push(item.name);
                            break;
                        case 4:
                            doct.push(item.name);
                            break;
                    }
                });
                let values = [];
                values.push({title: "预计覆盖人数", value: "312977777"});
                values.push({title: "推广区域（" + region.length + "）", value: region.join(" ")});
                values.push({title: "覆盖科室（" + dep.length + "）", value: dep.join(" ")});
                values.push({title: "医院等级（" + hosp.length + "）", value: hosp.join(" ")});
                values.push({title: "医生职称（" + doct.length + "）", value: doct.join(" ")});
                obj.values = values;
                _peopleList.push(obj);
            });
        }

        const TextCardJSX = _peopleList.map((item, index) => {
            const menu = (
                <Menu onClick={this.editPeople.bind(this, item)}>
                    <Menu.Item>
                        编辑
                    </Menu.Item>
                    <Menu.Item>
                        删除
                    </Menu.Item>
                </Menu>
            );
            return <Col key={index} span={12}>
                <div className="text-card-box relative">
                    <Dropdown overlay={menu}>
                        <a className="ant-dropdown-link fiexd" href="javascript:void(0)">
                            <Icon type="ellipsis" style={{fontSize: "1.2rem"}}/>
                        </a>
                    </Dropdown>
                    <TextCard data={item}/>
                </div>
            </Col>
        });
        return (
            <div className="peopleMgt-list">
                {/*<Alert style={{marginBottom: "1rem"}}
                       message={<div><p>人群管理说明：</p><p style={{fontSize: "16px", color: "#999999"}}>
                           以下配置为推广人群组，将用于创建营销战役及推广项目</p></div>}
                       type="warning"
                       showIcon/>*/}
                <Alert className="peo-list-alert"
                       message={<span style={{fontSize:"16px",color:"#666",lineHeight:"28px"}}>人群管理说明：</span>}
                       description={<span style={{fontSize:"14px",color:"#999",lineHeight:"26px"}}>以下配置为推广人群组，将用于创建营销战役及推广项目</span>}
                       type="warning"
                       showIcon/>
                <div className="alert-right">
                    <span>您还可以：</span>
                    <div>
                        <Icon type="socialfill"/>
                    </div>
                    <a>市场分级管理</a>
                </div>

                <div className="BLine"></div>
                <AdvSearch dataSource={this.state.avdSearchData}/>
                <div className="BLine"></div>
                <div>
                    <Card style={{border:"0px"}} title={<div className="card-title"><Icon type="qun"/><span>目标人群</span></div>}
                          extra={<div className="card-head-right"><Search placeholder="请输入搜索内容" onSearch={value => console.log(value)}
                                              style={{width: 200}}/> {/*enterButton*/}
                              <Button onClick={() => {
                                  this.props.router.push("/peopleManagement/edit")
                              }} type="primary" icon="plus">新建</Button>
                          </div>}>
                        <Row>
                            {TextCardJSX}
                        </Row>
                    </Card>
                </div>
            </div>
        )
    }

    editPeople(item, menuObj) {
        if (menuObj.key === "item_0") {
            this.props.router.push({
                pathname: "/peopleManagement/edit",
                search: "?id=" + item.id
            })
        }
        if(menuObj.key==="item_1"){
            let {peopleAct}=this.props;
            peopleAct.deletePeopleGroup({id:item.id}).done((res)=>{
                peopleAct.getPeopleGroup({key: "a"});
            });
        }
    }

}

export default connect(
    (state) => {
        return {
            $$peopleGroupList: state.$$peopleGroupList,
        }
    },
    (dispatch) => {
        return {
            peopleAct: bindActionCreators(Actions, dispatch)
        }
    })(withRouter(PeopleMgtList))