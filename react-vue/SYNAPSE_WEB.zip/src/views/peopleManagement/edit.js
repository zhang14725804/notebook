import Immutable from "immutable"
import React, {Component} from "react"
import ReactDOM from "react-dom"
import {Link, withRouter} from "react-router"
import {connect} from "react-redux"
import {bindActionCreators} from "redux"
import * as Actions from "actions/common"
import * as peopleAct from "actions/peopleManagement"
import {tools} from "utils"
import {EnumCn, Enum} from "enum"
import {
    Card,
    Row,
    Col,
    Input,
    Button,
    Menu,
    Dropdown,
    Icon,
    Form,
    Select,
    Modal,
    Tag,
    Tabs,
} from "antd"
import moment from "moment"

import "assets/style/views/peopleManagement/edit.less"
import mockdata from "mockdata/allDepartment"
import EditInfo from "components/editInfo"
import CountUp from 'react-countup';
import {ColorEnum} from "src/constants/customEnum"

const FormItem = Form.Item;
const Option = Select.Option;
const TabPane = Tabs.TabPane;
const formItemLayout_m = {
    labelCol: {span: 4},
    wrapperCol: {span: 20},
};

const defValue = {//下拉选【全部】对应值
    province: "820001",   // TODO 之前返的是0，以后这个值可能会变
    hospLevel: "0",
    docLevel: "0",
    department: "0"
}

class PeopleMgtEdit extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isShowPeopleNum: false,
            query:tools.getQuery(),
            block_id:null
        }
        this.end=31292238;
    }

    componentDidMount() {
        let {commonActs,peopleAct}=this.props;
        let {query}=this.state;
        if(query.id){
            peopleAct.getInfoPeopleGroup({id:query.id}).done((res)=>{
                let data=res.data;
                this.setState({block_id:data.block_id});
                let dep=[],hosp=[],region=[],doct=[];
                let temp=JSON.parse(data.template);
                temp.forEach((item,index)=>{
                    switch (item.category){
                        case 1:
                            region.push(item.subject_id);
                            break;
                            case 2:
                            hosp.push(item.subject_id);
                            break;
                            case 3:
                            dep.push(item.subject_id);
                            break;
                            case 4:
                            doct.push(item.subject_id);
                            break;
                    }
                });
                this.props.form.setFieldsValue({
                    name:data.name,
                    department_ids: dep,
                    hospitalLevel_ids:hosp,
                    province_ids:region,
                    doctorLevel_ids:doct
                });
            });
        }
        commonActs.getAllDepartment();
        commonActs.getAllProvince();
        commonActs.getAllHospLevel();
        commonActs.getAllDocLevel();
    }

    render() {
        const {form} = this.props;
        const fieldProps = this._getFieldProps();
      /*  let info={
            title: "新建目标人群",
            creator: "小白菜",
            department: "市场部",
            product: "韦瑞德",
            field: "HIV",
        }*/
        let colorStyle={
            color:ColorEnum.colorType[2].color,
            backgroundColor:ColorEnum.colorType[2].bgColor,
        }
        return (
            <div className="peopleMgt-edit">
                {/*<EditInfo dataSource={info} onCancel={::this.onCancel} onComplete={::this.onComplete}/>*/}
                <div className="pe-page-header-box" style={{paddingBottom:"30px"}}>
                    <Row style={{paddingTop:"30px"}}>
                        <Col span={16}>
                            <div className='pe-icon' style={{backgroundColor:colorStyle.backgroundColor}}>
                                <Icon style={{color:colorStyle.color,fontSize:'18px'}} type='tuiguang'></Icon>
                            </div>
                            <span className="pe-title">新建目标人群</span>
                        </Col>
                        <Col span={8}>
                            <div style={{float:"right",marginRight:"55px"}}>
                                <div className="pe-baseBtn" onClick={::this.onCancel}>取 消</div>
                                <div className="pe-baseBtn pe-btn-blueBg" onClick={::this.onComplete}>完 成</div>
                            </div>
                        </Col>
                    </Row>
                    <div className="pe-create-info" style={{marginTop:"15px"}}>
                        <Row>
                            <Col span={5}>创建人：小白菜</Col>
                            <Col span={10}>所属部门：市场部</Col>
                        </Row>
                        <Row>
                            <Col span={5}>产品名：韦瑞德</Col>
                            <Col span={10}>关联领域：HIV</Col>
                        </Row>
                    </div>
                </div>
                <div className="borderBox" style={{height:"calc(100% - 163px)"}}>
                    <_SecondPromotion fieldProps={fieldProps} {...this.props} />
                    <div className="peo-edit-bottom">
                        <div className="center">
                            <Button size="large" onClick={this.onSubmit.bind(this)}>预估覆盖人数</Button>
                        </div>
                        {
                            this.state.isShowPeopleNum ?
                                <div className="center cover_num">
                                    <CountUp start={0}
                                             duration={1}
                                        // separator=","
                                             separator=""
                                             end={this.end}/>
                                </div> :
                                <div></div>
                        }
                    </div>
                </div>
            </div>
        )
    }

    //点击取消
    onCancel(){
        this.props.router.go(-1);
    }
    //点击完成
    onComplete(){
        let {peopleAct,form}=this.props;
        form.validateFields((err, values) => {
            if (!err) {
                let obj={}
                obj.name=values.name;
                obj.block_id=1;
                let dep=[],doct=[],hosp=[],region=[];
                values.province_ids.forEach((item,index)=>{
                    region.push({category:1,subject_id:item});
                });
                values.hospitalLevel_ids.forEach((item,index)=>{
                    hosp.push({category:2,subject_id:item});
                });
                values.department_ids.forEach((item,index)=>{
                    dep.push({category:3,subject_id:item})
                }) ;
                values.doctorLevel_ids.forEach((item,index)=>{
                    doct.push({category:4,subject_id:item})
                });
                obj.template=JSON.stringify([...region,...hosp,...dep,...doct]);
                if (this.state.query.id){
                    obj.id=this.state.query.id;
                    obj.block_id=this.state.block_id;
                    // peopleAct.modifyInfoPeopleGroup(obj);
                }else {
                    peopleAct.addPeopleGroup(obj);
                }
                this.onCancel()
            }else {
                return;
            }
        });
    }

    //点击预估覆盖人数
    onSubmit() {
        this.end++;
        this.props.form.validateFields((err, values) => {
            if (!err) {
                this.setState({isShowPeopleNum:true})
                console.log('Received values of form: ', values);
            }
        });
    }

    //规范化多选输出
    _normalizeMultiSel(curKeys, prevKeys, allKeys, defKey) {
        // debugger
        let selKey = (curKeys || []).slice(-1)[0];
        let resKeys = [];
        if (selKey === defKey) {
            resKeys = [defKey];
        } else {
            if ($.inArray(defKey, curKeys) > -1) {
                tools.showDialog.error("请取消全部");
                resKeys = prevKeys;
            } else {
                resKeys = curKeys;
            }
        }
        return resKeys;
    }

    //获取表单属性
    _getFieldProps() {
        let {form} = this.props;
        let {getFieldDecorator} = this.props.form;
        return {
            name: getFieldDecorator("name", {
                initialValue: null,
                rules: [
                    {required: true, message: "请填写群组名称"}
                ]
            }),
            //科室
            department_ids: getFieldDecorator("department_ids", {
                initialValue: [],
                normalize: (curKeys, prevKeys, allKeys) => {
                    let prevAllKeys = this.props.form.getFieldsValue();

                    if (!Immutable.fromJS(curKeys || {}).equals(Immutable.fromJS(prevKeys || {}))) {
                        return this._normalizeMultiSel.call(this, curKeys, prevKeys, allKeys, defValue.department);
                    } else {
                        return curKeys;
                    }
                },
                rules: [
                    {
                        validator: (rule, value, cb) => {
                            if (value == null || value.length === 0) {
                                $('.promotion-department').css({
                                    borderColor: '#f50',
                                    boxShadow: '0 0 0 2px rgba(255,85,0,.2)'
                                })
                                cb("请选择科室")
                            } else {
                                $('.promotion-department').css({
                                    borderColor: 'rgb(236,236,236)',
                                    boxShadow: 'none'
                                })
                                cb()
                            }
                        }
                    }
                ]
            }),
            //区域
            province_ids: getFieldDecorator("province_ids", {
                initialValue: [],
                normalize: (curKeys, prevKeys, allKeys) => {
                    let prevAllKeys = this.props.form.getFieldsValue();
                    if (!Immutable.fromJS(curKeys || {}).equals(Immutable.fromJS(prevKeys || {}))) {
                        return this._normalizeMultiSel.call(this, curKeys, prevKeys, allKeys, defValue.province);
                    } else {
                        return curKeys;
                    }
                },
                rules: [
                    {required: true, message: "请选择区域", type: "array"}
                ]
            }),
            //医院分级
            hospitalLevel_ids: getFieldDecorator("hospitalLevel_ids", {
                initialValue: [],
                normalize: (curKeys, prevKeys, allKeys) => {
                    let prevAllKeys = this.props.form.getFieldsValue();
                    if (!Immutable.fromJS(curKeys || {}).equals(Immutable.fromJS(prevKeys || {}))) {
                        return this._normalizeMultiSel.call(this, curKeys, prevKeys, allKeys, defValue.hospLevel);
                    } else {
                        return curKeys;
                    }
                },
                rules: [
                    {required: true, message: "请选择医院分级", type: "array"}
                ]
            }),
            //医生等级
            doctorLevel_ids: getFieldDecorator("doctorLevel_ids", {
                initialValue: [],
                normalize: (curKeys, prevKeys, allKeys) => {
                    let prevAllKeys = this.props.form.getFieldsValue();
                    if (!Immutable.fromJS(curKeys || {}).equals(Immutable.fromJS(prevKeys || {}))) {
                        return this._normalizeMultiSel.call(this, curKeys, prevKeys, allKeys, defValue.docLevel);
                    } else {
                        return curKeys;
                    }
                },
                rules: [
                    {required: true, message: "请选择医生级别", type: "array"}
                ]
            }),
        }
    }
}

class _SecondPromotion extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            //是否显示弹窗
            isShow: false,
            selDpmIds: []//此项作为当前component的临时存储区，用于保存弹窗中选中的item，弹窗关闭后置空
        }
    }

    render() {
        let {fieldProps, form} = this.props;
        let {allDepartment,allProvince,allHospLevel,allDocLevel}=this.props.$$common.toJS();
        //区域
        const provinceJSX = allProvince.map(item => <Option key={item.id}>{item.name}</Option>);
        //医院等级
        const hospLevelJSX = allHospLevel.map(item => <Option key={item.id}>{item.name}</Option>);
        //医生等级
        const docLevelJSX = allDocLevel.map(item => <Option key={item.id}>{item.grade}</Option>);
        //科室
        let dpmJSX = [];
        if (form.getFieldValue("department_ids") && form.getFieldValue("department_ids").length == 0) {
            dpmJSX = <span style={{color: '#ccc'}}>请选择</span>
        } else {
            dpmJSX = $.map(form.getFieldValue("department_ids"), id => {
                let dpm = null;
                $.map(allDepartment, group => {//查询所有dpm.leaves
                    let index = $.inArray(id, $.map(group.leaves || [], leaves => leaves.id));
                    if (index > -1) dpm = (group.leaves)[index];
                });
                return dpm != null ? <Tag closable={!fieldProps.department_ids.disabled} key={dpm.id} onClose={(e) => {
                    this.onCloseDpm.call(this, e, dpm.id)
                }}>{dpm.name}</Tag> : null;
            });
        }

        return (
            <div>
                <Row>
                    <Col span={6}></Col>
                    <Col span={12}>
                        <FormItem
                            {...formItemLayout_m}
                            required
                            label="群组名称：">
                            {fieldProps.name(
                                <Input style={{width: '100%'}}
                                       placeholder="请输入"/>
                            )}
                        </FormItem>
                        <FormItem
                            {...formItemLayout_m}
                            required
                            label="覆盖科室：">
                            {fieldProps.department_ids(
                                <div
                                    style={{width: '100%'}}
                                    onClick={fieldProps.department_ids.disabled ? null : this.onClickDpm.bind(this)}
                                    className={fieldProps.department_ids.disabled ? "promotion-department disabled" : "promotion-department"}>
                                    {dpmJSX}
                                </div>
                            )}
                        </FormItem>
                        <FormItem
                            {...formItemLayout_m}
                            label="推广区域：">
                            {fieldProps.province_ids(
                                <Select
                                    style={{width: '100%'}}
                                    mode='multiple'
                                    placeholder="请选择">{provinceJSX}</Select>
                            )}
                        </FormItem>
                        <FormItem
                            {...formItemLayout_m}
                            label="医院等级：">
                            {fieldProps.hospitalLevel_ids(
                                <Select
                                    style={{width: '100%'}}
                                    mode='multiple'
                                    placeholder="请选择">{hospLevelJSX}</Select>
                            )}
                        </FormItem>
                        <FormItem
                            {...formItemLayout_m}
                            label="医生职称：">
                            {fieldProps.doctorLevel_ids(
                                <Select
                                    style={{width: '100%'}}
                                    mode='multiple'
                                    placeholder="请选择">{docLevelJSX}</Select>
                            )}
                        </FormItem>
                    </Col>
                    <Col span={6}></Col>
                </Row>
                <_SecondSelector
                    title="选择科室"
                    width="1000px"
                    visible={this.state.isShow}
                    onOk={this.onConfirm.bind(this)}
                    onCancel={this.onClose.bind(this)}
                    dataSource={allDepartment}
                    chkKeys={form.getFieldValue("department_ids")}/>
            </div>
        );
    }

    //点击关联科室按钮
    onClickDpm() {
        this.setState({
            isShow: true
        })
    }

    //点击科室弹窗中的确认按钮
    onConfirm(keys) {
        this.props.form.setFieldsValue({
            department_ids: keys
        });
        this.props.form.validateFields(['department_ids']);
        this.setState({
            isShow: false
        })
    }

    //点击科室弹窗中的关闭按钮
    onClose() {
        this.setState({
            isShow: false
        })
    }

    //关闭选中科室时执行
    onCloseDpm(e, id) {
        e.stopPropagation();
        let {getFieldValue, setFieldsValue} = this.props.form;
        let dpms = $.grep(getFieldValue("department_ids"), key => key != id);
        setFieldsValue({
            department_ids: dpms
        });
        this.props.form.validateFields(['department_ids']);
    }
};

//选择科室弹窗
class _SecondSelector extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            chkKeys: (props.chkKeys || []).slice(),
            defValue: defValue.department
        };
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            chkKeys: nextProps.chkKeys
        });
    }

    render() {
        let chkKeys = this.state.chkKeys;
        let chkItems = [];
        let jsx = $.map(this.props.dataSource, (item) => {
            // debugger
            let subJsx = $.map(item.leaves || [], (sub) => {
                defValue
                //获取选中的实体
                $.map(chkKeys, key => {
                    if (key === sub.id) chkItems.push(sub);
                });
                return (
                    <span
                        key={sub.id}
                        className={"pop-sub " + ($.inArray(sub.id, chkKeys) > -1 ? "checked" : "")}
                        onClick={this.onClickItem.bind(this, sub.id)}>{sub.name}</span>
                );

            });
            return (

                <Row key={item.id} className="pop-row">
                    <Col span="4" className="pop-col-left">{item.name}</Col>
                    <Col span="20" className="pop-col-right">{subJsx}</Col>
                </Row>
            );
        });
        let selJsx = chkItems.map(item => <Tag key={item.id} closable
                                               onClose={this.onClickItem.bind(this, item.id)}>{item.name}</Tag>)

        return (
            <Modal
                {...this.props}
                onOk={this.onConfirm.bind(this)}
                onCancel={this.onClose.bind(this)}>
                <div>
                    <Row className="pop-row">
                        <Col span="4" className="pop-col-left">已选</Col>
                        <Col span="20" className="pop-col-right">{selJsx}</Col>
                    </Row>
                    <div>{jsx}</div>
                </div>
            </Modal>
        );
    }

    //点击弹窗确认按钮
    onConfirm() {
        if (typeof this.props.onOk === "function") {
            this.props.onOk.call(this, this.state.chkKeys.slice());
        }
        this.setState({
            chkKeys: []
        });
    }

    //点击弹窗关闭按钮
    onClose() {
        if (typeof this.props.onCancel === "function") {
            this.props.onCancel.call(this);
        }
        this.setState({
            chkKeys: []
        });
    }

    //点击科室弹框中的选项
    onClickItem(id) {
        // debugger
        let chkKeys = this.state.chkKeys.slice();
        let defDpmId = this.state.defValue;
        //校验是否已选中全部
        if (id != defDpmId && $.inArray(defDpmId, chkKeys) > -1) {
            tools.showDialog.error("请取消全部科室");
            return;
        }

        //若当前项已选中，则删除；否则插入
        let resKeys = $.grep(chkKeys, key => {
            return key != id;
        });

        if (resKeys.length === chkKeys.length) {
            //若选中项为全部，则删除其余选项
            if (id === defDpmId) {
                resKeys = [];
            }
            resKeys.push(id);
        }

        this.setState({
            chkKeys: resKeys
        });
    }
};

PeopleMgtEdit = Form.create()(PeopleMgtEdit);

export default connect(
    (state) => {
        return {
            $$common: state.$$common,
        }
    },
    (dispatch) => {
        return {
            commonActs: bindActionCreators(Actions, dispatch),
            peopleAct: bindActionCreators(peopleAct, dispatch),
        }
    })(withRouter(PeopleMgtEdit))    