import React from "react"
import ReactDOM from "react-dom"
import { bindActionCreators } from 'redux';
import { connect } from "react-redux"
import '../../assets/style/views/dataInsight/dataInsight.less'
import '../../assets/style/views/dataInsight/dataInsightCard.less'
import { Link, withRouter } from "react-router"
import Icon from "antd/lib/icon"
import { Card, Tooltip, Row, Col } from 'antd';
import * as broadcardlistActions from 'src/actions/broadcast.js';
import { ColorEnum } from 'src/constants/customEnum'
const imgs = {
    img1: require('../../assets/image/u31.png'),
    img2: require('../../assets/image/u395.png'),
    imgAdd: require('../../assets/image/u592.png'),
    img3: require('../../assets/image/u11171.png'),
    img4: require('../../assets/image/u11173.png'),
    img5: require('../../assets/image/u11175.png'),
}
class DataInsight extends React.Component {
    componentDidMount() {
        let { broadcardlistActs } = this.props;
        broadcardlistActs.resetbroadlist();
        broadcardlistActs.getBroadcardList();
    }
    render() {
        let { broadcardlist } = this.props.$$broadcardlist.toJS();
        console.log(broadcardlist,'list');
        let broadJSX=broadcardlist.map((item,i)=>{
            return(<Col className='single-card' key={i} md={12} lg={8} xl={8} xxl={6}><DataInsightCard {...item} router={this.props.router}/></Col>)
        })
        let backIconStyle = {
            width: '25px',
            height: '25px',
            lineHeight: '25px',
            backgroundColor: '#ccc'
        }
        return (
            <section className='dataInsight-page'>
                <div className='top-bar'>
                    <div className='top-bar-right'>
                        <div><Link><span><Icon style={backIconStyle} className='back-icon' type='jijianfasong' /></span><span>统计说明</span></Link></div>
                    </div>
                </div>
                <div className='broad-content'>
                    <Row gutter={16}>
                        {broadJSX}
                        <Col className='single-card' md={12} lg={8} xl={8} xxl={6}>
                            <Link>
                                <Card className='card-add'>
                                    {/*<img src={imgs.imgAdd} alt=""/>*/}
                                    <Icon type='plus'></Icon>
                                </Card>

                            </Link>
                        </Col>
                    </Row>
                </div>
            </section>
        );
    }
}

class DataInsightCard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }
    componentDidMount() {

    }

    componentWillReceiveProps(nextProps) {
    }

    render() {
        let prop = this.props;
        let colorType = ColorEnum.colorType;
        let colorId = prop && prop.id ? colorType.length - (parseInt(prop.id) % colorType.length) : 1;
        let iconColorStyle = {
            color: colorType[colorId].color,
            backgroundColor: colorType[colorId].bgColor,
            fontSize: '21px'
        }
        let tagColorStyle = prop && prop.labelType ? {
            color: colorType[prop.labelType - 1].color,
            backgroundColor: colorType[prop.labelType - 1].bgColor,
        } : {
            color: "#1890ff",
            backgroundColor: 'e6f7ff'
        }
        let menuData = [{
            id: '1-1',
            name: '市场推广',
            url: 'marketBusi',
            icon: 'tuiguang'
        }, {
            id: '1-2',
            name: '人群管理',
            url: 'peopleManagement/list',
            icon: 'qun'
        }, {
            id: '1-3',
            name: '资源中心',
            url: 'documentCenter/list',
            icon: 'wenjianjia1'
        }, {
            id: '1-4',
            name: 'KM及标签管理',
            url: 'KMManagement/detail',
            icon: 'flag_fill'
        }]
        let menuJSX = menuData.map((item, index) => {
            return (<p key={index}>
                <Tooltip placement='top' title={item.name}>
                    <span>
                        <Icon className='back-icon' type={item.icon} style={{ color: '#fff' }} onClick={this.onClickMenuIcon.bind(this, item)} />
                    </span>
                </Tooltip>
            </p>)
        })
        return (
            <Card className='dataInsight-card' onClick={:: this.onCardClick}>
                <div className='card-top-right'>
                    <div className='tab-angle' style={{ borderTopColor: tagColorStyle.backgroundColor }}>
                        <p style={{ color: tagColorStyle.color }}>{prop.labelName}</p>
                    </div>
                </div>
                <Row className='card-top'>
                    <div>
                        <Col span={3}>
                            <Col className='top-lefticon1' span={24}><Icon className='back-icon' style={iconColorStyle} type='shouye'/></Col>
                            <Col className='top-lefticon2' span={24}><img src={imgs.img1} alt=""/></Col>
                        </Col>
                        <Col span={21} style={{paddingLeft:'10px'}}>
                            <Col span={24}><p className='top-title'>{prop.cn_name}</p></Col>
                            <Col span={24}><p className='top-des'>{prop.des}</p></Col>
                            <Col className='top-sickname' span={24}>
                                <span className='top-sickname-wrap' span={4}><Icon type='msnui-link'/></span>
                                <span>{prop.zz}</span>
                            </Col>
                        </Col>
                    </div>
                </Row>
                <div className='card-content'>
                    <div>
                        <p>影响人群</p>
                        <p className='effect-peo-num'>{prop.sumP}</p>
                    </div>
                    <div className='size-num'>
                        <div>
                            <p>数据源</p>
                            <p>{prop.sum1}</p>
                        </div>
                        <div>
                            <p>平均占用时长</p>
                            <p>{prop.sum2}</p>
                        </div>
                        <div>
                            <p>KM量</p>
                            <p>{prop.sum3}</p>
                        </div>
                    </div>
                </div>
                <div className='card-bottom'>
                    <span className='top-sickname-wrap' span={4}><Icon type='msnui-link'/></span>
                    <span className='bottom-txt'>渠道：</span>
                    <span><img style={{width:'34px'}} src={imgs.img5} alt=""/></span>
                    <span><img src={imgs.img4} alt=""/></span>
                    <span><img src={imgs.img3} alt=""/></span>
                </div>
            </Card >
        )
    }
    onClickMenuIcon(item){
        this.props.router.push({
            pathname: item.url,
        });
    }
    onCardClick(){
        console.log('cardclick');
    }
}

export default connect(
    (state) => {
        return {
            $$broadcardlist: state.$$broadcardlist
        }
    },
    (dispatch) => {
        return {
            broadcardlistActs: bindActionCreators(broadcardlistActions, dispatch)
        }
    }
)(withRouter(DataInsight))