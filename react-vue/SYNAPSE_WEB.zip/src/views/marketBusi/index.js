import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { List, Avatar,Card,Input ,Button,Row,Col,Icon,Table} from 'antd';
const Search = Input.Search;
import $ from 'jquery';
import {tools} from "utils"
import 'src/assets/style/views/marketBusi/marketBroad/marketBroad.less'
import AvdSearch from 'src/components/advSearch/index.js'
import {ColorEnum} from 'src/constants/customEnum'
class MarketBroad extends React.Component {//市场推广列表页
    constructor(props) {
        super(props);
        this.state={
        }
    }
    componentDidMount() {
    }

    componentWillReceiveProps(nextProps) {
    }
    render() {
        let {data}=this.state;
        // 卡片头部附加内容：搜索框
        let extra=<div>
            <Row gutter={16}>
                <Col span={18}>
                    <Search
                        placeholder="请输入搜索内容"
                        onSearch={value => console.log(value)}
                        style={{ width: 200 }}
                    />
                </Col>
                <Col span={6}>
                    <Button type="primary" onClick={()=>{this.props.router.push("/marketCamp/edit")}}>
                        <Icon type='plus'></Icon>
                        <span>新增</span>
                    </Button>
                </Col>
            </Row>
        </div>
        let colorType=ColorEnum.colorType;
        // 列表数据调完列表接口放在state里
        const dataSource = [{
            key: '1',
            battle: '买韦瑞德！2千万用户的共同选择',
            name: 4,
            sum: '12300',
            startTime:1506482821000,
            endTime:1507482821000,
            status:true
        },{
            key: '2',
            battle: '买韦瑞德！2千万用户的共同选择',
            name: 4,
            sum: '12300',
            startTime:1506582822000,
            endTime:1507482821000,
            status:true
        },{
            key: '3',
            battle: '买韦瑞德！2千万用户的共同选择',
            name: 4,
            sum: '12300',
            startTime:1506682823000,
            endTime:1507482821000,
            status:false
        }];
        let cfg = {
            dataSource: dataSource,
            rowKey: r => r.key,
            columns: [{
                title: '营销战役',
                dataIndex: 'battle',
                key: 'battle',
                render: (text,r) => {
                    // let colorId=parseInt(Math.random()*5,10)+1;//随机色
                    let colorId=parseInt(r.key)%colorType.length-1; //循环0-4
                    let colorStyle={
                        color:colorType[colorId]&&colorType[colorId].color||'#eb2f96',
                        backgroundColor:colorType[colorId]&&colorType[colorId].bgColor||'#fff0f6',
                    }
                    return(<div>
                        <div className='battle-icon' style={{backgroundColor:colorStyle.backgroundColor}}>
                            <Icon style={{color:colorStyle.color,fontSize:'18px'}} type='tuiguang'></Icon>
                        </div>
                        {/*<Link to="/marketCamp/detail">*/}
                        {text}
                        {/*</Link>*/}
                    </div>)
                }
            }, {
                title: '推广项目',
                dataIndex: 'name',
                key: 'name',
            }, {
                title: '预估总消耗',
                dataIndex: 'sum',
                key: 'sum',
                render:text=><div>
                    ￥{text}
                </div>
            },{
                title: '开始时间',
                dataIndex: 'startTime',
                key: 'startTime',
                render:text=>{
                    let t=new hDate(text).format(`${tools.dateFormat2}`)
                    return(
                        <div>{t}</div>
                    )
                }


            }, {
                title: '结束时间',
                dataIndex: 'endTime',
                key: 'endTime',
                render:text=>{
                    let t=new hDate(text).format(`${tools.dateFormat2}`)
                    return(
                        <div>{t}</div>
                    )
                }


            },{
                title: '战役状态',
                dataIndex: 'status',
                key: 'status',
                render:(text,r)=>{
                    let iconColor={
                        icon_true:'#1890FF',
                        icon_false:'#52C41A'
                    }
                    let txt=`icon_${text}`
                    return(
                        <div>
                            <span><Icon style={{color:iconColor[txt]}} type={'yuandianzhong'}></Icon></span>
                            <span>{text?'进行中':'已结束'}</span>
                        </div>
                    )
                }

            }, {
                title: '操作',
                key: 'action',
                render: (text, record) => (
                    <div key={record.key} style={{display:record.status?'table-cell':'none'}} onClick={this.stopAction.bind(this,record.key)} className='action'><div></div></div>
                )
            }],
            pagination: $.extend(true, {}, tools.config.pagination, {
                current: 2,
                pageSize: 5,
                total: 20
            }),
            onChange: (page, filter, sort) => {
                console.log(page, filter, sort,'page');
            },
            /*rowSelection: {
                type: "radio",
                selectedRowKeys: checkedExps.map(d => d.id),
                onChange: (selectedRowKeys, selectedRows) => {
                    let {expSinActs} = this.props;
                    expSinActs.setCheckedExpSin(selectedRows);
                }
            }*/
        };
        let avdSearchData={
            dataItem: [
                {
                    name: "全部",
                    value: "0"
                }, {
                    name: "进行中",
                    value: "1"
                }, {
                    name: "推广完成",
                    value: "2"
                }
            ]
        }
        return (
            <div className='marketbroad-page'>
                {/*高级搜索*/}
                <AvdSearch dataSource={avdSearchData} onChangeItem={this.onChangeCatetory.bind(this)} onSeniorQuery={this.onQuery.bind(this)}/>
                {/*表格卡*/}
                <Card className='broad-card' title={<div className='marketbroad-title'>市场推广列表</div>} bordered={false} extra={extra}>
                    <Table
                        onRow={(record) => {
                            return {
                                onClick: () => {console.log(record,record.key,996)
                                    this.props.router.push({pathname:'/marketCamp/detail',query:{marketCampId:record.key}})
                                },       // 点击行
                            }
                        }}
                        {...cfg} />
                </Card>
            </div>
        );
    }
    stopAction(val,e){//结束战役
        console.log(val,'-结束战役-');
        e.stopPropagation();//防止触发列表点击事件
        // 调取完结束接口再获取一遍列表接口
    }
    onChangeCatetory(val){
        console.log(val,'-类目切换-');
    }
    onQuery(val){
        console.log(val,'-高级查询-');
    }
}
export default connect(
    (state) => {
        return {
        }
    },
    (dispatch) => {
        return {
        }
    }
)(withRouter(MarketBroad))