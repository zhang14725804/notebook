import $ from "jquery"
import Immutable from "immutable"
import React from "react"
import ReactDOM from "react-dom"
import { connect } from "react-redux"
import { withRouter } from "react-router"
import { bindActionCreators } from "redux"
import * as Actions from "actions/product"
import { Enum, EnumCn } from "enum"
import { tools } from "utils"
import Chart from "components/chart"
// import {Row, Col, Button, Icon, Tabs, Form, Select  } from "assets/lib/antd"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Button from "antd/lib/button"
import Icon from "antd/lib/icon"
import Tabs from "antd/lib/tabs"
import Form from "antd/lib/form"
import Select from "antd/lib/select"
const TabPane = Tabs.TabPane
const Option = Select.Option

import "assets/style/views/product/detail.less"

class ProductDetail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            query: props.location.query
        }
    }
    componentDidMount() {
        let {$$layout, pdtActs} = this.props;
        let loginUser = $$layout.toJS().login_user;
        let pdtId = this.state.query.productId;
        pdtActs.reset();
        pdtActs.getPdt(pdtId);
        //统计分析接口，待对接
        // pdtActs.getOverView({
        //     company_id: loginUser.company_id,
        //     product_id: pdtId
        // });
        //趋势图接口，待对接
        // pdtActs.getTrend({
        //     company_id: loginUser.company_id,
        //     product_id: pdtId,
        //     range: Enum.ChartTime.today,
        //     type: [Enum.ChartTarget.pv]
        // });
    }
    render() {
        let pdt = this.props.$$productDetail.toJS().product;
        let iconMap = {
            state_0: { icon: "cross-circle", className: "m-text-error" },
            state_1: { icon: "check-circle", className: "m-text-success" }
        }
        return (
            <section>
                <Row className="m-margin-b">
                    <Col span="2">
                        <Icon
                            type={iconMap["state_" + pdt.status].icon}
                            className={"m-margin-r " + iconMap["state_" + pdt.status].className} />
                        <span>{EnumCn.ProductState[pdt.status]}</span>
                    </Col>
                    <Col span="22" className="m-ta-r">
                        {this.props.$$layout.toJS().login_user.company_manager &&
                            <Button
                                type="ghost"
                                onClick={this.onClickEdit.bind(this)}>编辑</Button>
                        }
                    </Col>
                </Row>
                <Row className="m-margin-b">
                    <Col span="24">
                        <img className="m-img" src={pdt.image} />
                        <div className="m-tb">
                            <div className="m-tb-title"><a>{(pdt.cn_name || tools.emptyInfo) + "（" + (pdt.general_name || tools.emptyInfo) + "）"}</a></div>
                            <div className="m-tb-text">
                                英文名称：{pdt.en_name || tools.emptyInfo}
                            </div>
                            <div className="m-tb-text">
                                上市时间：{pdt.listing_time ? new hDate(pdt.listing_time).format(tools.dateFormat + " " + tools.timeFormat) : tools.emptyInfo}
                            </div>
                            <div className="m-tb-text">
                                产品类型：{EnumCn.DrugType[pdt.otc] || tools.emptyInfo}
                            </div>
                        </div>
                    </Col>
                </Row>
                <Row className="m-margin-b">
                    <Col span="24">
                        <div className="m-bgb">
                            <Icon type="money-o" className="m-ico green" />
                            <div className="m-tb">
                                <div className="m-tb-title">价格</div>
                                <div className="m-tb-text">￥{pdt.price ? pdt.price.toFixed(2) : '0.00'}/盒</div>
                            </div>
                        </div>
                        <div className="m-bgb">
                            <Icon type="medicine-o" className="m-ico blue" />
                            <div className="m-tb">
                                <div className="m-tb-title">医保信息</div>
                                <div className="m-tb-text">{EnumCn.InsuranceType[pdt.insurance_type] || tools.emptyInfo}</div>
                            </div>
                        </div>
                        <div className="m-bgb">
                            <Icon type="calendar-o" className="m-ico orange" />
                            <div className="m-tb">
                                <div className="m-tb-title">创建时间</div>
                                <div className="m-tb-text">{pdt.ctime ? new hDate(pdt.ctime).format(`${tools.dateFormat} hh:mm:ss`) : tools.emptyInfo}</div>
                            </div>
                        </div>
                    </Col>
                </Row>
                <Tabs defaultActiveKey="1">
                    <TabPane tab="药品说明" key="1">
                        <ul className="pd-info-list">
                            {function (p) {
                                const colorArr = ["orange", "red", "green", "blue"];
                                const timeline = [
                                    {
                                        title: "成分",
                                        description: p.ingredient
                                    }, {
                                        title: "治疗领域",
                                        description: p.adaptation
                                    }, {
                                        title: "用法用量",
                                        description: p.usage
                                    }, {
                                        title: "不良反应",
                                        description: p.reactions
                                    }, {
                                        title: "配方禁忌",
                                        description: p.taboos
                                    }, {
                                        title: "注意事项",
                                        description: p.matters
                                    }, {
                                        title: "药物分类",
                                        description: p.classification
                                    }];
                                return timeline.map((t, i) => (
                                    <li key={i}>
                                        <Icon type="sign" className={colorArr[i % colorArr.length]} />
                                        <div className="pd-item-title">{t.title || tools.emptyInfo}</div>
                                        <div className="pd-item-text">{t.description || tools.emptyInfo}</div>
                                    </li>
                                ))
                            } (pdt)}
                        </ul>
                    </TabPane>
                    {
                        // <TabPane tab="统计分析" key="2">
                        //     <_Chart_Trend
                        //         {...this.props} />
                        // </TabPane>
                    }
                </Tabs>
            </section>
        )
    }
    //点击【编辑】按钮
    onClickEdit() {
        let props = this.props;
        props.router.push({
            pathname: "/product/edit",
            query: props.location.query
        });
    }
}

//趋势图
class _Chart_Trend extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        let fieldProps = this._getFieldProps();
        let {$$productDetail} = this.props;
        let {summary} = $$productDetail.toJS();
        let axisXLength = Math.max.apply(Math, $.map(summary.trend_data, o => (o.data || []).length));

        //趋势
        let trendCfg = {
            grid: {
                left: "0%",
                right: "0%",
                bottom: "0%",
                top: "10%",
                containLabel: true
            },
            tooltip: {
                trigger: "axis"
            },
            xAxis: {
                splitLine: { show: false },
                data: (((summary.trend_data.filter(o => o.data.length === axisXLength).pop() || {}).data) || []).map(o => o.step)
            },
            yAxis: {
                minInterval: 1,
                axisLine: { show: false },
                splitLine: { lineStyle: { color: "rgb(230,230,230)" } }
            },
            series: summary.trend_data.map(o => {
                return {
                    name: o.name,
                    type: "line",
                    data: o.data.map(d => d.count)
                }
            }),
            legend: {
                orient: "horizontal",
                left: "left",
                top: 0,
                data: summary.trend_data.map(o => o.name)
            },
            color: tools.chartColor
        }
        //时间范围
        const rangeJSX = Object.getOwnPropertyNames(EnumCn.ChartTime)
            .filter(name => !isNaN(Number(name)))
            .map(key => <Option key={key} value={key}>{EnumCn.ChartTime[key]}</Option>);
        //数据类型
        const targetJSX = Object.getOwnPropertyNames(EnumCn.ChartTarget)
            .filter(name => !isNaN(Number(name)))
            .map(key => <Option key={key} value={key}>{EnumCn.ChartTarget[key]}</Option>);
        return (
            <Form>
                <Row className="m-margin-b">
                    <div className="m-stb">
                        <div className="m-tb-title">覆盖次数</div>
                        <div className="m-tb-text">{tools.getToThousands(summary.info.cover_count || 0)}</div>
                    </div>
                    <div className="m-stb">
                        <div className="m-tb-title">总花费</div>
                        <div className="m-tb-text">￥{tools.getToThousands(summary.info.cash || 0)}</div>
                    </div>
                    <div className="m-stb">
                        <div className="m-tb-title">覆盖用户数</div>
                        <div className="m-tb-text">{tools.getToThousands(summary.info.cover_user || 0)}</div>
                    </div>
                </Row>
                <Row className="m-margin-b">
                    <div className="m-stb">
                        <div className="m-tb-title">被引用的文档</div>
                        <div className="m-tb-text">{summary.info.relates_essay || 0}篇</div>
                    </div>
                    <div className="m-stb">
                        <div className="m-tb-title">被引用的问卷</div>
                        <div className="m-tb-text">{summary.info.relates_qa || 0}项</div>
                    </div>
                    <div className="m-stb">
                        <div className="m-tb-title">被引用的视频（直播/点播）</div>
                        <div className="m-tb-text">{(Number(summary.info.relates_vod) + Number(summary.info.relates_lvb)) || 0}例</div>
                    </div>
                </Row>
                <Row className="chart-box">
                    <div className="chart-cdt">
                        <div>趋势图</div>
                        <Select
                            placeholder="请选择"
                            style={{ width: 170 }}
                            className="m-margin-r"
                            {...fieldProps.trend_range}>{rangeJSX}</Select>
                        <Select
                            mode='multiple'
                            placeholder="请选择"
                            style={{ width: 400 }}
                            {...fieldProps.trend_type}>{targetJSX}</Select>
                    </div>
                    <Chart {...trendCfg} />
                </Row>
            </Form>
        )
    }
    //获取字段属性
    _getFieldProps() {
        let {form, $$productDetail, $$layout} = this.props;
        let summary = $$productDetail.toJS().summary;
        let loginUser = $$layout.toJS().login_user;
        return {
            //趋势时间范围
            trend_range: form.getFieldProps("trend_range", {
                initialValue: summary.trend_condition.range,
                onChange: (range) => {
                    let fields = form.getFieldsValue();
                    let {pdtActs, location} = this.props;
                    //趋势图接口，待对接
                    pdtActs.getTrend({
                        company_id: loginUser.company_id,
                        product_id: location.query.productId,
                        range: range,
                        type: fields.trend_type
                    })
                }
            }),
            //趋势折线类型
            trend_type: form.getFieldProps("trend_type", {
                initialValue: summary.trend_condition.type,
                onChange: (type) => {
                    let fields = form.getFieldsValue();
                    let {pdtActs, location} = this.props;
                    //趋势图接口，待对接
                    pdtActs.getTrend({
                        company_id: loginUser.company_id,
                        product_id: location.query.productId,
                        type: type,
                        range: fields.trend_range
                    })
                }
            })
        }
    }
}

_Chart_Trend = Form.create()(_Chart_Trend);

export default connect(
    (state) => {
        return {
            $$productDetail: state.$$productDetail,
            $$layout: state.$$layout
        }
    },
    (dispatch) => {
        return {
            pdtActs: bindActionCreators(Actions, dispatch)
        }
    }
)(withRouter(ProductDetail))
