import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/product"
import { Enum, EnumCn } from "enum"
import { tools } from "utils"
import SearchBar from "components/searchBar"
import Icon from "antd/lib/icon"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import Table from "antd/lib/table"
const InputGroup = Input.Group
const ButtonGrup = Button.Group

class ProductList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            pageReload: tools.getLocationRandom(),
        }
    }
    componentDidMount() {
        this._pageReloadInit()
    }
    componentWillReceiveProps(nextProps) {
        if (this.state.pageReload !== tools.getLocationRandom()) {
            this._pageReloadInit()
            this.refs.searchBar.clear()
        }
    }
    _pageReloadInit() {
        let {pdtActs} = this.props;
        pdtActs.reset();
        pdtActs.getProductList();
        this.setState({
            pageReload: tools.getLocationRandom(),
        })
    }
    render() {
        let {products, conditions, checkedPdts} = this.props.$$productList.toJS();
        let cfg = {
            dataSource: products.data,
            rowKey: r => r.id,
            columns: [
                {
                    title: "产品名",
                    width: "30%",
                    dataIndex: "cn_name",
                    key: "cn_name",
                    render: (text, r) => <Link to={{ pathname: "/product/detail", query: { productId: r.id } }} >{text}</Link>
                }, {
                    title: "通用名",
                    dataIndex: "general_name",
                    width: "35%",
                    key: "general_name"
                }, {
                    title: "创建时间",
                    width: "18%",
                    dataIndex: "ctime",
                    key: "ctime",
                    sorter: true,
                    render: (val) => new hDate(val).format(`${tools.dateFormat} hh:mm:ss`)
                }, {
                    title: "状态",
                    width: "10%",
                    dataIndex: "status",
                    key: "status",
                    sorter: true,
                    render: (text) => {
                        let iconMap = {
                            state_0: { icon: "cross-circle", className: "m-text-error" },
                            state_1: { icon: "check-circle", className: "m-text-success" }
                        }
                        return (
                            <div>
                                <Icon
                                    type={iconMap["state_" + text].icon}
                                    className={"m-margin-r " + iconMap["state_" + text].className} />
                                <span>{EnumCn.ProductState[text]}</span>
                            </div>
                        );
                    }
                }
            ],
            // bordered: true,
            onChange: (page, filter, sort) => {
                let {pdtActs} = this.props;
                pdtActs.getProductList({
                    page: page.current,
                    count: page.pageSize,
                    order: sort.field,
                    order_type: typeof sort.order === "string" ? sort.order.replace("end", "") : undefined
                });
            },
            pagination: $.extend(true, {}, tools.config.pagination, {
                current: conditions.page,
                pageSize: conditions.count,
                total: products.total
            }),
            rowSelection: {
                selectedRowKeys: checkedPdts,
                onChange: (selectedRowKeys, selectedRows) => {
                    let {pdtActs} = this.props;
                    pdtActs.setCheckedPdts(selectedRowKeys);
                }
            }
        }
        return (
            <section>
                <div className="m-margin-b">产品列表</div>
                <Row className="m-margin-b">
                    <Col span="18">
                        {this.props.$$layout.toJS().login_user.company_manager &&
                            <div>
                                <Button
                                    type="primary"
                                    size="large"
                                    className="m-margin-r"
                                    onClick={function () { this.props.router.push({ pathname: '/product/edit' }) }.bind(this)}>新增</Button>
                                <ButtonGrup size="large">
                                    <Button type="ghost" disabled={checkedPdts.length === 0} onClick={this.onClickEnable.bind(this)}>启用</Button>
                                    <Button type="ghost" disabled={checkedPdts.length === 0} onClick={this.onClickDisable.bind(this)}>禁用</Button>
                                    <Button type="ghost" disabled={checkedPdts.length === 0} onClick={this.onClickDelete.bind(this)}>删除</Button>
                                </ButtonGrup>
                            </div>}
                    </Col>

                    <Col span="6">
                        <SearchBar
                            ref='searchBar'
                            onSearch={this.onClickSearch.bind(this)}></SearchBar>
                    </Col>
                </Row>

                <Row>
                    <Col span="24">
                        <Table {...cfg} />
                    </Col>
                </Row>
            </section>
        );
    }
    //点击【搜索】按钮
    onClickSearch(keyword) {
        let {pdtActs} = this.props;
        pdtActs.getProductList({
            key: { title: keyword },
            page: 1
        });
    }
    //点击【启用】按钮
    onClickEnable() {
        let {pdtActs, $$productList} = this.props;
        let checkedPdts = $$productList.toJS().checkedPdts;
        pdtActs.changePdtsState(checkedPdts, Enum.ProductState.enable);
    }
    //点击【禁用】按钮
    onClickDisable() {
        let {pdtActs, $$productList} = this.props;
        let checkedPdts = $$productList.toJS().checkedPdts;
        tools.showDialog.confirm("禁用后，对现有已关联的推广内容无影响，但新建推广时将无法关联该产品，请确认是否禁用？", () => {
            pdtActs.changePdtsState(checkedPdts, Enum.ProductState.disable);
        })
    }
    //点击【删除】按钮
    onClickDelete() {
        let {pdtActs, $$productList} = this.props;
        let checkedPdts = $$productList.toJS().checkedPdts;
        tools.showDialog.confirm("确定删除选中的产品？", () => {
            pdtActs.deletePdts(checkedPdts);
        }, () => {
            pdtActs.setCheckedPdts([]);
        })
    }
}


export default connect(
    (state) => {
        return {
            $$productList: state.$$productList,
            $$layout: state.$$layout
        }
    },
    (dispatch) => {
        return {
            pdtActs: bindActionCreators(Actions, dispatch)
        }
    })(withRouter(ProductList))
