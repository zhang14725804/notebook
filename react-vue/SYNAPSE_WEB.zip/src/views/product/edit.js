import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/product"
import { Enum, EnumCn } from "enum"
import { tools } from "utils"
import Upload from "components/upload"
import moment from 'moment';
// import {Row, Col, Form, Input, Select, DatePicker, Button, Checkbox } from "assets/lib/antd"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Select from "antd/lib/select"
import DatePicker from "antd/lib/date-picker"
import Button from "antd/lib/button"
import Checkbox from "antd/lib/checkbox"
import message from "antd/lib/message"
const FormItem = Form.Item
const Option = Select.Option


class ProductEdit extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            query: props.location.query,
            isEdit: !!props.location.query.productId
        }
    }
    componentDidMount() {
        let { pdtActs } = this.props;
        let productId = this.state.query.productId;
        pdtActs.reset();
        if (this.state.isEdit) {
            //获取产品详情
            pdtActs.getPdt(productId, true);
        }
    }
    render() {
        let { form } = this.props;
        let fieldProps = this._getFieldProps();
        const formItemLayout = {
            labelCol: { span: 5 },
            wrapperCol: { span: 16 }
        };
        //上传文件配置
        let uploadCfg = {
            url: tools.javaApi("/uploadpic"),
            previewUrl: form.getFieldsValue().image,
            onSuccess: (data) => {
                message.success("上传成功");
                this.props.form.setFieldsValue({
                    image: data.imageurl
                })
            },
            onErrorMessage: (error) => {
                tools.showDialog.error(error);
            }
        }
        //时间范围
        const optJSX = Object.getOwnPropertyNames(EnumCn.InsuranceType)
            .filter(name => !isNaN(Number(name)))
            .map(key => <Option key={key} value={key}>{EnumCn.InsuranceType[key]}</Option>);
        //数据类型
        const drugTypeJSX = Object.getOwnPropertyNames(EnumCn.DrugType)
            .filter(name => !isNaN(Number(name)))
            .map(key => <Option key={key} value={key}>{EnumCn.DrugType[key]}</Option>);
        return (
            <section>
                <Form>
                    <Row className="m-margin-b m-edit-header">
                        <Col span="18">
                            <Col span="5" className="m-edit-title">{this.state.isEdit ? "编辑产品" : "新增产品"}</Col>
                            <Col span="16">
                                {fieldProps.status(<Checkbox>启用</Checkbox>)}
                            </Col>
                        </Col>
                    </Row>

                    <Row style={{ "paddingLeft": "20px" }}>
                        <Col span="18">
                            <FormItem {...formItemLayout} label="产品名称：">
                                {fieldProps.cn_name(
                                    <Input
                                        type="text"
                                        placeholder="请输入内容" />
                                )}
                            </FormItem>
                            <FormItem {...formItemLayout} label="英文名称：">
                                {fieldProps.en_name(
                                    <Input
                                        type="text"
                                        placeholder="请输入内容" />
                                )}
                            </FormItem>
                            <FormItem {...formItemLayout} label="通用名：">
                                {fieldProps.general_name(
                                    <Input
                                        type="text"
                                        placeholder="请输入内容" />
                                )}
                            </FormItem>
                            <FormItem {...formItemLayout} label="价格：">
                                {fieldProps.price(
                                    <Input
                                        type="text"
                                        addonAfter="/ 盒"
                                        placeholder="请输入内容"
                                        style={{ width: "100%" }} />
                                )}
                            </FormItem>
                            <FormItem {...formItemLayout} label="医保类型：">
                                {fieldProps.insurance_type(
                                    <Select
                                        placeholder="请选择">
                                        {optJSX}
                                    </Select>
                                )}
                            </FormItem>
                            <FormItem {...formItemLayout} label="上市时间：">
                                {fieldProps.listing_time(
                                    <DatePicker style={{ width: "100%" }} format={'YYYY-MM-DD'}/>
                                )}
                            </FormItem>
                            <FormItem {...formItemLayout} label="产品类型：">
                                {fieldProps.otc(
                                    <Select
                                        placeholder="请选择">
                                        {drugTypeJSX}
                                    </Select>
                                )}
                            </FormItem>
                            <FormItem {...formItemLayout} label="成分：">
                                {fieldProps.ingredient(
                                    <Input.TextArea
                                        placeholder="请输入内容" />
                                )}
                            </FormItem>
                            <FormItem {...formItemLayout} label="治疗领域：">
                                {fieldProps.adaptation(
                                    <Input.TextArea
                                        placeholder="请输入内容" />
                                )}
                            </FormItem>
                            <FormItem {...formItemLayout} label="用法用量：">
                                {fieldProps.usage(
                                    <Input.TextArea
                                        placeholder="请输入内容" />
                                )}
                            </FormItem>
                            <FormItem {...formItemLayout} label="不良反应：">
                                {fieldProps.reactions(
                                    <Input.TextArea
                                        placeholder="请输入内容" />
                                )}
                            </FormItem>
                            <FormItem {...formItemLayout} label="配方禁忌：">
                                {fieldProps.taboos(
                                    <Input.TextArea
                                        placeholder="请输入内容" />
                                )}
                            </FormItem>
                            <FormItem {...formItemLayout} label="注意事项：">
                                {fieldProps.matters(
                                    <Input.TextArea
                                        placeholder="请输入内容" />
                                )}
                            </FormItem>
                            <FormItem {...formItemLayout} label="药物分类：">
                                {fieldProps.classification(
                                    <Input.TextArea
                                        placeholder="请输入内容" />
                                )}
                            </FormItem>
                        </Col>
                        <Col span="6" >
                            <FormItem
                                {...formItemLayout}>
                                <div className="ant-form-item-required">上传图片</div>
                                {fieldProps.image(
                                    <Upload
                                    {...uploadCfg}/>
                                )}
                            </FormItem>
                        </Col>
                    </Row>
                </Form >
                <div className="m-handle-btn">
                    <div className="wrap">
                        <Button type="primary" onClick={this.onClickSave.bind(this)}>保存</Button>
                    </div>
                </div>
            </section>
        );
    }
    //点击保存按钮
    onClickSave() {
        this.props.form.validateFieldsAndScroll((errors, values) => {
            if (!!errors) return;
            const { pdtActs } = this.props;
            const { isEdit, query } = this.state;
            pdtActs.savePdt($.extend(true, {}, values, isEdit ? { product_id: query.productId } : {}), isEdit);
        });
    }
    //设置字段属性
    _getFieldProps() {
        const { getFieldDecorator } = this.props.form;
        const { pdtActs, $$productEdit } = this.props;
        const { product } = $$productEdit.toJS();
        return {
            //状态
            status: getFieldDecorator("status", {
                initialValue: product.status == Enum.ProductState.enable,
                valuePropName: "checked"
            }),
            //产品名称
            cn_name: getFieldDecorator("cn_name", {
                initialValue: product.cn_name,
                rules: [
                    { required: true, message: "请填写产品名称" },
                    { max: 50, message: "产品名称不得超过50个字符" }
                ]
            }),
            //英文名称
            en_name: getFieldDecorator("en_name", {
                initialValue: product.en_name,
                rules: [
                    { max: 151, message: "英文名称不得超过150个字符" }
                ]
            }),
            //通用名
            general_name: getFieldDecorator("general_name", {
                initialValue: product.general_name,
                rules: [
                    { required: true, message: "请填写通用名" },
                    { max: 50, message: "通用名不得超过50个字符" }
                ]
            }),
            //价格
            price: getFieldDecorator("price", {
                initialValue: product.price
            }),
            //医保类型
            insurance_type: getFieldDecorator("insurance_type", {
                initialValue: Number(product.insurance_type) + "",
                rules: [
                    { required: true, message: "请选择医保类型" }
                ]
            }),
            //上市时间
            listing_time: getFieldDecorator("listing_time", {
                initialValue: product.listing_time == null ? null : moment(product.listing_time),
                rules: [
                    { required: true, message: "请选择上市时间"}
                ]
            }),
            //产品类型
            otc: getFieldDecorator("otc", {
                initialValue: product.otc.toString() + "",
                rules: [
                    { required: true, message: "请选择产品类型" }
                ]
            }),
            //成分
            ingredient: getFieldDecorator("ingredient", {
                initialValue: product.ingredient,
                // rules: [
                //     { max: 2000, message: "成分不得超过2000个字符" }
                // ]
            }),
            //治疗领域
            adaptation: getFieldDecorator("adaptation", {
                initialValue: product.adaptation,
                // rules: [
                //     { max: 2000, message: "治疗领域不得超过2000个字符" }
                // ]
            }),
            //用法用量
            usage: getFieldDecorator("usage", {
                initialValue: product.usage,
                // rules: [
                //     { max: 2000, message: "用法用量不得超过2000个字符" }
                // ]
            }),
            //不良反应
            reactions: getFieldDecorator("reactions", {
                initialValue: product.reactions,
                // rules: [
                //     { max: 2000, message: "不良反应不得超过2000个字符" }
                // ]
            }),
            //配方禁忌
            taboos: getFieldDecorator("taboos", {
                initialValue: product.taboos,
                // rules: [
                //     { max: 2000, message: "配方禁忌不得超过2000个字符" }
                // ]
            }),
            //注意事项
            matters: getFieldDecorator("matters", {
                initialValue: product.matters,
                // rules: [
                //     { max: 2000, message: "注意事项不得超过2000个字符" }
                // ]
            }),
            //药品分类
            classification: getFieldDecorator("classification", {
                initialValue: product.classification,
                // rules: [
                //     { max: 2000, message: "药品分类不得超过2000个字符" }
                // ]
            }),
            //图片
            image: getFieldDecorator("image", {
                initialValue: product.image,
                rules: [
                    {
                        validator: (rule, value, cb) => {
                            let url = this.props.form.getFieldsValue().image;
                            url == null || url.length === 0 ? cb("请上传图片") : cb();
                        }
                    }
                ]
            })
        }
    }

    //获取输入项字数
    _getCharCount(fieldName, maxLength) {
        let { getFieldValue } = this.props.form;
        let curLength = getFieldValue(fieldName).length;
        const style = {
            position: "absolute",
            right: 0,
            bottom: "-28px"
        }
        return (
            <div style={{ position: "relative" }}>
                <div style={style}>
                    <span className={curLength > maxLength ? "m-text-error" : ""}>{curLength}</span>
                    <span>/{maxLength}</span>
                </div>
            </div>
        )
    }
}


ProductEdit = Form.create()(ProductEdit);



export default connect(
    (state) => {
        return {
            $$productEdit: state.$$productEdit
        }
    },
    (dispatch) => {
        return {
            pdtActs: bindActionCreators(Actions, dispatch)
        }
    }
)(ProductEdit)
