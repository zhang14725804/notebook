import Immutable from "immutable"
import $ from "jquery"
import React from "react"
import ReactDOM from "react-dom"
import { Link, withRouter } from "react-router"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/ta"
import { Enum, EnumCn } from "enum"
import { tools } from "utils"
import SearchBar from "components/searchBar"
import TAEdit from "./edit"
// import {Icon, Row, Col, Input, Button, Table} from "assets/lib/antd"
import Icon from "antd/lib/icon"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import Table from "antd/lib/table"
const ButtonGrup = Button.Group


class TAList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            pageReload: tools.getLocationRandom(),
            isShow: false
        }
    }
    componentDidMount() {
        this._pageReloadInit()
    }
    componentWillReceiveProps(nextProps) {
        if (this.state.pageReload !== tools.getLocationRandom()) {
            this._pageReloadInit()
            this.refs.searchBar.clear()
        }
    }
    _pageReloadInit() {
        let {taActs} = this.props;
        taActs.reset();
        taActs.getTAList();
        this.setState({
            pageReload: tools.getLocationRandom(),
        })
    }
    render() {
        let {tas, checkedTAs, conditions} = this.props.$$taList.toJS();
        let cfg = {
            dataSource: tas.data,
            rowKey: (r) => r.id,
            columns: [
                {
                    title: "治疗领域",
                    dataIndex: "name",
                    width: "65%",
                    key: "name",
                    render: (text, r) => <Link to={{ pathname: "/ta/detail", query: { taId: r.id } }} >{text}</Link>
                }, {
                    title: "创建时间",
                    width: "18%",
                    dataIndex: "ctime",
                    key: "ctime",
                    sorter: true,
                    render: val => new hDate(val).format(`${tools.dateFormat} hh:mm:ss`)
                }, {
                    title: "状态",
                    width: "10%",
                    dataIndex: "status",
                    key: "status",
                    sorter: true,
                    render: (text) => {
                        let iconMap = {
                            state_0: { icon: "cross-circle", className: "m-text-error" },
                            state_1: { icon: "check-circle", className: "m-text-success" }
                        }
                        return (
                            <div>
                                <Icon
                                    type={iconMap["state_" + text].icon}
                                    className={"m-margin-r " + iconMap["state_" + text].className} />
                                <span>{EnumCn.TAState[text]}</span>
                            </div>
                        );
                    }
                }
            ],
            // bordered: true,
            onChange: (page, filter, sort) => {
                let {taActs} = this.props;
                taActs.getTAList({
                    page: page.current,
                    count: page.pageSize,
                    order: sort.field,
                    order_type: typeof sort.order === "string" ? sort.order.replace("end", "") : undefined
                });
            },

            pagination: $.extend(true, {}, tools.config.pagination, {
                current: conditions.page,
                pageSize: conditions.count,
                total: tas.total
            }),
            rowSelection: {
                selectedRowKeys: checkedTAs,
                onChange: (selectedRowKeys, selectedRows) => {
                    let {taActs} = this.props;
                    taActs.setCheckedTAs(selectedRowKeys);
                }
            }
        }
        return (
            <section>
                <div className="m-margin-b">治疗领域列表</div>
                <Row className="m-margin-b">
                    <Col span="18">
                        {this.props.$$layout.toJS().login_user.company_manager &&
                            <div>
                                <Button
                                    type="primary"
                                    size="large"
                                    className="m-margin-r"
                                    onClick={this.onClickAdd.bind(this)}>新增
                        </Button>
                                <ButtonGrup size="large">
                                    <Button type="ghost" disabled={checkedTAs.length === 0} onClick={this.onClickEnable.bind(this)}>启用</Button>
                                    <Button type="ghost" disabled={checkedTAs.length === 0} onClick={this.onClickDisable.bind(this)}>禁用</Button>
                                    <Button type="ghost" disabled={checkedTAs.length === 0} onClick={this.onClickDelete.bind(this)}>删除</Button>
                                </ButtonGrup>
                            </div>}
                    </Col>
                    <Col span="6">
                        <SearchBar
                            ref='searchBar'
                            onSearch={this.onClickSearch.bind(this)}></SearchBar>
                    </Col>
                </Row>

                <Row>
                    <Col span="24">
                        <Table {...cfg} />
                    </Col>
                </Row>
                <TAEdit
                    {...this.props}
                    title="新增治疗领域"
                    visible={this.state.isShow}
                    onOk={this.onClickSave.bind(this)}
                    onCancel={this.onClickClose.bind(this)} />
            </section>
        );
    }
    //点击【搜索】按钮
    onClickSearch(keyword) {
        let {taActs} = this.props;
        taActs.getTAList({
            key: { title: keyword },
            page: 1
        });
    }
    //点击【启用】按钮
    onClickEnable() {
        let {taActs, $$taList} = this.props;
        let {checkedTAs} = $$taList.toJS();
        taActs.changeTAsState(checkedTAs, Enum.TAState.enable);
    }
    //点击【禁用】按钮
    onClickDisable() {
        let {taActs, $$taList} = this.props;
        let {checkedTAs} = $$taList.toJS();
        tools.showDialog.confirm("禁用后，对现有已关联的推广内容无影响，但新建推广时将无法关联该治疗领域，请确认是否禁用？", () => {
            taActs.changeTAsState(checkedTAs, Enum.TAState.disable);
        })
    }
    //点击【删除】按钮
    onClickDelete() {
        let {taActs, $$taList} = this.props;
        let {checkedTAs} = $$taList.toJS();
        tools.showDialog.confirm("确定删除选中的治疗领域？", () => {
            taActs.deleteTAs(checkedTAs);
        }, () => {
            taActs.setCheckedTAs([])
        })
    }
    //点击【新增】按钮
    onClickAdd() {
        this._openWindow();
    }
    //点击弹窗【保存】按钮
    onClickSave(fields) {
        let {taActs} = this.props;
        taActs.saveTA(fields);
        this._closeWindow();
    }
    //点击弹窗【关闭/取消】按钮
    onClickClose() {
        this._closeWindow()
    }
    //打开弹窗
    _openWindow() {
        this.setState({
            isShow: true
        });
    }
    //关闭弹窗
    _closeWindow() {
        this.setState({
            isShow: false
        });
    }
}

export default connect(
    (state) => {
        return {
            $$taList: state.$$taList,
            $$taEdit: state.$$taEdit,
            $$layout: state.$$layout
        }
    },
    (dispatch) => {
        return {
            taActs: bindActionCreators(Actions, dispatch)
        }
    })(withRouter(TAList))
