import React from "react"
import ReactDON from "react-dom"
import $ from "jquery"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import * as Actions from "actions/ta"
// import {Row, Col, Input, Button, Form, Modal} from "assets/lib/antd"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import Form from "antd/lib/form"
import Modal from "antd/lib/modal"
const InputGroup = Input.Group
const FormItem = Form.Item

class TAEdit extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            query: props.location.query,
            isEdit: !!props.location.query.taId
        };
    }
    render() {
        const formItemLayout = {
            labelCol: { span: 5 },
            wrapperCol: { span: 19 },
        };
        let fieldProps = this._getFieldProps();
        return (
            <Modal
                title={this.props.title}
                visible={this.props.visible}
                onOk={this.onClickSave.bind(this)}
                onCancel={this.onClickCancel.bind(this)}>
                <Form>
                    <FormItem {...formItemLayout} label="治疗领域名称：">
                        {fieldProps.name(
                            <Input
                                type="text"
                                placeholder="请输入内容" />
                        )}
                    </FormItem>
                    <FormItem {...formItemLayout} label="描述：">
                        {fieldProps.description(
                            <Input.TextArea
                                placeholder="请输入内容" />
                        )}
                    </FormItem>
                </Form >
            </Modal>
        );
    }
    //点击确定按钮，将获取的值传给父级
    onClickSave() {
        const { form, onOk } = this.props;
        form.validateFields((errors, values) => {
            if (!!errors) return;
            if (typeof onOk === "function") {
                onOk.call(this, values);
                form.resetFields();
            }
        });
    }
    onClickCancel() {
        const { form, onCancel } = this.props;
        if (typeof onCancel === "function") {
            form.resetFields();
            onCancel.call(this);
        }
    }
    //获取表单属性
    _getFieldProps() {
        const { getFieldDecorator } = this.props.form;
        const { ta } = this.props.$$taEdit.toJS();
        return {
            //名称
            name: getFieldDecorator("name", {
                initialValue: ta.name,
                rules: [
                    { required: true, message: "请填写治疗领域名称" },
                    { max: 50, message: "名称不得超过50个字符" }
                ]
            }),
            //描述
            description: getFieldDecorator("description", {
                initialValue: ta.description,
                rules: [
                    { max: 150, message: "描述不得超过150个字符" }
                ]
            })
        }
    }
}

TAEdit = Form.create()(TAEdit);

export default connect(
    (state) => {
        return {
            $$taEdit: state.$$taEdit
        }
    },
    (dispatch) => {
        return {
            taActs: bindActionCreators(Actions, dispatch)
        }
    }
)(TAEdit)
