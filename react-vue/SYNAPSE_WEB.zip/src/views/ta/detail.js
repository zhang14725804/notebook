import $ from "jquery"
import Immutable from "immutable"
import React from "react"
import ReactDON from "react-dom"
import { connect } from "react-redux"
import { bindActionCreators } from "redux"
import { Link, withRouter } from "react-router"
import { tools } from "utils"
import { Enum, EnumCn } from "enum"
import * as Actions from "actions/ta"
import TAEdit from "./edit"
import Chart from "components/chart"
// import {Row, Col, Icon, Button, Tabs, Table, Form, Select} from "assets/lib/antd"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Icon from "antd/lib/icon"
import Button from "antd/lib/button"
import Tabs from "antd/lib/tabs"
import Table from "antd/lib/table"
import Form from "antd/lib/form"
import Select from "antd/lib/select"
const TabPane = Tabs.TabPane;
const Option = Select.Option

class TADetail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isShow: false,
            query: props.location.query
        }
    }
    componentDidMount() {
        let {$$layout, taActs} = this.props;
        let loginUser = $$layout.toJS().login_user;
        let taId = this.state.query.taId;
        taActs.reset();
        taActs.getTA(taId);
        taActs.getReferByTA({
            ta_id: taId,
            page: 1,
            count: tools.listPageSize
        });
        //数据统计相关接口，待对接
        // taActs.getOverView({
        //     company_id: loginUser.company_id,
        //     ta_id: taId
        // });
        // taActs.getTrend({
        //     company_id: loginUser.company_id,
        //     ta_id: taId,
        //     range: Enum.ChartTime.today,
        //     type: [Enum.ChartTarget.pv]
        // });
    }
    render() {
        let {ta, infoList, conditions} = this.props.$$taDetail.toJS();
        let cfg = {
            dataSource: infoList.data,
            rowKey: (r) => { return `${(r || {}).type}_${(r.data || {}).id}` },
            columns: [
                {
                    title: "引用本治疗领域文档",
                    width: "70%",
                    dataIndex: "data",
                    key: "data",
                    render: (text, r) => <Link to={{ pathname: "/ta/detail", query: { taId: r.id } }} >{text.title}</Link>
                }, {
                    title: "分类",
                    width: "15%",
                    dataIndex: "type",
                    key: "type",
                    render: text => <span>{EnumCn.DocumentType[text]}</span>
                }, {
                    title: "状态",
                    width: "15%",
                    dataIndex: "status",
                    key: "status",
                    render: (text, r) => {
                        let status = r.data.status;
                        if (!status.toString()) return;
                        let iconMap = {
                            state_0: { icon: "cross-circle", className: "m-text-error" },
                            state_1: { icon: "check-circle", className: "m-text-success" },
                            state_2: { icon: "minus-circle", className: "m-text-minor" },
                            state_3: { icon: "question-circle", className: "m-text-warning" }
                        }
                        let map = iconMap["state_" + status] || {};
                        return (
                            <div>
                                <Icon
                                    type={map.icon}
                                    className={map.className} />
                                <span>{EnumCn.NewsState[status]}</span>
                            </div>
                        )
                    }
                }
            ],
            // bordered: true,
            pagination: $.extend(true, {}, tools.config.pagination, {
                current: conditions.page,
                pageSize: conditions.count,
                total: infoList.total
            }),
            onChange: (page, filter, sort) => {
                let {taActs} = this.props;
                taActs.getReferByTA({
                    ta_id: this.state.query.taId,
                    page: page.current,
                    count: page.pageSize
                });
            }

        }
        let iconMap = {
            state_0: { icon: "cross-circle", className: "m-text-error" },
            state_1: { icon: "check-circle", className: "m-text-success" }
        }
        return (
            <section>
                <Row className="m-margin-b">
                    <Col span="4">
                        <Icon
                            type={iconMap["state_" + ta.status].icon}
                            className={"m-margin-r " + iconMap["state_" + ta.status].className} />
                        <span>{EnumCn.ProductState[ta.status]}</span>
                    </Col>
                    <Col span="20" className="m-ta-r">
                        {this.props.$$layout.toJS().login_user.company_manager &&
                            <Button
                                type="ghost"
                                onClick={this.onClickEdit.bind(this)}>编辑</Button>}
                    </Col>
                </Row>
                <Row className="m-margin-b">
                    <Col span="24">
                        <div className="m-tb">
                            <div className="m-tb-title"><a>{ta.name || tools.emptyInfo}</a></div>
                            <div className="m-tb-text">
                                描述：{ta.description || tools.emptyInfo}
                            </div>
                        </div>
                    </Col>

                </Row>
                <Row className="m-margin-b">
                    <Col span="24">
                        <div className="m-bgb">
                            <Icon type="pencil-o" className="m-ico red" />
                            <div className="m-tb">
                                <div className="m-tb-title">创建人</div>
                                <div className="m-tb-text">{ta.create_user.nickname || tools.emptyInfo}</div>
                            </div>
                        </div>
                        <div className="m-bgb">
                            <Icon type="tip-o" className="m-ico blue" />
                            <div className="m-tb">
                                <div className="m-tb-title">被引用的资源</div>
                                <div className="m-tb-text">{infoList.total || 0}个</div>
                            </div>
                        </div>
                        <div className="m-bgb">
                            <Icon type="calendar-o" className="m-ico orange" />
                            <div className="m-tb">
                                <div className="m-tb-title">创建时间</div>
                                <div className="m-tb-text">{ta.ctime ? new hDate(ta.ctime).format(`${tools.dateFormat} hh:mm:ss`) : tools.emptyInfo}</div>
                            </div>
                        </div>
                    </Col>
                </Row>
                <Tabs defaultActiveKey="1">
                    <TabPane tab="引用详情" key="1">
                        <Table {...cfg} />
                    </TabPane>
                    {
                        // <TabPane tab="统计分析" key="2">
                        //     <_Chart_Trend
                        //         {...this.props} />
                        // </TabPane>
                    }
                </Tabs>
                <TAEdit
                    {...this.props}
                    title="编辑治疗领域"
                    visible={this.state.isShow}
                    onOk={this.onClickSave.bind(this)}
                    onCancel={this.onClickClose.bind(this)} />
            </section>
        );
    }
    //点击治疗领域【编辑】按钮
    onClickEdit() {
        //将详情页信息赋值给编辑页
        const {taActs} = this.props;
        const {query} = this.state;
        taActs.getTA(query.taId, true).done(() => {
            this._openWindow();
        })
    }
    //点击弹窗【保存】按钮
    onClickSave(fields) {
        let {taActs} = this.props;
        let taId = this.state.query.taId;
        taActs.saveTA($.extend(true, {}, fields, {
            ta_id: taId
        }), true);
        this._closeWindow();
    }
    //点击弹窗【取消/关闭】按钮
    onClickClose() {
        let {taActs} = this.props;
        //taActs.resetEdit();
        this._closeWindow()
    }
    //打开弹窗
    _openWindow() {
        this.setState({
            isShow: true
        });
    }
    //关闭弹窗
    _closeWindow() {
        this.setState({
            isShow: false
        });
    }
}


//趋势图
class _Chart_Trend extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        let fieldProps = this._getFieldProps();
        let {summary} = this.props.$$taDetail.toJS();
        let axisXLength = Math.max.apply(Math, summary.trend_data.map(o => (o.data || []).length));

        //趋势
        let trendCfg = {
            grid: {
                left: "0%",
                right: "0%",
                bottom: "0%",
                top: "10%",
                containLabel: true
            },
            tooltip: {
                trigger: "axis"
            },
            xAxis: {
                splitLine: { show: false },
                data: (((summary.trend_data.filter(o => o.data.length === axisXLength).pop() || {}).data) || []).map(o => o.step)
            },
            yAxis: {
                minInterval: 1,
                axisLine: { show: false },
                splitLine: { lineStyle: { color: "rgb(230,230,230)" } }
            },
            series: summary.trend_data.map(o => {
                return {
                    name: o.name,
                    type: "line",
                    data: o.data.map(d => d.count)
                }
            }),
            legend: {
                orient: "horizontal",
                left: "left",
                top: 0,
                data: summary.trend_data.map(o => o.name)
            },
            color: tools.chartColor
        }
        //时间范围
        const rangeJSX = Object.getOwnPropertyNames(EnumCn.ChartTime)
            .filter(name => !isNaN(Number(name)))
            .map(key => <Option key={key} value={key}>{EnumCn.ChartTime[key]}</Option>);
        //数据类型
        const targetJSX = Object.getOwnPropertyNames(EnumCn.ChartTarget)
            .filter(name => !isNaN(Number(name)))
            .map(key => <Option key={key} value={key}>{EnumCn.ChartTarget[key]}</Option>);
        return (
            <Form>
                <Row className="m-margin-b">
                    <div className="m-stb">
                        <div className="m-tb-title">覆盖次数</div>
                        <div className="m-tb-text">{tools.getToThousands(summary.info.cover_count || 0)}</div>
                    </div>
                    <div className="m-stb">
                        <div className="m-tb-title">总花费</div>
                        <div className="m-tb-text">￥{tools.getToThousands(summary.info.cash || 0)}</div>
                    </div>
                    <div className="m-stb">
                        <div className="m-tb-title">覆盖用户数</div>
                        <div className="m-tb-text">{tools.getToThousands(summary.info.cover_user || 0)}</div>
                    </div>
                </Row>
                <Row className="m-margin-b">
                    <div className="m-stb">
                        <div className="m-tb-title">被引用的文档</div>
                        <div className="m-tb-text">{summary.info.relates_essay || 0}篇</div>
                    </div>
                    <div className="m-stb">
                        <div className="m-tb-title">被引用的问卷</div>
                        <div className="m-tb-text">{summary.info.relates_qa || 0}项</div>
                    </div>
                    <div className="m-stb">
                        <div className="m-tb-title">被引用的视频（直播/点播）</div>
                        <div className="m-tb-text">{(Number(summary.info.relates_vod) + Number(summary.info.relates_lvb)) || 0}例</div>
                    </div>
                </Row>
                <Row className="chart-box">
                    <div className="chart-cdt">
                        <div>趋势图</div>
                        <Select
                            placeholder="请选择"
                            style={{ width: 170 }}
                            className="m-margin-r"
                            {...fieldProps.trend_range}>{rangeJSX}</Select>
                        <Select
                            mode='multiple'
                            placeholder="请选择"
                            style={{ width: 400 }}
                            {...fieldProps.trend_type}>{targetJSX}</Select>
                    </div>
                    <Chart {...trendCfg} />
                </Row>
            </Form>
        )
    }
    //获取字段属性
    _getFieldProps() {
        let {form, $$taDetail, $$layout} = this.props;
        let {summary} = $$taDetail.toJS();
        let loginUser = $$layout.toJS().login_user;
        return {
            //趋势时间范围
            trend_range: form.getFieldProps("trend_range", {
                initialValue: summary.trend_condition.range,
                onChange: (range) => {
                    let fields = form.getFieldsValue();
                    let {taActs, location} = this.props;
                    //获取趋势图，待对接
                    taActs.getTrend({
                        company_id: loginUser.company_id,
                        ta_id: location.query.taId,
                        range: range,
                        type: fields.trend_type
                    })
                }
            }),
            //趋势折线类型
            trend_type: form.getFieldProps("trend_type", {
                initialValue: summary.trend_condition.type,
                onChange: (type) => {
                    let fields = form.getFieldsValue();
                    let {taActs, location} = this.props;
                    //获取趋势图，待对接
                    taActs.getTrend({
                        company_id: loginUser.company_id,
                        ta_id: location.query.taId,
                        type: type,
                        range: fields.trend_range
                    })
                }
            })
        }
    }
}

_Chart_Trend = Form.create()(_Chart_Trend);


export default connect(
    (state) => {
        return {
            $$taDetail: state.$$taDetail,
            $$taEdit: state.$$taEdit,
            $$layout: state.$$layout
        }
    },
    (dispatch) => {
        return {
            taActs: bindActionCreators(Actions, dispatch)
        }
    }
)(withRouter(TADetail))
