import React, {Component} from "react"
import {
    Row,
    Col,
    Icon,
    DatePicker
} from "antd"
import moment from "moment"
const {  RangePicker } = DatePicker;
const dateFormat = 'YYYY-MM-DD';
import ChartBox from "components/chart/ChartBox"
import StackArea from "components/chart/StackArea"
import StackLine from "components/chart/StackLine"

export default class ContentQuality extends Component {
    constructor(props){
        super(props);
        this.state={

        }
    }
    render() {
        return (
            <div>
                <Row>
                    <Col span={12} style={{paddingRight:"12px"}}>
                        <ChartBox title="文档总量变化趋势"><_StackArea/></ChartBox>
                    </Col>
                    <Col span={12} style={{paddingRight:"12px"}}>
                        <ChartBox title="文档类型变化趋势"><_StackLine/></ChartBox>
                    </Col>
                </Row>
                <Row style={{marginTop:"12px"}}>
                    <Col span={12} style={{paddingRight:"12px"}}>
                        <ChartBox title="文档总量变化趋势"><_StackLine/></ChartBox>
                    </Col>
                    <Col span={12} style={{paddingRight:"12px"}}>
                        <ChartBox title="文档类型变化趋势"><_StackLine/></ChartBox>
                    </Col>
                </Row>
                <Row style={{marginTop:"12px"}}>
                    <Col span={12} style={{paddingRight:"12px"}}>
                        <ChartBox title="文档总量变化趋势"><_StackLine/></ChartBox>
                    </Col>
                    <Col span={12} style={{paddingRight:"12px"}}>
                        <ChartBox title="文档类型变化趋势"><_StackLine/></ChartBox>
                    </Col>
                </Row>
            </div>
        );
    }
}
class _StackArea extends Component{
    render(){
        return(
            <div>
                <div style={{paddingLeft:"43px",paddingTop:"20px"}}>
                    <span style={{fontSize:"14px"}}>时间段：</span>
                    <RangePicker
                    defaultValue={[moment('2015/01/01', dateFormat), moment('2015/01/01', dateFormat)]}
                    format={dateFormat}/>
                </div>
                <StackArea height={432} padding={20}/>
            </div>
        );
    }
}
class _StackLine extends Component{
    render(){
        return(
            <div>
                <div style={{paddingLeft:"43px",paddingTop:"20px"}}>
                    <span style={{fontSize:"14px"}}>时间段：</span>
                    <RangePicker
                    defaultValue={[moment('2015/01/01', dateFormat), moment('2015/01/01', dateFormat)]}
                    format={dateFormat}/>
                </div>
                <StackLine height={432} padding={20}/>
            </div>
        );
    }
}
