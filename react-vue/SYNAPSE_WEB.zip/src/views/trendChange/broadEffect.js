import React, {Component} from "react"
// const data = require("mockdata/scatterMapData.json")
import {Row,Col,Table,Card} from 'antd'
import TrendChart from 'src/components/chart/trendChart/index.js'
import LineChart from 'src/components/chart/lineChart/index'
import 'src/assets/style/views/trendChange/broadEffect.less'
export default class BroadEffect extends Component {
    render() {
        return (
            <div className='broad-effect'>
                <Row>
                    <Col className='row'>
                        <TrendChart ifTime color={['#883549','#D75953', '#E9814D', '#FDB153','#F1D551','#EADAA7']} title='不同时段、不同市场分级传播效果对比分析'/>
                    </Col>
                    <Col className='row'>
                        <TrendChart ifTime color={['#883549','#D75953', '#E9814D', '#FDB153','#F1D551','#EADAA7']} title='不同时段、不同城市分级传播效果对比分析'/>
                    </Col>
                    <Col className='row'>
                        <TrendChart ifTime color={['#883549','#D75953', '#E9814D', '#FDB153','#F1D551','#EADAA7']} title='不同时段、不同医院等级传播效果对比分析'/>
                    </Col>
                    <Col className='row'>
                        <TrendChart ifTime color={['#883549','#D75953', '#E9814D', '#FDB153','#F1D551','#EADAA7']} title='不同时段、不同医生职称传播效果对比分析'/>
                    </Col>
                </Row>
            </div>
        );
    }
}