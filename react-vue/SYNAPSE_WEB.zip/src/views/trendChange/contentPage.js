/**
 *
 * title: contentPage.js
 *
 * author: WangPei.
 *
 * date: 2018/3/18.
 *
 */
import React,{Component} from "react"
import {Tabs} from "antd"
import GlobalSearch from "components/globalSearch"
import "src/assets/style/views/statusData/contentPage.less"
import ContentQuality from "./contentQuality"
import BroadEffect from "./broadEffect"
import CognizeChange from "./cognizeChange"
import PeopleDistribute from "./peopleDistribute"
const TabPane = Tabs.TabPane;

export default class ContentPage extends Component{
    constructor(props){
        super(props);
        this.state={
            data:{
                dataItem: [
                    {
                        name: "传播效果",
                        value: "0"
                    }, {
                        name: "人群分布",
                        value: "1"
                    }, {
                        name: "行为习惯",
                        value: "2"
                    }, {
                        name: "内容质量",
                        value: "3"
                    }, {
                        name: "认知变化",
                        value: "4"
                    }
                ]
            },
            selectedTag:"0"
        }
    }
    render(){
        let content=null;
        switch (this.state.selectedTag){
            case "0":
                content=<BroadEffect/>;
                break;
            case "2":
                content=<BroadEffect/>;
                break;
            case "3":
                content=<ContentQuality/>;
                break;
            case "1":
                content=<PeopleDistribute/>;
            case "4":
                content=<CognizeChange/>;
                break;

        }
        return(
            <div className="data-ins-content" style={{backgroundColor: "rgba(243, 244, 247, 1)", padding: "12px"}}>
                <div style={{marginBottom:"12px"}}>
                    <GlobalSearch isHideBtn={this.state.selectedTag!=="4"?true:false} isHideItem1={this.state.selectedTag==="4"?true:false} dataSource={this.state.data} onChangeItem={::this.onChangeTag}/>
                </div>
                {content}
            </div>
        );
    }
    onChangeTag(tag){
        this.setState({selectedTag:tag});
    }
}