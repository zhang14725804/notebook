import React, {Component} from "react"
// const data = require("mockdata/scatterMapData.json")
import {Row,Col,Table,Card} from 'antd'
import TrendChart from 'src/components/chart/trendChart/index.js'
import LineChart from 'src/components/chart/lineChart/index'
import DataInsightCard from 'src/components/dataInsightCard/simpleCard/index.js'
import TableInsightCard from 'src/components/dataInsightCard/tableCard/index'
import 'src/assets/style/views/trendChange/cognizeChange.less'
export default class BroadEffect extends Component {
    render() {
        let data1=
        {
            type:'Offline',
            content:[{
            name:'拜访',
            num:'10923'
        },{
            name:'会议',
            num:'109'
        }]
        }
        let data2=
            {
                type:'Offline',
                content:[{
                    name:'拜访',
                    num:'10923'
                },{
                    name:'会议',
                    num:'109'
                },{
                    name:'会议',
                    num:'109'
                },]
            }
        return (
            <div className='cognize-change'>
                <Row>
                    <Col span={12} className='row'>
                        <TrendChart type1 title='全体受众 接收度 趋势变化'/>
                    </Col>
                    <Col span={12}className='row'>
                        <TrendChart type1 title='全体受众 接受度 趋势变化'/>
                    </Col>
                    <Col span={12} className='row'>
                        <TrendChart  color={['#883549','#D75953', '#E9814D', '#FDB153','#F1D551','#EADAA7']} title='市场分级 接收度 趋势变化'/>
                    </Col>
                    <Col span={12} className='row'>
                        <TrendChart  color={['#883549','#D75953', '#E9814D', '#FDB153','#F1D551','#EADAA7']} title='市场分级 接受度 趋势变化'/>
                    </Col>
                    <Col span={12} className='row'>
                        <TrendChart  color={['#883549','#D75953', '#E9814D', '#FDB153','#F1D551','#EADAA7']} title='城市分级 接收度 趋势变化'/>
                    </Col>
                    <Col span={12} className='row'>
                        <TrendChart  color={['#883549','#D75953', '#E9814D', '#FDB153','#F1D551','#EADAA7']} title='城市分级 接受度 趋势变化'/>
                    </Col>
                    <Col span={12} className='row'>
                        <TrendChart  color={['#883549','#D75953', '#E9814D', '#FDB153','#F1D551','#EADAA7']} title='医院分级 接收度 趋势变化'/>
                    </Col>
                    <Col span={12} className='row'>
                        <TrendChart  color={['#883549','#D75953', '#E9814D', '#FDB153','#F1D551','#EADAA7']} title='医院分级 接受度 趋势变化'/>
                    </Col>
                    <Col span={12} className='row'>
                        <TrendChart  color={['#883549','#D75953', '#E9814D', '#FDB153','#F1D551','#EADAA7']} title='医生分级 接收度 趋势变化'/>
                    </Col>
                    <Col span={12} className='row'>
                        <TrendChart  color={['#883549','#D75953', '#E9814D', '#FDB153','#F1D551','#EADAA7']} title='医生分级 接受度 趋势变化'/>
                    </Col>
                    <Col span={12} className='row'>
                        <TrendChart  color={['#883549','#D75953', '#E9814D', '#FDB153','#F1D551','#EADAA7']} title='产品相关性 接收度 趋势变化'/>
                    </Col>
                    <Col span={12} className='row'>
                        <TrendChart  color={['#883549','#D75953', '#E9814D', '#FDB153','#F1D551','#EADAA7']} title='产品相关性 接受度 趋势变化'/>
                    </Col>
                    <Col span={12} className='row'>
                        <TrendChart  color={['#883549','#D75953', '#E9814D', '#FDB153','#F1D551','#EADAA7']} title='学术深度 接收度 趋势变化'/>
                    </Col>
                    <Col span={12} className='row'>
                        <TrendChart  color={['#883549','#D75953', '#E9814D', '#FDB153','#F1D551','#EADAA7']} title='学术深度 接受度 趋势变化'/>
                    </Col>
                </Row>
                <Row>
                    <Col style={{paddingRight:'12px'}} span={12}>
                        <Row style={{paddingBottom:'12px'}}>
                            <Col span={9}><DataInsightCard datas={data1}/></Col>
                            <Col style={{paddingLeft:'12px'}} span={15}><DataInsightCard datas={data2}/></Col>
                        </Row>
                        <Row>
                            <Col><TableInsightCard/></Col>
                        </Row>
                    </Col>
                    <Col span={12}>
                        <LineChart title='变化人数'/>
                    </Col>

                </Row>
            </div>
        );
    }
}