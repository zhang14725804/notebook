import React from "react"
import ReactDOM from "react-dom"
import { tools } from "utils"
import Upload from "components/upload"
import Footer from "components/footer"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import message from "antd/lib/message"
const FormItem = Form.Item;

import "assets/lib/antd/style/antd.less";
import "assets/style/outside/active.less";
import "assets/style/views/index.less"

const url = {
	validatereglink: tools.javaApi("/account/validatereglink"),
	uploadpic: tools.javaApi("/uploadpic"),
	sendvalidatemsg: tools.javaApi("/account/sendvalidatemsg"),
	saveuser: tools.javaApi("/account/saveuser")
}

class Active extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			query: tools.getQuery(),
			isActive: false,//邮箱是否激活成功

			id: "",//email&id将从校验k的接口中获得
			email: "",
			phone: "",

			//-------
			phone_dur: 0,//发送验证码计时开始时间戳
			return_dur: 10,//提交注册成功后计时开始时间戳
			isRegister: false
		}
	}

	componentDidMount() {
		//校验邮件中的k是否合法
		tools.ajax({
			url: url.validatereglink,
			data: {
				k: this.state.query.k
			},
			info: "激活账号",
			success: (rep) => {
				this.setState({
					isActive: true,
					email: rep.data.email,
					id: rep.data.id
				})
			}
		})
	}
	render() {
		let formItemLayout = {
			labelCol: { span: 12 },
			wrapperCol: { span: 12 }
		}
		let fieldProps = this._getFieldProps();
		let { form } = this.props;
		//上传文件配置
		let uploadCfg = {
			url: url.uploadpic,
			previewUrl: form.getFieldsValue().company_licence,
			onSuccess: (data) => {
				message.success("上传营业执照成功");
				this.props.form.setFieldsValue({
					company_licence: data.imageurl
				})
			},
			onErrorMessage: (error) => {
				tools.showDialog.error(error);
			}
		}
		return (
			<section className="os-container">
				<div className="os-header">
					<div className="os-header-title"></div>
				</div>
				{
					this.state.isActive ?

						!this.state.isRegister ?
							<div className="os-content">
								<Form className="os-form">
									<FormItem>
										{fieldProps.nickname(<Input
											className="os-input"
											placeholder="您的名字"
										/>)}
									</FormItem>
									<FormItem>
										{fieldProps.passwd1(<Input
											className="os-input"
											placeholder="密码（字母、数字、8-20个字符）"
											type="password"
											autoComplete="off"
										/>)}
									</FormItem>
									<FormItem>
										{fieldProps.passwd2(<Input
											className="os-input"
											placeholder="重复密码确认"
											type="password"
											autoComplete="off"
											{...fieldProps.passwd2} />)}
									</FormItem>
									<FormItem>
										{fieldProps.phone(<Input
											className="os-input"
											placeholder="手机号码"
											{...fieldProps.phone}
											addonAfter={
												<div>
													{
														this.state.phone_dur <= 0 ?
															<a onClick={this.getVFCode.bind(this)}>获取验证码</a> :
															<span>重新发送（{this.state.phone_dur}s）</span>
													}
												</div>
											} />)}
									</FormItem>
									<FormItem>
										{fieldProps.code(
											<Input
											className="os-input"
											placeholder="验证码" />
										)}
									</FormItem>
									<FormItem hasFeedback>
										{fieldProps.companyName(<Input
											className="os-input"
											placeholder="企业名称"
											 />)}
									</FormItem>
									<FormItem label="上传营业执照" required>
										<Upload {...uploadCfg} />
									</FormItem>
									<br />
									<FormItem>
										<Button
											className="os-btn"
											type="primary"
											onClick={this.onClickSubmit.bind(this)}>提交</Button>
									</FormItem>
								</Form>
							</div>
							:
							<div className="os-content">
								<div className="os-content-extra">
									<div className="os-title"><a>您的注册信息已提交成功，将在两个工作日完成审核</a></div>
									<div className="os-text">
										<span>登录名：</span>
										<span>{this.state.email}</span>
									</div>
									<div className="os-text">
										<span>绑定手机：</span>
										<span>{this.state.phone}</span>
									</div>
									<div className="os-text">
										<span>审核状态：</span>
										<span style={{ color: "orange" }}>进行中</span>
									</div>
								</div>
								<div className="os-form">
									<hr />
								</div>
								<div className="os-content-extra">
									<div className="os-text">{this.state.return_dur}秒后自动返回系统首页</div>
									<div className="os-text"><a href="/">点击返回首页</a></div>
								</div>
							</div>
						:
						<div className="os-content">
							<div className="os-content-extra">
								<div className="os-text">
									<a href="/">点击返回首页</a>
								</div>
							</div>
						</div>
				}
				<Footer />
			</section >
		);
	}

	onClickSubmit() {
		let { validateFields } = this.props.form;
		validateFields((errors, values) => {
			if (!!errors) return;
			tools.ajax({
				type: "post",
				url: url.saveuser,
				data: {
					user_id: this.state.id,
					email: this.state.email,
					phone: values.phone,
					password: values.passwd1,
					phone_validatecode: values.code,
					company_name: values.companyName,
					nickname: values.nickname,
					company_licence: values.company_licence
					// company_licence: "http://emkt.sfaessentials.com/images/upload/20160905/14730680666460.png"
				},
				info: "注册账号",
				isSuccessShow: true,
				success: (resp) => {
					this.setState({
						isRegister: true,
						phone: values.phone
					});
					//计时10s
					this._counter(10, (dur, time) => {
						if (dur > 0) {
							this.setState({
								return_dur: dur
							})
						} else {
							this.setState({
								return_dur: 0
							});
							clearInterval(time);
							window.location = "/";
						}
					});
				}
			})
		})
	}


	//获取验证码 
	getVFCode() {
		const { getFieldValue, validateFields } = this.props.form;
		validateFields(["phone"], (error, values) => {
			if (!!error) return;
			tools.ajax({
				url: url.sendvalidatemsg,
				data: {
					phone: getFieldValue("phone"),
					user_id: this.state.id
				},
				result: tools.ajax.resultEnum.bool,
				info: "发送验证码",
				isSuccessShow: true,
				success: (rep) => {
					//计时60s
					this._counter(60, (dur, time) => {
						if (dur > 0) {
							this.setState({
								phone_dur: dur
							})
						} else {
							this.setState({
								phone_dur: 0
							});
							clearInterval(time);
						}
					});
				}
			})
		});
	}


	//倒计时
	_counter(duration, cb) {
		let start_time = new hDate().getTime();
		let time = setInterval(() => {
			let dur = duration - parseInt((new hDate().getTime() - start_time) / 1000);
			cb.call(this, dur, time);
		}, 1000)
	}

	_getFieldProps() {
		let { getFieldDecorator } = this.props.form;
		return {
			nickname: getFieldDecorator("nickname", {
				rules: [
					{ required: true, message: "请输入姓名" }
				]
			}),
			passwd1: getFieldDecorator("passwd1", {
				rules: [
					{ required: true, message: "请输入密码" },
					{
						validator: (rule, value, callback) => {
							let password = /^[a-zA-Z0-9]{8,20}$/;
							if (!value) {
								callback();
							} else {
								if (!password.test(value)) {
									callback([new Error('请输入8-20位的字母数字组合密码')]);
								} else {
									const { validateFields } = this.props.form;
									validateFields(["passwd2"], { force: true });
									callback();
								}
							}
						}
					}
				]
			}),
			passwd2: getFieldDecorator("passwd2", {
				rules: [
					{ required: true, message: "请再次输入密码" },
					{
						validator: (rule, value, callback) => {
							const { getFieldValue } = this.props.form
							if (!value) {
								callback()
							} else {
								getFieldValue("passwd1") === getFieldValue("passwd2") ? callback() : callback("两次输入的密码不一致")
							}
						}
					}
				]
			}),
			phone: getFieldDecorator("phone", {
				rules: [
					{ required: true, message: "请输入手机号码" }
				]
			}),
			code: getFieldDecorator("code", {
				rules: [
					{ required: true, message: "请输入验证码" }
				]
			}),
			companyName: getFieldDecorator("companyName", {
				rules: [
					{ required: true, message: "请输入企业名称" }
				]
			}),
			company_licence: getFieldDecorator("company_licence", {
				rules: [
					{ required: true, message: "请上传营业执照" }
				]
			}),
		}
	}
}



Active = Form.create()(Active)

ReactDOM.render(<Active />, document.getElementById("p_active"));
