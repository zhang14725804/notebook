import React from "react"
import ReactDOM from "react-dom"
import $ from "jquery";
import { tools } from "utils"
import Footer from "components/footer"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import Slider from "antd/lib/slider"
const FormItem = Form.Item;

import "assets/lib/antd/style/antd.less";
import "assets/style/outside/forget.less";
import "assets/style/views/index.less"

const url = {
	findpassword: tools.javaApi("/account/findpassword")
}

class Forget extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			unDragable: false,
			isSendEmail: false,
			email: ""
		}
	}

	componentDidMount() {
		$(".ant-slider").append("<div class = 'fg-slider-txt' id = 'fg-holder'>请按住滑块拖到右边进行验证</div>")
		$(".ant-slider-handle").append("<div class = 'fg-slider-txt' id = 'fg-dot'>&gt;&gt;</div>");
	}
	render() {
		let fieldProps = this._getFieldProps();
		return (
			<section className="os-container">
				<div className="os-header">
					<div className="os-header-title"></div>
				</div>
				{
					!this.state.isSendEmail ?
						<div className="os-content">
							<Form className="os-form">
								<FormItem>
									{fieldProps.email(<Input
										className="os-input"
										placeholder="请输入有效邮箱账号"
									/>)}
								</FormItem>
								<FormItem>
									{fieldProps.slider(<Slider
										tipFormatter={() => "请拖至最右侧"}
										disabled={this.state.unDragable} 
									/>)}
								</FormItem>
								<FormItem>
									<Button
										className="os-btn"
										type="primary"
										onClick={this.onClickSend.bind(this)}>确认</Button>
								</FormItem>
								<FormItem>
									<hr />
								</FormItem>
								<FormItem>
									<Button
										className="os-btn"
										type="ghost"
										onClick={() => { window.location.href = "/" } }>返回首页</Button>
								</FormItem>
							</Form>
						</div>
						:
						<div className="os-content">
							<div className="os-content-extra">
								<div className="os-title">一封邮件已经寄到了您的电子邮箱 <a>{this.state.email}</a></div>
								<div className="os-text">请点击邮件内的激活链接重置密码，激活链接在24小时内有效。<a onClick={this.onClickReSend.bind(this)}>重新发送邮件</a></div>
							</div>
							<div className="os-content">
								<FormItem horizontal className="os-form">
									<Button
										className="os-btn"
										type="primary"
										onClick={this.onClickCheckMail.bind(this)}>前往邮箱查看</Button>
								</FormItem>
							</div>
						</div>
				}
				<Footer />
			</section >
		);
	}

	//点击【发送邮件】
	onClickSend() {
		let { validateFields } = this.props.form;
		//找回密码
		validateFields((errors, values) => {
			if (!!errors) return;
			//注册
			this.setState({
				email: values.email
			})
			this._sendEmail(values.email);
		})
	}

	//点击【再次发送邮件】
	onClickReSend() {
		this._sendEmail(this.state.email);
	}
	//发送邮件
	_sendEmail(email) {
		tools.ajax({
			type: "post",
			url: url.findpassword,
			data: {
				email: email,
			},
			result: tools.ajax.resultEnum.bool,
			info: "发送邮件",
			isShowSuccess: true,
			success: resp => {
				this.setState({
					isSendEmail: true
				})
			}
		})
	}

	//去邮箱检查邮件
	onClickCheckMail() {
		let url = this.state.email;
		let re = /\@[a-zA-Z0-9]+\.[a-zA-Z0-9]{2,}$/
		window.open("http://" + 'mail.' + url.match(re)[0].replace("@", ""));
	}

	_getFieldProps() {
		let { getFieldDecorator } = this.props.form;
		return {
			email: getFieldDecorator("email", {
				rules: [
					{ required: true, message: "请输入邮箱" },
					{
						validator: (rule, value, callback) => {
							let email = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
							if (!value) {
								callback();
							} else {
								!email.test(value) ? callback([new Error('请检查邮箱是否正确')]) : callback();
							}
						}
					}
				]
			}),
			slider: getFieldDecorator("slider", {
				rules: [
					{
						validator: (rule, value, callback) => {
							if (value === 100) {
								this.setState({
									unDragable: true
								})
								$("#fg-holder").html("<div class = 'fg-slider-txt-left'  id = 'fg-holder'>完成验证</div>")
								callback()
							} else {
								$("#fg-holder").html("<div class = 'fg-slider-txt' id = 'fg-holder'>请按住滑块拖到右边进行验证</div>")
								callback("请完成滑动验证")
							}
						}
					}
				]
			})
		}
	}
}

Forget = Form.create()(Forget)


ReactDOM.render(<Forget />, document.getElementById("p_forget"));
