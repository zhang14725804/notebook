import React from "react"
import ReactDOM from "react-dom"
import $ from "jquery"
import {tools} from "utils"
import {Enum, EnumCn} from "enum"
import Upload from "components/upload"
import Table from "antd/lib/table"
import Icon from "antd/lib/icon"
import Modal from "antd/lib/modal"
import Button from "antd/lib/button"

import "assets/lib/antd/style/antd.less";
import "assets/style/main.less";
import "assets/style/outside/review.less"
import "assets/style/views/index.less"

const url = {
	reviewlist: tools.javaApi("/account/reviewlist"),
	reviewAccount: tools.javaApi("/account/review")
}


class Review extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			condition: {
				page: 1,
				count: tools.listPageSize,
				//order: "status",
				order_type: Enum.OrderType.desc
			},
			reviewList: {
				count: 0,
				data: []
			},
			isShowPreview: false,
			previewUrl: ""
		}
	}

	componentDidMount() {
		const {condition} = this.state;
		this.getReviewList(condition);
	}
    render() {
		const {reviewList, condition, isShowPreview, previewUrl} = this.state;
		const cfg = {
			dataSource: reviewList.data,
			columns: [
				{
					title: "企业名称",
					dataIndex: "company_name",
					width: "30%",

					key: "company_name"
				}, {
					title: "公司执照",
					dataIndex: "company_licence",
					width: "30%",
					key: "company_licence",
					render: (c) => {
						return <a onClick={this.onClickPreview.bind(this, c) }><img src = {c} style={{ width: "50px" }}/></a>
					},
				},
				{
					title: "状态",
					dataIndex: "status",
					width: "20%",
					sorter: true,
					key: "status",
					render: (text, r) => {
						let iconMap = {
							state_1: { type: "check-circle", className: "m-text-success" },
							state_0: { type: "minus-circle", className: "m-text-error" },
							"state_-1": { type: "cross-circle", className: "m-text-error" },
							"state_-2": { type: "minus-circle", className: "m-text-warning" },
							"state_-3": { type: "check-circle", className: "m-text-warning" },
						}
						return (
							<div>
								<Icon
									type={iconMap["state_" + text].type}
									className={"m-margin-r " + iconMap["state_" + text].className}/>
								<span>{EnumCn.AccountState[text]}</span>
							</div>
						);
					}
				},
                {
                    title: "操作",
                    width: "20%",
                    dataIndex: "status",
                    key: "id",
                    render: (c, r) => {

                        return (

                            <div>
								{
									c == Enum.AccountState.toActive ?
										<div>等待用户自行激活</div>
										:
										<div>
											{
												c == Enum.AccountState.enable ?
													<a onClick = {this.changeAdminState.bind(this, r, Enum.AccountState.disable) }>禁用</a>
													:
													<a onClick = {this.changeAdminState.bind(this, r, Enum.AccountState.enable) }>启用</a>
											}
										</div>
								}
                            </div>
                        );

                    }
                }],
			bordered: true,
			pagination: $.extend(true, {},
				tools.config.pagination,
				{
					total: reviewList.total,
					current: condition.page,
					pageSize: condition.count
				}
			),
			onChange: (page, filter, sort) => {
				// 设置查找条件
				const cdt = {
					page: page.current,
					count: page.pageSize,
					order: sort.field,
					order_type: typeof sort.order === "string" ? sort.order.replace("end", "") : undefined
				}
				//使用搜索接口获取信息
				this.getReviewList(cdt);
			},
			rowKey: record => record.id
		}
        return (
            <section>
				<h2>待审核企业账户列表</h2>
				<Table {...cfg}/>
				<Modal
					visible={isShowPreview}
					title="公司执照"
					onCancel={this.onCancel.bind(this) }
					footer={
						<Button type="primary" onClick={this.onCancel.bind(this) }>确定</Button>
					}>
					<img src={previewUrl} id="imgWidthMax"/>
				</Modal>
			</section>
        );
	}
	//预览
	onClickPreview(img) {
		this.setState({
			previewUrl: img,
			isShowPreview: true
		})
	}
	//取消预览
	onCancel() {
		this.setState({
			previewUrl: "",
			isShowPreview: false
		})
	}
	//获取审核列表
	getReviewList(cdt) {
		const condition = {};
		Object.getOwnPropertyNames(this.state.condition).map(name => {
			condition[name] = cdt[name] === undefined ? this.state.condition[name] : cdt[name];
		})
		this.setState({
			condition: condition
		})
		tools.ajax({
			url: url.reviewlist,
			data: condition,
			info: "获取审核列表",
			success: (resp) => {
				this.setState({
					reviewList: resp.data
				})
			}
		})
	}
	//禁用厂商
	changeAdminState(company, status) {
		tools.ajax({
			url: url.reviewAccount,
			result: tools.ajax.resultEnum.bool,
			type: "POST",
			data: {
				company_id: company.id,
				user_id: company.create_user,
				status: status
			},
			info: "变更账户状态",
			isShowSuccess: true,
			success: (resp) => {
				const cdt = $.extend(true, {}, this.state.condition)
				this.getReviewList(cdt);
				this.setState({
					condition: cdt
				})
			}
		})
	}
}




ReactDOM.render(<Review/>, document.getElementById("p_review"));
