import React from "react"
import ReactDOM from "react-dom"

import $ from "jquery";
import { tools } from "utils"
import Footer from "components/footer"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
import Checkbox from "antd/lib/checkbox"
import Slider from "antd/lib/slider"
const FormItem = Form.Item;


import "assets/lib/antd/style/antd.less";
import "assets/style/outside/register.less";
import "assets/style/views/index.less"

const url = {
	sendregmail: tools.javaApi("/account/sendregmail")
}
class Register extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			slider_disable: false,
			isSendEmail: false,
			email: ""
		}
	}

	componentDidMount() {
		$(".ant-slider").append("<div class = 'rs-slider-txt' id = 'rs-holder'>请按住滑块拖到右边进行验证</div>")
		$(".ant-slider-handle").append("<div class = 'rs-slider-txt' id = 'rs-dot'>&gt;&gt;</div>")
	}
	render() {
		let formItemLayout = {
			labelCol: { span: 0 },
			wrapperCol: { span: 24 }
		}
		let fieldProps = this._getFieldProps();
		return (
			<section className="os-container">
				<div className="os-header">
					<div className="os-header-title"></div>
				</div>
				<div className={this.state.isSendEmail ? "os-content hide" : "os-content show"}>
					<Form className="os-form">
						<FormItem
							{...formItemLayout}
							hasFeedback>
							{fieldProps.email(<Input
								className="os-input"
								placeholder="请输入有效邮箱账号"
							/>)}
						</FormItem>
						<FormItem
							{...formItemLayout}>
							{fieldProps.slider(<Slider
								tipFormatter={() => "请拖至最右侧"}
								disabled={this.state.slider_disable} />)}							
						</FormItem>
						<FormItem>
							{fieldProps.obeyRules(<Checkbox
								>创建网站账户的同时，我同意遵守</Checkbox>)}
							<div><a>《IDB线上营销平台服务协议》</a></div>
						</FormItem>
						<FormItem
							{...formItemLayout}>
							<Button
								className="os-btn"
								type="primary"
								onClick={this.onClickLogin.bind(this)}>确认</Button>
						</FormItem>
						<FormItem
							{...formItemLayout}>
							<hr />
						</FormItem>
						<FormItem
							{...formItemLayout}>
							<Button
								className="os-btn"
								type="ghost"
								onClick={() => { window.location.href = "/account/login" }}>已有账户？登录</Button>
						</FormItem>
						<FormItem
							{...formItemLayout}>
							<Button
								className="os-btn"
								type="ghost"
								onClick={() => { window.location.href = "/account/forget" }}>忘记密码？重置</Button>
						</FormItem>
						<FormItem
							{...formItemLayout}>
							<Button
								className="os-btn"
								type="ghost"
								onClick={() => { window.location.href = "/" }}>返回首页</Button>
						</FormItem>
					</Form>
				</div>
				<div className={this.state.isSendEmail ? "os-content show" : "os-content hide"}>
					<div className="os-content-extra">
						<div className="os-title">一封邮件已经寄到了您的电子邮箱 <a>{this.state.email}</a></div>
						<div className="os-text">请点击邮件内的激活链接完成注册，激活链接在24小时内有效。<a onClick={this.onClickReSend.bind(this)}>重新发送邮件</a></div>
					</div>
					<Form horizontal className="os-form">
						<FormItem>
							<Button
								className="os-btn"
								type="primary"
								onClick={this.onClickCheckMail.bind(this)}>前往邮箱查收</Button>
						</FormItem>
						<hr />
						<FormItem
							{...formItemLayout}>
							<Button
								className="os-btn"
								type="ghost"
								onClick={this.onReset.bind(this)}>更新邮箱</Button>
						</FormItem>
						<FormItem
							{...formItemLayout}>
							<Button
								className="os-btn"
								type="ghost"
								onClick={() => { window.location.href = "/" }}>返回首页</Button>
						</FormItem>
					</Form>
				</div>
				<Footer />
			</section>
		);
	}
	//点击【更新邮箱】
	onReset() {
		this.props.form.resetFields();
		this.props.form.setFieldsValue({
			slider: 0,
			obeyRules: false
		})
		$("#rs-holder").html("<div class = 'rs-slider-txt' id = 'rs-holder'>请按住滑块拖到右边进行验证</div>")
		$(".ant-slider-handle").html("<div class = 'rs-slider-txt' id = 'rs-dot'>&gt;&gt;</div>")
		this.setState({
			isSendEmail: false,
			slider_disable: false
		});
	}
	//点击【登录】
	onClickLogin() {
		let { validateFields } = this.props.form;
		validateFields((errors, values) => {
			if (!!errors) return;
			//注册
			this.setState({
				email: values.email
			})
			this._sendEmail(values.email);
		})
	}
	//点击【重发邮件】
	onClickReSend() {
		let email = this.state.email;
		this._sendEmail(email);
	}

	//点击【前往邮箱查收】
	onClickCheckMail() {
		let url = this.state.email;
		let re = /\@[a-zA-Z0-9]+\.[a-zA-Z0-9]{2,}$/;
		window.open("http://" + 'mail.' + url.match(re)[0].replace("@", ""));
	}

	_sendEmail(email) {
		tools.ajax({
			type: "post",
			url: url.sendregmail,
			result: tools.ajax.resultEnum.bool,
			data: {
				email: email
			},
			info: "发送注册邮件",
			isShowSuccess: true,
			success: (rep) => {
				this.setState({
					isSendEmail: true
				});
			}
		})
	}

	_getFieldProps() {
		let { getFieldDecorator } = this.props.form;
		return {
			email: getFieldDecorator("email", {
				rules: [
					{ required: true, message: "请输入邮箱" },
					{
						validator: (rule, value, callback) => {
							let email = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
							if (!value) {
								callback();
							} else {
								!email.test(value) ? callback([new Error('请检查邮箱是否正确')]) : callback();
							}
						}
					}
				]
			}),
			obeyRules: getFieldDecorator("obeyRules", {
				valuePropName: 'checked',
				rules: [
					{
						validator: (rule, value, callback) => {
							if (value == true) {
								callback();
							} else {
								callback("请同意以上条款");
							}
						}
					}
				]
			}),
			slider: getFieldDecorator("slider", {
				rules: [
					{
						validator: (rule, value, callback) => {
							if (value === 100) {
								this.setState({
									slider_disable: true
								})
								$("#rs-holder").html("<div class = 'rs-slider-txt-left'  id = 'rs-holder'>完成验证</div>")
								callback()
							} else {
								this.setState({
									slider_disable: false
								})
								$("#rs-holder").html("<div class = 'rs-slider-txt' id = 'rs-holder'>请按住滑块拖到右边进行验证</div>")
								$(".ant-slider-handle").html("<div class = 'rs-slider-txt' id = 'rs-dot'>&gt;&gt;</div>")
								callback("请完成滑动验证")
							}
						}
					}
				],
			})
		}
	}

}

Register = Form.create()(Register)


ReactDOM.render(<Register />, document.getElementById("p_register"));
