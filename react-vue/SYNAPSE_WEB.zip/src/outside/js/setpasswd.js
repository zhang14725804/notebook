import React from "react"
import ReactDOM from "react-dom"
import { tools } from "utils"
import Footer from "components/footer"
import Row from "antd/lib/row"
import Col from "antd/lib/col"
import Form from "antd/lib/form"
import Input from "antd/lib/input"
import Button from "antd/lib/button"
const FormItem = Form.Item;
import "assets/lib/antd/style/antd.less";
import "assets/style/outside/setpasswd.less";
import "assets/style/views/index.less"

const url = {
	validatereglink: tools.javaApi("/account/validatereglink"),
	resetpassword: tools.javaApi("/account/resetpassword"),
	ajaxlogin: tools.javaApi("/account/ajaxlogin")
}

//设置密码状态
const PasswordState = {
	//初始化
	init: 0,
	//重置
	reset: 1
}

class SetPasswd extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			//是否激活了账号
			isActive: false,
			//是否提交了注册信息
			isSubmit: false,
			query: tools.getQuery(),
			//验证邮箱的标识
			email: "",
			user_id: "",
			passwd: "",
			//注册成功倒计时
			return_dur: 10
		}
	}
	componentDidMount() {
		//校验邮件中的k是否合法
		tools.ajax({
			url: url.validatereglink,
			data: {
				k: this.state.query.k
			},
			success: (resp) => {
				this.setState({
					isActive: true,
					user_id: resp.data.id,
					email: resp.data.email
				})
			}
		})
	}

	render() {
		let formItemLayout = {
			labelCol: { span: 9 },
			wrapperCol: { span: 15 }
		}
		let fieldProps = this._getFieldProps();
		return (
			<section className="os-container">
				<div className="os-header">
					<div className="os-header-title"></div>
				</div>
				{
					this.state.isActive ?
						!this.state.isSubmit ?
							<div className="os-content">
								<Form className="os-form">
									<FormItem label="请设置您的账户密码" required style={{ "textAlign": "left" }}></FormItem>
									<FormItem>
										{fieldProps.passwd1(<Input
											className="os-input"
											placeholder="密码（字母、数字、8-20个字符）"
											type="password"
											autoComplete="off"/>
										)}	
									</FormItem>
									<FormItem>
										{fieldProps.passwd2(<Input
											className="os-input"
											placeholder="重复密码确认"
											type="password"
											autoComplete="off"/>
										)}						
									</FormItem>
									<FormItem>
										<Button
											className="os-btn"
											type="primary"
											onClick={this.onClickSetPasswd.bind(this)}>提交</Button>
									</FormItem>
									<hr />
									<FormItem>
										<Button
											className="os-btn"
											type="ghost"
											onClick={() => { window.location.href = "/" } }>返回首页</Button>
									</FormItem>
								</Form>
							</div>
							:
							<div className="os-content">
								<div className="os-content-extra">
									<div className="os-title"><a>密码设置成功</a></div>
									<div className="os-text">
										<span>账户：</span>
										<span>{this.state.email}</span>
									</div>
									<div className="os-text">
										<span>密码：</span>
										<span>{this.state.password}</span>
									</div>
								</div>
								<div className="os-form">
									<hr />
								</div>
								<div className="os-content-extra">
									<div className="os-text">{this.state.return_dur}后自动进入控制台页面</div>
									<div className="os-text"><a onClick={this.onClickLogin.bind(this)}>点击进入控制台页面</a></div>
								</div>
							</div>
						:
						<div className="os-content">
							<div className="os-content-extra">
								<div className="os-text">
									<a href="/">点击返回首页</a>
								</div>
							</div>
						</div>
				}
				<Footer />
			</section >
		);
	}

	//点击设置密码
	onClickSetPasswd() {
		let { validateFields } = this.props.form;
		validateFields((errors, values) => {
			if (!!errors) return;
			tools.ajax({
				// url: this.state.query.isreset == PasswordState.init ? url.setpassword : url.resetpassword,
				url: url.resetpassword,
				data: {
					user_id: this.state.user_id,
					password: values.passwd1,
					email: this.state.email,
					sign: this.state.query.k
				},
				type: "post",
				info: "设置密码",
				isShowSuccess: true,
				success: (resp) => {
					this.setState({
						isSubmit: true,
						password: values.passwd1
					});
					this._counter(10, (dur, time) => {
						if (dur > 0) {
							this.setState({
								return_dur: dur
							})
						} else {
							this.setState({
								return_dur: 0
							});
							clearInterval(time);
							//登录系统
							this._login();
						}
					});
				}
			})
		})
	}

	//点击登录按钮
	onClickLogin() {
		this._login();
	}
	//登录
	_login() {
		tools.ajax({
			// xhrFields: {
			// 	withCredentials: true
			// },
			// crossDomain: true,
			type: "post",
			url: url.ajaxlogin,
			data: {
				useremail: this.state.email,
				password: this.state.password
			},
			result: tools.ajax.resultEnum.bool,
			success: rep => {
				window.location = "/app/#/overview";
			}
		})
	}
	//倒计时
	_counter(duration, cb) {
		let start_time = new hDate().getTime();
		let time = setInterval(() => {
			let dur = duration - parseInt((new hDate().getTime() - start_time) / 1000);
			cb.call(this, dur, time);
		}, 1000)
	}

	_getFieldProps() {
		let { getFieldDecorator } = this.props.form;
		return {
			passwd1: getFieldDecorator("passwd1", {
				rules: [
					{ required: true, message: "请输入密码" },
					{
						validator: (rule, value, callback) => {
							let password = /^[a-zA-Z0-9]{8,20}$/;
							if (!value) {
								callback();
							} else {
								if (!password.test(value)) {
									callback([new Error('请输入8-20位的字母数字组合密码')]);
								} else {
									const { validateFields } = this.props.form;
									validateFields(["passwd2"], { force: true });
									callback();
								}
							}
						}
					}
				]
			}),
			passwd2: getFieldDecorator("passwd2", {
				rules: [
					{ required: true, message: "请再次输入密码" },
					{
						validator: (rule, value, callback) => {
							const { getFieldValue } = this.props.form
							if (!value) {
								callback()
							} else {
								getFieldValue("passwd1") === getFieldValue("passwd2") ? callback() : callback("两次输入的密码不一致")
							}
						}
					}
				]
			})
		}
	}
}

SetPasswd = Form.create()(SetPasswd)

ReactDOM.render(<SetPasswd />, document.getElementById("p_setpasswd"));
