import React from "react";
import ReactDOM from "react-dom";
import { tools } from "utils";
import Footer from "components/footer"
import Form from "antd/lib/form";
import Input from "antd/lib/input";
import Button from "antd/lib/button";
const FormItem = Form.Item;
import "assets/lib/antd/style/antd.less";
import "assets/style/outside/login.less";
import "assets/style/views/index.less"

const url = {
	ajaxlogin: tools.javaApi("/aj/account/ajaxlogin")
}

class Login extends React.Component {
	constructor(props) {
		super(props);

	}
	componentDidMount() {
		//输入框获取焦点
		// ReactDOM.findDOMNode(this).querySelector(".input_email").focus();
		// ReactDOM.findDOMNode(this).querySelector(".input_password").focus();
	}
	render() {
		let fieldProps = this._getFieldProps();
		return (
			<section className="os-container">
				<div className="os-header">
					<div className="os-header-title"></div>
				</div>
				<div className="os-content">
					<Form className="os-form">
						<FormItem hasFeedback>
							{fieldProps.email(<Input
								className="os-input input_email"
								placeholder="请输入邮箱"
								onKeyDown={this.onPressLogin.bind(this)}
							/>)}
						</FormItem>
						<FormItem hasFeedback>
							{fieldProps.passwd(<Input
								className="os-input  input_password"
								placeholder="密码"
								type="password"
								autoComplete="off"
								onKeyDown={this.onPressLogin.bind(this)}
							/>)}							
						</FormItem>

						<FormItem>
							<Button
								className="os-btn"
								type="primary"
								onClick={this.onClickLogin.bind(this)}>登录</Button>
						</FormItem>
						<FormItem>
							<hr />
						</FormItem>
						<FormItem>
							<Button
								className="os-btn"
								type="ghost"
								onClick={() => { window.location.href = "/account/register" } }>还没有账号？免费注册</Button>
						</FormItem>
						<FormItem>
							<Button
								className="os-btn"
								type="ghost"
								onClick={() => { window.location.href = "/account/forget" } }>忘记密码？重置</Button>
						</FormItem>
					</Form>
				</div>
				<Footer />
			</section>
		);
	}

	//点击登录按钮
	onClickLogin() {
		this._login();
	}

	onPressLogin(e) {
		if (e.keyCode === 13) {
			this._login();
		}
	}

	_login() {
		let { validateFields } = this.props.form;
		validateFields((errors, values) => {
			if (!!errors) return;
			tools.ajax({
				// xhrFields: {
				// 	withCredentials: true
				// },
				// crossDomain: true,
				type: "post",
				url: url.ajaxlogin,
				result: tools.ajax.resultEnum.bool,
				data: {
					useremail: values.email,
					password: values.passwd
				},
				success: rep => {
					window.location = "/app/#/broadcast";
				}
			})
		})
	}


	_getFieldProps() {
		let { getFieldDecorator } = this.props.form;
		return {
			email: getFieldDecorator("email", {
				rules: [
					{ required: true, message: "请输入邮箱" },
					{
						validator: (rule, value, callback) => {
							let email = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
							if (!value) {
								callback();
							} else {
								!email.test(value) ? callback([new Error('请检查邮箱是否正确')]) : callback();
							}
						}
					}
				]
			}),
			passwd: getFieldDecorator("passwd", {
				rules: [
					{ required: true, message: "请输入密码" },
					{
						validator: (rule, value, callback) => {
							let password = /^[a-zA-Z0-9]{8,20}$/;
							if (!value) {
								callback();
							} else {
								!password.test(value) ? callback([new Error('请输入8-20位的字母数字组合密码')]) : callback();
							}
						}
					}
				]
			})
		}
	}
}



Login = Form.create()(Login)


ReactDOM.render(<Login />, document.getElementById("p_login"));
