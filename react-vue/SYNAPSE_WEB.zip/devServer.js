var path = require("path");
var express = require("express");
var webpack = require("webpack");
var proxy = require("http-proxy-middleware");
var config = require("./build/webpack.config.dev");
var help = require("./build/constants.js");

var app = express();
var compiler = webpack(config);


var multiPath = "./src/outside/";

app.use(require("webpack-dev-middleware")(compiler, {
  noInfo: true,
  publicPath: config.output.publicPath,
  inline: true,
  hot: true
}));

app.use(require("webpack-hot-middleware")(compiler));

app.use('/v2', proxy({ target: 'http://10.90.0.10:8084' }));

app.get("/", function (req, res) {
  res.sendFile(path.join(__dirname, "./index.html"));
});

app.get("/account/login", function (req, res) {
  res.sendFile(path.join(__dirname, multiPath, "./login.html"));
});

app.get("/account/register", function (req, res) {
  res.sendFile(path.join(__dirname, multiPath, "./register.html"));
});

app.get("/account/forget", function (req, res) {
  res.sendFile(path.join(__dirname, multiPath, "./forget.html"));
});

app.get("/account/active", function (req, res) {
  res.sendFile(path.join(__dirname, multiPath, "./active.html"));
});

app.get("/account/setpasswd", function (req, res) {
  res.sendFile(path.join(__dirname, multiPath, "./setpasswd.html"));
});
app.get("/account/review", function (req, res) {
  res.sendFile(path.join(__dirname, multiPath, "./review.html"));
});

app.get("/app", function (req, res) {
  res.sendFile(path.join(__dirname, multiPath, "./app.html"));
});

// app.listen(help.devUrl.port, help.devUrl.host, function (err) {
//   if (err) {
//     console.log(err);
//     return;
//   }

//   console.log("Listening at " + help.devUrl.host + ":" + help.devUrl.port);
// });
app.listen(5000);

