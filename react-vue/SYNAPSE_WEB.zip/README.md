# React_Antd_Demo
React Ant_Design SPA Webpack

## 技术栈
- React
- Redux
- Webpack
- Less
- Ant_Design
- Gulp
- Nodejs


## 介绍
通过Webpack进行项目构建及资源文件的模块化加载，使用基于React的Ant_Design组合页面，Redux进行数据流管理，React-Router(HashHistory)实现SPA，NPM进行插件安装

## 安装
```
npm install
```
## 开发环境
```
npm run start
```
Local:http://localhost:5000     

## 生产环境
```
npm run build
```